"""SOURCE/DATA-only preparation. No project import, test, SDK or runtime call."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
BASE = ROOT / 'experiments/prototypes/e02_ordinary_client_v1'
SOURCE = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v1'
EVIDENCE = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r1'
OLD_EVIDENCE = ROOT / 'docs/decisions/evidence/e02-ordinary-client-resume-r1'
DATA = ROOT / 'docs/decisions/evidence/e02-api35-fixture-preparation-r2'
SDK_ROOT = '/tmp/nbdp-e02-api35-fixture-r2/sdk'
RUN_ROOT = '/tmp/nbdp-e02-ordinary-client-api35-v1'
RUNTIME_SCHEMA = 'e02-api35-first-cell-runtime-plan-v1'
RELEASE_SCHEMA = 'e02-api35-first-cell-release-v1'
RESULT_SCHEMA = 'e02-api35-first-cell-supervisor-result-v1'
AUTHOR = '/root/ordinary_api35_source'


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)


def save(name, data):
    write(EVIDENCE / name, (json.dumps(data, indent=2) + '\n').encode())


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def ast_changes(left, right, location='$'):
    """Full typed AST comparison, including every field; ignore source locations only."""
    changes = []
    if type(left) is not type(right):
        return [{'field': location, 'before': repr(left), 'after': repr(right), 'kind': 'TYPE'}]
    if isinstance(left, ast.AST):
        assert left._fields == right._fields
        for field in left._fields:
            changes.extend(ast_changes(getattr(left, field), getattr(right, field), location + '.' + field))
    elif isinstance(left, list):
        for i in range(max(len(left), len(right))):
            if i >= len(left) or i >= len(right):
                value = right[i] if i >= len(left) else left[i]
                changes.append({'field': location + '[' + str(i) + ']',
                                'before': None if i >= len(left) else ast.dump(value),
                                'after': None if i >= len(right) else ast.dump(value), 'kind': 'LIST_DATA'})
            else:
                changes.extend(ast_changes(left[i], right[i], location + '[' + str(i) + ']'))
    elif left != right:
        changes.append({'field': location, 'before': left, 'after': right, 'kind': 'VALUE'})
    return changes


def main():
    assert not (EVIDENCE / 'subject.json').exists(), 'Exclusive one-shot source preparation'
    old_subject_path = OLD_EVIDENCE / 'complete-source-config-subject-r11.json'
    old_subject = json.loads(old_subject_path.read_text())
    assert len(old_subject['sources']) == 21
    baseline = []
    for entry in old_subject['sources']:
        assert pin(Path(entry['path'])) == entry, entry['path']
        baseline.append(entry)
    ordinary_sources = [Path(entry['path']) for entry in baseline if Path(entry['path']).is_relative_to(BASE)]
    assert len(ordinary_sources) == 18
    for path in ordinary_sources:
        write(SOURCE / path.relative_to(BASE), path.read_bytes())

    # All replacements below are complete declared DATA/profile operands.
    replacement_spec = [
        ("Path('/tmp/nbdp-e02-ordinary-client-v1')", "Path('" + RUN_ROOT + "')"),
        ("'android': (8192, 512, 4)", "'android': (8192, 512, 8)"),
        ('android-36', 'android-35'),
        ('swiftshader_indirect', 'lavapipe'),
        ("len(os.sched_getaffinity(0)) >= 4", "len(os.sched_getaffinity(0)) >= 8"),
        ('at least4 host affinity CPUs', 'at least8 host affinity CPUs'),
        ("OLD / 'records/runtime-sdk-tree.json'", "REPO / 'docs/decisions/evidence/e02-api35-fixture-preparation-r2/sdk-tree.json'"),
        ('e02-single-cell-runtime-plan-v1', RUNTIME_SCHEMA),
        ('/tmp/nbdp-e02-ingress-runtime/sdk', SDK_ROOT),
        ('e02-first-cell-release-v1', RELEASE_SCHEMA),
        ('e02-first-cell-supervisor-result-v1', RESULT_SCHEMA),
    ]
    supervisor = (BASE / 'supervisor.py').read_text()
    for before, after in replacement_spec:
        assert before in supervisor, before
        supervisor = supervisor.replace(before, after)
    (SOURCE / 'supervisor.py').write_text(supervisor)

    cleanup = (BASE / 'test_cleanup.py').read_text()
    cleanup_replacements = [
        ("('--cpus', '4')", "('--cpus', '8')"),
        ('test_android_trial_affinity_refuses_three_before_later_actions',
         'test_android_trial_affinity_refuses_seven_before_later_actions'),
        ('return_value={0, 1, 2}', 'return_value={0, 1, 2, 3, 4, 5, 6}'),
        ("'at least4'", "'at least8'"),
        ('test_android_trial_affinity_accepts_four_without_expanding_admission',
         'test_android_trial_affinity_accepts_eight_without_expanding_admission'),
        ('return_value={2, 4, 6, 8}', 'return_value={0, 1, 2, 3, 4, 5, 6, 7}'),
    ]
    for before, after in cleanup_replacements:
        cleanup = replace_once(cleanup, before, after)
    (SOURCE / 'test_cleanup.py').write_text(cleanup)

    template = json.loads((BASE / 'runtime-plan.json').read_text())
    template.update(schema=RUNTIME_SCHEMA, sdkRoot=SDK_ROOT,
                    state='SOURCE_ONLY_NOT_EXECUTED_NOT_REVIEWED_NOT_RELEASED',
                    actualGuardTests='CURRENT_PROFILE_NOT_EXECUTED',
                    supervisorSource='MATERIALIZED_REQUIRES_NEW_SOURCE_REVIEW',
                    driverSource='BYTE_IDENTICAL_TO_CURRENT_R11',
                    fixtureSource='BYTE_IDENTICAL_TO_CURRENT_R11',
                    sourceAndDependencyPins='EXTERNAL_PROPOSED_CONFIG_REQUIRES_REVIEW',
                    exactIndependentRuntimeReviews='PENDING_NEW_SOURCE_AND_ACTUAL_CONTROLS')
    template['limits'] = [
        'No activation authority: new independent SOURCE QA/security, actual current controls and their independent reviews, then exact fresh coordinator release are required.',
        'One first JS-to-Rust incoming rsrelay ordinary-client cell only; seven other producer matrix cells and canonical integration remain undone.',
        'API35 whole OS fixture + Lavapipe + containerCPU8 constitute a semantic readiness candidate, not a causal comparison.',
        'Original1800s lease, guest4CPU4096MiB, Android8192MiB memory/swap cap, PID512 and original2048M requested data partition remain unchanged.',
        'Existing bounded known Settings/SystemUI Wait-only recovery is retained; unknown/Quickstep refuse. No never-ANR prerequisite is added.',
        'Strict full unmasked public synthetic NSEC, actual reopened TorOff PNG, closed ADB, actual app subscription/EOSE and no fixture fallback remain required.',
        'API35 DATA-only acceptance does not establish guest boot or client compatibility. Existing failed attempts and canonical PARTIAL22 remain visible.',
    ]
    (SOURCE / 'runtime-plan.json').write_text(json.dumps(template, indent=2) + '\n')

    prefix = '''# API35 ordinary-client source profile: preparation only

This directory is a SOURCE-only derivative of the original current R11 ordinary
first-cell sources. The authoritative proposed configuration and complete source
subject are in `docs/decisions/evidence/e02-ordinary-api35-preparation-r1/`.
No tests or Android/runtime actions have been executed for this profile, and no
release or lease has been issued. Independent SOURCE QA/security, actual current
controls and independent review of those controls precede any exact root release.

Only declared profile data changes: private run namespace, profile-specific
runtime/release/result schemas, accepted isolated API35 SDK/inventory, Android35
AVD target, Lavapipe renderer, Android container CPU8 and host affinity>=8.
Guest4CPU/4096MiB, container memory/swap8192MiB, PID512, original1800s lease,
original requested2048M data partition, pinned images/APKs and all safety logic
remain unchanged. Emulator37.2.12/platform-tools37.0.1 are the same copied410
inventory rows. The acquired API35 OS fixture is a whole environment change;
this profile is a semantic readiness candidate, not a causal comparison.

The strict current R11 driver remains byte-identical: require actual password
state and whole unmasked public synthetic NSEC, actual reopened TorOff PNG,
bounded known Settings/SystemUI Wait-only<=2 recovery, and refuse unknown or
Quickstep dialogs. No added never-ANR prerequisite and no broadened handling.
Only the first JS-to-Rust incoming rsrelay cell is prepared; all other seven
producer matrix cells and canonical integration remain undone. One successful
cell cannot promote E02 to PASS or close architectural blockers.

The separate API35 no-install diagnostic's first actual run failed before
guest/ADB on preallocation of its separate6G userdata profile. This ordinary
profile preserves its original2048M request and original6GiB disk admission;
the diagnostic's proposed8GiB retry margin is not an ordinary prerequisite.
Boot and ordinary-client compatibility remain UNKNOWN. Preserve actual first
failure, do not substitute cached snapshots, and add no blanket healthy-OS gate.

The copied helper build files are historical source provenance only; this
profile reuses the exact already pinned helper APK and does not authorize a new
helper build. The original runtime instructions below are historical context;
their original paths/schema names do not activate this API35 profile.

---

'''
    for name in ('README.md', 'SUPERVISOR.md'):
        (SOURCE / name).write_text(prefix + (BASE / name).read_text())

    inventory = pin(DATA / 'sdk-tree.json')
    assert (inventory['bytes'], inventory['sha256']) == (
        89738, '5c996f67fd8aba0ea618adc7f7f9e6a2c27c641cc95910deb07bdfa8a10562a8')
    tree = json.loads((DATA / 'sdk-tree.json').read_text())
    assert tree['root'] == SDK_ROOT and len(tree['files']) == 434
    old_tree = json.loads(Path('/tmp/nbdp-e02-minimal-rs-v7/records/runtime-sdk-tree.json').read_text())
    base_rows = lambda value: [row for row in value['files'] if row['path'].startswith(('emulator/', 'platform-tools/'))]
    assert len(base_rows(tree)) == 410 and base_rows(tree) == base_rows(old_tree)
    acceptance = json.loads((DATA / 'acceptance.json').read_text())
    assert acceptance['decision'] == 'ACCEPT_ISOLATED_API35_FIXTURE_DATA_ONLY'
    assert pin(Path(acceptance['subject']['path'])) == acceptance['subject']
    for review in acceptance['actualIndependentReviews']:
        assert pin(Path(review['path'])) == review
    assert acceptance['inventory'] == inventory
    save('accepted-data-prerequisite-link.json', {
        'schema': 'e02-ordinary-api35-accepted-data-link-v1',
        'acceptance': pin(DATA / 'acceptance.json'), 'fixtureSubject': acceptance['subject'],
        'actualIndependentReviews': acceptance['actualIndependentReviews'],
        'sdkRoot': SDK_ROOT, 'inventory': inventory,
        'sourceProperties': pin(DATA / 'properties.json'),
        'base410RowsByteSizeModeHashEqual': True,
        'authority': 'Existing actual independent DATA-only acceptance; no author self approval or runtime authority.',
        'guestBootAndOrdinaryCompatibility': 'UNKNOWN_NOT_ESTABLISHED_BY_DATA_OR_SOURCE',
    })

    # Configuration construction is JSON/DATA only: do not import/call supervisor.
    config = json.loads((OLD_EVIDENCE / 'proposed-run-config-r11.json').read_text())
    config.update(schema=RUNTIME_SCHEMA, sdkRoot=SDK_ROOT, sdkInventory=inventory,
                  runId=uuid.uuid4().hex,
                  state='SOURCE_ONLY_REQUIRES_NEW_SOURCE_CONTROL_REVIEWS_AND_FRESH_RELEASE')
    config['sourceAndDependencyPins'] = [pin(SOURCE / Path(entry['path']).name)
                                         for entry in config['sourceAndDependencyPins']]
    assert config['originalLeaseSeconds'] == 1800
    assert config['amethystApk']['sha256'] == '5165a9f79326524c494108b8ab728fb173ac14fa16bf67ebbd86364c895e98b5'
    assert config['helperApk']['sha256'] == 'a680e513a9b36cab634620507b77bba36532ce13acb465a860c7bef60d23ec20'
    save('proposed-run-config.json', config)
    output = Path(RUN_ROOT) / 'runs' / config['runId']
    assert not output.exists()

    proof = []
    patches = []
    for original in ordinary_sources:
        relative = original.relative_to(BASE)
        current = SOURCE / relative
        before, after = original.read_bytes(), current.read_bytes()
        same = before == after
        row = {'relativePath': str(relative), 'baseline': pin(original), 'current': pin(current), 'byteIdentical': same}
        if original.suffix == '.py':
            left, right = ast.parse(before), ast.parse(after)
            differences = ast_changes(left, right)
            row['wholeModuleTypedAstDiff'] = differences
            row['astNodeTypesAndFieldsCompared'] = True
            if relative.name == 'supervisor.py':
                expected = (BASE / 'supervisor.py').read_text()
                for before_text, after_text in replacement_spec:
                    expected = expected.replace(before_text, after_text)
                assert ast.dump(ast.parse(expected), include_attributes=False) == ast.dump(right, include_attributes=False)
                assert all(change['kind'] == 'VALUE' for change in differences)
                assert all(change['field'].endswith(('.value', '.id')) for change in differences)
                row['declaredDataOperandChangesOnly'] = True
            elif relative.name == 'test_cleanup.py':
                expected = (BASE / 'test_cleanup.py').read_text()
                for before_text, after_text in cleanup_replacements:
                    expected = replace_once(expected, before_text, after_text)
                assert ast.dump(ast.parse(expected), include_attributes=False) == ast.dump(right, include_attributes=False)
                assert all(change['kind'] in ('VALUE', 'LIST_DATA') for change in differences)
                row['declaredTestNameCpuExpectedAndBoundarySetDataChangesOnly'] = True
                row['assertStatementsBeforeAfter'] = [sum(isinstance(node, ast.Assert) for node in ast.walk(value)) for value in (left, right)]
            else:
                assert not differences
        if not same:
            patches.extend(difflib.unified_diff(original.read_text().splitlines(True), current.read_text().splitlines(True),
                                               fromfile=str(original), tofile=str(current)))
        proof.append(row)
    write(EVIDENCE / 'source.diff', ''.join(patches).encode())
    counts = {path.name: sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_')
                              for node in ast.walk(ast.parse(path.read_bytes())))
              for path in sorted(SOURCE.glob('test_*.py'))}
    assert counts == {'test_android_driver.py': 38, 'test_cleanup.py': 24, 'test_lease_guard.py': 29}
    assert (SOURCE / 'lease_guard.py').read_bytes() == (BASE / 'lease_guard.py').read_bytes()
    assert (SOURCE / 'android_driver.py').read_bytes() == (BASE / 'android_driver.py').read_bytes()
    assert (SOURCE / 'fixture.mjs').read_bytes() == (BASE / 'fixture.mjs').read_bytes()
    assert 'disk.dataPartition.size=2048M' in supervisor
    assert '>= 6 * 1024**3' in supervisor
    after_originals = [pin(Path(entry['path'])) for entry in baseline]
    assert after_originals == baseline
    sources = [pin(SOURCE / path.relative_to(BASE)) for path in ordinary_sources]
    sources.extend(entry for entry in baseline if not Path(entry['path']).is_relative_to(BASE))
    assert len(sources) == 21
    save('baseline-provenance.json', {
        'schema': 'e02-ordinary-api35-baseline-provenance-v1', 'originalR11Subject': pin(old_subject_path),
        'originalR11Configuration': pin(OLD_EVIDENCE / 'proposed-run-config-r11.json'),
        'original21PinsBefore': baseline, 'original21PinsAfter': after_originals,
        'allOriginal21Unchanged': True, 'copiedOwnSources': 18, 'externalUnchangedConsumerSources': 3,
        'amethystCommit': 'e6f464a1179def75274512b3c5bab921de3bf3d8',
        'history': 'Original38UI/29guard/24cleanup/27fixture/14consumer results have separate historical scopes and are not new-profile execution evidence.',
    })
    save('static-checks.json', {
        'schema': 'e02-ordinary-api35-source-static-v1', 'author': AUTHOR,
        'method': 'stdlib DATA hashes, full unified source diff, whole-module typed AST field comparison; no project imports, tests, SDK or runtime',
        'declaredSupervisorReplacements': replacement_spec, 'declaredCleanupControlReplacements': cleanup_replacements,
        'sourceProofs': proof, 'testDefinitionsOnly': counts,
        'requiredSeparateFixtureAndConsumerControls': {'fixture': 27, 'consumer': 14},
        'original21Unchanged': True, 'copiedSame410SdkBaseInventoryRows': True,
        'sourcePatch': pin(EVIDENCE / 'source.diff'), 'configuration': pin(EVIDENCE / 'proposed-run-config.json'),
        'partitionFinding': 'Ordinary R11 requests2048M and keeps6GiB admission unchanged. The failed separate API35 diagnostic used6G; its proposed8GiB retry margin is not an ordinary prerequisite.',
        'newRuntimeBranchesOrCalls': False, 'driverGuardFixtureLogicChanged': False,
        'actualExecution': {'controls': 0, 'android': 0, 'services': 0},
    })
    save('subject.json', {
        'schema': 'e02-ordinary-api35-source-config-subject-v1', 'author': AUTHOR, 'coordinator': '/root',
        'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_SOURCE_QA_SECURITY',
        'scope': config['scope'], 'sources': sources, 'configuration': pin(EVIDENCE / 'proposed-run-config.json'),
        'baselineProvenance': pin(EVIDENCE / 'baseline-provenance.json'),
        'staticChecks': pin(EVIDENCE / 'static-checks.json'), 'sourceDiff': pin(EVIDENCE / 'source.diff'),
        'acceptedDataPrerequisite': pin(EVIDENCE / 'accepted-data-prerequisite-link.json'),
        'preparationSource': pin(Path(__file__).resolve()), 'plannedOutput': str(output),
        'executionReleased': False, 'actualExecution': {'controls': 0, 'android': 0, 'services': 0},
        'mandatoryPending': ['Exact new independent SOURCE QA and security',
                             'Actual current38UI/29guard/24cleanup/27fixture/14consumer controls with correct separate scopes and independent result review',
                             'Fresh host resources and exact output disk admission, image/APK/SDK/dependency/source provenance',
                             'Fresh exact coordinator first-cell-only release before runtime'],
        'claims': ['First-cell SDK35 semantic readiness candidate only; no causal comparison.',
                   'Not a completed ordinary matrix or canonical E02 integration; canonicalPARTIAL22 and Q01/Q08/Q13/Q15/Q27 BLOCKER unchanged.',
                   'No never-ANR prerequisite, broadened dialog handling, fallback data, new SDK/kind/NIP or deployment.'],
    })
    interpreter = Path('/home/peterhorvath/.miniforge3/bin/python3.13')
    commands = [[str(interpreter), '-I', '-B', str(SOURCE / name)]
                for name in ('test_lease_guard.py', 'test_cleanup.py', 'test_android_driver.py')]
    save('execution-plan.json', {
        'schema': 'e02-ordinary-api35-control-and-runtime-plan-v1', 'state': 'PROPOSED_NOT_EXECUTED_NOT_RELEASED',
        'subject': pin(EVIDENCE / 'subject.json'), 'configuration': pin(EVIDENCE / 'proposed-run-config.json'),
        'pythonInterpreter': pin(interpreter), 'proposedPythonControlCommands': commands,
        'countsExpectedOnly': counts,
        'separateFixtureControl': {'command': ['PIN_CURRENT_NODE_INTERPRETER_BEFORE_RUN', str(SOURCE / 'test_fixture.mjs')], 'expectedHistoricCount': 27,
                                   'meaning': 'Pure metadata/generation/source-shape controls only; no crypto/relay/Android.'},
        'separateConsumerControl': {'command': [str(interpreter), '-I', '-B', str(ROOT / 'experiments/prototypes/e02_ordinary_control_evidence_v1/test_consumer.py')],
                                    'expectedHistoricCount': 14, 'meaning': 'DATA-only evidence-consumer negative controls, not actual ordinary-client acceptance.'},
        'captureRequirement': 'Fresh finite foreground children; raw stdout/stderr, natural exit/signal, EOF/reap/force/error/timing; before/after exact source/interpreter pins. Stop at first failure, preserve history; no silent retry.',
        'releaseSchema': RELEASE_SCHEMA, 'runtimeResultSchema': RESULT_SCHEMA,
        'futureRuntimeFixedArgvWithoutMissingRelease': [str(interpreter), '-I', '-B', str(SOURCE / 'supervisor.py'), '--config',
            str(EVIDENCE / 'proposed-run-config.json'), '--config-sha', pin(EVIDENCE / 'proposed-run-config.json')['sha256'], '--out', str(output)],
        'missingRuntimeArguments': ['--release exact actual reviewed root release path', '--release-sha exact existing release hash'],
        'prerequisites': [
            'New independent SOURCE QA/security accept exact frozen subject, config, SDK DATA link and entire typed AST diff.',
            'Execute/review meaningful current control scopes; historical counts are not current-profile passes.',
            'Recheck current source-specific E01/E02 provenance before original fixture gates; do not transfer PASS onto changed adapters/dependencies.',
            'Fresh free disk>=6GiB on actual output filesystem as in original ordinary admission; preserve original2048M request. Separate6G diagnostic failure/retry margin is not an ordinary prerequisite.',
            'Fresh >=8 host affinity CPUs, >=12GiB MemAvailable, KVM access and exact cached image/APK/helper/SDK/dependency pins. Configured caps are not measured resources.',
            'Issue new externally hash-bound finite original1800s first-cell-only root release; no SOURCE approval alone authorizes runtime.',
        ],
        'runtimeAcceptance': [
            'Retain actual SDK/API build/renderer/guest/resource observations without assuming requested backend or healthy boot.',
            'Original closed ADB, immutable lease/clocks, owned isolation/caps and cleanup checks hold.',
            'Actual full unmasked public scalar2 NSEC and reopened TorOff PNG; known Settings/SystemUI Wait-only<=2 permitted; Quickstep/unknown refuse.',
            'Actual Amethyst1059 #p subscription and same-generation EOSE before publication; no fixture fallback.',
            'Actual received EVENT/wire joins, independent current JS/Rust validation, render PNG/XML and complete raw client clipboard export; strict six-field inner-rumor match.',
            'Exact-owned complete container cleanup and independent QA/security review of observations; any failure remains failed/unqualified or PARTIAL.',
        ],
        'completionLimits': 'Even successful first cell is scoped PARTIAL. Seven other matrix producer cells, canonical evidence integration and architectural blocker decisions remain open.',
        'rootReleaseCreated': False, 'leaseIssued': False, 'controlsExecuted': False,
        'androidExecuted': False, 'humanInputNeededForSourcePreparation': None,
    })
    write(EVIDENCE / 'README.md', b'''# API35 ordinary-client preparation R1

SOURCE/DATA preparation only. `subject.json` freezes the complete21-source
subject (18 new ordinary copies and3 unchanged external consumer sources),
configuration, full source diff and typed AST proof. `baseline-provenance.json`
preserves exact original R11 pins and confirms all21 originals stayed unchanged.
`accepted-data-prerequisite-link.json` joins existing independent DATA-only
acceptance. This author grants no independent review or runtime approval.

`execution-plan.json` identifies unexecuted current controls, raw capture and
independent review requirements, exact profile schema and pending root release.
No control, Node, SDK, Android, installation, service, lease, grant or runtime
action was executed during this preparation. API35 boot/client compatibility
remains UNKNOWN. Existing ordinary failures, E02PARTIAL22 and blockers remain.

The requested ordinary userdata constant is2048M, preserved from original R11.
The existing ordinary6GiB free-disk admission remains unchanged and must be
rechecked on the actual output filesystem. The separate6G diagnostic's failed
preallocation and proposed8GiB retry margin are not ordinary prerequisites.
Preserve original failures; API35 boot and client readiness remain UNKNOWN.

The original current driver keeps strict unmasked whole public synthetic NSEC,
actual reopened TorOff PNG and bounded known Settings/SystemUI Wait-only<=2;
Quickstep/unknown refuse. No never-ANR prerequisite or handler relaxation.
The first JS-to-Rust incoming rsrelay cell is a semantic readiness candidate,
not a causal comparison, whole ordinary matrix, canonical PASS or blocker close.
''')
    print(json.dumps({'state': 'WRITES_STOPPED_SOURCE_ONLY', 'subject': pin(EVIDENCE / 'subject.json'),
                      'configuration': pin(EVIDENCE / 'proposed-run-config.json'),
                      'sources': len(sources), 'controlDefinitionsOnly': counts,
                      'changedCopiedFiles': [row['relativePath'] for row in proof if not row['byteIdentical']],
                      'supervisor': pin(SOURCE / 'supervisor.py'), 'sourceDiff': pin(EVIDENCE / 'source.diff')}))


if __name__ == '__main__':
    main()
