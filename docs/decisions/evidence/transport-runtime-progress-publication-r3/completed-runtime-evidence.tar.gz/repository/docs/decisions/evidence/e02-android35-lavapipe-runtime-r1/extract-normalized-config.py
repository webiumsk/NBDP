"""One fixed DATA parsing correction. Does not import/run any project source."""
from pathlib import Path
import hashlib
import json

E = Path('/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence/e02-android35-lavapipe-runtime-r1')
RAW = E / 'actual-run/android-state/avd/ordinary.avd/config.ini'
REPORT = E / 'profile-observation.json'
DEST = E / 'config-key-normalization-addendum.json'
PRESERVE = ('profile-observation.json', 'subject.json', 'mirror-manifest.json',
            'artifact-manifest.json', 'observation.json', 'README.md',
            'archive-data.py', 'archive-execution.json',
            'actual-run/android-state/avd/ordinary.avd/config.ini')


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    before = [pin(E / name) for name in PRESERVE]
    raw_pin = pin(RAW)
    assert (raw_pin['bytes'], raw_pin['sha256']) == (564, 'ba431436dcf65fba34625774ec583528218f8601d881eecce813d213821e44ec')
    original = json.loads(REPORT.read_text())
    assert original['file'] == raw_pin and all(value is None for value in original['configured'].values())
    parsed = {}
    for line in RAW.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith(('#', ';')): continue
        key, value = (part.strip() for part in line.split('=', 1))
        assert key and key not in parsed, 'Duplicate/empty normalized key'
        parsed[key] = value
    fields = {key: parsed[key] for key in ('hw.cpu.ncore', 'hw.ramSize', 'hw.gpu.mode',
                                         'disk.dataPartition.size', 'image.sysdir.1')}
    assert fields == {'hw.cpu.ncore': '4', 'hw.ramSize': '4096', 'hw.gpu.mode': 'lavapipe',
                      'disk.dataPartition.size': '6442450944',
                      'image.sysdir.1': 'system-images/android-35/default/x86_64/'}
    result = {
        'schema': 'api35-config-key-normalization-addendum-v1',
        'evidenceType': 'DATA_PARSING_CORRECTION_ONLY', 'author': '/root/android_health_implementer',
        'finding': 'Actual independent QA LOW: original derived report returned null because keys retained trailing whitespace.',
        'originalDerivedReport': pin(REPORT), 'exactRawConfig': raw_pin,
        'extractionScript': pin(Path(__file__).resolve()),
        'method': 'Split each noncomment setting at the first equals sign; strip key and value whitespace; reject duplicate/empty normalized keys; preserve values as strings.',
        'correctedConfiguredFields': fields,
        'supersedes': 'Only the five null configured fields in the original derived report; original report/raw/index/subject remain intact.',
        'meaning': 'Retained AVD config settings after failed initialization, not observed running guest resources, booted API or allocated userdata partition. They may have been normalized by emulator startup.',
        'partitionLimit': 'The retained file says6442450944. This addendum neither changes the source-requested partition setting nor claims successful allocation or permission to change it.',
        'execution': {'projectImports': False, 'runtimeOrExperiment': False, 'sourceOrSdkChanged': False},
        'preservedOriginalFiles': before, 'allOriginalPinsUnchanged': True,
        'remainingReview': 'Independent QA/security assessment of this DATA correction belongs to the coordinator.',
    }
    assert [pin(E / name) for name in PRESERVE] == before
    with DEST.open('x') as out: out.write(json.dumps(result, indent=2) + '\n')
    assert [pin(E / name) for name in PRESERVE] == before
    print(json.dumps({'addendum': pin(DEST), 'correctedConfiguredFields': fields,
                      'originalFilesUnchanged': True, 'state': 'WRITES_STOPPED'}))


if __name__ == '__main__':
    main()
