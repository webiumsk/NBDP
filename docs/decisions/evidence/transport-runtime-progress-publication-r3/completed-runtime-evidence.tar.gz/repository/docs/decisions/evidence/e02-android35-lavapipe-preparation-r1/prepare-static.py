"""Source-only DATA hash/diff/typed-AST proof; imports no project module."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
S = ROOT / 'experiments/prototypes/e02_android35_lavapipe_trace_v1'
B = ROOT / 'experiments/prototypes/e02_android_lavapipe_trace_v1'
E = ROOT / 'docs/decisions/evidence/e02-android35-lavapipe-preparation-r1'
P = ROOT / 'docs/decisions/evidence/e02-android-lavapipe-preparation-r1'
DATA = ROOT / 'docs/decisions/evidence/e02-api35-fixture-preparation-r2'
SDK = Path('/tmp/nbdp-e02-api35-fixture-r2/sdk')
REPLACEMENTS = (
    ('e02-android-lavapipe-trace', 'e02-android35-lavapipe-trace'),
    ('ANDROID_LAVAPIPE_TRACE_ONLY_NO_INSTALL_OR_INTENT', 'ANDROID35_LAVAPIPE_TRACE_ONLY_NO_INSTALL_OR_INTENT'),
    ('/tmp/nbdp-e02-ingress-runtime/sdk', '/tmp/nbdp-e02-api35-fixture-r2/sdk'),
    ('android-36', 'android-35'),
    ('e02_android_lavapipe_trace_driver', 'e02_android35_lavapipe_trace_driver'),
)


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (E / name).open('x') as out: out.write(json.dumps(value, indent=2) + '\n')


class DeclaredLiterals(ast.NodeTransformer):
    """Preserve AST node types/control flow; change only named DATA operands."""
    def visit_Constant(self, node):
        value = node.value
        if type(value) is str:
            for before, after in REPLACEMENTS: value = value.replace(before, after)
        elif type(value) is bytes:
            for before, after in REPLACEMENTS: value = value.replace(before.encode(), after.encode())
        return ast.copy_location(ast.Constant(value=value), node)
    def visit_BinOp(self, node):
        if (isinstance(node.left, ast.Name) and node.left.id == 'OLD' and isinstance(node.op, ast.Div)
                and isinstance(node.right, ast.Constant) and node.right.value == 'records/runtime-sdk-tree.json'):
            return ast.copy_location(ast.BinOp(left=ast.Name(id='REPO', ctx=ast.Load()), op=ast.Div(),
                right=ast.Constant(value='docs/decisions/evidence/e02-api35-fixture-preparation-r2/sdk-tree.json')), node)
        return self.generic_visit(node)


def main():
    assert not (E / 'subject.json').exists()
    protected = []
    for name, path in (
        ('ordinary21', E.parent / 'e02-ordinary-client-resume-r1/complete-source-config-subject-r11.json'),
        ('healthA11', E.parent / 'e02-android-health-preparation-r2/subject.json'),
        ('cpu8B11', E.parent / 'e02-android-health-cpu8-preparation-r1/subject.json'),
        ('boot11', E.parent / 'e02-android-boot-trace-preparation-r1/subject.json'),
        ('lavapipe12', P / 'subject.json'),
    ):
        obj = json.loads(path.read_text())
        for entry in obj['sources']: assert pin(Path(entry['path'])) == entry, entry['path']
        protected.append({'name': name, 'subject': pin(path), 'count': len(obj['sources']), 'allPinsMatch': True})
    sources = [pin(p) for p in sorted(S.iterdir()) if p.is_file()]
    assert len(sources) == 12
    proofs = []
    for name in ('supervisor.py', 'android_driver.py', 'test_diagnostic.py'):
        original = ast.parse((B / name).read_bytes())
        desired = DeclaredLiterals().visit(original)
        actual = ast.parse((S / name).read_bytes())
        assert ast.dump(desired, include_attributes=False) == ast.dump(actual, include_attributes=False), name
        proofs.append({'file': name, 'wholeModuleTypedAstEqualAfterDeclaredLiteralBindingsOnly': True,
                       'newBranchesCallsCapabilitiesOrAssertionRemoval': False})
    for name in ('lease_guard.py', 'test_lease_guard.py', 'test_cleanup.py', 'fixture.mjs', 'fixture-plan.json', 'ui-plan.json'):
        assert (B / name).read_bytes() == (S / name).read_bytes(), name
        proofs.append({'file': name, 'byteIdentical': True})
    text = (B / 'test_lavapipe.py').read_text().replace(
        'test_lavapipe_is_only_renderer_semantic_delta_and_old_files_unchanged',
        'test_api35_is_only_os_fixture_delta_and_old_renderer_resources_unchanged').replace(
        "old = HERE.parent / 'e02_android_boot_trace_v1'", "old = HERE.parent / 'e02_android_lavapipe_trace_v1'").replace(
        "values['CONFIG'].replace('swiftshader_indirect', 'lavapipe')", "values['CONFIG'].replace('android-36', 'android-35')")
    assert ast.dump(ast.parse(text), include_attributes=False) == ast.dump(ast.parse((S / 'test_lavapipe.py').read_bytes()), include_attributes=False)
    proofs.append({'file': 'test_lavapipe.py', 'typedAstEqualAfterFirstProfileTestNameAndComparisonLiteralsOnly': True,
                   'assertionsRemoved': 0})
    counts = {p.name: sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(p.read_bytes())))
              for p in sorted(S.glob('test_*.py'))}
    assert counts == {'test_cleanup.py': 24, 'test_diagnostic.py': 28, 'test_lavapipe.py': 11, 'test_lease_guard.py': 29}
    inventory = pin(DATA / 'sdk-tree.json')
    assert (inventory['bytes'], inventory['sha256']) == (89738, '5c996f67fd8aba0ea618adc7f7f9e6a2c27c641cc95910deb07bdfa8a10562a8')
    tree = json.loads((DATA / 'sdk-tree.json').read_text()); assert tree['root'] == str(SDK) and len(tree['files']) == 434
    oldtree = json.loads(Path('/tmp/nbdp-e02-minimal-rs-v7/records/runtime-sdk-tree.json').read_text())
    base = lambda rows: [row for row in rows if row['path'].startswith(('emulator/', 'platform-tools/'))]
    assert len(base(tree['files'])) == 410 and base(tree['files']) == base(oldtree['files'])
    properties = json.loads((DATA / 'properties.json').read_text())
    assert properties['imageSourceProperties']['values']['AndroidVersion.ApiLevel'] == '35'
    assert properties['imageSourceProperties']['values']['AndroidVersion.ExtensionLevel'] == '13'
    assert properties['imageSourceProperties']['values']['Pkg.Revision'] == '2'
    patch = []
    for path in sorted(S.iterdir()):
        if path.is_file(): patch.extend(difflib.unified_diff((B / path.name).read_text().splitlines(True),
            path.read_text().splitlines(True), fromfile=str(B / path.name), tofile=str(path)))
    with (E / 'source.diff').open('x') as out: out.writelines(patch)
    config = json.loads((P / 'proposed-run-config.json').read_text())
    config.update(schema='e02-android35-lavapipe-trace-runtime-plan-v1',
        scope='ANDROID35_LAVAPIPE_TRACE_ONLY_NO_INSTALL_OR_INTENT', runId=uuid.uuid4().hex,
        sdkRoot=str(SDK), sdkInventory=inventory, state='SOURCE_ONLY_REQUIRES_API35_DATA_AND_SOURCE_REVIEW_THEN_NEW_RELEASE')
    config['sourceAndDependencyPins'] = [pin(S / Path(entry['path']).name) for entry in config['sourceAndDependencyPins']]
    save('proposed-run-config.json', config)
    output = Path('/tmp/nbdp-e02-android35-lavapipe-trace-v1/runs') / config['runId']; assert not output.exists()
    save('fixture-linkage.json', {'schema': 'api35-source-profile-fixture-link-v1', 'sdkRoot': str(SDK),
        'sdkInventory': inventory, 'api35DataSubject': pin(DATA / 'subject.json'),
        'api35DataResult': pin(DATA / 'result.json'), 'imageProperties': pin(DATA / 'properties.json'),
        'sourceFingerprint': properties['imageFingerprintSourceOnly'],
        'copiedBase410InventoryRowsByteSizeModeHashEqual': True,
        'api35DataIndependentReviewAtPreparation': 'PENDING_NOT_SELF_APPROVED',
        'requiredBeforeRuntime': 'Actual independent DATA QA/security acceptance of the exact acquired fixture, then exact SOURCE/control/release gates.',
        'limits': ['DATA index/property linkage only; not runtime, independent QA acceptance or source-to-binary attestation.',
                   'API35 changes the whole OS fixture; no causal/healthy/client-compatibility claim.']})
    save('static-checks.json', {'schema': 'api35-lavapipe-source-static-v1', 'actor': '/root/android_health_implementer',
        'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_REVIEW',
        'method': 'DATA hashes/diff/whole-module typed AST normalization, no imports/tests/runtime',
        'declaredStringAndByteLiteralReplacements': REPLACEMENTS,
        'declaredTypedPathBinding': {'before': "OLD / 'records/runtime-sdk-tree.json'",
                                     'after': "REPO / 'docs/decisions/evidence/e02-api35-fixture-preparation-r2/sdk-tree.json'"},
        'astAndByteProofs': proofs, 'protectedSources': protected, 'protectedSourceCount': sum(x['count'] for x in protected),
        'currentSources': sources, 'testDefinitionsOnly': counts, 'sourcePatch': pin(E / 'source.diff'),
        'fixtureLinkage': pin(E / 'fixture-linkage.json'), 'proposedConfiguration': pin(E / 'proposed-run-config.json'),
        'actualExecution': {'controls': 0, 'android': 0, 'services': 0},
        'unchangedRequirements': ['Original1800s lease/early30s/post180s/child10s/outer15s',
            'Lavapipe/emulator/platform-tools/guest4CPU4096/containerCPU8memswap8192/PID512',
            'Closed guard/spool/privacy/first-error/sticky/owned cleanup/mandatory UI',
            'No install/intent/login/input/publication/recovery/fallback/canonical or blocker change']})
    save('subject.json', {'schema': 'e02-android35-lavapipe-source-config-subject-v1',
        'author': '/root/android_health_implementer', 'sourceAuthors': json.loads((P / 'subject.json').read_text())['sourceAuthors'],
        'coordinator': '/root', 'scope': config['scope'], 'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_REVIEW',
        'sources': sources, 'configuration': pin(E / 'proposed-run-config.json'),
        'staticChecks': pin(E / 'static-checks.json'), 'baselineProvenance': pin(E / 'baseline-provenance.json'),
        'fixtureLinkage': pin(E / 'fixture-linkage.json'), 'baselineSourceSubject': pin(P / 'subject.json'),
        'preparedStaticSource': pin(Path(__file__).resolve()), 'plannedOutput': str(output),
        'executionReleased': False, 'actualExecution': {'controls': 0, 'android': 0, 'services': 0},
        'requiredReviews': ['Actual independent API35 DATA QA/security', 'Exact new SOURCE QA/security',
            'Actual new29/24/28/11 controls plus independent result reviews', 'Fresh exact root diagnostic-only release'],
        'limits': ['No old PASS transfer, runtime/cause/health/backend/client compatibility or blocker closure.',
                   'Author may not approve own DATA or SOURCE work.']})
    interpreter = Path('/home/peterhorvath/.miniforge3/bin/python3.13')
    save('execution-plan.json', {'schema': 'api35-lavapipe-prepared-execution-plan-v1',
        'state': 'SOURCE_ONLY_NOT_EXECUTED_NOT_RELEASED', 'subject': pin(E / 'subject.json'),
        'configuration': pin(E / 'proposed-run-config.json'), 'interpreter': pin(interpreter),
        'proposedPureControlCommands': [[str(interpreter), '-I', '-B', str(S / n)] for n in ('test_lease_guard.py', 'test_cleanup.py', 'test_diagnostic.py', 'test_lavapipe.py')],
        'counts': counts, 'captureRequirement': 'Finite foreground/raw streams/natural exit/reap/EOF/force/error/timing/source and interpreter before-after; stop at first failure, no retry/fix.',
        'pureControlMeaning': 'Owned finite Python children/tempfiles/mocks only, not emulator/SDK/Docker/crypto/protocol execution.',
        'futureRuntimeFixedArgv': [str(interpreter), '-I', '-B', str(S / 'supervisor.py'), '--config',
            str(E / 'proposed-run-config.json'), '--config-sha', pin(E / 'proposed-run-config.json')['sha256'], '--out', str(output)],
        'freshFutureReleaseRequired': {'schema': 'e02-android35-lavapipe-trace-release-v1',
            'missingActualBindings': ['--release actual reviewed coordinator-owned path', '--release-sha actual existing release SHA256'],
            'fixturePrerequisite': 'Independent accepted actual API35 DATA evidence must be joined in source review/root release provenance.'},
        'rootReleaseCreated': False, 'leaseIssued': False, 'testsExecuted': False, 'humanInputNeeded': None})
    print(json.dumps({'state': 'WRITES_STOPPED_SOURCE_ONLY', 'sources': len(sources),
        'protectedSources': 66, 'preparedControls': counts, 'subject': pin(E / 'subject.json'),
        'configuration': pin(E / 'proposed-run-config.json')}))


if __name__ == '__main__':
    main()
