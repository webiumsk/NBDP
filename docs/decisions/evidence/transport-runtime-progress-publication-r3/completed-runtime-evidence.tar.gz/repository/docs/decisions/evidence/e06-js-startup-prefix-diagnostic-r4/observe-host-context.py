"""Read-only HOST observation; no project imports, tracing, grant or mutation."""
from pathlib import Path
import hashlib,json,os,stat,time
ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
BASE=ROOT/'docs/decisions/evidence/e06-js-startup-prefix-diagnostic-r3/original-inventory.json'
OWN=ROOT/'docs/decisions/evidence/e06-js-startup-prefix-diagnostic-r4/supervisor.py'
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def state(p):
 s=p.lstat();d=pin(p);after=p.lstat()
 ident=lambda z:(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns,z.st_mode,z.st_uid,z.st_gid)
 assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and ident(s)==ident(after)
 return {'descriptor':d,'stat':{'device':s.st_dev,'inode':s.st_ino,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid}}
def optional_read(p):
 try:return Path(p).read_text()
 except OSError as e:return {'unavailable':type(e).__name__,'message':str(e)}
def optional_link(p):
 try:return os.readlink(p)
 except OSError as e:return {'unavailable':type(e).__name__,'message':str(e)}
started=time.monotonic_ns();base=pin(BASE)
assert base['bytes']==243423 and base['sha256']=='89f456c670afd5140d19e7f2b2bd85268062a978b2c4da4effb5759bbd2afecf'
inv=json.loads(BASE.read_bytes());changes=[];drift=[];keys=['device','inode','size','mtimeNs','ctimeNs','mode']
for i,old in enumerate(inv['files']):
 current=state(Path(old['descriptor']['path']))
 if current['descriptor']!=old['descriptor'] or any(current['stat'][k]!=old['stat'][k] for k in keys):
  drift.append({'index':i,'old':old,'host':current})
 if [current['stat']['uid'],current['stat']['gid']] != [old['stat']['uid'],old['stat']['gid']]:
  changes.append({'index':i,'old':[old['stat']['uid'],old['stat']['gid']],'host':[current['stat']['uid'],current['stat']['gid']]})
membership=[]
for root,expected in inv['rawTreeFiles'].items():
 actual=[]
 for p in sorted(Path(root).rglob('*')):
  s=p.lstat();assert not stat.S_ISLNK(s.st_mode)
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode);actual.append(str(p))
 membership.append({'root':root,'expectedCount':len(expected),'hostCount':len(actual),'exactMatch':actual==expected})
record={'schema':'e06-startup-host-ownership-observation-v1','action':'SUPPORTED_HOST_READ_ONLY_METADATA','baseInventory':base,'originalRowsChecked':len(inv['files']),'sourceMemberCount':inv['sourceMemberCount'],'originalR2FileCount':inv['originalR2FileCount'],'verifiedNonOwnershipFields':keys,'allOriginalByteDescriptorsMatch':not any(d['old']['descriptor']!=d['host']['descriptor'] for d in drift),'unexpectedByteOrNonOwnershipDrift':drift,'uidGidChanges':changes,'rawMembership':membership,'newOwnSupervisorHostState':state(OWN),'hostContext':{'uid':os.getuid(),'gid':os.getgid(),'uidMap':optional_read('/proc/self/uid_map'),'gidMap':optional_read('/proc/self/gid_map'),'userNamespace':optional_link('/proc/self/ns/user'),'mountNamespace':optional_link('/proc/self/ns/mnt')},'hostCacheState':state(Path('/etc/ld.so.cache')),'elapsedNs':time.monotonic_ns()-started,'writes':0,'NodeRuns':0,'tracingRuns':0,'controlRuns':0,'limits':['Observed ownership depends on execution namespace.','This metadata comparison grants no runtime approval and changes no ownedJSON/0600 validation.']}
print(json.dumps(record,separators=(',',':')))
raise SystemExit(0 if not drift and all(m['exactMatch'] for m in membership) else 2)
