# API35 ordinary-client preparation R1

SOURCE/DATA preparation only. `subject.json` freezes the complete21-source
subject (18 new ordinary copies and3 unchanged external consumer sources),
configuration, full source diff and typed AST proof. `baseline-provenance.json`
preserves exact original R11 pins and confirms all21 originals stayed unchanged.
`accepted-data-prerequisite-link.json` joins existing independent DATA-only
acceptance. This author grants no independent review or runtime approval.

`execution-plan.json` identifies unexecuted current controls, raw capture and
independent review requirements, exact profile schema and pending root release.
No control, Node, SDK, Android, installation, service, lease, grant or runtime
action was executed during this preparation. API35 boot/client compatibility
remains UNKNOWN. Existing ordinary failures, E02PARTIAL22 and blockers remain.

The requested ordinary userdata constant is2048M, preserved from original R11.
The existing ordinary6GiB free-disk admission remains unchanged and must be
rechecked on the actual output filesystem. The separate6G diagnostic's failed
preallocation and proposed8GiB retry margin are not ordinary prerequisites.
Preserve original failures; API35 boot and client readiness remain UNKNOWN.

The original current driver keeps strict unmasked whole public synthetic NSEC,
actual reopened TorOff PNG and bounded known Settings/SystemUI Wait-only<=2;
Quickstep/unknown refuse. No never-ANR prerequisite or handler relaxation.
The first JS-to-Rust incoming rsrelay cell is a semantic readiness candidate,
not a causal comparison, whole ordinary matrix, canonical PASS or blocker close.
