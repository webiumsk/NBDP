from pathlib import Path
import os,stat,json,hashlib,subprocess,shutil,time
R=Path('/home/peterhorvath/apps/bitcoin/NBDP');E=R/'docs/decisions/evidence';P=E/'e02-owned-avd-overlay-reclamation-r3';assert not P.exists();P.mkdir(mode=0o700)
def d(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def save(n,v):
 fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
rows=[];cids=[]
for run,inode,expected in [('e8db184344724508a1d2aa722d4e9c6d',2492082,'b846f0d6d65d240af843f162faf9809a0b15bfbed95221addd6192ebfa95929a'),('b157caba287c402fb37195b2a433f6b6',2492739,'958fc38b9a125facecef9951d6ae59b5fb4f9b4332c8ab324d0be9c9dc02604d')]:
 root=Path('/tmp/nbdp-e02-ordinary-client-v1/runs')/run;p=root/'android-state/avd/ordinary.avd/userdata-qemu.img.qcow2';s=p.lstat();assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==os.getuid()==1000 and s.st_nlink==1 and s.st_dev==64513 and s.st_ino==inode and stat.S_IMODE(s.st_mode)==0o644
 assert all(not a.is_symlink() for a in p.parents)
 result=root/'supervisor-result.json';assert d(result)['sha256']==expected;x=json.loads(result.read_bytes());assert x['executionState']=='FAILED_UNQUALIFIED' and x['cleanup']['ok'] and len(x['cleanup']['rows'])==4 and all(v['identityVerified'] and v['absenceConfirmed'] and v['removeExit']==0 for v in x['cleanup']['rows']);cids.extend(v['cid'] for v in x['cleanup']['rows'])
 profiles=[d(p.parent/n) for n in ['config.ini','hardware-qemu.ini']];assert profiles[0]['sha256']=='dd71da7dee014463713cd9416acd4f114962b0d4c0f82262ade3166b4c6309ca' and profiles[1]['sha256']=='5981e25c6cf395378f4697e7824a07adde4b02a3d27c989941900a1dd0f7747f'
 rows.append(dict(overlay=d(p),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,allocatedBytes=s.st_blocks*512,preservedProfiles=profiles,sourceResult=d(result)))
closure=(E/'e06-qualification-current-source-r3/source-closure.json').read_text();assert all(v['overlay']['path'] not in closure for v in rows)
a=subprocess.run(['docker','inspect',*cids],capture_output=True,timeout=20);assert a.returncode==1 and a.stdout.strip()==b'[]' and a.stderr==b''.join(('error: no such object: '+cid+'\n').encode() for cid in cids)
b=subprocess.run(['fuser',*[v['overlay']['path'] for v in rows]],capture_output=True,timeout=20);assert b.returncode==1 and not b.stdout.strip() and not b.stderr.strip()
save('before.json',dict(schema='nbdp-owned-disposable-overlay-reclamation-before-v1',actor='/root',utcNs=time.time_ns(),files=rows,freeBefore=shutil.disk_usage('/tmp').free,absence=dict(cids=cids,dockerExit=a.returncode,stdout=a.stdout.decode(),stderr=a.stderr.decode(),fuserExit=b.returncode),independentInventory=dict(session='/root/android_anr_diagnosis',proof='1284 relevantJSON/source449 and589/616 archivedobservationrows noimagepins, exactownedstate mounts andcurrentabsence.'),reason='Requestedordinary2048M doesnotproveallocatedsize: sevenretainedhardwarefilesnormalized6g; API35diagnosticactual7.2GiBpreallocationdemand. Futureordinaryexternal>=8GiBmarginchosen; originalsource6GiBfloor/partitionrequestunchanged.',scope='Onlytwoexactunreferencedownuserdataoverlays; allotherstate/source/config/keys/evidence/SDK/userworkpreserved.'))
for row in rows:
 p=Path(row['overlay']['path']);s=p.lstat();assert s.st_dev==row['device'] and s.st_ino==row['inode'] and s.st_uid==1000 and s.st_nlink==1 and s.st_size==row['overlay']['bytes'] and s.st_mtime_ns==row['mtimeNs'] and s.st_ctime_ns==row['ctimeNs'] and stat.S_ISREG(s.st_mode);p.unlink();assert not p.exists()
 for q in row['preservedProfiles']:assert d(Path(q['path']))==q
save('result.json',dict(schema='nbdp-owned-disposable-overlay-reclamation-result-v1',actor='/root',before=d(P/'before.json'),removed=[v['overlay'] for v in rows],allFourProfilesPreserved=True,freeAfter=shutil.disk_usage('/tmp').free,requiredFutureOrdinaryExternalAdmissionBytes=8*1024**3,sourceAdmissionFloorBytesUnchanged=6*1024**3,limits='Configuredextraadmissionmargin, notmeasuredminimum/peakguarantee. Onlythese2filesremoved; no source/code/gate/blocker/credentialschange.'))
print((P/'result.json').read_text())
