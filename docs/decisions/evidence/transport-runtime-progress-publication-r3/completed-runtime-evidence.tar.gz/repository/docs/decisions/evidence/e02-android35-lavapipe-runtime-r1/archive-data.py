"""Fixed DATA-only archive of failed API35 initialization; no project imports."""
from pathlib import Path
import ast
import hashlib
import json
import re

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
RUN = Path('/tmp/nbdp-e02-android35-lavapipe-trace-v1/runs/50f907e3e77b4cff9137030fcaef1086')
OUT = ROOT / 'docs/decisions/evidence/e02-android35-lavapipe-runtime-r1'
PREP = ROOT / 'docs/decisions/evidence/e02-android35-lavapipe-preparation-r1'
DIRS = ('commands', 'cleanup', 'ownership', 'session')
PROFILES = ('android-state/avd/ordinary.ini', 'android-state/avd/ordinary.avd/config.ini',
            'android-state/avd/ordinary.avd/hardware-qemu.ini',
            'android-state/avd/ordinary.avd/emu-launch-params.txt',
            'android-state/avd/ordinary.avd/qemu-version.txt')


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (OUT / name).open('x') as stream: stream.write(json.dumps(value, indent=2) + '\n')


def mirror(src, dst):
    assert src.is_file() and not src.is_symlink()
    expected = pin(src); raw = src.read_bytes(); dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('xb') as stream: stream.write(raw)
    actual = pin(dst)
    assert pin(src) == expected and (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
    return dict(expected, mirror=str(dst))


def main():
    assert not (OUT / 'mirror-manifest.json').exists()
    result_pin = pin(RUN / 'supervisor-result.json')
    assert (result_pin['bytes'], result_pin['sha256']) == (3113, 'd4709063f9130f179020835d7196ad8969aa3a7ca1851113f58dca1d0fe7b1c1')
    files = []
    for dirname in DIRS:
        for src in sorted((RUN / dirname).rglob('*')):
            if src.is_file(): files.append(mirror(src, OUT / 'actual-run' / src.relative_to(RUN)))
    for name in ('supervisor-result.json', 'input/run-config.json'):
        files.append(mirror(RUN / name, OUT / 'actual-run' / name))
    missing_profiles = []
    for name in PROFILES:
        if (RUN / name).is_file(): files.append(mirror(RUN / name, OUT / 'actual-run' / name))
        else: missing_profiles.append(name)
    for name in ('subject.json', 'proposed-run-config.json', 'exact-root-android35-release.json'):
        files.append(mirror(PREP / name, OUT / 'preparation-inputs' / name))
    selected = {Path(x['path']) for x in files if Path(x['path']).is_relative_to(RUN)}
    all_members = {p for p in RUN.rglob('*') if p.is_file()}
    exclusions = []
    for dirname in ('android-state', 'input', 'docker-config', 'relay-data'):
        paths = [p for p in (RUN / dirname).rglob('*') if p.is_file() and p not in selected]
        exclusions.append({'path': str(RUN / dirname), 'count': len(paths),
                           'bytesFromMetadataOnly': sum(p.stat().st_size for p in paths),
                           'reason': 'Unselected mutable state/keys/locks, mounted inputs, Docker config or DB; no contents copied.'})
    assert len(all_members - selected) == sum(x['count'] for x in exclusions)
    receipts = [(p.name, json.loads(p.read_text())) for p in sorted((RUN / 'commands').glob('*.json'))]
    assert len(receipts) == 14
    for _, row in receipts[:13]:
        assert row['exit'] == 0 and not row['forced'] and not row['timedOut'] and row['error'] is None
        assert row['reaped'] and row['stdoutEOF'] and row['stderrEOF']
    last = receipts[-1][1]
    assert last['exit'] == 137 and last['forced'] and last['error'] == 'LeaseDenied: sticky revocation'
    assert last['reaped'] and last['stdoutEOF'] and last['stderrEOF'] and not last['timedOut']
    result = json.loads((RUN / 'supervisor-result.json').read_text())
    assert result['executionState'] == 'FAILED_UNQUALIFIED' and not result['secondaryErrors']
    assert result['cleanup']['ok'] and len(result['cleanup']['rows']) == 4
    assert all(r['identityVerified'] and r['absenceConfirmed'] and not r['errors'] for r in result['cleanup']['rows'])
    stdout = (RUN / 'session/fixtures/emulator.stdout').read_bytes()
    stderr = (RUN / 'session/fixtures/emulator.stderr').read_bytes()
    assert len(stdout) == 1265 and not stderr
    fatal = next(line for line in stdout.decode().splitlines() if line.startswith('FATAL'))
    assert 'Not enough space to create userdata partition.' in fatal
    amounts = re.search(r'Available: ([0-9.]+) MB at (.+), need ([0-9.]+) MB\.', fatal)
    assert amounts
    revoked = (RUN / 'session/control/REVOKED').read_text()
    assert revoked == 'owned command exited unsuccessfully\n'
    config = json.loads((RUN / 'input/run-config.json').read_text())
    schema = config['schema']
    assert schema == 'e02-android35-lavapipe-trace-runtime-plan-v1'
    tree = ast.parse((RUN / 'input/supervisor.py').read_bytes())
    validator = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'verify_config')
    assert schema in [n.value for n in ast.walk(validator) if isinstance(n, ast.Constant)]
    source_bindings = []
    for name in ('supervisor.py', 'lease_guard.py', 'android_driver.py'):
        actual = pin(RUN / 'input' / name)
        expected = next(e for e in config['sourceAndDependencyPins'] if Path(e['path']).name == name)
        assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
        source_bindings.append({'actualMountedSource': actual, 'reviewedSource': expected})
    assert pin(PREP / 'proposed-run-config.json')['sha256'] == pin(RUN / 'input/run-config.json')['sha256']
    initial = json.loads((RUN / 'commands/0012.stdout').read_text())[0]
    final = json.loads((RUN / 'cleanup/android-inspect.stdout').read_text())[0]
    caps = {key: initial['HostConfig'].get(key) for key in ('Memory', 'MemorySwap', 'PidsLimit', 'NanoCpus',
        'CgroupnsMode', 'CgroupParent', 'NetworkMode', 'ReadonlyRootfs', 'Privileged', 'PortBindings')}
    assert caps['Memory'] == caps['MemorySwap'] == 8589934592 and caps['PidsLimit'] == 512
    assert caps['NanoCpus'] == 8000000000 and caps['CgroupnsMode'] == 'private'
    assert final['State']['ExitCode'] == 2 and final['State']['OOMKilled'] is False
    missing = [name for name in ('early-boot-result.json', 'early-boot-partial.json',
        'diagnostic-result.json', 'diagnostic-partial.json', 'evidence', 'diagnostics') if not (RUN / name).exists()]
    save('observation.json', {'schema': 'api35-initialization-failure-data-v1',
        'state': 'FAILED_UNQUALIFIED_BEFORE_GUEST_ADB', 'actor': '/root/android_health_implementer, DATA archiver only',
        'emulatorFatal': fatal, 'availableAsReported': {'value': amounts[1], 'unit': 'MB', 'path': amounts[2]},
        'requiredAsReported': {'value': amounts[3], 'unit': 'MB'},
        'chronology': ['Emulator live stdout retains userdata-partition allocation FATAL.',
            'Original shared revocation records owned command exited unsuccessfully.',
            'Outer wait-for-device receipt14 records exit137/forced/sticky, empty streams, reaped/full EOF.',
            'Supervisor retains sticky error; all four exact-owned containers removed.'],
        'chronologyLimit': 'No nested emulator receipt/per-command elapsed samples were retained; FATAL is the original observed service failure, not a measured guest OS outcome. No OOM or137-cause inference.',
        'rawStickyReason': revoked, 'secondaryAdbReceipt': last, 'normalPriorCommandReceipts': 13,
        'emulatorStdout': pin(RUN / 'session/fixtures/emulator.stdout'),
        'emulatorStderr': pin(RUN / 'session/fixtures/emulator.stderr'),
        'actualAndroidContainerCaps': caps, 'androidInitialDockerState': initial['State'], 'androidFinalDockerState': final['State'],
        'namespaceEvidence': 'Docker NetworkMode/container sharing and isolation inspect retained; guest address/listener inventory NOT_REACHED.',
        'hostDiskAdmission': {'configuredMinimumBytes': 6442450944,
            'meaning': 'Source admission threshold was passed; it does not guarantee later emulator userdata preallocation. Emulator reports its own available/needed MB; not silently reinterpreted as GiB.'},
        'actualRunConfigSchema': schema, 'schemaEvidence': 'Staged actual config and source verify_config AST; coordinator grant-preparation-history prose labels were not copied or adopted.',
        'actualIssuedRelease': result['runRelease'], 'sourceBindings': source_bindings,
        'missingEvidence': missing, 'missingProfiles': missing_profiles,
        'earlyPhase': 'NOT_STARTED', 'postbootPhase': 'NOT_STARTED', 'guestProperties': 'NOT_ACQUIRED',
        'osHealth': 'UNKNOWN_NOT_BOOTED_OR_QUALIFIED', 'effectiveBackend': 'UNKNOWN_NO_RUNTIME_VENDOR_PROOF',
        'ordinaryControlQualified': False, 'canonicalE02Changed': False, 'cleanup': result['cleanup'],
        'limits': ['No API35 boot/ANR/client-compatibility, healthy baseline, causal fix or ordinary-client row.',
            'Host6GiB admission is distinct from emulator allocation demand; no partition/reserve/timeout change or rerun.',
            'No SDK/ZIP/images/keys/APKs copied; only selected raw runtime/config profile text.']})
    save('root-tool-association.json', {'schema': 'root-tool-association-transcription-v1',
        'provenance': 'Explicit parent /root mailbox transcription, not operated or independently witnessed by this DATA archiver.',
        'foregroundSession': 74027, 'launchToolChunk': 'fa3729', 'completionToolChunk': '1be1cc',
        'exit': 2, 'state': 'FINISHED', 'run': str(RUN), 'supervisor': result_pin})
    save('mirror-manifest.json', {'schema': 'api35-failed-runtime-selected-mirror-v1', 'run': str(RUN),
        'archiver': pin(Path(__file__).resolve()), 'files': files, 'mirroredFiles': len(files),
        'selectedRunFiles': len(selected), 'mirroredBytes': sum(x['bytes'] for x in files),
        'exclusions': exclusions, 'externalExclusions': ['SDK and acquired ZIP/image/dependency trees not traversed or copied.',
            'Existing ADB keys/userstate and unselected locks excluded; no production data.'],
        'originalAndMirrorPinsVerified': True, 'experimentRerun': False, 'projectImports': False})
    print(json.dumps({'mirroredFiles': len(files), 'selectedRunFiles': len(selected),
        'mirroredBytes': sum(x['bytes'] for x in files), 'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_REVIEW'}))


if __name__ == '__main__':
    main()
