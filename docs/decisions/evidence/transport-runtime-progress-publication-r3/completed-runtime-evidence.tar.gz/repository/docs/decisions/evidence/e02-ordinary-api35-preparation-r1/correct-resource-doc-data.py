"""Bounded DOC/DATA correction only; no project import, controls or runtime."""
from pathlib import Path
import difflib
import hashlib
import json
import os

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
E = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r1'
S = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v1'
BASE = ROOT / 'experiments/prototypes/e02_ordinary_client_v1'
H = E / 'historicalinitial-source-review-r1'
FINDINGS = ['QA-ORDINARY35-RESOURCE-DOC-001', 'ORDINARY_API35_DISK_ADMISSION_DOCUMENTATION']


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def exclusive(path, raw):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)


def jsonbytes(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def main():
    assert not H.exists(), 'Exclusive DOC/DATA correction; preserve initial exact source review'
    initial = json.loads((E / 'subject.json').read_text())
    assert pin(E / 'subject.json')['sha256'] == 'ee4f6fd75befec65807036058d589594438877b9968c7744abe58b0a385f5c47'
    assert pin(E / 'proposed-run-config.json') == initial['configuration']
    assert initial['configuration']['bytes'] == 3236
    assert initial['configuration']['sha256'] == '4756736d5214b23f1b56ca063e124b0924e13d9fdd41656cf69c0eb7de6344b4'
    for row in initial['sources']:
        assert pin(Path(row['path'])) == row
    copies = [E / name for name in ('subject.json', 'source.diff', 'static-checks.json',
              'execution-plan.json', 'README.md', 'artifact-manifest.json',
              'preparation-execution.json', 'prepare-static.py')]
    copies.extend(S / name for name in ('README.md', 'SUPERVISOR.md'))
    mappings = []
    for path in copies:
        target = H / ('profile' if path.is_relative_to(S) else 'evidence') / path.name
        exclusive(target, path.read_bytes())
        mappings.append({'initial': pin(path), 'preservedExactBytes': pin(target)})
    exclusive(H / 'preservation-manifest.json', jsonbytes({
        'schema': 'e02-ordinary-api35-initial-source-review-history-v1',
        'initialReviewedSubject': pin(E / 'subject.json'), 'files': mappings,
        'actualFindingIdsFromCoordinatorMailbox': FINDINGS,
        'reviewMeaning': 'Coordinator reports two actual independent SOURCE reviews of the exact initial subject; shared LOW resource documentation finding. No new review or approval manufactured by this author.',
        'staticSerializationFailureHistory': pin(E / 'static-preparation-failure-r1/failure.json'),
    }))

    hardware = []
    for path in sorted(Path('/tmp/nbdp-e02-ordinary-client-v1/runs').glob('*/android-state/avd/ordinary.avd/hardware-qemu.ini')):
        raw = path.read_bytes()
        lines = [line.strip() for line in raw.decode().splitlines() if line.strip().startswith('disk.dataPartition.size')]
        assert lines == ['disk.dataPartition.size = 6g']
        run_id = path.relative_to(Path('/tmp/nbdp-e02-ordinary-client-v1/runs')).parts[0]
        target = E / 'disk-source-observations' / run_id / 'hardware-qemu.ini'
        exclusive(target, raw)
        hardware.append({'original': pin(path), 'preservedExactBytes': pin(target), 'normalizedSizeLine': lines[0]})
    assert len(hardware) == 7
    latest = next(row for row in hardware if '/267acc88b6604d1d9218e5ffe89f6ff1/' in row['original']['path'])
    assert latest['original']['bytes'] == 3975
    assert latest['original']['sha256'] == 'a9ca4eb75427709f5c73a74905d3305b098d41c6577e69fe1d4a778998000479'
    diag = ROOT / 'docs/decisions/evidence/e02-android35-lavapipe-runtime-r1'
    raw_log = diag / 'actual-run/session/fixtures/emulator.stdout'
    fatal = 'FATAL        | Not enough space to create userdata partition. Available: 7326.61 MB at /state/avd/../avd/ordinary.avd, need 7372.80 MB.'
    assert fatal in raw_log.read_text()
    exclusive(E / 'disk-source-observations/api35-no-install-emulator.stdout', raw_log.read_bytes())
    prerequisite = {
        'schema': 'e02-ordinary-api35-coordinator-disk-prerequisite-v1',
        'origin': 'Explicit coordinator task /root to /root/ordinary_api35_source after actual independent SOURCE findings',
        'actualFindingIds': FINDINGS,
        'requiredBeforeAnyOrdinaryGrant': {'freshFreeBytesAtLeast': 8 * 1024**3, 'unit': 'bytes',
            'filesystem': 'Actual filesystem containing the exact fresh ordinary run output',
            'evidence': 'Fresh coordinator-owned measured resource receipt, hash-bound into the future exact grant/release'},
        'meaning': 'Coordinator-selected conservative8GiB free-disk margin, not an experimentally measured minimum or readiness/boot guarantee.',
        'unchangedSource': {'requestedDataPartition': '2048M', 'sourceFreeDiskFloorGiB': 6,
            'supervisor': next(row for row in initial['sources'] if Path(row['path']).name == 'supervisor.py'),
            'configuration': initial['configuration']},
        'ordinaryRuntimeHardwareEvidence': hardware,
        'inferenceLimit': 'Requested2048M is not proof of a2GB allocation or footprint: all seven retained ordinary hardware-qemu.ini files normalized to6g.',
        'api35NoInstallFailure': {'rawSource': pin(raw_log),
            'preservedRawLog': pin(E / 'disk-source-observations/api35-no-install-emulator.stdout'),
            'observation': pin(diag / 'observation.json'), 'fatalExact': fatal,
            'stage': 'Before guest/ADB; no guest OS, compatibility, OOM or exit137-cause inference.'},
        'coordinatorCleanupContext': 'Coordinator reports reclaiming only two verified disposable old overlays, targeting about9.49GB free; this author neither performed cleanup nor treats the estimate as a fresh measurement.',
        'authority': 'Hash-bound prerequisite DATA only; not a grant, lease, release, independent approval or executed resource admission.',
        'noNewRuntimeGate': 'No code/cap/partition/health/dialog change; existing6GiB source floor remains unchanged. Fresh>=8GiB is additional coordinator admission before any grant.',
    }
    exclusive(E / 'coordinator-resource-prerequisite.json', jsonbytes(prerequisite))
    prerequisite_pin = pin(E / 'coordinator-resource-prerequisite.json')
    old_paragraph = '''The separate API35 no-install diagnostic's first actual run failed before
guest/ADB on preallocation of its separate6G userdata profile. This ordinary
profile preserves its original2048M request and original6GiB disk admission;
the diagnostic's proposed8GiB retry margin is not an ordinary prerequisite.
Boot and ordinary-client compatibility remain UNKNOWN. Preserve actual first
failure, do not substitute cached snapshots, and add no blanket healthy-OS gate.'''
    new_paragraph = '''The original requested2048M partition and source6GiB free-disk floor remain
unchanged. Requested2048M does not prove a2GB footprint: all seven retained
ordinary hardware-qemu.ini files normalized disk.dataPartition.size to6g.
The separate API35 no-install emulator failed before guest/ADB: available
7326.61MB, required7372.80MB. This supports no guest OS failure inference.
Before any ordinary grant the coordinator requires fresh measured>=8GiB free
on the actual output filesystem. This is a conservative admission margin,
not a measured minimum or boot/readiness guarantee, and does not lower or
replace the source6GiB floor. Hash-bound prerequisite DATA:
`docs/decisions/evidence/e02-ordinary-api35-preparation-r1/coordinator-resource-prerequisite.json`
SHA256 `''' + prerequisite_pin['sha256'] + '''`.
Only two verified disposable old overlays are being reclaimed by the coordinator;
the reported~9.49GB target is not this author's fresh resource measurement.
Boot/client compatibility remain UNKNOWN. Preserve first failures; no cached
snapshot substitution, blanket healthy-OS gate or broadened dialog handling.'''
    doc_diffs = []
    for name in ('README.md', 'SUPERVISOR.md'):
        path = S / name
        before = path.read_text()
        assert before.count(old_paragraph) == 1
        after = before.replace(old_paragraph, new_paragraph)
        path.write_text(after)
        doc_diffs.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
            fromfile=str(H / 'profile' / name), tofile=str(path)))
    path = E / 'README.md'
    before = path.read_text()
    old = '''The requested ordinary userdata constant is2048M, preserved from original R11.
The existing ordinary6GiB free-disk admission remains unchanged and must be
rechecked on the actual output filesystem. The separate6G diagnostic's failed
preallocation and proposed8GiB retry margin are not ordinary prerequisites.
Preserve original failures; API35 boot and client readiness remain UNKNOWN.'''
    assert before.count(old) == 1
    after = before.replace(old, new_paragraph + '''

Initial SOURCE-reviewed subject7917/ee4f6fd75befec65807036058d589594438877b9968c7744abe58b0a385f5c47
and exact initial docs/DATA remain in `historicalinitial-source-review-r1/`.
This correction addresses coordinator-forwarded actual independent findings
QA-ORDINARY35-RESOURCE-DOC-001 and ORDINARY_API35_DISK_ADMISSION_DOCUMENTATION.
New bounded independent DOC/DATA acknowledgements remain pending. Unchanged
code review does not constitute approval of this corrected subject or runtime.''')
    path.write_text(after)
    doc_diffs.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
        fromfile=str(H / 'evidence/README.md'), tofile=str(path)))
    exclusive(E / 'resource-documentation.delta.diff', ''.join(doc_diffs).encode())

    current_sources = []
    for row in initial['sources']:
        current = pin(Path(row['path']))
        if Path(row['path']) not in (S / 'README.md', S / 'SUPERVISOR.md'):
            assert current == row
        current_sources.append(current)
    # Full original->current diff is refreshed, but historical original diff is exact.
    patches = []
    for row in current_sources:
        path = Path(row['path'])
        if path.is_relative_to(S):
            original = BASE / path.relative_to(S)
            if original.read_bytes() != path.read_bytes():
                patches.extend(difflib.unified_diff(original.read_text().splitlines(True), path.read_text().splitlines(True),
                    fromfile=str(original), tofile=str(path)))
    (E / 'source.diff').write_text(''.join(patches))
    checks = json.loads((E / 'static-checks.json').read_text())
    for row in checks['sourceProofs']:
        if row['relativePath'] in ('README.md', 'SUPERVISOR.md'):
            row['current'] = pin(S / row['relativePath'])
    checks['sourcePatch'] = pin(E / 'source.diff')
    checks['partitionFinding'] = 'Requested2048M/source6GiB floor unchanged; seven retained ordinary hardware-qemu.ini normalize6g. API35 no-install FATAL available7326.61MB need7372.80MB before guest/ADB. Coordinator requires fresh>=8GiB on actual output filesystem before ordinary grant as conservative margin, not measured minimum/guarantee; no source/cap/partition/health change.'
    checks['documentationCorrection'] = {'findings': FINDINGS, 'initialStaticChecks': pin(H / 'evidence/static-checks.json'),
        'coordinatorPrerequisite': prerequisite_pin, 'docDelta': pin(E / 'resource-documentation.delta.diff'),
        'other19SourceDescriptorsUnchanged': True, 'runtimeConfigUnchanged': True,
        'wholeModuleTypedAstProofsUnchanged': True, 'testsOrRuntimeExecuted': False}
    (E / 'static-checks.json').write_bytes(jsonbytes(checks))
    subject = dict(initial)
    subject.update(state='WRITES_STOPPED_PENDING_BOUNDED_DOC_DATA_REVIEW_ACK', sources=current_sources,
        staticChecks=pin(E / 'static-checks.json'), sourceDiff=pin(E / 'source.diff'),
        initialReviewedSubject=pin(H / 'evidence/subject.json'),
        initialHistory=pin(H / 'preservation-manifest.json'),
        coordinatorResourcePrerequisite=prerequisite_pin,
        documentationCorrectionSource=pin(Path(__file__).resolve()),
        documentationDelta=pin(E / 'resource-documentation.delta.diff'))
    subject['mandatoryPending'][0] = 'Actual bounded independent QA/security acknowledgements of DOC/DATA delta; unchanged code source review carries only for verified unchanged descriptors.'
    subject['preparationSourceMeaning'] = 'Initial SOURCE generator retained unchanged for provenance; current DOC/DATA correction is described by documentationCorrectionSource and historicalinitial-source-review-r1.'
    (E / 'subject.json').write_bytes(jsonbytes(subject))
    plan = json.loads((E / 'execution-plan.json').read_text())
    plan['subject'] = pin(E / 'subject.json')
    plan['prerequisites'][0] = 'Actual bounded independent QA/security DOC/DATA acknowledgements of corrected subject; original code review carries only for verified unchanged source descriptors, not as new approval.'
    plan['prerequisites'][3] = 'Before ordinary grant require fresh measured free disk>=8GiB on actual output filesystem, hash-bound into coordinator grant/release. Conservative margin, not measured minimum/guarantee. Original requested2048M and source6GiB admission unchanged; all seven retained old ordinary hardware files normalize6g.'
    plan['coordinatorResourcePrerequisite'] = prerequisite_pin
    plan['documentationCorrection'] = {'findings': FINDINGS, 'initialPlan': pin(H / 'evidence/execution-plan.json'),
        'codeConfigControlsChanged': False, 'actualControlsExecuted': False, 'deltaIndependentAcknowledgements': 'PENDING_ACTUAL_OTHER_AGENTS'}
    (E / 'execution-plan.json').write_bytes(jsonbytes(plan))
    assert pin(E / 'proposed-run-config.json') == initial['configuration']
    for row in current_sources:
        assert pin(Path(row['path'])) == row
    exclusive(E / 'resource-doc-correction-execution.json', jsonbytes({
        'schema': 'e02-ordinary-api35-resource-doc-correction-execution-v1',
        'author': '/root/ordinary_api35_source', 'scope': 'DOC/DATA only',
        'initialSubject': pin(H / 'evidence/subject.json'), 'currentSubject': pin(E / 'subject.json'),
        'delta': pin(E / 'resource-documentation.delta.diff'), 'configurationUnchanged': initial['configuration'],
        'findingsAddressedByAuthorPendingIndependentAck': FINDINGS,
        'other19Of21SourceDescriptorsUnchanged': True,
        'functionsLogicConfigTestsOriginalsChanged': False,
        'controlsAndroidSdkNodeDockerInstallGrantLeaseReleaseActions': 0,
        'historicalNegativeSerializationEvidencePreserved': pin(E / 'static-preparation-failure-r1/failure.json'),
        'reviewAcknowledgements': 'NOT_CREATED_OR_CLAIMED_BY_AUTHOR',
        'writes': 'STOPPED_AFTER_THIS_RECEIPT_AND_MANIFEST'}))
    (E / 'artifact-manifest.json').write_bytes(jsonbytes({
        'schema': 'e02-ordinary-api35-preparation-artifact-manifest-v1',
        'subject': pin(E / 'subject.json'),
        'artifacts': [pin(p) for p in sorted(E.rglob('*')) if p.is_file() and p != E / 'artifact-manifest.json'],
        'limits': 'DOC/DATA correction only. No self hash, controls, new independent approval or runtime authority.'}))
    print(json.dumps({'state': 'WRITES_STOPPED', 'subject': pin(E / 'subject.json'),
        'configUnchanged': pin(E / 'proposed-run-config.json'),
        'docDelta': pin(E / 'resource-documentation.delta.diff'),
        'coordinatorPrerequisite': prerequisite_pin, 'executionPlan': pin(E / 'execution-plan.json'),
        'staticChecks': pin(E / 'static-checks.json'), 'other19SourcesUnchanged': True,
        'runtimeCodeConfigTestsChanged': False, 'controlsExecuted': False}))


if __name__ == '__main__':
    main()
