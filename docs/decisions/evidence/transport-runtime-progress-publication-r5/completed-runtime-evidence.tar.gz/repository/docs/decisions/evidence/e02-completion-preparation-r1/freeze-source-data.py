"""Owned SOURCE/DATA freeze; no project imports, tests, crypto/native or services."""
from pathlib import Path
import difflib
import hashlib
import json
import os

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP');EXP=ROOT/'experiments'
P=EXP/'prototypes/e02_completion_v1';E=ROOT/'docs/decisions/evidence/e02-completion-preparation-r1'
C=ROOT/'docs/decisions/evidence/e02-ordinary-minimum-consumer-preparation-r2'
PRODUCER=ROOT/'docs/decisions/evidence/e02-ordinary-minimum-preparation-r1/subject.json'

def pin(p):
    p=Path(p);b=p.read_bytes()
    if p.resolve()!=p or p.is_symlink():raise ValueError('Canonical input')
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def write(p,v):
    p=Path(p);p.write_text(v if type(v) is str else json.dumps(v,indent=2)+'\n');p.chmod(0o600)

def check(d):
    if pin(d['path'])!=d:raise ValueError('Pinned input changed:'+d['path'])

# Immutable read-only provenance: source snapshots, not experimental executions.
e01=json.loads((EXP/'results/E01.json').read_text())
e02=json.loads((EXP/'results/E02.json').read_text())
fixture=json.loads((EXP/'prototypes/e02_ordinary_minimum_v1/fixture-plan.json').read_text())
consumer=json.loads((C/'subject.json').read_text())
old_producer=json.loads(PRODUCER.read_text())
originals=[pin(EXP/'results/E01.json'),pin(EXP/'results/E02.json'),pin(EXP/'fixtures/generated/E02-bidirectional-wires.json'),*[pin(EXP/n) for n in e01['source_sha256']],*[pin(EXP/n) for n in e02['source_sha256']],*old_producer['sources'],*consumer['sources']]
originals=list({d['path']:d for d in originals}.values())
for d in originals:check(d)
write(E/'protected-inputs-before.json',{'schema':'e02-completion-protected-input-snapshot-v1','files':originals,'sourceOnly':True})
source19=[pin(EXP/n) for n in e01['source_sha256']]
if len(source19)!=19 or {str(Path(d['path']).relative_to(EXP)):d['sha256'] for d in source19}!=e01['source_sha256']:raise ValueError('E01 current19')
deps=[{'path':d['source'],'bytes':d['bytes'],'sha256':d['sha256']} for d in fixture['dependencyFiles']]
if len(deps)!=816:raise ValueError('Installed dependency inventory')
for d in deps:check(d)
profile={'schema':'e02-completion-profile-v1','e01':pin(EXP/'results/E01.json'),'e01Sources':source19,'primarySources':[pin(EXP/'e02-validation/test.mjs'),pin(EXP/'shared/evidence.mjs'),pin(EXP/'docker/proxy.mjs')],'integrationSources':[pin(P/n) for n in ('data.mjs','runner.mjs','test_data.mjs','CONTRACT.md','README.md')],'dependencies':deps,'node':pin('/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node'),'python':pin('/home/peterhorvath/.miniforge3/bin/python3.13'),'timeout':pin('/usr/bin/timeout'),'rustBinary':{'path':fixture['pins']['rustBinary']['source'],'bytes':fixture['pins']['rustBinary']['bytes'],'sha256':fixture['pins']['rustBinary']['sha256']},'consumerSubject':pin(C/'subject.json'),'consumerSources':consumer['sources'],'consumerControlCapture':pin(C/'current-controls-r1/capture-controls.py'),'consumerControlResult':pin(C/'current-controls-r1/results-r1/subject.json'),'producerSubject':pin(PRODUCER),'adoption':pin(ROOT/'docs/decisions/evidence/e02-ordinary-minimum-profile-proposal-r1/coordinator-adoption.json'),'relayImages':['sha256:d72c7eb4e19562e22c24924ea51bc345ea5d22d03ada1429a46e0bb90ea97d40','sha256:fe586a0bc68edefb553a62d21983de469128f7cb785bfcc2ef7c82dbf1cded82'],'relayConfigs':[pin(EXP/'docker/strfry.conf'),pin(EXP/'docker/rs-relay.toml')],'protectedArtifacts':[pin(EXP/'results/E01.json'),pin(EXP/'results/E02.json'),pin(EXP/'fixtures/generated/E02-bidirectional-wires.json')]}
write(P/'profile.json',profile)
write(P/'run-config-template.json',{'schema':'e02-completion-run-config-template-v1','effectiveRunConfigMaterialized':False,'futureSchema':'e02-completion-run-config-v1','runId':None,'operator':None,'createdAtUtcMillis':None,'outputRoot':None,'environment':None,'ordinaryManifest':None,'ordinaryOrigin':None,'readRoots':[],'sourceSubject':None,'consumerControls':None,'note':'Nonexecutable SOURCE template; actual complete ordinary graph/current relay receipts/control acceptance/root releases required.'})
write(E/'interface-mapping.json',{'schema':'e02-completion-existing-interface-mapping-v1','primaryExecute':pin(EXP/'e02-validation/test.mjs'),'originalEvidence':pin(EXP/'shared/evidence.mjs'),'unusedStockWriter':pin(EXP/'shared/run.mjs'),'unchangedMethods':['check','equal','truth','skip','finish','observations'],'onlyOverride':'Evidence instance.save -> exact one fresh exclusive E02-bidirectional-wires.json; original class file unchanged.','primary22Names':[t['name'] for t in e02['tests']],'literalSkipRetained':e02['skipped'],'literalObservationRetained':e02['observations'],'consumerSource':profile['consumerSubject'],'actualConsumerControlCaptureSource':profile['consumerControlCapture'],'actualConsumerControlResultNotAcceptance':profile['consumerControlResult'],'nativeControlFieldNames':['stdoutEOF','stderrEOF','sourceUnchanged','firstError','secondaryErrors','captureMatched','controlResultAcceptedByAuthor'],'remainingAdapter':'Root must supply actual nonauthor/nonoperator control-result acceptance origin, complete actual minimum manifest/origin and primary original tool receipt. No such future data is fabricated.','primaryRpcLimit':'Original RustClient ready/source echo and stdin-close semantics, no explicit native wait receipt; actual natural external Node exit0 required, fixed GNU timeout makes nonzero/expiry unqualified.','stockGateEffect':'NONE_CANONICAL_PARTIAL_AND449PIN_GRAPHS_UNTOUCHED'})
write(E/'full-source.diff',''.join(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=str(p))) for p in sorted(P.iterdir()) if p.is_file()))
write(E/'control-plan.json',{'schema':'e02-completion-targeted-data-control-plan-v1','state':'PREPARED_NOT_RUN_PENDING_ACTUAL_INDEPENDENT_SOURCE_REVIEW_AND_ROOT_RELEASE','author':'/root/ordinary_api35_source','argv':[profile['node']['path'],str(P/'test_data.mjs')],'plannedChecks':54,'scope':'SYNTHETIC_PRIMARY_SKIP_ORDINARY_WIRE_REVIEW_JSON_DATA_ONLY','timeoutSeconds':60,'rawRetentionBytes':{'stdout':1048576,'stderr':262144},'retentionMeaning':'Post-capture refusal/retention, not a streaming memory cap.','sourceInputs':[pin(p) for p in sorted(P.iterdir()) if p.is_file()],'node':profile['node'],'noCryptoNativeNetworkOrRunnerExecution':True,'negativeCoverage':['missing/duplicate/reordered/failed/typed primary check','unknown/demoted/filtered/rewritten mandatory skip','rewritten original observation/raw status','ordinary incomplete count/origin/canonical/gate claim','wire role/recipient/whole shared rumor/report frame mismatch','duplicate/escaped JSON keys/nonfinite/negative zero/depth','missing/author/operator/same-session/wrong-subject/finding/boolean review'],'limits':['Synthetic positive summaries are explicitly not authenticated real evidence.','No positive whole primary/consumer/integration runtime graph is executed or claimed.','Actual consumer86 is a separate other-agent completed DATA scope, pending actual result acceptance when inspected; not execution by this task.'],'laterRuntimeCommands':{'prefix':profile['timeout']['path']+' --signal=TERM --kill-after=3s 1800s '+profile['node']['path']+' '+str(P/'runner.mjs'),'primary':'primary CONFIG CONFIG_SHA ROOT_PRIMARY_RELEASE RELEASE_SHA NONE NONE /tmp/nbdp-e02-completion-v1/runs/RUNID/primary','candidate':'candidate CONFIG CONFIG_SHA ROOT_CANDIDATE_RELEASE RELEASE_SHA PRIMARY_SUBJECT PRIMARY_SHA /tmp/nbdp-e02-completion-v1/runs/RUNID/candidate','finalize':'finalize CONFIG CONFIG_SHA ROOT_FINAL_RELEASE RELEASE_SHA CANDIDATE CANDIDATE_SHA /tmp/nbdp-e02-completion-v1/runs/RUNID/finalize'},'noEffectiveConfigOrGrantCreated':True})
write(E/'README.md','''# External E02 completion SOURCE preparation r1

Owned prefixes only: e02_completion_v1 and this preparation directory. The original
primary/Evidence/shared runner/results/generated fixtures, minimum producer,
consumer-v2 and independent E06 work remain read only. Protected pins before and
after are explicit. No canonical status, dependency or blocker is changed.

The external runner preserves raw original22 PARTIAL/mandatory skip/observations,
then composes exactly the known ordinary criterion using actual accepted whole
minimum evidence and real consumer-v2 inspection. Finalize requires actual
same-candidate nonauthor QA/security and DATA reinspection. Stock E04/E06 fixed
inputs remain unchanged and locked by their existing gates.

Exact source/interface mapping, full new-source diff, profile, nonexecutable
config template and54 prepared targeted DATA definitions are available. No tests,
imports, crypto/native, relay, services, leases, grants or completion ran in this
task. Static Node --check only is separately recorded as syntax, never test PASS.

Other-agent consumer86 raw result is pinned as current source-interface evidence,
not self-approved acceptance. Its actual independent acceptance adapter, complete
actual role windows/history/origins/current primary runtime witnesses and exact
root releases remain future inputs. Original tool API responses are preserved
separately from process journals; no portable Popen attestation is invented.
GNU timeout uses an existing pinned tool, with nonzero/expiry always unqualified.
Actual whole graph source/control/runtime reviews remain necessary.
''')
for d in originals:check(d)
write(E/'protected-inputs-after.json',{'schema':'e02-completion-protected-input-snapshot-v1','files':originals,'sourceOnly':True})
write(E/'preparation-execution.json',{'schema':'e02-completion-source-preparation-record-v1','actor':'/root/ordinary_api35_source','actions':['Read canonical E02/current project state and exact original primary/Evidence/Rust/relay/consumer/control-capture interfaces.','Write only newly delegated source/docs and stdlib hashes/JSON/source diff.','Pin raw actual other-agent consumer86 result without acceptance claim.','Static Node --check syntax only; no module imports/evaluation or tests.'],'syntaxOriginalReceipts':pin(E/'syntax-only-original-tool-receipts.json'),'testsExecuted':0,'experimentsExecuted':0,'primaryExecuted':False,'consumerExecutedByThisTask':False,'independentSourceQaSecurity':'PENDING_ACTUAL_OTHER_AGENTS','noEffectiveConfigGrantOrApprovalWritten':True,'script':pin(Path(__file__).resolve())})
sources=[pin(p) for p in sorted(P.iterdir()) if p.is_file()]
artifacts=[pin(p) for p in sorted(E.iterdir()) if p.is_file() and p.name not in ('subject.json','artifact-manifest.json')]
write(E/'subject.json',{'schema':'e02-completion-source-subject-v1','author':'/root/ordinary_api35_source','coordinator':'/root','state':'WRITES_STOPPED_SOURCE_ONLY_PENDING_ACTUAL_INDEPENDENT_QA_SECURITY','sources':sources,'sourcePreparationArtifacts':artifacts,'originalPrimaryExecute':profile['primarySources'][0],'originalEvidence':profile['primarySources'][1],'consumerSubject':profile['consumerSubject'],'producerSubject':profile['producerSubject'],'adoption':profile['adoption'],'consumer86RawResultNotAcceptance':profile['consumerControlResult'],'sourceProfile':pin(P/'profile.json'),'contract':pin(P/'CONTRACT.md'),'controlPlan':pin(E/'control-plan.json'),'preparedSyntheticDataChecks':54,'executedSyntheticDataChecks':0,'runtimeExecuted':False,'effectiveConfigOrRootReleaseMaterialized':False,'originalInputsUnchanged':True,'canonicalE02':'PARTIAL22_UNCHANGED','stockE04E06Unlocked':False,'architecturalBlockersUnchanged':['Q01','Q08','Q13','Q15','Q27'],'remainingInputs':['Actual independent SOURCE/control review and54 DATA execution/result acceptance.','Root authenticated exact consumer86 result acceptance adapter.','Actual complete minimum two-role graph/origin plus genuine source/control/history/window reviews.','Actual fresh isolated primary relay environment and original outer launch/completion receipts.','Actual same-candidate independent QA/security before any external completion PASS.','Separate approved fixed canonical E04/E06 prerequisite integration; this source does not change449 historical pins or gates.']})
write(E/'artifact-manifest.json',{'schema':'e02-completion-source-artifact-manifest-v1','files':[pin(p) for p in sorted(E.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'],'excludesSelf':True})
for root in (P,E):
    for p in root.iterdir():
        if p.is_file():p.chmod(0o600)
print(json.dumps({'state':'WRITES_STOPPED','subject':pin(E/'subject.json'),'profile':pin(P/'profile.json'),'contract':pin(P/'CONTRACT.md'),'controlPlan':pin(E/'control-plan.json'),'sourceDiff':pin(E/'full-source.diff'),'protectedOriginals':len(originals),'actualOwnTestsExperiments':0},indent=2))
