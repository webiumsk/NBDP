"""SOURCE ONLY: modeled guard faults. No process, strace or Node is launched.

Fake proc identities/pidfds model safety ownership, not actual kernel semantics.
These regressions do not count among the7 actual pinned-strace cases.
"""
from pathlib import Path
import importlib.util,json,os,signal,subprocess,sys,types,unittest
from unittest.mock import patch,MagicMock
HERE=Path(__file__).resolve().parent
OUT=HERE/'pure-guard-actual-r1'
def module():
 spec=importlib.util.spec_from_file_location('guard_pure_fixture',HERE/'guard.py')
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def save(name,v):
 b=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(OUT/(name+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())

class GuardFaultControls(unittest.TestCase):
 def cleanup_model(self,kind):
  m=module();root=93000;pid=93001;state={'alive':True,'reaped':False};signals=[]
  row={'pid':pid,'ppid':root,'uid':os.getuid(),'starttime':123456,'session':pid,'cmdline':b'owned-synthetic-fixture\0'.hex()}
  owner=m.SafetyOwner(root,999999999999)
  handle=types.SimpleNamespace(pid=pid)
  def wait(timeout=0):
   self.assertFalse(state['alive']);self.assertFalse(state['reaped']);state['reaped']=True;return -9
  handle.wait=wait
  def census(*args):return [] if state['reaped'] else [dict(row)]
  def identity(p):
   self.assertEqual(p,pid)
   if state['reaped']:raise FileNotFoundError()
   return dict(row)
  def send(*args):
   self.assertFalse(state['reaped']);signals.append(args);state['alive']=False
  def waitid(*args):return None if state['alive'] else types.SimpleNamespace(si_pid=pid)
  def waitpid(p,flags):
   self.assertEqual(p,pid);self.assertFalse(state['alive']);state['reaped']=True;return pid,9
  def kids(p):return [pid] if p==root and not state['reaped'] else []
  pidfd_failure=OSError('SYNTHETIC_PIDFD_OPEN_FAILURE') if kind=='pidfd' else None
  with patch.object(m.subprocess,'Popen',return_value=handle),patch.object(m,'ancestry_tree',side_effect=census),\
       patch.object(m,'identity',side_effect=identity),patch.object(m,'children',side_effect=kids),\
       patch.object(m,'pidfd_open',side_effect=pidfd_failure,return_value=401),\
       patch.object(m.Path,'read_text',return_value='Pid:\t93001\n'),patch.object(m,'exited',side_effect=lambda fd:not state['alive']),\
       patch.object(m,'pidfd_send_signal',side_effect=send),patch.object(m.os,'kill',side_effect=send),\
       patch.object(m.os,'waitid',side_effect=waitid),patch.object(m.os,'waitpid',side_effect=waitpid),\
       patch.object(m.time,'sleep',return_value=None):
   if kind=='identity':
    with patch.object(owner,'census',side_effect=ValueError('SYNTHETIC_IDENTITY_FAILURE')):
     with self.assertRaises(ValueError):owner.launch(['synthetic-owned-fixture'])
    self.assertEqual(len(owner.handles),1)
   elif kind=='unregistered':owner.census()  # Actual descendant never had any ready JSON or registration.
   else:owner.launch(['synthetic-owned-fixture'])
   self.assertTrue(owner.cleanup());self.assertTrue(owner.fallback)
  self.assertTrue(state['reaped']);self.assertGreaterEqual(len(signals),1)
  self.assertTrue(all(v['reaped'] for v in owner.known.values()))
  self.assertTrue(all(not v['registered'] for v in owner.known.values()))
  save('cleanup-'+kind,{'model':'FAKE_KERNEL_NO_LIVE_PROCESSES','initial':row,'signals':signals,'events':owner.events,
    'faults':owner.faults,'fallbackAlwaysFail':owner.fallback,'reaped':state['reaped']})

 def test_01_Popen_failure_preserves_failure_and_runs_empty_census_cleanup(self):
  m=module();owner=m.SafetyOwner(93000,999999999999)
  with patch.object(m.subprocess,'Popen',side_effect=OSError('SYNTHETIC_POPEN_FAILURE')):
   with self.assertRaises(OSError):owner.launch(['synthetic'])
  self.assertEqual(owner.handles,[])
  with patch.object(m,'ancestry_tree',return_value=[]) as census,patch.object(m,'children',return_value=[]),patch.object(m.time,'sleep',return_value=None):
   self.assertTrue(owner.cleanup());self.assertGreaterEqual(census.call_count,2)
  self.assertTrue(owner.fallback);save('popen-failure',{'noHandleReturned':True,'completeEmptyCensusCleanup':True,'alwaysFail':True})
 def test_02_pidfd_failure_retains_actual_launch_handle_and_cleanup(self):self.cleanup_model('pidfd')
 def test_03_identity_failure_afterPopen_retains_handle_and_cleanup(self):self.cleanup_model('identity')
 def test_04_unregistered_descendant_is_censused_signalled_reaped_and_FAIL(self):self.cleanup_model('unregistered')
 def test_05_ready_ACK_write_failure_does_not_discard_owner(self):
  m=module();row={'pid':93001,'starttime':123};runner=types.SimpleNamespace(pid=93001)
  held={'identity':row};owner=types.SimpleNamespace(register=MagicMock(return_value=held));registered={}
  out=MagicMock();(out.__truediv__.return_value).exists.return_value=True
  with patch.object(m,'read',return_value={'pid':93001}),patch.object(m,'identity',return_value=row),\
       patch.object(m,'put',side_effect=OSError('SYNTHETIC_ACK_WRITE_FAILURE')):
   with self.assertRaises(OSError):m.process_registrations(out,owner,runner,'deadline',registered)
  self.assertIs(registered['runner'],held);owner.register.assert_called_once()
  save('ready-write-failure',{'registeredOwnerRetainedBeforeFailedACK':True,'fallbackRequired':True})
 def test_06_missing_registration_hits_absolute_ready_cutoff(self):
  m=module()
  with self.assertRaisesRegex(ValueError,'REGISTRATION_READY_DEADLINE'):m.enforce_times(0,3.01,False,None,None)
  save('missing-registration',{'now':3.01,'ready':False,'refused':True})
 def test_07_corrupt_registration_JSON_is_refused_without_cleanup_dependency(self):
  m=module();p=OUT/'corrupt-registration.json';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b'{"pid":93001,"pid":93002}\n')
  with self.assertRaisesRegex(ValueError,'DUPLICATE_METADATA_KEY'):m.read(p)
  save('corrupt-refused',{'duplicateReadyJSONRefused':True,'cleanupOwnershipIndependentOfJSON':True})
 def test_08_late_registration_remains_fail_even_if_then_present(self):
  m=module()
  with self.assertRaisesRegex(ValueError,'REGISTRATION_READY_DEADLINE'):m.enforce_times(0,3.5,False,None,None)
  save('late-registration',{'lateReadyAt':3.5,'refused':True})
 def test_09_late_capture_receipt_is_fail_despite_dead_tracees(self):
  m=module()
  with self.assertRaisesRegex(ValueError,'LATE_CAPTURE_RECEIPT'):m.enforce_times(0,7.1,True,7.1,7.2)
  save('late-capture',{'receipt':7.1,'absence':7.2,'refused':True})
 def test_10_selfexpiry_belowguard_and_lateabsence_both_refused(self):
  m=module()
  with patch.object(m,'FAULT_SELF_EXPIRY_SECONDS',8):
   with self.assertRaisesRegex(ValueError,'FAULT_LIFETIME_MUST_EXCEED_WHOLE_GUARD'):m.enforce_times(0,1,True,1,None)
  with self.assertRaisesRegex(ValueError,'LATE_OWNED_ABSENCE'):m.enforce_times(0,8,True,6,8)
  save('selfexpiry',{'old8sConfigurationRefused':True,'late8sAbsenceRefused':True,'newLifetime':m.FAULT_SELF_EXPIRY_SECONDS})
 def test_11_reaped_or_reused_identity_never_signalled(self):
  m=module();owner=m.SafetyOwner(93000,999999999999)
  v={'identity':{'pid':93001,'ppid':93000,'uid':os.getuid(),'starttime':123},'fd':None,'reaped':True}
  with patch.object(m.os,'kill') as kill,patch.object(m,'pidfd_send_signal') as send:
   with self.assertRaisesRegex(ValueError,'NO_POST_REAP_SIGNAL'):owner.send(v,signal.SIGKILL,'fixture')
   v['reaped']=False
   with patch.object(m,'identity',return_value={**v['identity'],'starttime':124}):
    with self.assertRaisesRegex(ValueError,'DIRECT_UNREAPED_FALLBACK_IDENTITY'):owner.send(v,signal.SIGKILL,'fixture')
   kill.assert_not_called();send.assert_not_called()
  v['fd']=401;owner.known={(93001,123):v}
  with patch.object(m,'identity',return_value={**v['identity'],'starttime':124}),patch.object(m,'exited',return_value=True),patch.object(m.os,'waitid') as waitid:
   owner.reap();waitid.assert_not_called();self.assertTrue(v['reaped'])
  save('no-reused-reaped-signals',{'bothRefused':True,'signals':0})


 def acquisition_rejection(self,kind):
  m=module();owner=m.SafetyOwner(93000,999999999999)
  row={'pid':93001,'ppid':93000,'uid':os.getuid(),'starttime':123,'session':93001,'cmdline':b'owned-fixture\0'.hex()}
  other={**row,'starttime':124} if kind=='reuse' else {**row,'uid':row['uid']+1}
  failure=OSError('SYNTHETIC_IDENTITY_EXCEPTION') if kind=='identity-exception' else ProcessLookupError('SYNTHETIC_IDENTITY_VANISHED')
  identities=[other] if kind in ('reuse','uid') else [dict(row),dict(row)]
  if kind in ('identity-exception','identity-vanished'):identities=[failure]
  fdinfo='Pid:\t-1\n' if kind=='fdinfo-mismatch' else 'Pid:\t93001\n'
  with patch.object(m,'ancestry_tree',return_value=[row]),patch.object(m,'pidfd_open',return_value=401),\
       patch.object(m,'identity',side_effect=identities),patch.object(m.Path,'read_text',return_value=fdinfo) as info,\
       patch.object(m.os,'close') as close,patch.object(m,'pidfd_send_signal') as signal_fd,patch.object(m.os,'kill') as numeric:
   if kind=='fdinfo-exception':info.side_effect=OSError('SYNTHETIC_FDINFO_EXCEPTION')
   owner.census();held=owner.known[(93001,123)]
   self.assertIsNone(held['fd']);self.assertTrue(held['acquisitionFailed']);self.assertTrue(owner.faults)
   close.assert_called_once_with(401)
   with self.assertRaisesRegex(ValueError,'REJECTED_ACQUISITION_NOT_SIGNALABLE'):owner.send(held,signal.SIGKILL,'synthetic')
   signal_fd.assert_not_called();numeric.assert_not_called();owner.close();close.assert_called_once_with(401)
  save('acquisition-'+kind,{'model':'SYNTHETIC_NO_REAL_PROCESS','initial':row,'fdCommitted':False,'closedProvisionalExactlyOnce':True,
   'signals':0,'events':owner.events,'firstFailure':owner.faults[0]})
 def test_12_open_returned_reusedPID_descriptor_is_closed_unsignalable(self):self.acquisition_rejection('reuse')
 def test_13_open_returned_changedUID_descriptor_is_closed_unsignalable(self):self.acquisition_rejection('uid')
 def test_14_identity_exception_or_vanished_afteropen_closes_without_signal(self):
  self.acquisition_rejection('identity-exception');self.acquisition_rejection('identity-vanished')
 def test_15_fdinfo_mismatch_or_exception_closes_without_signal(self):
  self.acquisition_rejection('fdinfo-mismatch');self.acquisition_rejection('fdinfo-exception')
 def test_16_persistentcensus_failure_still_kills_reapsknown_and_staysFAIL(self):
  m=module();root=93000;pid=93001;owner=m.SafetyOwner(root,.25)
  state={'alive':True,'reaped':False,'clock':0};signals=[]
  row={'pid':pid,'ppid':root,'uid':os.getuid(),'starttime':123,'session':pid,'cmdline':b'owned-fixture\0'.hex()}
  def wait(timeout=0):
   self.assertFalse(state['alive']);self.assertFalse(state['reaped']);state['reaped']=True;return -9
  handle=types.SimpleNamespace(pid=pid,wait=wait)
  def send(fd,sig,*args):
   self.assertEqual(fd,401);self.assertFalse(state['reaped']);signals.append({'pidfd':fd,'signal':int(sig)});state['alive']=False
  def clock():state['clock']+=.01;return state['clock']
  def identity(p):
   if state['reaped']:raise FileNotFoundError()
   return dict(row)
  with patch.object(m.subprocess,'Popen',return_value=handle),patch.object(m,'ancestry_tree',return_value=[row]) as census,\
       patch.object(m,'identity',side_effect=identity),patch.object(m,'children',side_effect=lambda p:[] if state['reaped'] else [pid]),\
       patch.object(m,'pidfd_open',return_value=401),patch.object(m.Path,'read_text',return_value='Pid:\t93001\n'),\
       patch.object(m,'exited',side_effect=lambda fd:not state['alive']),patch.object(m,'pidfd_send_signal',side_effect=send),\
       patch.object(m.os,'waitid',side_effect=lambda *a:None if state['alive'] else types.SimpleNamespace(si_pid=pid)),\
       patch.object(m.os,'kill') as numeric,patch.object(m.time,'monotonic',side_effect=clock),patch.object(m.time,'sleep',return_value=None),\
       patch.object(m.os,'close') as close:
   owner.launch(['synthetic-owned-child']);self.assertEqual(len(owner.handles),1)
   self.assertEqual(owner.known[(pid,123)]['fd'],401)
   census.side_effect=OSError('SYNTHETIC_PERSISTENT_CENSUS_FAILURE')
   self.assertFalse(owner.cleanup());self.assertTrue(owner.censusUncertain);self.assertTrue(owner.fallback)
   self.assertTrue(state['reaped']);self.assertEqual(signals,[{'pidfd':401,'signal':int(signal.SIGKILL)}]);numeric.assert_not_called()
   self.assertEqual(owner.faults[0]['message'],'SYNTHETIC_PERSISTENT_CENSUS_FAILURE')
   self.assertTrue(owner.handles[0]['reaped']);owner.close();close.assert_called_once_with(401)
  save('persistent-census-failure',{'model':'SYNTHETIC_NO_REAL_PROCESS','knownChildKilledAndReaped':True,'signals':signals,
    'completeAbsenceQualified':False,'censusUncertain':owner.censusUncertain,'fallbackAlwaysFail':owner.fallback,
    'events':owner.events,'firstFailure':owner.faults[0],'secondaryFailures':owner.faults[1:]})


 def adapter_module(self):
  spec=importlib.util.spec_from_file_location('pure_fake_libc_abi_adapter',HERE/'pidfd_adapter.py')
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
 def fake_abi(self,opening,sending):
  a=self.adapter_module()
  class Symbol:
   def __init__(self,fn):self.fn=fn;self.calls=[];self.argtypes=None;self.restype=None
   def __call__(self,*args):self.calls.append(args);return self.fn(*args)
  library=types.SimpleNamespace(pidfd_open=Symbol(opening),pidfd_send_signal=Symbol(sending))
  return a,a.PidfdABI(library),library
 def test_17_explicit_C_signatures_NULL_flags0_success_with_FAKE_symbols(self):
  a,api,lib=self.fake_abi(lambda pid,flags:401,lambda fd,sig,info,flags:0)
  self.assertEqual(lib.pidfd_open.argtypes,[a.ctypes.c_int,a.ctypes.c_uint]);self.assertIs(lib.pidfd_open.restype,a.ctypes.c_int)
  self.assertEqual(lib.pidfd_send_signal.argtypes,[a.ctypes.c_int,a.ctypes.c_int,a.ctypes.c_void_p,a.ctypes.c_uint])
  self.assertIs(lib.pidfd_send_signal.restype,a.ctypes.c_int)
  self.assertEqual(api.open(93001),401);self.assertIsNone(api.send(401,signal.SIGKILL))
  self.assertEqual(lib.pidfd_open.calls,[(93001,0)]);self.assertEqual(lib.pidfd_send_signal.calls,[(401,9,None,0)])
  self.assertEqual(api.calls,{'open':1,'send':1});self.assertIsNone(api.binding)
  save('abi-success',{'FAKE_SYMBOLS_ONLY':True,'signaturesExplicit':True,'NULLinfoFlags0':True,'actualPidfdCalls':0})
 def test_18_open_C_errno_is_preserved_without_retry_with_FAKE_symbol(self):
  import ctypes,errno
  def opening(pid,flags):ctypes.set_errno(errno.ESRCH);return -1
  a,api,lib=self.fake_abi(opening,lambda *args:0);ctypes.set_errno(errno.EPERM)
  with self.assertRaises(ProcessLookupError) as error:api.open(93001)
  self.assertEqual(error.exception.errno,errno.ESRCH);self.assertEqual(len(lib.pidfd_open.calls),1)
  self.assertEqual(lib.pidfd_send_signal.calls,[])
  save('abi-open-errno',{'FAKE_SYMBOLS_ONLY':True,'expectedErrno':errno.ESRCH,'actualErrno':error.exception.errno,'attempts':1,'actualPidfdCalls':0})
 def test_19_send_C_errno_is_preserved_without_retry_with_FAKE_symbol(self):
  import ctypes,errno
  def sending(*args):ctypes.set_errno(errno.EPERM);return -1
  a,api,lib=self.fake_abi(lambda *args:401,sending)
  with self.assertRaises(PermissionError) as error:api.send(401,signal.SIGKILL)
  self.assertEqual(error.exception.errno,errno.EPERM);self.assertEqual(len(lib.pidfd_send_signal.calls),1)
  self.assertEqual(lib.pidfd_open.calls,[])
  save('abi-send-errno',{'FAKE_SYMBOLS_ONLY':True,'expectedErrno':errno.EPERM,'actualErrno':error.exception.errno,'attempts':1,'actualPidfdCalls':0})
 def test_20_bad_flags_types_NULL_profile_returns_or_missingerrno_refuse_with_FAKE_symbols(self):
  import ctypes
  a,api,lib=self.fake_abi(lambda *args:401,lambda *args:0)
  for action in [lambda:api.open(True),lambda:api.open(2147483648),lambda:api.open(93001,1),
    lambda:api.send(401,9,object()),lambda:api.send(401,9,None,1)]:
   with self.assertRaises(ValueError):action()
  self.assertEqual(lib.pidfd_open.calls,[]);self.assertEqual(lib.pidfd_send_signal.calls,[])
  a,badopen,_=self.fake_abi(lambda *args:-2,lambda *args:0)
  with self.assertRaises(ValueError):badopen.open(93001)
  a,badsend,_=self.fake_abi(lambda *args:401,lambda *args:1)
  with self.assertRaises(ValueError):badsend.send(401,9)
  a,noerrno,_=self.fake_abi(lambda *args:-1,lambda *args:-1)
  with self.assertRaisesRegex(ValueError,'PIDFD_OPEN_ERRNO_REQUIRED'):noerrno.open(93001)
  with self.assertRaisesRegex(ValueError,'PIDFD_SEND_ERRNO_REQUIRED'):noerrno.send(401,9)
  save('abi-invalid-inputs-results',{'FAKE_SYMBOLS_ONLY':True,'invalidInputsRefusedBeforeFakeCall':5,'invalidReturnBranches':2,'missingErrnoBranches':2,'actualPidfdCalls':0})

 def temporal_model(self,kind):
  from contextlib import ExitStack
  m=module();root=93000;owner=m.SafetyOwner(root,999999999999)
  rows=[{'pid':p,'ppid':root,'uid':os.getuid(),'starttime':p+100,'session':p,'cmdline':b'owned-fixture\0'.hex()} for p in range(93001,93007)]
  for i,row in enumerate(rows):
   held={'identity':row,'fd':401+i,'registered':i<5,'reaped':False,'acquisitionFailed':False}
   owner.known[m.key(row)]=held;owner.events.append({'operation':'held-validated-owned-descendant','identity':row,'pidfd':401+i})
  extra=owner.known[m.key(rows[-1])];original=dict(extra);initial_keys=list(owner.known)
  current=rows[:-1];observed=None;proc_state=None;wait=types.SimpleNamespace(si_pid=93006,si_code=os.CLD_EXITED,si_status=0)
  if kind in ('zombie-wait','zombie-ECHILD','wait-missing'):
   current=rows;observed=rows[-1];proc_state='Z'
  if kind=='reuse':observed={**rows[-1],'starttime':999999,'uid':os.getuid()+1}
  with ExitStack() as stack:
   stack.enter_context(patch.object(owner,'census',return_value=current))
   census=stack.enter_context(patch.object(m,'strict_ready_census',return_value=current))
   dead=stack.enter_context(patch.object(m,'exited',return_value=True))
   info=stack.enter_context(patch.object(m,'ready_fdinfo',return_value={'pid':93006 if observed==rows[-1] else -1,'raw':'Pid:\t'+str(93006 if observed==rows[-1] else -1)+'\n'}))
   ident=stack.enter_context(patch.object(m,'ready_current_identity',return_value=observed))
   stack.enter_context(patch.object(m,'ready_proc_state',return_value=proc_state))
   waitid=stack.enter_context(patch.object(m.os,'waitid',return_value=wait))
   send=stack.enter_context(patch.object(m,'pidfd_send_signal'))
   numeric=stack.enter_context(patch.object(m.os,'kill'));reap=stack.enter_context(patch.object(m.os,'waitpid'))
   if kind=='zombie-ECHILD':waitid.side_effect=ChildProcessError('SYNTHETIC_NONCHILD')
   if kind=='live':dead.return_value=False
   if kind=='missing-fd':extra['fd']=None
   if kind=='acquisition-failed':extra['acquisitionFailed']=True
   if kind=='uncertain-exit':dead.side_effect=OSError('SYNTHETIC_PIDFD_UNCERTAIN')
   if kind=='bad-fdinfo':info.return_value={'pid':99999,'raw':'Pid:\t99999\n'}
   if kind=='identity-error':ident.side_effect=OSError('SYNTHETIC_IDENTITY_UNCERTAIN')
   if kind=='wait-missing':waitid.return_value=None
   if kind=='census-uncertain':owner.censusUncertain=True
   if kind=='census-error':census.side_effect=OSError('SYNTHETIC_CENSUS_INCOMPLETE')
   if kind=='census-drift':census.side_effect=[current,[]]
   expected_failure=kind not in ('absent','zombie-wait','zombie-ECHILD','reuse','new-after')
   if expected_failure:
    with self.assertRaises((ValueError,OSError)):m.prepare_ready_boundary(owner)
    proof=None
   else:
    proof=m.prepare_ready_boundary(owner)
    self.assertEqual(len(proof['historicalTerminal']),1)
    self.assertTrue(proof['historicalTerminal'][0]['pidfdExitedBefore'])
    self.assertEqual(list(owner.known),initial_keys);self.assertFalse(extra['registered']);self.assertFalse(extra['reaped'])
    self.assertEqual(extra,original);self.assertFalse(owner.fallback)
    if kind=='new-after':
     unknown={'identity':{**rows[-1],'pid':94000,'starttime':777},'fd':999,'registered':False,'reaped':False,'acquisitionFailed':False}
     owner.known[m.key(unknown['identity'])]=unknown
     with self.assertRaisesRegex(ValueError,'NEW_UNREGISTERED_OWNED_DESCENDANT_AFTER_READY'):m.enforce_after_ready(owner,proof,[])
    else:m.enforce_after_ready(owner,proof,current)
   if kind in ('absent','reuse'):waitid.assert_not_called()
   send.assert_not_called();numeric.assert_not_called();reap.assert_not_called()
  save('temporal-'+kind,{'model':'FAKE_KERNEL_NO_LIVE_PROCESSES','kind':kind,'expectedFailure':expected_failure,
   'readyProof':proof,'registrationOrReapFabricated':False,'actualSignals':0,'actualPidfdCalls':0,
   'newAfterReadyRefused':kind=='new-after'})
  return proof
 def test_21_preREADY_exited_transient_needs_explicit_terminal_evidence_without_fakeACK(self):
  for kind in ('absent','zombie-wait','zombie-ECHILD'):
   with self.subTest(kind=kind):self.temporal_model(kind)
 def test_22_still_live_unregistered_atREADY_refuses(self):self.temporal_model('live')
 def test_23_new_unregistered_afterREADY_refuses_even_if_exited(self):self.temporal_model('new-after')
 def test_24_missing_uncertain_acquisition_exit_identity_reap_or_census_refuses(self):
  for kind in ('missing-fd','acquisition-failed','uncertain-exit','bad-fdinfo','identity-error','wait-missing','census-uncertain','census-error','census-drift'):
   with self.subTest(kind=kind):self.temporal_model(kind)
  # Exercise the strict traversal itself; skipped/raced parentage is not a complete READY sample.
  m=module();owner=m.SafetyOwner(93000,999999999999)
  with patch.object(m,'children',return_value=[93001]),patch.object(m,'identity',side_effect=FileNotFoundError()):
   with self.assertRaises(FileNotFoundError):m.strict_ready_census(owner)
  save('strict-census-vanished-refused',{'model':'FAKE_KERNEL','vanishedDuringTraversalRefused':True})
 def test_25_PIDreuse_terminal_proof_never_waits_signals_or_reaps_replacement(self):
  proof=self.temporal_model('reuse')
  self.assertEqual(proof['historicalTerminal'][0]['reapStatus'],'ORIGINAL_REAPED_PID_REUSED')

 def diagnostic_rejection(self,kind,field=None):
  from contextlib import ExitStack
  m=module();root=93000;pid=93001;uid=os.getuid()
  before={'pid':pid,'ppid':root,'uid':uid,'starttime':123,'session':pid,'cmdline':b'owned-synthetic-fixture\0'.hex()}
  other=dict(before)
  if field:other[field]=other[field]+1 if type(other[field]) is int else other[field]+'00'
  if kind=='long-command':
   before['cmdline']='ab'*12000;other={**before,'cmdline':before['cmdline'][:-2]+'cd'}
  owner=m.SafetyOwner(root,999999999999,diagnostic_guard_uid_admission=uid)
  if kind in ('sink-failure','persistent-sink-failure'):
   class FailingSink(list):
    def append(self,event):
     if kind=='persistent-sink-failure' or event['operation']=='rejected-custody-diagnostic':
      raise OSError('SYNTHETIC_DIAGNOSTIC_SINK_WRITE_FAILURE')
     return super().append(event)
   owner.events=FailingSink()
  if kind in ('sink-failure','persistent-sink-failure','bound-failure'):other={**before,'cmdline':before['cmdline']+'00'}
  if kind in ('first-read-error','open-error','fdinfo-error','fdinfo-mismatch','second-read-error','uid-operand','uid-read-error'):other=dict(before)
  first_error=OSError('SYNTHETIC_FIRST_IDENTITY_READ_ERROR')
  second_error=OSError('SYNTHETIC_SECOND_IDENTITY_READ_ERROR')
  sequence=[other]
  if kind=='first-read-error':sequence=[first_error]
  if kind in ('final-mismatch','second-read-error'):sequence=[dict(before),other if kind=='final-mismatch' else second_error]
  fdinfo='Pid:\t99999\n' if kind=='fdinfo-mismatch' else 'Pid:\t93001\n'
  expected_id_reads=2 if kind in ('final-mismatch','second-read-error') else 0 if kind=='open-error' else 1
  expected_fdinfo_reads=1 if kind in ('final-mismatch','second-read-error','fdinfo-error','fdinfo-mismatch') else 0
  with ExitStack() as stack:
   stack.enter_context(patch.object(m,'ancestry_tree',return_value=[dict(before)]))
   opened=stack.enter_context(patch.object(m,'pidfd_open',return_value=401))
   identities=stack.enter_context(patch.object(m,'identity',side_effect=sequence))
   read=stack.enter_context(patch.object(m.Path,'read_text',return_value=fdinfo))
   guarduid=stack.enter_context(patch.object(m.os,'getuid',return_value=uid+1 if kind=='uid-operand' else uid))
   close=stack.enter_context(patch.object(m.os,'close'))
   signal_fd=stack.enter_context(patch.object(m,'pidfd_send_signal'));numeric=stack.enter_context(patch.object(m.os,'kill'))
   if kind=='open-error':opened.side_effect=OSError('SYNTHETIC_OPEN_ERROR')
   if kind=='fdinfo-error':read.side_effect=OSError('SYNTHETIC_EXISTING_FDINFO_READ_ERROR')
   if kind=='uid-read-error':guarduid.side_effect=OSError('SYNTHETIC_ORIGINAL_UID_READ_ERROR')
   if kind=='bound-failure':stack.enter_context(patch.object(m,'DIAGNOSTIC_EVENT_BYTES',8))
   owner.census();held=owner.known[(pid,123)]
   self.assertIsNone(held['fd']);self.assertTrue(held['acquisitionFailed']);self.assertTrue(owner.faults)
   self.assertEqual(identities.call_count,expected_id_reads);self.assertEqual(read.call_count,expected_fdinfo_reads)
   uid_evaluated=kind in ('final-mismatch','second-read-error','fdinfo-error','fdinfo-mismatch','uid-operand','uid-read-error')
   self.assertEqual(guarduid.call_count,1 if uid_evaluated else 0)
   self.assertEqual(close.call_args_list,[] if kind=='open-error' else [unittest.mock.call(401)])
   original=owner.faults[0]
   with self.assertRaisesRegex(ValueError,'REJECTED_ACQUISITION_NOT_SIGNALABLE'):owner.send(held,signal.SIGKILL,'synthetic')
   signal_fd.assert_not_called();numeric.assert_not_called();owner.close()
   self.assertEqual(close.call_count,0 if kind=='open-error' else 1)
  diagnostics=[e['evidence'] for e in owner.events if e['operation']=='rejected-custody-diagnostic']
  unavailable=[e for e in owner.events if e['operation']=='rejected-custody-diagnostic-unavailable']
  if kind in ('bound-failure','sink-failure','persistent-sink-failure'):
   self.assertEqual(diagnostics,[]);self.assertTrue(len(owner.faults)>1)
   if kind!='persistent-sink-failure':self.assertEqual(len(unavailable),1)
   self.assertEqual(original['message'],'PIDFD_FULL_IDENTITY_UID_BEFORE_CUSTODY')
  else:
   self.assertEqual(len(diagnostics),1);d=diagnostics[0]
   self.assertEqual(d['guardUIDAtAdmission']['value'],uid)
   self.assertEqual(d['guardUIDAtOriginalPredicate']['value'],uid+1 if kind=='uid-operand' else uid if uid_evaluated and kind!='uid-read-error' else None)
   self.assertEqual(d['postOpen']['status'],'NOT_COLLECTED' if kind in ('first-read-error','open-error') else 'COLLECTED')
   self.assertEqual(d['postFdinfo']['status'],'COLLECTED' if kind=='final-mismatch' else 'NOT_COLLECTED')
   self.assertEqual(d['fdinfo']['status'],'COLLECTED' if kind in ('final-mismatch','second-read-error','fdinfo-mismatch') else 'NOT_COLLECTED')
   if kind in ('first-mismatch','long-command'):
    self.assertEqual(d['censusVsPostOpen']['differingFieldNames'],[field or 'cmdline'])
    self.assertEqual(d['guardUIDAtOriginalPredicate']['status'],'NOT_EVALUATED_SHORT_CIRCUIT_OR_EARLIER_STAGE')
   if kind=='final-mismatch':self.assertEqual(d['postOpenVsPostFdinfo']['differingFieldNames'],[field])
   if kind in ('first-read-error','second-read-error','fdinfo-error','open-error','uid-read-error'):
    self.assertEqual(d['originalException']['messagePrefix'],original['message'])
   if kind=='uid-read-error':self.assertEqual(d['guardUIDAtOriginalPredicate']['status'],'GETUID_RAISED_BEFORE_VALUE_COLLECTED')
   self.assertLessEqual(len(json.dumps(d).encode()),m.DIAGNOSTIC_EVENT_BYTES)
   if kind=='long-command':
    self.assertFalse(d['censusBefore']['cmdline']['complete']);self.assertFalse(d['postOpen']['cmdline']['complete'])
    self.assertEqual(d['censusBefore']['cmdline']['hexPrefix'],d['postOpen']['cmdline']['hexPrefix'])
    self.assertEqual(d['censusBefore']['cmdline']['originalHexLength'],24000)
  save('diagnostic-'+kind+('-'+field if field else ''),{'model':'FAKE_KERNEL_AND_SINK_NO_LIVE_PROCESSES',
   'kind':kind,'field':field,'diagnostics':diagnostics,'unavailable':unavailable,'firstFault':original,
   'secondaryFaults':owner.faults[1:],'identityReads':expected_id_reads,'fdinfoReads':expected_fdinfo_reads,
   'UIDPredicateReads':1 if uid_evaluated else 0,'additionalDiagnosticProbes':0,'closeAttempts':0 if kind=='open-error' else 1,
   'custodyCommitted':False,'rejectedFdSignals':0,'actualPidfdCalls':0})

 def test_26_each_fullidentity_field_mismatch_records_both_actual_samples_and_refuses(self):
  for field in ('pid','ppid','uid','starttime','session','cmdline'):
   with self.subTest(field=field):self.diagnostic_rejection('first-mismatch',field)
  self.diagnostic_rejection('uid-operand')
 def test_27_missing_AFTER_read_or_open_error_retains_original_exception_without_probe(self):
  for kind in ('first-read-error','second-read-error','open-error','uid-read-error'):
   with self.subTest(kind=kind):self.diagnostic_rejection(kind)
 def test_28_fdinfo_and_final_identity_predicates_keep_refusal_and_exact_collected_stage(self):
  for kind in ('fdinfo-mismatch','fdinfo-error'):
   with self.subTest(kind=kind):self.diagnostic_rejection(kind)
  for field in ('pid','ppid','uid','starttime','session','cmdline'):
   with self.subTest(field=field):self.diagnostic_rejection('final-mismatch',field)
 def test_29_bounded_incomplete_prefix_keeps_full_comparison_and_bounds_failure_keeps_firstfault(self):
  self.diagnostic_rejection('long-command');self.diagnostic_rejection('bound-failure')
 def test_30_diagnostic_sink_failures_keep_closeonce_poison_and_originalfirstfault(self):
  self.diagnostic_rejection('sink-failure');self.diagnostic_rejection('persistent-sink-failure')
  # A broken diagnostic sink cannot prevent independent cleanup of a separately
  # validated held child. Its failed-custody descendant is never signalled.
  m=module();root=93000;uid=os.getuid();clock={'t':0};dead=False;reaped=set();signals=[]
  parent={'pid':93001,'ppid':root,'uid':uid,'starttime':123,'session':93001,'cmdline':b'owned-parent\0'.hex()}
  child={**parent,'pid':93002,'ppid':93001,'starttime':124,'session':93002}
  owner=m.SafetyOwner(root,.3,diagnostic_guard_uid_admission=uid)
  owner.known[(93001,123)]={'identity':parent,'fd':402,'registered':False,'reaped':False,'acquisitionFailed':False}
  class BrokenSink(list):
   def append(self,event):raise OSError('SYNTHETIC_PERSISTENT_DIAGNOSTIC_SINK_WRITE_FAILURE')
  owner.events=BrokenSink()
  def identity(pid):
   if pid in reaped:raise FileNotFoundError()
   return dict(parent if pid==93001 else child)
  def send(fd,sig,*args):
   nonlocal dead
   self.assertEqual(fd,402);self.assertFalse(dead);dead=True;signals.append(fd)
  def wait(timeout=0):self.assertTrue(dead);reaped.add(93001);return -9
  def waitpid(pid,flags):self.assertEqual(pid,93002);self.assertTrue(dead);reaped.add(pid);return pid,9
  def now():clock['t']+=.01;return clock['t']
  owner.handles=[{'handle':types.SimpleNamespace(pid=93001,wait=wait),'pid':93001,'reaped':False}]
  with patch.object(m,'ancestry_tree',side_effect=lambda *a:[parent,child] if len(reaped)<2 else []),\
       patch.object(m,'pidfd_open',return_value=401),patch.object(m,'identity',side_effect=[{**child,'cmdline':child['cmdline']+'00'}]) as ids,\
       patch.object(m.os,'close') as close,patch.object(m,'pidfd_send_signal',side_effect=send),patch.object(m.os,'kill') as numeric,\
       patch.object(m.time,'monotonic',side_effect=now),patch.object(m.time,'sleep',return_value=None),\
       patch.object(m,'children',side_effect=lambda p:[] if len(reaped)==2 else [93001]),\
       patch.object(m,'exited',side_effect=lambda fd:dead),\
       patch.object(m.os,'waitid',side_effect=lambda how,pid,opts:types.SimpleNamespace(si_pid=pid) if dead else None),\
       patch.object(m.os,'waitpid',side_effect=waitpid):
   owner.census();self.assertEqual(owner.faults[0]['message'],'PIDFD_FULL_IDENTITY_UID_BEFORE_CUSTODY')
   self.assertTrue(owner.known[(93002,124)]['acquisitionFailed']);self.assertIsNone(owner.known[(93002,124)]['fd'])
   close.assert_called_once_with(401);ids.side_effect=identity
   self.assertTrue(owner.cleanup());self.assertTrue(owner.fallback);self.assertEqual(reaped,{93001,93002})
   self.assertEqual(signals,[402]);numeric.assert_not_called();close.assert_called_once_with(401)
   owner.close();self.assertEqual(close.call_args_list,[unittest.mock.call(401),unittest.mock.call(402)])
  save('diagnostic-persistent-sink-independent-cleanup',{'model':'FAKE_KERNEL_NO_LIVE_PROCESSES','cleanupRanDespiteDiagnosticFailure':True,
   'rejectedFd401ClosedExactlyOnce':True,'rejectedFdSignals':0,'knownValidatedPidfdSignals':signals,'allOwnedReaped':True,
   'fallbackRemainsUnqualified':owner.fallback,'firstFault':owner.faults[0],'secondaryFaults':owner.faults[1:]})

if __name__=='__main__':OUT.mkdir(mode=0o700,exist_ok=False);unittest.main(verbosity=2)
