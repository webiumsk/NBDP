"""SOURCE/DATA-only narrow adaptation of existing finite trusted capture."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
HERE=ROOT/'docs/decisions/evidence/e02-completion-preparation-r1/current-controls-r1'
PREP=HERE.parent
SOURCE=ROOT/'experiments/prototypes/e02_completion_v1'
BASE=ROOT/'docs/decisions/evidence/e02-ordinary-minimum-consumer-preparation-r2/current-controls-r1/capture-controls.py'

def pin(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def save(name,value):
    p=HERE/name;p.write_text(value if type(value) is str else json.dumps(value,indent=2)+'\n');p.chmod(0o600)

def descriptors(value,out=None):
    if out is None:out={}
    if type(value) is dict:
        if set(value)=={'path','bytes','sha256'}:
            if value['path'] in out and out[value['path']]!=value:raise ValueError('Conflicting frozen pin')
            out[value['path']]=value
        else:
            for item in value.values():descriptors(item,out)
    elif type(value) is list:
        for item in value:descriptors(item,out)
    return out

subject=json.loads((PREP/'subject.json').read_text())
profile=json.loads((SOURCE/'profile.json').read_text())
protected=json.loads((PREP/'protected-inputs-after.json').read_text())
rows=descriptors(subject);descriptors(profile,rows);descriptors(protected,rows)
for p in (PREP/'subject.json',PREP/'artifact-manifest.json',PREP/'control-plan.json',SOURCE/'profile.json',PREP/'protected-inputs-before.json',PREP/'protected-inputs-after.json'):rows[str(p)]=pin(p)
for row in rows.values():
    if pin(Path(row['path']))!=row:raise ValueError('Frozen input drift')
save('frozen-inputs.json',{'schema':'e02-completion-control-frozen-inputs-v1','files':[rows[p] for p in sorted(rows)],'profileDependencyCount':len(profile['dependencies']),'protectedInputCount':len(protected['files']),'meaning':'Full explicit source/preparation/profile/dependency/protected/interpreter inputs only, no runtime qualification.'})
text=BASE.read_text().replace('once-only86 synthetic DATA','once-only54 synthetic DATA')
text=text.replace("PREP = HERE.parent\nSOURCE = ROOT / 'experiments/prototypes/e02_ordinary_minimum_consumer_v2'", "PREP = HERE.parent\nSOURCE = ROOT / 'experiments/prototypes/e02_completion_v1'\nNODE = Path('/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node')")
text=text.replace("ACTOR = '/root/android_health_implementer'", "ACTOR = '/root/ordinary_api35_source'")
a=text.index('SOURCE_SHA =');b=text.index('\n\ndef utc()',a)
text=text[:a]+"SOURCE_SHA = 'b5b230d20f3ff571f6282ee3d529308f75127e9536e13bcf6a38b3b2981afd99'\nMANIFEST_SHA = '"+pin(PREP/'artifact-manifest.json')['sha256']+"'\nFROZEN_PLAN_SHA = 'df9bc4705affa71551b3ac9ad8066e9ae904e619c702d4184b04c32aabfbf7ca'\nARGV = [str(NODE), str(SOURCE / 'test_data.mjs')]\nLIMITS = {'stdout':1048576,'stderr':262144}\n"+text[b:]
text=text.replace('67108864','268435456').replace('67108865','268435457')
a=text.index('def snapshot(');b=text.index('\n\ndef main()',a)
text=text[:a]+'''def snapshot(ack_sha):
    subject = pin(PREP / 'subject.json')
    assert subject['sha256'] == SOURCE_SHA, 'Exact completion source required'
    manifest = pin(PREP / 'artifact-manifest.json')
    assert manifest['sha256'] == MANIFEST_SHA
    frozen_plan = pin(PREP / 'control-plan.json')
    assert frozen_plan['sha256'] == FROZEN_PLAN_SHA
    proposed = doc(PREP / 'control-plan.json')
    assert proposed['argv'] == ARGV and proposed['plannedChecks'] == 54
    assert proposed['timeoutSeconds'] == 60 and proposed['rawRetentionBytes'] == LIMITS
    control_plan = doc(HERE / 'control-plan.json')
    assert control_plan['argv'] == ARGV and control_plan['plannedChecks'] == 54
    assert control_plan['timeoutSeconds'] == 60 and control_plan['retentionBytes'] == LIMITS
    profile = doc(SOURCE / 'profile.json')
    assert len(profile['dependencies']) == 816
    protected = doc(PREP / 'protected-inputs-after.json')
    assert len(protected['files']) == 51
    assert doc(PREP / 'protected-inputs-before.json') == protected
    frozen_inputs = doc(HERE / 'frozen-inputs.json')
    assert frozen_inputs['schema'] == 'e02-completion-control-frozen-inputs-v1'
    rows = frozen_inputs['files']
    assert 1 <= len(rows) <= 4096 and len({row['path'] for row in rows}) == len(rows)
    actual = [pin(Path(row['path'])) for row in rows]
    assert actual == rows, 'Full frozen input closure changed'
    by_path = {row['path']:row for row in rows}
    for expected in [*proposed['sourceInputs'],*profile['dependencies'],*protected['files']]:
        assert by_path[expected['path']] == expected, 'Required source/dependency/protected input omitted'
    interpreters = {'node':pin(NODE),'python':pin(PYTHON)}
    assert interpreters == {'node':profile['node'],'python':profile['python']}
    assert interpreters['node'] == proposed['node']
    ack_path = HERE / 'coordinator-acknowledgement.json'
    ack_pin = pin(ack_path)
    assert ack_pin['sha256'] == ack_sha and (ack_path.stat().st_mode & 0o777) == 0o600
    ack = doc(ack_path)
    assert set(ack) == {'schema','actor','sourceSubject','runnerSubject','runner','controlPlan',
        'sourceQaReview','sourceSecurityReview','sourceQaDecision','sourceSecurityDecision',
        'pureControlsAuthorized','allowedCount','stopFirstFailure','noRetry','primaryAuthorized',
        'consumerAuthorized','androidAuthorized','servicesAuthorized','cryptoOrNativeAuthorized','sdkAuthorized'}
    assert ack['schema'] == 'e02-completion-controls-root-ack-v1' and ack['actor'] == '/root'
    assert ack['sourceSubject'] == subject and ack['allowedCount'] == 54
    for key in ('pureControlsAuthorized','stopFirstFailure','noRetry'):
        assert ack[key] is True
    for key in ('primaryAuthorized','consumerAuthorized','androidAuthorized','servicesAuthorized','cryptoOrNativeAuthorized','sdkAuthorized'):
        assert ack[key] is False
    assert ack['runner'] == pin(Path(__file__).resolve()) and ack['controlPlan'] == pin(HERE / 'control-plan.json')
    assert ack['runnerSubject'] == pin(HERE / 'runner-subject.json')
    runner_subject = doc(HERE / 'runner-subject.json')
    assert runner_subject['runner'] == ack['runner'] and runner_subject['controlPlan'] == ack['controlPlan']
    for row in runner_subject['preparationArtifacts']:
        assert pin(Path(row['path'])) == row
    sessions, review_pins = [], []
    for field, decision_field, role in (('sourceQaReview','sourceQaDecision','qa'),('sourceSecurityReview','sourceSecurityDecision','security')):
        review_pin = ack[field]
        assert Path(review_pin['path']).parent == PREP and pin(Path(review_pin['path'])) == review_pin
        review = doc(Path(review_pin['path']))
        assert set(review) == {'role','session','decision','subject'}, 'Actual closed4 SOURCE record only'
        assert review['subject'] == subject and review['role'] == role
        assert type(ack[decision_field]) is str and review['decision'] == ack[decision_field]
        # The root binds the actual accepted scoped decision after both genuine
        # independent sessions return; this checker never interprets a future result.
        assert review['session'] not in (ACTOR,'/root','/root/android_health_implementer')
        assert type(review['session']) is str and review['session'].startswith('/root/')
        sessions.append(review['session']);review_pins.append(review_pin)
    assert len(set(sessions)) == 2
    return dict(sourceSubject=subject, sourceManifest=manifest, frozenSourcePlan=frozen_plan,
        fullFrozenInputs=actual, interpreters=interpreters, monitor=pin(Path(__file__).resolve()),
        runnerSubject=ack['runnerSubject'],controlPlan=ack['controlPlan'],
        sourceReviewRecords=review_pins,coordinatorAcknowledgement=ack_pin,
        frozenInputManifest=pin(HERE / 'frozen-inputs.json'))
'''+text[b:]
text=text.replace("'ONCE_86_SYNTHETIC_DATA_ONLY_NO_ANDROID_SDK_SERVICES_OR_CRYPTO'", "'ONCE_54_SYNTHETIC_DATA_ONLY_NO_PRIMARY_CONSUMER_ANDROID_SDK_SERVICES_CRYPTO'")
text=text.replace('e02-minimum-consumer-pure-control-execution-v1','e02-completion-pure-control-execution-v1')
text=text.replace('expectedCount=86','expectedCount=54')
a=text.index("    match = re.search(");b=text.index('    try:\n        after = snapshot',a)
text=text[:a]+'''    try:
        assert raw['stderr'] == b'', 'Exact empty Node stderr required'
        assert raw['stdout'].endswith(b'\\n') and raw['stdout'].count(b'\\n') == 1
        value = strict(raw['stdout'])
        assert set(value) == {'scope','checks','cases','primaryExecuted','consumerExecuted','cryptoExecuted','completionPassClaimed'}
        assert value['scope'] == 'E02_COMPLETION_SYNTHETIC_DATA_ONLY'
        assert type(value['checks']) is int and value['checks'] == 54
        assert type(value['cases']) is list and len(value['cases']) == 54
        assert all(type(name) is str and 1 <= len(name) <= 160 for name in value['cases'])
        assert len(set(value['cases'])) == 54
        for key in ('primaryExecuted','consumerExecuted','cryptoExecuted','completionPassClaimed'):
            assert value[key] is False
        receipt['observedCount'] = value['checks']
        receipt['countAndOutputShapeMatched'] = True
    except BaseException as exc:
        error('original-output-shape', exc)
'''+text[b:]
text=text.replace('e02-minimum-consumer-control-result-files-v1','e02-completion-control-result-files-v1')
text=text.replace('Synthetic DATA only, not genuine GUI/native/client evidence, whole-consumer acceptance, canonicalPASS, SDK or experiment authority.', 'Synthetic DATA only; no primary/consumer/runtime/crypto/native/client execution or external/canonicalPASS, SDK or experiment authority.')
# Preserve established actual process lifecycle unchanged; only output interpretation
# and fixed scope/pins/snapshot/closed4 review mapping differ.
runner=HERE/'capture-controls.py';runner.write_text(text);runner.chmod(0o600)
a=ast.dump(ast.parse(BASE.read_text()),indent=2,include_attributes=False)
b=ast.dump(ast.parse(text),indent=2,include_attributes=False)
save('capture-full-typed-ast-before.json',{'source':pin(BASE),'tree':a})
save('capture-full-typed-ast-after.json',{'source':pin(runner),'tree':b})
save('capture-full-typed-ast.diff',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(BASE),tofile=str(runner))))
save('capture-full-source.diff',''.join(difflib.unified_diff(BASE.read_text().splitlines(True),text.splitlines(True),fromfile=str(BASE),tofile=str(runner))))
plan={'schema':'e02-completion-current-data-capture-plan-v1','actor':'/root/ordinary_api35_source','state':'PREPARED_NOT_EXECUTED_PENDING_BOTH_ACTUAL_SOURCE_DECISIONS_AND_EXPLICIT_ROOT_RELEASE','sourceSubject':pin(PREP/'subject.json'),'frozenSourcePlan':pin(PREP/'control-plan.json'),'runner':pin(runner),'previousTrustedCapture':pin(BASE),'argv':[profile['node']['path'],str(SOURCE/'test_data.mjs')],'plannedChecks':54,'timeoutSeconds':60,'retentionBytes':{'stdout':1048576,'stderr':262144},'retentionMeaning':'Popen.communicate in-memory until completion; post-capture raw file retention/refusal, NOT streaming resource cap.','frozenInputs':pin(HERE/'frozen-inputs.json'),'frozenInputCount':len(rows),'closure':'Whole original SOURCE/preparation/profile +816 dependencies +51 protected inputs, Node/Python/monitor/plans/actual closed4 SOURCE records/root acknowledgement before and after.','onceCommand':[profile['python']['path'],'-I','-B',str(runner),'--execute-once','--root-ack-sha','ACTUAL_ROOT_ACK_SHA256'],'sourceQaActualKnownDecision':'ACCEPT_SOURCE_FOR_SCOPED_DATA_CONTROLS_ONLY','sourceSecurityDecision':'Actual literal only after real final report; root acknowledgement binds it exactly, no placeholder success.','actualSourceReviewShape':['role','session','decision','subject'],'rootAcknowledgementFields':['schema','actor','sourceSubject','runnerSubject','runner','controlPlan','sourceQaReview','sourceSecurityReview','sourceQaDecision','sourceSecurityDecision','pureControlsAuthorized','allowedCount','stopFirstFailure','noRetry','primaryAuthorized','consumerAuthorized','androidAuthorized','servicesAuthorized','cryptoOrNativeAuthorized','sdkAuthorized'],'rootAcknowledgementSchema':'e02-completion-controls-root-ack-v1','rootAcknowledgementAuthority':'Actual external root release only; cannot be generated by operator.','originalOuterApiReceipts':'Caller immediately persists actual toolName/arguments/unmodified response objects, separately from process journal.','stopFirstFailure':True,'noRetry':True,'sameFrozenResultIndependentReviewRequired':True,'actualControlsExecuted':False,'primaryConsumerCryptoNativeAndroidSdkServicesExecuted':False}
save('control-plan.json',plan)
artifacts=[pin(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ('runner-subject.json',)]
save('runner-subject.json',{'schema':'e02-completion-pure-control-runner-source-subject-v1','author':'/root/ordinary_api35_source','state':'WRITES_STOPPED_SOURCE_ONLY_NOT_EXECUTED','sourceSubject':pin(PREP/'subject.json'),'runner':pin(runner),'controlPlan':pin(HERE/'control-plan.json'),'preparationArtifacts':artifacts,'actualSourceAcknowledgementWrittenByAuthor':False,'actualTestsExecuted':False})
print(json.dumps({'state':'WRITES_STOPPED_RUNNER_READY_NOT_EXECUTED','runner':pin(runner),'plan':pin(HERE/'control-plan.json'),'runnerSubject':pin(HERE/'runner-subject.json'),'frozenInputCount':len(rows)},indent=2))
