"""Actual54 result DATA freeze only; no test/runner imports or self-approval."""
from pathlib import Path
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
PREP=HERE.parent
OUT=HERE/'results-r1'
OUT.mkdir(mode=0o700)

def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def save(name,v):
    fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'w') as f:f.write(json.dumps(v,indent=2)+'\n')

for name in ('original-tool-launch-receipt.json','original-tool-poll-01-receipt.json'):
    (HERE/name).chmod(0o600)
e=json.loads((HERE/'execution.json').read_text())
value=json.loads((HERE/'data.stdout').read_bytes())
before=json.loads((HERE/'sources-before.json').read_text())
after=json.loads((HERE/'sources-after.json').read_text())
raw_cases=value['cases']
groups={'primary-exact-and-negative':[],'ordinary-summary-exact-and-negative':[],'criterion-mapping-preservation':[],'wire-role-report-joins':[],'strict-json-data':[],'independent-review-shape-refusals':[]}
for name in raw_cases:
    if name.startswith(('exact-original','refuse-primary-')):key='primary-exact-and-negative'
    elif name.startswith(('exact-consumer','refuse-ordinary-','extra-result-')):key='ordinary-summary-exact-and-negative'
    elif name.startswith('criterion-map-'):key='criterion-mapping-preservation'
    elif name.startswith(('four-direction-','refuse-fixture-')):key='wire-role-report-joins'
    elif name.startswith(('DATA-parser-','refuse-json-')):key='strict-json-data'
    else:key='independent-review-shape-refusals'
    groups[key].append(name)
save('named-branch-results.json',{'schema':'e02-completion-actual54-named-branch-data-v1','rawStdout':pin(HERE/'data.stdout'),'actualEmittedCount':value['checks'],'allActualNamedCasesInOrder':raw_cases,'branchGroups':{k:{'count':len(v),'cases':v} for k,v in groups.items()},'meaning':'Names emitted after each prepared assertion returned successfully. This is the actual narrow synthetic DATA suite, not independent acceptance, primary execution, consumer execution or interoperability.','actualCapabilityDeclarations':{k:value[k] for k in ('primaryExecuted','consumerExecuted','cryptoExecuted','completionPassClaimed')}})
manifest=[pin(p) for p in sorted(HERE.rglob('*')) if p.is_file() and not p.is_relative_to(OUT)]
save('raw-artifact-manifest.json',{'schema':'e02-completion-current-data-result-artifacts-v1','files':manifest,'originalCaptureManifestUnmodified':pin(HERE/'result-artifact-manifest.json'),'futureReviewerFilesExcluded':True,'manifestExcludesSelf':True})
save('subject.json',{'schema':'e02-completion-actual54-data-controls-subject-v1','actor':'/root/ordinary_api35_source','author':'/root/ordinary_api35_source','operator':'/root/ordinary_api35_source','state':'WRITES_STOPPED_PENDING_ACTUAL_NONAUTHOR_NONOPERATOR_QA_SECURITY','scope':'ONE_54_SYNTHETIC_NODE_DATA_SUITE_ONLY','sourceSubject':pin(PREP/'subject.json'),'sourceProfile':next(d for d in json.loads((PREP/'subject.json').read_text())['sources'] if d['path'].endswith('/profile.json')),'runnerSubject':pin(HERE/'runner-subject.json'),'runner':pin(HERE/'capture-controls.py'),'controlPlan':pin(HERE/'control-plan.json'),'rootAcknowledgement':pin(HERE/'coordinator-acknowledgement.json'),'sourceReviewRecords':before['sourceReviewRecords'],'sourcesBefore':pin(HERE/'sources-before.json'),'sourcesAfter':pin(HERE/'sources-after.json'),'frozenInputCount':len(before['fullFrozenInputs']),'sourceUnchanged':before==after,'execution':pin(HERE/'execution.json'),'rawArtifactManifest':pin(OUT/'raw-artifact-manifest.json'),'namedBranchResults':pin(OUT/'named-branch-results.json'),'originalOuterApiReceipts':[pin(HERE/'original-tool-launch-receipt.json'),pin(HERE/'original-tool-poll-01-receipt.json')],'actualToolAssociation':{'launchTool':'tools.exec_command','launchChunkId':'f8c8db','sessionId':4067,'completionTool':'tools.write_stdin','completionChunkId':'6a7711','returnedExitCode':0,'inventedApiFields':False},'actualExpectedCount':e['expectedCount'],'actualObservedCount':e['observedCount'],'captureMatched':e['captureMatched'],'actualNaturalExit':e['naturalExit'],'actualExitCode':e['exitCode'],'actualSignal':e['signal'],'actualReaped':e['reaped'],'actualStdoutEOF':e['stdoutEOF'],'actualStderrEOF':e['stderrEOF'],'actualForceRequested':e['forceRequested'],'actualFirstError':e['firstError'],'actualSecondaryErrors':e['secondaryErrors'],'actualTruncated':e['truncated'],'actualElapsedNanoseconds':e['elapsedNanoseconds'],'controlResultAcceptedByAuthor':False,'independentResultReview':'PENDING_ACTUAL_NONAUTHOR_NONOPERATOR_QA_SECURITY','rawStreamModes':{n:oct((HERE/('data.'+n)).stat().st_mode&0o777) for n in ('stdout','stderr')},'retentionMeaning':'stdout1MiB/stderr256KiB post-capture file retention/refusal; not a streaming memory cap.','noRetry':True,'noSourceFixAfterAttempt':True,'noPrimaryConsumerCandidateFinalizeCryptoNativeAndroidSdkRelaysServicesExecuted':True,'canonicalE02':'PARTIAL22_UNCHANGED','stockE04E06Unlocked':False,'architecturalBlockersUnchanged':['Q01','Q08','Q13','Q15','Q27'],'remaining':['Actual same-result-subject independent QA/security.','Actual ordinary minimum role windows and accepted whole consumer graph; no such outcomes created here.','Actual isolated current primary22 and original outer tool witness.','Actual candidate/finalize input reviews and separate stock prerequisite integration.']})
print(json.dumps({'state':'WRITES_STOPPED','resultSubject':pin(OUT/'subject.json'),'rawManifest':pin(OUT/'raw-artifact-manifest.json'),'namedBranches':pin(OUT/'named-branch-results.json'),'actualCount':e['observedCount'],'sourceUnchanged':before==after,'naturalExitCode':e['exitCode'],'actualError':e['firstError'],'actualForceRequested':e['forceRequested'],'branches':{k:len(v) for k,v in groups.items()}},indent=2))
