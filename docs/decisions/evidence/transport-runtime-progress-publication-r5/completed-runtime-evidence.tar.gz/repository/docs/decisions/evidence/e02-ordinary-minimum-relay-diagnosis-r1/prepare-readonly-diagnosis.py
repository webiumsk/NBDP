"""Read/hash/copy finished evidence and pinned sources; no runtime experiment."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import os
import subprocess

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
P=ROOT/'docs/decisions/evidence/e02-ordinary-minimum-runtime-r1'
OUT=ROOT/'docs/decisions/evidence/e02-ordinary-minimum-relay-diagnosis-r1'
RELAY=Path('/tmp/nbdp-005-rs-relay')
COMMIT='b5c1f642e4f4c3b9c54f5d18d66f4c3b9c54f5d18d66f4c53642076b4'
# Exact known relay pin; no fetch/install or repository changes.
COMMIT='b5c1f642e4f4c3b9c54f5d18d66f4c53642076b4'

def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,b):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b)
 return pin(p)
def j(name,v):return save(name,(json.dumps(v,indent=2)+'\n').encode())

files=['src/server.rs','src/repo/sqlite.rs','src/subscription.rs','src/config.rs','src/main.rs']
argv=['git','--no-optional-locks','-C',str(RELAY),'diff','--exit-code',COMMIT,'--',*files]
r=subprocess.run(argv,capture_output=True,timeout=15)
save('source/git-diff.stdout',r.stdout);save('source/git-diff.stderr',r.stderr)
if r.returncode!=0:raise ValueError('Pinned relay source differs')
source_inputs=[]
for name in files:
 p=RELAY/name;preserved=save('source/relay/'+name,p.read_bytes());source_inputs.append({'original':pin(p),'preserved':preserved})
config=json.loads((P/'source-authority/proposed-incoming-run-config.json').read_text())
relay_config=Path(config['relayConfig']['path'])
if pin(relay_config)!=config['relayConfig']:raise ValueError('Mounted relay configuration drift')
relay_config_copy=save('source/rs-relay.toml',relay_config.read_bytes())
for n in ['fixture.mjs','supervisor.py','lease_guard.py','fixture-plan.json']:
 p=P/'producer-source'/n;source_inputs.append({'original':pin(p),'preserved':save('source/producer/'+n,p.read_bytes())})

capture=P/'run/session/fixtures/capture.jsonl';rows=[json.loads(line) for line in capture.read_text().splitlines()]
decoded=[]
for row in rows:
 x={k:v for k,v in row.items() if k!='rawBase64'}
 if 'rawBase64'in row:
  f=json.loads(base64.b64decode(row['rawBase64'],validate=True));x['messageType']=f[0]
  if f[0]=='EVENT':
   event=f[-1];x['eventId']=event['id'];x['kind']=event['kind'];x['subscription']=f[1] if len(f)==3 else None
  else:x['decodedFrame']=f
 decoded.append(x)
query_rows=[r for r in rows if r.get('exchangeLabel')=='incoming-business-query']
reply_rows=[r for r in query_rows if r['direction']=='RELAY_TO_PRODUCER']
window=json.loads((P/'run/session/fixtures/incoming-business-publication-window.json').read_text())
lease=json.loads((P/'run/session/lease.json').read_text())
command=json.loads((P/'run/commands/0360.json').read_text())
command_error=P/'run/session/fixtures/command-error-1792820586591.json'
error_ms=1792820586591
query_row=next(r for r in rows if r['sequence']==56)
def ms(text):return int(datetime.datetime.fromisoformat(text.replace('Z','+00:00')).timestamp()*1000)
j('timeline.json',{'schema':'e02-minimum-query-timeout-readonly-timeline-v1','capture':pin(capture),'rawRows':len(rows),'decodedTimeline':decoded,'criticalSequences':{'actualPublicationIntent':47,'actualPublishFrameIntent':48,'relayPositiveOK':49,'actualAppFrame':50,'actualAppSendCallback':51,'sealedPublicationWindow':52,'ownedQueryFrameIntent':56},'queryBackendRepliesRecorded':len(reply_rows),'publicationWindow':window,'queryIntentToCommandErrorWallMilliseconds':error_ms-ms(query_row['utc']),'publicationWindowCloseToCommandErrorWallMilliseconds':error_ms-ms(rows[51]['utc']),'commandErrorTimestampSource':'Date.now() in command-error filename from the same fixture process; wall-time observation, not per-phase monotonic measurement.','queryStartSendCallbackGuardOrDBDurationsMeasured':False,'leaseRemainingAtCommandErrorSeconds':(lease['deadlineUtcNs']-error_ms*1000000)/1000000000,'originalLeaseExpiredAtPrimaryFailure':False,'limitations':['Node log times occur after synchronous guards, not kernel-arrival timestamps.','Sequence56 is logged before ws.send, so exact request intent bytes do not establish backend receipt or completed send callback.','The failed exchange has no persisted return object, so its in-memory ACK/query/EOSE/send callback state and elapsed duration cannot be reconstructed as measured facts.']})
resource={}
for role in ('fixture','rs-relay','android'):
 p=P/('run/cleanup/'+role+'-inspect.stdout');v=json.loads(p.read_text())[0];h=v['HostConfig'];resource[role]={'inspection':pin(p),'image':v['Image'],'memoryBytes':h['Memory'],'memorySwapBytes':h['MemorySwap'],'nanoCpus':h['NanoCpus'],'pidsLimit':h['PidsLimit'],'stateAtCleanup':v['State'],'logConfig':h['LogConfig']}
j('resource-policy.json',{'schema':'e02-minimum-query-resource-policy-inspection-v1','actualInspections':resource,'meaning':'Configured cgroup limits and cleanup state only; no named-process CPU/RSS/PSI/event-loop/DB queue runtime measurements. OOMKilled:false is the actual flag, not proof of general resource health.','operationalRelayStdout':pin(P/'run/cleanup/rs-relay-logs.stdout'),'operationalRelayStderr':pin(P/'run/cleanup/rs-relay-logs.stderr'),'relayStderrMeaning':'44-byte sticky revocation diagnostic after primary command failure; no SQL/load-shed/query trace available.','sourceConfig':relay_config_copy,'sourceAuthorization':'limit_scrapers=false explicit; gift-wrap AUTH-read default inspected in pinned config source, no query response observed to establish its runtime branch.'})
j('source-evidence-map.json',{'schema':'e02-minimum-query-timeout-source-map-v1','relayCommit':COMMIT,'readOnlyGitDiff':{'argv':argv,'exitCode':r.returncode,'stdout':pin(OUT/'source/git-diff.stdout'),'stderr':pin(OUT/'source/git-diff.stderr')},'inputs':source_inputs,'sourceFacts':[{'source':'producer/fixture.mjs:20-24','fact':'check synchronously spawns the existing Python guard with5000ms timeout; no per-call timings emitted.'},{'source':'producer/fixture.mjs:153-196','fact':'10000ms network timer begins before open/send; open,send,message and callbacks synchronously check guard. Outgoing intent logged before ws.send; failed exchange rejects without its result object.'},{'source':'producer/fixture.mjs:237-239','fact':'Exact-ID relay query occurs after qualified actual app delivery/window close, before native validation/client render/export.'},{'source':'relay/src/server.rs:1205-1224,1425-1458','fact':'Normal DB query emits EVENT and EOSE; source scraper branch would emit EOSE even when ignoring query. No such query reply recorded.'},{'source':'relay/src/repo/sqlite.rs:323-357,531-536','fact':'Reader semaphore/checkpoint wait precede source >5s queue shedding that returns without normal EOSE. This is an unobserved possible branch, not proven runtime cause.'},{'source':'producer/supervisor.py:620-649,670-673','fact':'Service bytes are guarded/captured and forwarded on completion/failure. Available relay capture has no operational DB trace; absence is not proof no internal error occurred.'}],'runtimeBranchesNotMeasured':['WebSocket open/send-callback completion for failed query','Kernel/backend receipt and backend reply timing','Individual sync guard elapsed/CPU','Node callback/event-loop delay','Relay DB semaphore/checkpoint/load shedding','Named-process resource usage']})
report='''# Minimum incoming query timeout — bounded read-only diagnosis

The preserved whole incoming window is FAILED_UNQUALIFIED and contributes zero
ordinary rows. Raw receipt0360 uses **exit:2**, reapedtrue, forcedfalse,
timedOutfalse, errornull and both EOFtrue. Its51-byte stderr is
`Error: FIXTURE_COMMAND_FAILED:Error: RELAY_TIMEOUT`. The separate command-error
record names RELAY_TIMEOUT. Sticky revocation/FINITE_LEASE_DENIED and subsequent
service exits follow that failed command; they are secondary. Original1800s lease
still had roughly1331s at the command-error filename timestamp. All four owned
containers have actual identity/remove/absence cleanup evidence.

Before the failure: actual account/login/Tor/one Feeds-collapse/Local-relay GUI
steps and subscription/EOSE were retained. Sequence49 is relay OKtrue for the
published business outer. Sequence50 is its actual APP EVENT with current
connection1/subscription mghfqw/request10/EOSE21,51 completes forwarding and52
seals actualNewAppFrameObservedtrue. That proves scoped wire forwarding, not
Amethyst decryption, selected rendering, private tag retention or business effects.
No GUI capture after publication, selected-note export, independent native
validation record or complete stage publication exists.

The failure is later: sequence56 retains the exact112-byte REQ with the published
outer ID and limit1. Source logs it BEFORE ws.send. No query reply is recorded;
no failed-exchange send callback or phase timing object is persisted. Therefore
backend receipt, actual reply absence, socket-send completion and timer-start
instant remain UNKNOWN. The10s query timer expired, not the parent55s command
ceiling or original30-minute lease.

Two source-supported hypotheses remain unproven. First, repeated synchronous
Python guard checks share the Node loop with open/send/message/watchdog/timer
callbacks. Observed unrelated APP REQ/EOSE callbacks continue between query intent
and error, but their timestamps are post-guard log times and cannot measure
kernel arrival, individual guard duration or CPU cause. Second, the pinned relay
has a >5s queued DB load-shed branch that omits normal EOSE. No operational relay
logs/DB queue timings establish that branch. Captured relay stdout is empty;
stderr is only later sticky revocation. Configured cgroup limits/OOMKilledfalse
are not CPU/RSS/PSI/guest-health measurements. Neither a relay bug, CPU shortage
nor Amethyst business incompatibility is established.

No functional assertion/deadline/profile fix is justified yet. In particular,
do not lengthen/restart the10s timer, remove the exact query, donate early rows,
relax EOSE/current generation/export, increase resources or retry the same cold
Android attempt without a reviewed evidence plan. A source-only observability
revision is justified: bounded monotonic phase records for exchange start,
open, guard entry/exit, send invocation/callback, raw backend callback entry,
timer firing and rejected outcome. Preserve exact raw operands and original
10s/3s/55s/1800s limits. A callback-entry evidence write before a guard may record
refusal context only; it must authorize no forwarding or action after failure.
Keep such records in a separately versioned diagnostic schema/profile so the
old strict consumer is not silently retargeted. Relay-specific bounded logging
would need reviewed configuration/guard environment handling and actual retained
logs, never assumed availability.

The smallest next runtime proposal is an isolated **transport-only diagnostic**,
first without Android traffic, using the same pinned relay and the already public
synthetic signed event/112-byte exact query. Require actual send callback, backend
receive/send, EVENT+EOSE or a precisely recorded refusal under the original timer.
A second separately declared synthetic case may add the frozen observed APP REQ
burst to test scheduling interference. The captured post-guard times are not an
exact reproduction of original socket arrivals; label that case modeled traffic.
No new encryption/signing/profile/nonce handling is needed. Keep all negative
and timeout histories. This would diagnose the transport/harness boundary only,
not qualify ordinary-client UI or unlock E02/E04/E06. Source, targeted controls,
independent QA/security and a fresh explicit finite diagnostic grant precede it.
No such source change, diagnostic, service, PID probe, import or retry was run.
'''
save('REPORT.md',report.encode())
j('subject.json',{'schema':'e02-minimum-query-timeout-readonly-diagnosis-subject-v1','author':'/root/ordinary_api35_source','state':'WRITES_STOPPED_READONLY_DIAGNOSIS_PENDING_INDEPENDENT_QA_SECURITY','failureSubject':pin(P/'subject-r2.json'),'report':pin(OUT/'REPORT.md'),'timeline':pin(OUT/'timeline.json'),'resourcePolicy':pin(OUT/'resource-policy.json'),'sourceMap':pin(OUT/'source-evidence-map.json'),'actualRootCause':'UNKNOWN_QUERY_REPLY_OR_CALLBACK_STAGE_NOT_OBSERVED','sourceFixImplemented':False,'runtimeExperimentOrProbeOrRetry':False,'ordinaryQualifiedRows':0,'canonicalE02':'PARTIAL22_UNCHANGED','noDeadlineResourceGateOrArchitectureChanges':True})
j('artifact-manifest.json',{'schema':'e02-minimum-query-readonly-diagnosis-artifact-manifest-v1','files':[pin(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'],'manifestExcludesSelf':True})
print(json.dumps({'state':'WRITES_STOPPED_READONLY_DIAGNOSIS','subject':pin(OUT/'subject.json'),'report':pin(OUT/'REPORT.md'),'manifest':pin(OUT/'artifact-manifest.json'),'rootCause':'UNKNOWN','queryRepliesRecorded':len(reply_rows),'noRuntime':True},indent=2))
