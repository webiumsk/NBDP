# Explicit libc pidfd provider — SOURCE ONLY

The pinned Python lacks os.pidfd_open, signal.pidfd_send_signal and P_PIDFD in
both observed managed and HOST contexts. Preserve SOURCE4 batch7-pass/9-error
model failure, completed13+3 subset and admission14 NOT EXECUTED. Missing mock
targets did not exercise custody remediation. No runtime vulnerability follows.

Primary ABI source is the versioned glibc2.39 sys/pidfd.h header:
https://raw.githubusercontent.com/bminor/glibc/glibc-2.39/sysdeps/unix/sysv/linux/sys/pidfd.h
The22-word normalized two-declaration excerpt is retained. Pinned local type
headers map __pid_t through __PID_T_TYPE/__S32_TYPE to C int on this x86_64 host.
Read-only supported HOST metadata23d590 established already loaded canonical
/usr/lib/x86_64-linux-gnu/libc.so.6,2129424bytes/SHA3a15d66867d83762c7f2f1e37359cb8f6c5743edb369c65285cb0b1c4f7498bf,
exact namespace context,64-bit pointers and source header pins. This metadata is a
truthful stdout transcription, not a retained original tool-return attestation.
Root's original feature inspection/tool response are preserved; original file600.
No pidfd open/signal was issued. Symbol/header presence is not runtime success.

pidfd_adapter.py is inert on import. Only future authorized load_provider selects
CDLL at that exact absolute canonical library with RTLD_NOW|RTLD_LOCAL/use_errno.
It verifies provider/hash, exact HOST+architecture/C widths, already loaded mapping
and inode/device, loaded GNU version2.39, bytes/maps before/after binding. No
stdlib fallback, dynamic library search, CDLL(None) for pidfds, guessed syscall
numbers or silent provider swap. Existing separate prctl subreaper path is unchanged.

The C signatures use c_int/c_uint returns c_int for open and
c_int/c_int/NULL c_void_p/c_uint returns c_int for send. NULL-only info needs no
siginfo structure layout; flags remain0. Explicit integer ranges prevent ctypes
wrapping. Thread-local errno is reset and captured; -1 raises actual errno,
missing errno or impossible return fails closed; no automatic retry/provider swap.

Guard owns pidfd_open/pidfd_send_signal functions. Models patch THESE functions,
never create fictitious absent stdlib attributes. Existing16 custody/ownership/
independent-cleanup models remain;4 fake-symbol ABI models cover exact signatures
and success/NULL/flags0, open errno, send errno, invalid input/return/missing errno.
No actual libc load or pidfd in those models.20 definitions remain NOT RUN.

SafetyOwner AST is identical after only call-target normalization: validation
before custody, provisional close/rejection, PID reuse, UID, WNOWAIT/reaping,
no post-reap/unowned signals and independent census-failure cleanup unchanged.
All capture/privacy/expiry/pre-fork gates and budgets unchanged.14 admission
models additionally reject wrong provider and zero real-call accounting within
existing definitions. No expected outcome is weakened for the old failures.

Before real7, complete fresh20+14 models/current whole SOURCE and actual independent
reviews are mandatory. Then separate root authorization is needed. Future7 records
must bind exact provider/library/HOST and record actual adapter open/send function
call deltas; interrupt/tracer-death/parent-death must exercise real send. Open FD
identity/readiness, case success and independent raw review must corroborate the
counters. Counters or symbol presence alone prove no syscall success. Guard checks
provider bytes/maps/context again after actual cases. Observer joins provider and
per-case call lineage before LOCAL. No source/model result unlocks Node.

This preparation makes no C/pidfd call, imports no prepared adapter/guard, runs no
controls/strace/Node/LOCAL. Only static ABI/source and HOST metadata are established.
Kernel permission/feature/ptrace/cleanup behavior still requires actual7. No new
protocol, SDK, architecture, source449 or production changes.
