"""SOURCE ONLY. Explicit pinned glibc2.39 pidfd ABI, inert until load_provider().

No guessed syscall number, missing-stdlib mock creation, alternate provider or
siginfo layout. send_signal supports only NULL info and flags0. Model ABI tests
bind fake callable symbols; only separately authorized real7 may call real pidfds.
"""
from pathlib import Path
import ctypes,hashlib,json,os,platform,stat
HERE=Path(__file__).resolve().parent
PROVIDER={'path':str(HERE/'pidfd-provider.json'),'bytes':2489,
 'sha256':'69426068143bf3d74488fc6e16eb0f1f5dd1696b025d1fd53b89db47dee9b0d8'}
LIBRARY={'path':'/usr/lib/x86_64-linux-gnu/libc.so.6','bytes':2129424,
 'sha256':'3a15d66867d83762c7f2f1e37359cb8f6c5743edb369c65285cb0b1c4f7498bf'}

def need(ok,message):
 if not ok:raise ValueError(message)
def pin(path):
 p=Path(path);need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),'CANONICAL_PINNED_ABI_INPUT')
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<=16777216,'BOUNDED_REGULAR_ABI_INPUT')
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def host_context():
 return {'uid':os.getuid(),'gid':os.getgid(),'uidMap':Path('/proc/self/uid_map').read_text(),
 'gidMap':Path('/proc/self/gid_map').read_text(),'userNamespace':os.readlink('/proc/self/ns/user'),
 'mountNamespace':os.readlink('/proc/self/ns/mnt')}
def mapped_library():
 raw=Path('/proc/self/maps').read_text();need(len(raw)<=1048576,'LOADED_LIBRARY_MAP_BOUND')
 rows=[line.split(maxsplit=5) for line in raw.splitlines()]
 paths=sorted({r[5] for r in rows if len(r)==6 and 'libc.so.6' in r[5]})
 need(paths==[LIBRARY['path']],'EXACT_SINGLE_ALREADY_LOADED_LIBC_NO_PROVIDER_SWAP')
 s=Path(LIBRARY['path']).stat()
 for r in rows:
  if len(r)==6 and r[5]==LIBRARY['path']:
   major,minor=[int(x,16) for x in r[3].split(':')]
   need(int(r[4])==s.st_ino and os.makedev(major,minor)==s.st_dev,'LOADED_LIBC_MATCHES_PINNED_FILE_OBJECT')
 return paths

class PidfdABI:
 """Bind only declared C signatures. Fake symbols allowed for explicit models."""
 def __init__(self,library):
  self.library=library;self.calls={'open':0,'send':0};self.binding=None
  self._open=library.pidfd_open;self._send=library.pidfd_send_signal
  self._open.argtypes=[ctypes.c_int,ctypes.c_uint];self._open.restype=ctypes.c_int
  self._send.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint];self._send.restype=ctypes.c_int
 def verify_binding(self):
  need(type(self.binding) is dict and self.binding['provider']==PROVIDER,'REAL_EXACT_PROVIDER_BINDING_REQUIRED')
  need(pin(LIBRARY['path'])==self.binding['library']==LIBRARY,'LIBC_BYTES_UNCHANGED_AFTER_CALLS')
  need(host_context()==self.binding['hostContext'] and mapped_library()==self.binding['loadedMapping'],
    'LIBC_HOST_MAP_UNCHANGED_AFTER_CALLS')
  return {'provider':dict(PROVIDER),'library':dict(LIBRARY),'hostContext':host_context(),'calls':dict(self.calls)}
 def open(self,pid,flags=0):
  need(type(pid) is int and 1<pid<2147483648 and type(flags) is int and flags==0,'PIDFD_OPEN_INT32_PID_FLAGS0')
  ctypes.set_errno(0);self.calls['open']+=1;rc=self._open(pid,0)
  need(type(rc) is int and -1<=rc<2147483648,'PIDFD_OPEN_C_INT_RETURN')
  if rc==-1:
   error=ctypes.get_errno();need(error>0,'PIDFD_OPEN_ERRNO_REQUIRED');raise OSError(error,os.strerror(error))
  return rc
 def send(self,fd,signum,info=None,flags=0):
  need(type(fd) is int and 0<=fd<2147483648 and isinstance(signum,int) and not isinstance(signum,bool)
    and -2147483648<=int(signum)<2147483648 and info is None and type(flags) is int and flags==0,
    'PIDFD_SEND_INT32_NULL_INFO_FLAGS0')
  ctypes.set_errno(0);self.calls['send']+=1;rc=self._send(fd,int(signum),None,0)
  need(type(rc) is int and rc in (0,-1),'PIDFD_SEND_C_INT_RETURN')
  if rc==-1:
   error=ctypes.get_errno();need(error>0,'PIDFD_SEND_ERRNO_REQUIRED');raise OSError(error,os.strerror(error))
  return None

def load_provider():
 """Metadata checks plus loading only; no pidfd syscall is issued here."""
 need(pin(PROVIDER['path'])==PROVIDER,'EXACT_REVIEWED_PIDFD_PROVIDER_CONFIGURATION')
 cfg=json.loads(Path(PROVIDER['path']).read_bytes())
 need(cfg['library']==LIBRARY and cfg['glibcVersion']=='2.39' and cfg['architecture']=='x86_64'
   and cfg['pointerBits']==64 and cfg['intBits']==32,'FIXED_GLIBC_ABI_CONTEXT')
 need(platform.machine()==cfg['architecture'] and ctypes.sizeof(ctypes.c_void_p)==8
   and ctypes.sizeof(ctypes.c_int)==ctypes.sizeof(ctypes.c_uint)==4,'ACTUAL_PINNED_X86_64_C_TYPES')
 need(host_context()==cfg['hostContext'],'EXACT_REVIEWED_HOST_FOR_LIBC_ABI')
 need(pin(LIBRARY['path'])==LIBRARY,'EXACT_LIBC_BYTES_BEFORE_BINDING');mapped=mapped_library()
 library=ctypes.CDLL(LIBRARY['path'],mode=os.RTLD_NOW|os.RTLD_LOCAL,use_errno=True)
 version=library.gnu_get_libc_version;version.argtypes=[];version.restype=ctypes.c_char_p
 need(version()==b'2.39','EXACT_LOADED_GLIBC_VERSION')
 api=PidfdABI(library)
 need(pin(LIBRARY['path'])==LIBRARY and mapped_library()==mapped,'EXACT_LIBC_BYTES_MAP_AFTER_BINDING')
 api.binding={'provider':dict(PROVIDER),'library':dict(LIBRARY),'glibcVersion':'2.39','hostContext':host_context(),
   'architecture':'x86_64','pointerBits':64,'loadedMapping':mapped,'useErrno':True,
   'openSignature':['c_int','c_uint','returns_c_int'],'sendSignature':['c_int','c_int','NULL_c_void_p','c_uint','returns_c_int'],
   'actualPidfdCallsAtBinding':dict(api.calls)}
 return api
