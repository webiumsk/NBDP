# Actual86 synthetic DATA controls — pending independent result review

The root explicitly authorized one execution of the frozen fixed runner with
exact acknowledgement SHA256
`8772a6d4eeb0a114b1edb000267e2e2d20d4cc6a69e9c6e0d56dee8d6281c86a`.
The real outer launch/poll API objects were preserved immediately and separately
from the owned child's Popen journal. No unavailable provider/process fields
were invented. Actual foreground10009, launch537d52, completionc1631e, outerexit0.

The raw unittest output reports86 tests, no skipped summary, OK. Actual child
exit0/natural/reaped/complete EOF, no force/error/truncation, empty stdout and
10887-byte stderr. All176 frozen inputs/interpreter/monitor/rootack/scoped source
representations matched before/after. Supplemental snapshots additionally retain
and rehash all eight original/full/alias/closed source review/disposition records.
The measured runner phase is1578228364ns; unittest reports0.900s. These are distinct
wall observations, not CPU/resource/interoperability measurements.

This is one Python synthetic DATA suite. Positives include source-backed XML/
selected-note custody and realistic nested RPC bytes, but are not actual Android
rendering, native Rust execution, transport crypto, authenticated execution origins
or a full positive `consume()` graph. Evidence/fixture SHA256/NIP01 hashing is DATA
validation only. No Android, SDK, Node, native, signing/encryption/decryption,
network, Docker/service or NBDP experiment ran. No fixes or retry occurred.

`captureMatched` records mechanical capture/count/source consistency. The operator
does not approve results. Actual same-frozen-result nonauthor/nonoperator QA and
security review are pending. A root-owned acceptance adapter may later bind those
real reports; no future acceptance or approval-shaped document is authored here.
Canonical E02 remains PARTIAL22, all architectural blockers/gates unchanged.

Raw streams/results are exclusive0600. The stdout1MiB/stderr256KiB limits are
post-capture retention/refusal limits, not a streaming-memory guarantee. The fixed
helper and all original SOURCE versions/HOLDs remain unchanged.
