"""Preparation only: stdlib text/AST/JSON/hash/stat; never imports prepared code."""
from pathlib import Path
import ast,hashlib,json,os,stat,difflib
ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP'); E=ROOT/'docs/decisions/evidence'
OLD=E/'e06-request-phase-diagnostic-source-r5'; OC=E/'e06-strace-containment-controls-r4'
NEW=E/'e06-request-phase-diagnostic-source-r6'; NC=E/'e06-strace-containment-controls-r5'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,b):
 if not isinstance(b,bytes):b=b.encode()
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:assert f.write(b)==len(b);f.flush();os.fsync(f.fileno())
def js(p,v):put(p,json.dumps(v,indent=2)+'\n')
def translate(s):return s.replace('e06-request-phase-diagnostic-source-r5','e06-request-phase-diagnostic-source-r6').replace('e06-strace-containment-controls-r4','e06-strace-containment-controls-r5')
def allfiles(paths):return sorted({p for root in paths for p in root.rglob('*') if p.is_file() and not p.is_symlink()})
def state(p):
 s=p.lstat();return {'descriptor':pin(p),'stat':{k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns']}}
history=allfiles([OLD,OC]);before={str(p):state(p) for p in history}
for n in ['test_observer.py','test_snapshot_paths.py','capture-controls.py','capture-data-controls.py','observer.py','test_admission.py','authorization-contracts.json']:
 s=translate((OLD/n).read_text())
 s=s.replace('GUARD20_ADMISSION14','GUARD25_ADMISSION18').replace('TWENTY_GUARD','TWENTYFIVE_GUARD')
 if n in ['observer.py','test_admission.py']:
  s=s.replace("['actualControls']==20","['actualControls']==25").replace("['passed']==20","['passed']==25").replace("['actualAdmissionControls']==14","['actualAdmissionControls']==18").replace("['admissionPassed']==14","['admissionPassed']==18")
  s=s.replace("'actualControls':20","'actualControls':25").replace("'passed':20","'passed':25").replace("'actualAdmissionControls':14","'actualAdmissionControls':18").replace("'admissionPassed':14","'admissionPassed':18")
 if n=='capture-data-controls.py':
  s=s.replace('counted14 DATA admission or20 modeled','counted18 DATA admission or25 modeled').replace("'admission14'","'admission18'").replace("'guard20'","'guard25'").replace("EXPECTED_COUNT=14 if SUITE=='admission18' else 20","EXPECTED_COUNT=18 if SUITE=='admission18' else 25")
  s=s.replace("HERE.parent/'e06-strace-containment-controls-r3',", "HERE.parent/'e06-request-phase-diagnostic-source-r5', HERE.parent/'e06-strace-containment-controls-r4', HERE.parent/'e06-strace-containment-controls-r3',")
 if n=='capture-controls.py':
  s=s.replace("HERE.parent/'e06-strace-containment-controls-r3',", "HERE.parent/'e06-request-phase-diagnostic-source-r5', HERE.parent/'e06-strace-containment-controls-r4', HERE.parent/'e06-strace-containment-controls-r3',")
 if n=='authorization-contracts.json':
  v=json.loads(s);v['modeledGuardAcceptance'].update(actualControls=25,actualAdmissionControls=18,newReadyTemporalModelDefinitions=5,newTemporalAdmissionDefinitions=4)
  v['actualContainmentAcceptance']['perCaseReadyTemporalProofRequired']=True
  s=json.dumps(v,indent=2)+'\n'
 put(NEW/n,s)
for n in ['fixture.py','runner.py','guard.py','test_guard_faults.py','timing-policy.json','pidfd_adapter.py','pidfd-provider.json','host-libc-metadata.json','upstream-header-excerpt.txt']:
 s=(OC/n).read_text()
 # Adapter/provider bytes remain EXACT. They contain no R4-owned source path.
 if n not in ['pidfd_adapter.py','pidfd-provider.json','host-libc-metadata.json','upstream-header-excerpt.txt']:
  s=translate(s).replace('GUARD20_ADMISSION14','GUARD25_ADMISSION18').replace('TWENTY_GUARD','TWENTYFIVE_GUARD')
 if n=='guard.py':
  s=s.replace("['actualControls']==20","['actualControls']==25").replace("['passed']==20","['passed']==25").replace("['actualAdmissionControls']==14","['actualAdmissionControls']==18").replace("['admissionPassed']==14","['admissionPassed']==18")
 put(NC/n,s)
# Preserve immutable before pins before material editing. No old file is modified.
js(NEW/'preserved-inputs.json',{'schema':'e06-source6-history-before-v1','method':'BYTES_AND_STAT_DATA_ONLY','files':before,'oldWholeSource':pin(OLD/'subject.json'),'oldFailedRealSeven':pin(OC/'real-seven-outer-r1/subject.json'),'oldDisposition':pin(OC/'real-seven-outer-r1/review-disposition.json'),'research':pin(E/'e06-strace-transient-source-research-r1/report.json')})
print(json.dumps({'copiedSourceOnly':True,'historicalFiles':len(history),'preparedImports':0,'tests':0}))
