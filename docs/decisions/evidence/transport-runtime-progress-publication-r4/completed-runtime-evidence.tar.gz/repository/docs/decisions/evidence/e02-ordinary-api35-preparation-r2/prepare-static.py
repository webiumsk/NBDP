"""SOURCE/DATA-only v2 profile assembly and AST provenance; no project imports."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
OLD = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v1'
NEW = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v2'
PREVIOUS = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r1'
E = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r2'
FAILED = Path('/tmp/nbdp-e02-ordinary-client-api35-v1/runs/c0fb2643c4c8453091db09bdd36aad5c')
LAB = '/tmp/nbdp-e02-ordinary-client-api35-v2'
AUTHOR = '/root/ordinary_api35_source'
NAMESPACE = [('nbdp-e02-ordinary-client-api35-v1', 'nbdp-e02-ordinary-client-api35-v2'),
             ('e02-api35-first-cell-runtime-plan-v1', 'e02-api35-v2-first-cell-runtime-plan-v1'),
             ('e02-api35-first-cell-release-v1', 'e02-api35-v2-first-cell-release-v1'),
             ('e02-api35-first-cell-supervisor-result-v1', 'e02-api35-v2-first-cell-supervisor-result-v1')]


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    raw = (json.dumps(value, indent=2) + '\n').encode()
    write(E / name, raw)


def write(path, raw):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)


def functions(path):
    result = {}
    def walk(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                name = prefix + child.name
                if not isinstance(child, ast.ClassDef):
                    result[name] = ast.dump(child, include_attributes=False)
                walk(child, name + '.')
            else:
                walk(child, prefix)
    walk(ast.parse(path.read_bytes()))
    return result


def main():
    assert not (E / 'subject.json').exists()
    baseline_subject = json.loads((PREVIOUS / 'subject.json').read_text())
    assert pin(PREVIOUS / 'subject.json')['sha256'] == 'ff877c4c7cbb59551e9a8bf0d13c837c285b3429812516b39091ece9c406d3c7'
    baseline = baseline_subject['sources']
    for row in baseline:
        path = Path(row['path'])
        assert pin(path) == row
        if path.is_relative_to(OLD):
            write(E / 'baseline-v1' / path.relative_to(OLD), path.read_bytes())
    for name in ('subject.json', 'proposed-run-config.json', 'static-checks.json', 'source.diff',
                 'coordinator-resource-prerequisite.json', 'source-qa-review.json', 'source-security-review.json'):
        path = PREVIOUS / name
        write(E / 'baseline-v1/evidence' / name, path.read_bytes())

    supervisor = (NEW / 'supervisor.py').read_text()
    for before, after in NAMESPACE:
        assert before in supervisor
        supervisor = supervisor.replace(before, after)
    (NEW / 'supervisor.py').write_text(supervisor)
    template = json.loads((NEW / 'runtime-plan.json').read_text())
    template['schema'] = 'e02-api35-v2-first-cell-runtime-plan-v1'
    template['state'] = 'SOURCE_ONLY_V2_VISIBILITY_CORRECTION_NOT_TESTED_NOT_RELEASED'
    template['driverSource'] = 'SOURCE_BOUND_VISIBILITY_SEMANTIC_CORRECTION_REQUIRES_NEW_REVIEW'
    template['actualGuardTests'] = 'UNCHANGED_BYTES_SCOPE_LINK_ONLY_NO_NEW_EXECUTION'
    template['limits'] = [
        'SOURCE ONLY: exact independent QA/security of v2 semantic correction, actual currentUI47/cleanup26 controls and independent result review, then fresh exact coordinator release.',
        'Same firstJS-to-Rust incoming rsrelay cell only; other seven producer cells and canonical integration remain undone.',
        'Retain one source-bound Hide Password to Show Password eye action; password metadata remains closed/recorded but is not visual-mask proof alone.',
        'Fresh post-input PNG/XML, same unique closed structural field/eye identity, Show Password state and exact whole public synthetic NSEC remain mandatory.',
        'Guard/fixture/consumer source/test bytes unchanged; only explicitly pinned actual29/27/14 prior pure scopes may carry, not priorUI38/cleanup24 or ordinary acceptance.',
        'SDK35/APK/helper/Lavapipe/containerCPU8/guest4CPU4096MiB/memswap8192MiB/PID512/original1800s lease, requested2048M partition/source6GiB floor unchanged.',
        'Coordinator requires fresh>=8GiB on actual output filesystem before ordinary grant: conservative margin, not measured minimum or boot guarantee.',
        'Known Settings/SystemUI Wait-only<=2 remains bounded; unknown/Quickstep refuse. No new health gate, fallback, SDK/kind/NIP, deployment or blocker closure.',
    ]
    (NEW / 'runtime-plan.json').write_text(json.dumps(template, indent=2) + '\n')
    prefix = '''# API35 ordinary-client v2: source-bound identity visibility correction

SOURCE ONLY. This is a separate first-cell candidate with a fresh run/output
namespace. No v2 tests, Android actions, grant, lease or release have executed.
Evidence and proposed configuration: `docs/decisions/evidence/e02-ordinary-api35-preparation-r2/`.

The archived v1 run correctly tapped the current eye centre once. Its PNG and
XML changed Visibility/Hide Password to VisibilityOff/Show Password while the
empty field retained password=true. Exact pinned Amethyst KeyTextField source
uses unconditional Password content/keyboard semantics; the same showCharsKey
selects Show Password/VisibilityOff and VisualTransformation.None. This is a
source inspection plus empty-field runtime observation, not proof of typed NSEC.

v2 keeps closed package/ancestry/bounds/uniqueness checks and at most one known
Hide-to-Show action. It records/typed-checks accessibility password metadata,
requires the pinned source's shown eye state before and after input, and still
requires the exact entire public synthetic NSEC. Fresh post-input PNG/XML and
independent visual review remain mandatory. Missing/truncated/masked/wrong text,
foreign/duplicate/malformed eye, changed structural field identity and eye
reversion refuse. Existing keyboard-dismissal action is unchanged; visible full
identity must also survive that existing action. Bounds are revalidated on each
capture; a multiline/IME geometry reflow alone does not change field identity.

SDK35, pinned APK/helper/images, Lavapipe, containerCPU8/guest4CPU4096MiB,
Android8192MiB memory/swap/PID512, original1800s lease, closed ADB, fixture,
dialog recovery and cleanup remain fixed. Requested2048M/source6GiB floor do
not prove a2GB footprint; all seven retained ordinary hardware files normalized
to6g. Fresh coordinator-measured>=8GiB on the actual output filesystem is needed
before any ordinary grant as a conservative margin, not a minimum/guarantee.

47 UI and26 cleanup test definitions await independent SOURCE review and actual
execution. Byte-identical guard29/fixture27/consumer14 have separately scoped
prior actual accepted control evidence; they prove no v2 ordinary behavior.
E02PARTIAL22 and all architectural blockers remain unchanged. Seven other
producer cells and canonical integration are still missing. No production SDK,
new kind/NIP, payment behavior, deployment, production data or automatic merge.

Original v1 and historical R11 sources/results are preserved; instructions below
are historical context and grant no v2 activation authority.

---

'''
    for name in ('README.md', 'SUPERVISOR.md'):
        historical = (OLD / name).read_text().split('\n---\n\n', 1)[1]
        (NEW / name).write_text(prefix + historical)

    source_path = Path('/tmp/nbdp-e02-android-artifact/source/commonsUI/src/commonMain/kotlin/com/vitorpamplona/amethyst/commons/account/ui/login/KeyTextField.kt')
    assert (pin(source_path)['bytes'], pin(source_path)['sha256']) == (5653, 'a2b40ef8dbbe401397148e1e05e0557eba3d5a55592603948620363da7795b74')
    inputs = []
    for path in [source_path, FAILED / 'commands/0146.json', FAILED / 'commands/0146.stdout',
                 FAILED / 'commands/0146.stderr', FAILED / 'supervisor-result.json'] + [
                 FAILED / 'ui' / (name + suffix) for name in ('ui-007-tor-saved-state-closed', 'ui-008-public-identity-visible')
                 for suffix in ('.xml', '.png')]:
        target = E / 'diagnosis-inputs' / path.name
        write(target, path.read_bytes())
        inputs.append({'original': pin(path), 'preservedExactBytes': pin(target)})
    save('diagnosis.json', {
        'schema': 'e02-api35-v2-source-bound-visibility-diagnosis-v1', 'author': AUTHOR,
        'inputs': inputs, 'sourceCommit': 'e6f464a1179def75274512b3c5bab921de3bf3d8',
        'sourceCommitCheck': 'Read-only git rev-parse HEAD matched; git diff --exit-code of KeyTextField.kt against pinned commit returned0 during diagnosis.',
        'observed': ['Actual tap846,900 equals button centre; receipt exit0/fullEOF/natural/reaped.',
            'Full XML differs only eye description Hide Password to Show Password; PNG icon changes consistently.',
            'Field remains empty/passwordtrue/focusedfalse; no input text command was executed.',
            'Supervisor FAILED_UNQUALIFIED at old passwordfalse guard; all four containers absent after successful cleanup.'],
        'sourceInspection': 'KeyTextField lines73/79 unconditional Password metadata; lines90-99 same showCharsKey drives eye state; lines123-124 select VisualTransformation.None when true.',
        'inference': 'Driver conflated accessibility password metadata with current visual masking. Actual icon/state changed, so no evidence supports wrong coordinates, missed tap, parent interception or another tap.',
        'limits': ['Empty-field transition does not prove any typed NSEC was rendered.',
            'Exact internal Compose path preserving passwordtrue was not inspected; no binary/source attestation or pixel OCR claim.',
            'v1 remains failed/unqualified, not relabelled PASS; v2 needs independent source/control/runtime review.'],
    })
    config = json.loads((PREVIOUS / 'proposed-run-config.json').read_text())
    config.update(schema=template['schema'], runId=uuid.uuid4().hex,
        state='SOURCE_ONLY_V2_VISIBILITY_FIX_REQUIRES_NEW_REVIEW_CONTROLS_AND_RELEASE')
    config['sourceAndDependencyPins'] = [pin(NEW / Path(row['path']).name) for row in config['sourceAndDependencyPins']]
    save('proposed-run-config.json', config)
    out = Path(LAB) / 'runs' / config['runId']
    assert not out.exists()
    save('coordinator-resource-prerequisite.json', {
        'schema': 'e02-api35-v2-coordinator-resource-prerequisite-v1',
        'origin': 'Explicit root v2 SOURCE assignment preserves original runtime/resource gates and8GiB external admission.',
        'previousActualResourceEvidence': pin(PREVIOUS / 'coordinator-resource-prerequisite.json'),
        'configuration': pin(E / 'proposed-run-config.json'), 'plannedOutput': str(out),
        'freshFreeDiskBytesRequiredBeforeGrant': 8 * 1024**3,
        'filesystem': 'Actual filesystem containing exact new v2 output',
        'meaning': 'Conservative coordinator margin; not a measured minimum or boot guarantee. Requested2048M/source6GiB floor unchanged.',
        'freshCurrentAdmission': 'NOT_EXECUTED_NOT_A_GRANT_OR_RELEASE',
    })

    control_acceptance = json.loads((PREVIOUS / 'current-controls-r1/control-acceptance.json').read_text())
    assert control_acceptance['decision'] == 'ACCEPT_CURRENT_PURE_CONTROL_SCOPES_ONLY'
    for row in control_acceptance['independentReviews']:
        assert pin(Path(row['path'])) == row
    carried = []
    control_subject = json.loads((PREVIOUS / 'current-controls-r1/subject.json').read_text())
    for scope, expected, names in [('guard', 29, ('lease_guard.py', 'test_lease_guard.py')),
            ('fixture', 27, ('fixture.mjs', 'fixture-plan.json', 'test_fixture.mjs')),
            ('consumer', 14, ())]:
        for name in names:
            assert (OLD / name).read_bytes() == (NEW / name).read_bytes()
        entry = next(row for row in control_subject['separateScopes'] if row['scope'] == scope)
        assert entry['count'] == expected
        for key in ('receipt', 'stdout', 'stderr', 'sourceBefore', 'sourceAfter'):
            assert pin(Path(entry[key]['path'])) == entry[key]
        carried.append({'scope': scope, 'count': expected, 'actualAcceptedEvidence': entry,
            'identicalOwnFiles': [pin(NEW / name) for name in names],
            'limits': 'Existing pure/synthetic scope only; no v2 execution, source self approval or ordinary-client runtime acceptance.'})
    save('unchanged-control-scope-link.json', {
        'schema': 'e02-api35-v2-unchanged-control-scope-link-v1',
        'priorActualCoordinatorAcceptance': pin(PREVIOUS / 'current-controls-r1/control-acceptance.json'),
        'actualIndependentReviews': control_acceptance['independentReviews'], 'scopes': carried,
        'unchangedExternalConsumer': [row for row in baseline if not Path(row['path']).is_relative_to(OLD)],
        'excluded': ['PreviousUI38 and cleanup24 do not satisfy changed v2UI47/cleanup26.',
            'No old PASS is transferred to changed runtime sources, dependencies or ordinary-client results.'],
        'authorDoesNotApproveOwnFindings': True,
    })

    before_functions, after_functions = functions(OLD / 'android_driver.py'), functions(NEW / 'android_driver.py')
    changed = sorted(name for name in before_functions if before_functions[name] != after_functions.get(name))
    added = sorted(set(after_functions) - set(before_functions))
    assert changed == ['UI.input_text', 'UI.visible_identity_field']
    assert added == ['UI.identity_control_subject', 'UI.identity_visibility']
    desired_supervisor = (OLD / 'supervisor.py').read_text()
    for before, after in NAMESPACE:
        desired_supervisor = desired_supervisor.replace(before, after)
    assert ast.dump(ast.parse(desired_supervisor), include_attributes=False) == ast.dump(ast.parse((NEW / 'supervisor.py').read_bytes()), include_attributes=False)
    proof = []
    patch = []
    for row in baseline:
        path = Path(row['path'])
        if not path.is_relative_to(OLD):
            assert pin(path) == row
            continue
        current = NEW / path.relative_to(OLD)
        byte_equal = path.read_bytes() == current.read_bytes()
        proof.append({'before': row, 'after': pin(current), 'byteIdentical': byte_equal})
        if not byte_equal:
            patch.extend(difflib.unified_diff(path.read_text().splitlines(True), current.read_text().splitlines(True),
                fromfile=str(path), tofile=str(current)))
    write(E / 'source.diff', ''.join(patch).encode())
    # Whole typed AST source dumps are DATA artifacts, not imports/compilation/tests.
    ast_pair = {'before': ast.dump(ast.parse((OLD / 'android_driver.py').read_bytes()), include_attributes=False, indent=2),
                'after': ast.dump(ast.parse((NEW / 'android_driver.py').read_bytes()), include_attributes=False, indent=2)}
    save('driver-full-typed-ast.json', ast_pair)
    write(E / 'driver-full-typed-ast.diff', ''.join(difflib.unified_diff(
        ast_pair['before'].splitlines(True), ast_pair['after'].splitlines(True), fromfile='v1-whole-typed-AST', tofile='v2-whole-typed-AST')).encode())
    counts = {p.name: sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_')
              for node in ast.walk(ast.parse(p.read_bytes()))) for p in NEW.glob('test_*.py')}
    assert counts == {'test_android_driver.py': 47, 'test_cleanup.py': 26, 'test_lease_guard.py': 29}
    old_tests, new_tests = functions(OLD / 'test_android_driver.py'), functions(NEW / 'test_android_driver.py')
    revised_old = ['IdentityVisibilityControls.test_masked_show_label_still_uses_actual_password_state',
                   'IdentityVisibilityControls.test_unmasked_field_is_never_toggled_even_with_hide_description']
    assert all(value == new_tests.get(name) for name, value in old_tests.items() if name not in revised_old)
    assert set(old_tests) - set(new_tests) == set(revised_old)
    save('historical-test-intent-ledger.json', {
        'schema': 'e02-api35-v2-historical-test-intent-ledger-v1',
        'originalCompleteV1Tests': pin(E / 'baseline-v1/test_android_driver.py'),
        'unchangedHistoricalTestMethods': 36, 'revisedWrongSemanticAssumptions': [
            {'old': revised_old[0], 'new': 'IdentityVisibilityControls.test_actual_shown_state_with_password_semantics_is_not_toggled_again',
             'reason': 'Actual ui008 proves source shown state can retain passwordtrue; original assertion of another tap is preserved as history, not misrepresented as correct.'},
            {'old': revised_old[1], 'new': 'IdentityVisibilityControls.test_contradictory_unpassworded_metadata_and_hidden_eye_refuses',
             'reason': 'Hide Password means source hidden state; synthetic passwordfalse+Hide is now an explicit contradiction negative, not silently accepted as visible.'}],
        'newAdditionalTests': 9, 'currentUiDefinitions': 47, 'currentCleanupDefinitions': 26,
        'newCleanupPurpose': 'Reject old v1 runtime/release schemas before source/inventory/import/resource work.',
        'execution': 'NOT_EXECUTED',
    })
    assert all(pin(Path(row['path'])) == row for row in baseline)
    save('static-checks.json', {
        'schema': 'e02-api35-v2-source-static-v1', 'author': AUTHOR,
        'method': 'stdlib hashes/unified diffs/full typed AST/function AST comparisons only; no project imports, tests, compilation, Node, SDK or runtime',
        'protectedV1Subject': pin(PREVIOUS / 'subject.json'), 'protectedV1Configuration': baseline_subject['configuration'],
        'protectedV1Original21Unchanged': True, 'sourceProofs': proof,
        'namespaceSchemaOnlySupervisorReplacements': NAMESPACE,
        'wholeSupervisorAstEqualsOnlyDeclaredNamespaceSchemaChanges': True,
        'driverChangedMethods': changed, 'driverAddedMethods': added,
        'allOtherDriverFunctionAstsIncludingIdentityControlsLoginAnrAdbFixtureUnchanged': True,
        'newLogicExplicit': ['Source-specific shown-state helper; reject contradictory metadata/hidden state.',
            'Stable structural identity across visibility/input, current strict bounds each capture; no frozen multiline geometry.',
            'Before/post input exact known shown state; existing whole-value check retained; new owned evidence record with actual password flags/PNG/XML.',
            'Recheck visible whole identity after existing keyboard-dismissal action. No additional ADB operation or action budget.'],
        'testDefinitionsOnly': counts, 'historicalTestIntent': pin(E / 'historical-test-intent-ledger.json'),
        'driverFullTypedAst': pin(E / 'driver-full-typed-ast.json'), 'driverFullTypedAstDiff': pin(E / 'driver-full-typed-ast.diff'),
        'sourceDiff': pin(E / 'source.diff'), 'configuration': pin(E / 'proposed-run-config.json'),
        'newExecution': {'controls': 0, 'android': 0, 'services': 0},
    })
    sources = [pin(NEW / Path(row['path']).relative_to(OLD)) if Path(row['path']).is_relative_to(OLD) else row for row in baseline]
    save('subject.json', {
        'schema': 'e02-api35-v2-source-config-subject-v1', 'author': AUTHOR, 'coordinator': '/root',
        'state': 'WRITES_STOPPED_PENDING_ACTUAL_INDEPENDENT_SOURCE_QA_SECURITY',
        'scope': config['scope'], 'sources': sources, 'configuration': pin(E / 'proposed-run-config.json'),
        'diagnosis': pin(E / 'diagnosis.json'), 'baselineV1Subject': pin(E / 'baseline-v1/evidence/subject.json'),
        'staticChecks': pin(E / 'static-checks.json'), 'sourceDiff': pin(E / 'source.diff'),
        'driverAstDiff': pin(E / 'driver-full-typed-ast.diff'),
        'coordinatorResourcePrerequisite': pin(E / 'coordinator-resource-prerequisite.json'),
        'unchangedControlScopeLink': pin(E / 'unchanged-control-scope-link.json'),
        'historicalTestIntent': pin(E / 'historical-test-intent-ledger.json'),
        'preparationSource': pin(Path(__file__).resolve()), 'plannedOutput': str(out),
        'executionReleased': False, 'newExecution': {'controls': 0, 'android': 0, 'services': 0},
        'mandatoryPending': ['Exact new independent SOURCE QA/security review of v2 semantic changes and pins.',
            'Actual currentUI47/cleanup26 controls and independent result reviews; pinned unchanged29/27/14 scope link only.',
            'Fresh host resources/outputFS>=8GiB, exact dependency/SDK/APK/image/current E01/E02 provenance, finite original1800s root first-cell-only release.',
            'Actual post-input PNG/XML exact whole public NSEC and source-bound shown state; no fixture or descriptor fallback.'],
        'limits': ['No v1 negative history rewritten, no canonical promotion or blocker closure.',
            'One first cell only; seven other producer cells/canonical integration remain open.',
            'No new dialog/unknown-ANR handling, health gate, production SDK, kind/NIP or deployment.'],
    })
    save('execution-plan.json', {
        'schema': 'e02-api35-v2-source-control-execution-plan-v1', 'state': 'SOURCE_ONLY_NOT_TESTED_NOT_RELEASED',
        'subject': pin(E / 'subject.json'), 'configuration': pin(E / 'proposed-run-config.json'),
        'actualNewUiCleanupTests': 'NOT_EXECUTED', 'python': pin(Path('/home/peterhorvath/.miniforge3/bin/python3.13')),
        'proposedCurrentControlCommands': [[str(Path('/home/peterhorvath/.miniforge3/bin/python3.13')), '-I', '-B', str(NEW / name)]
            for name in ('test_cleanup.py', 'test_android_driver.py')],
        'expectedSeparateCounts': {'cleanup': 26, 'ui': 47},
        'unchangedActualScopeLink': pin(E / 'unchanged-control-scope-link.json'),
        'doNotRepeatUnchangedScopesForPathsOnly': ['guard29', 'fixture27', 'consumer14'],
        'capture': 'After actual SOURCE QA/security: execute each changed meaningful scope once, finite raw0600 stdout/stderr, natural exit/signal/reap/EOF/force/error/time, source/config/interpreter before-after; stop first failure/no retry.',
        'resourcePrerequisite': pin(E / 'coordinator-resource-prerequisite.json'),
        'futureRuntime': {'supervisor': pin(NEW / 'supervisor.py'), 'plannedOutput': str(out),
            'freshReleaseSchema': 'e02-api35-v2-first-cell-release-v1',
            'missing': 'Actual SOURCE/control independent acceptance, fresh admissions and exact externally pinned coordinator release; none is manufactured here.'},
        'runtimeAcceptance': ['Exactly one known Hide-to-Show action if needed; retain closed metadata/ancestry/bounds/unique login and budgets.',
            'Fresh before/postinput actual PNG/XML, recorded password flags, exact full public NSEC and same structural field/eye subject; independent visual review.',
            'Actual app1059#p/EOSE generation before publication, actual EVENT/wire and independent JS/Rust validation, full actual raw client export, original first-failure/cleanup gates.',
            'Any failure remains failed/unqualified/PARTIAL; successful first cell remains scoped PARTIAL, never canonical E02 PASS.'],
        'grantLeaseReleaseCreated': False, 'sdkAndroidNodeServicesActions': 0,
    })
    write(E / 'README.md', (prefix + '\nEvidence: `subject.json`, `diagnosis.json`, `source.diff`, `driver-full-typed-ast.diff`,\n`historical-test-intent-ledger.json`, `unchanged-control-scope-link.json` and `execution-plan.json`.\n').encode())
    save('artifact-manifest.json', {'schema': 'e02-api35-v2-source-preparation-artifact-manifest-v1',
        'subject': pin(E / 'subject.json'), 'artifacts': [pin(p) for p in sorted(E.rglob('*')) if p.is_file()],
        'limits': 'No self hash; source preparation only, no independent self approval or runtime authority.'})
    print(json.dumps({'state': 'WRITES_STOPPED_SOURCE_ONLY', 'subject': pin(E / 'subject.json'),
        'configuration': pin(E / 'proposed-run-config.json'), 'driver': pin(NEW / 'android_driver.py'),
        'supervisor': pin(NEW / 'supervisor.py'), 'newControlDefinitionsOnly': {'ui': 47, 'cleanup': 26},
        'newRunId': config['runId'], 'sourceDiff': pin(E / 'source.diff')}))


if __name__ == '__main__':
    main()
