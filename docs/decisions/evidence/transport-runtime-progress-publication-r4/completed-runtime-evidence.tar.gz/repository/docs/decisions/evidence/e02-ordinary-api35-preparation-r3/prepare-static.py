"""SOURCE/DATA-only v3 semantic-shape correction; never imports project code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
OLD = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v2'
NEW = ROOT / 'experiments/prototypes/e02_ordinary_client_api35_v3'
PREVIOUS = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r2'
E = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r3'
DIAG = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-structure-diagnosis-r1'
AUTHOR = '/root/ordinary_api35_source'
REPLACEMENTS = [('nbdp-e02-ordinary-client-api35-v2', 'nbdp-e02-ordinary-client-api35-v3'),
    ('e02-api35-v2-first-cell-runtime-plan-v1', 'e02-api35-v3-first-cell-runtime-plan-v1'),
    ('e02-api35-v2-first-cell-release-v1', 'e02-api35-v3-first-cell-release-v1'),
    ('e02-api35-v2-first-cell-supervisor-result-v1', 'e02-api35-v3-first-cell-supervisor-result-v1')]


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, raw):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)


def save(name, value):
    write(E / name, (json.dumps(value, indent=2) + '\n').encode())


def function_asts(path):
    result = {}
    def visit(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.ClassDef, ast.FunctionDef)):
                name = prefix + child.name
                if isinstance(child, ast.FunctionDef):
                    result[name] = ast.dump(child, include_attributes=False)
                visit(child, name + '.')
            else:
                visit(child, prefix)
    visit(ast.parse(path.read_bytes()))
    return result


def main():
    assert not (E / 'subject.json').exists()
    baseline = json.loads((PREVIOUS / 'subject.json').read_text())
    assert pin(PREVIOUS / 'subject.json')['sha256'] == '92293d79675c0294a652fc8fe3a0e578c950d2e62a64d4c3862039acf7d5bd51'
    for row in baseline['sources']:
        path = Path(row['path'])
        assert pin(path) == row
        if path.is_relative_to(OLD):
            write(E / 'baseline-v2' / path.relative_to(OLD), path.read_bytes())
    for name in ('subject.json', 'proposed-run-config.json', 'static-checks.json', 'source.diff',
                 'source-qa-review.json', 'source-security-review.json'):
        write(E / 'baseline-v2/evidence' / name, (PREVIOUS / name).read_bytes())
    for path in sorted((PREVIOUS / 'diagnosis-inputs').iterdir()):
        if path.is_file():
            write(E / 'diagnosis-inputs' / path.name, path.read_bytes())
    for path in sorted((DIAG / 'inputs').glob('ui-0*')):
        write(E / 'diagnosis-inputs' / path.name, path.read_bytes())
    write(E / 'diagnosis-inputs/v2-supervisor-result.json', (DIAG / 'inputs/supervisor-result.json').read_bytes())
    assert pin(DIAG / 'subject.json')['sha256'] == '9dd1a567386c2e072256f3b00626f753898450cff8691cdc35b019dbca83e2a1'
    supervisor = (NEW / 'supervisor.py').read_text()
    for before, after in REPLACEMENTS:
        assert before in supervisor
        supervisor = supervisor.replace(before, after)
    (NEW / 'supervisor.py').write_text(supervisor)
    cleanup = (NEW / 'test_cleanup.py').read_text()
    cleanup_bindings = [('e02-api35-first-cell-runtime-plan-v1', 'e02-api35-v2-first-cell-runtime-plan-v1'),
        ('e02-api35-first-cell-release-v1', 'e02-api35-v2-first-cell-release-v1'),
        ('test_v1_runtime_schema_', 'test_v2_runtime_schema_'),
        ('test_v1_release_schema_', 'test_v2_release_schema_'),
        ('nbdp-e02-v2-release-negative-', 'nbdp-e02-v3-release-negative-')]
    for before, after in cleanup_bindings:
        assert before in cleanup
        cleanup = cleanup.replace(before, after)
    (NEW / 'test_cleanup.py').write_text(cleanup)
    template = json.loads((NEW / 'runtime-plan.json').read_text())
    template.update(schema='e02-api35-v3-first-cell-runtime-plan-v1',
        state='SOURCE_ONLY_V3_SEMANTIC_SHAPE_NO_POSITIONAL_IDENTITY_NOT_TESTED_NOT_RELEASED',
        driverSource='ONLY_VOLATILE_INDEX_EXCLUSION_AND_SEMANTIC_SHAPE_DOCSTRING_REQUIRE_REVIEW')
    template['limits'] = [value.replace('v2', 'v3').replace('UI47', 'UI49') for value in template['limits']]
    template['limits'].append('Semantic class/package/resource-id role shape is not persistent object identity. Positional indices may change when placeholder disappears; current bounds/unique ancestry/known shown state/exact whole public NSEC remain required.')
    (NEW / 'runtime-plan.json').write_text(json.dumps(template, indent=2) + '\n')
    prefix = '''# API35 ordinary-client v3: semantic shape without positional identity

SOURCE ONLY. No v3 controls or Android actions have executed. New source/config
and plan: `docs/decisions/evidence/e02-ordinary-api35-preparation-r3/`.
The exact failed v2 sources, observations and original wrong-index test case are
preserved. Actual ui009->ui010 showed the whole public synthetic NSEC, same
shown eye and password metadata; only button.index3->2 changed in the added
fingerprint when the preceding placeholder TextView disappeared.

The only driver change excludes positional index from the semantic-shape keys
and clarifies its docstring. All other driver methods are AST-identical to v2:
closed current uniqueness/package/ancestry/bounds, known source-bound shown
state, at most one Hide-to-Show action, exact entire public NSEC, post-input
PNG/XML/evidence, existing keyboard-dismissal check, ANR, fixture/export,
budgets and original1800s lease remain unchanged. Matching class/package and
resource IDs (often empty) establishes semantic shape consistency; it never
proves a persistent object identity across Compose recomposition.

49 UI and26 namespace/release cleanup definitions need actual independent
SOURCE review, then finite current controls and independent result acceptance.
The real disappearing-placeholder/index3->2 regression complements the prior
synthetic geometry-only case. Foreign/duplicate/malformed controls, semantic
resource/class/package/role changes, changed eye, unknown metadata and all
partial/masked/missing/wrong whole-value cases still refuse. Actual PNG/XML
and fresh runtime review remain required; source tests alone prove no client
interop or canonical PASS.

SDK35/APK/helper/images/Lavapipe/containerCPU8/guest4CPU4096MiB/memswap8192MiB/
PID512/requested2048M/source6GiB floor remain unchanged. Fresh coordinator
measured>=8GiB on the actual output filesystem is required before any grant,
as a conservative margin rather than a measured minimum or guarantee.
Identical guard29/fixture27/consumer14 retain only their explicitly pinned prior
pure scopes; no reexecution or transfer to changed UI/cleanup/ordinary behavior.

Same first JS-to-Rust incoming rsrelay cell only. Canonical E02 remains PARTIAL22
and blockers remain open. No producer/matrix extension or gate interpretation
is introduced; canonical coverage reconciliation is a separate architect task.
No new kind/NIP, production SDK, deployment, production data or automatic merge.
Historical instructions below grant no v3 activation authority.

---

'''
    for name in ('README.md', 'SUPERVISOR.md'):
        (NEW / name).write_text(prefix + (OLD / name).read_text().split('\n---\n\n', 1)[1])
    config = json.loads((PREVIOUS / 'proposed-run-config.json').read_text())
    config.update(schema=template['schema'], runId=uuid.uuid4().hex,
        state='SOURCE_ONLY_V3_POSITIONAL_INDEX_CORRECTION_REQUIRES_NEW_REVIEW_CONTROLS_RELEASE')
    config['sourceAndDependencyPins'] = [pin(NEW / Path(row['path']).name) for row in config['sourceAndDependencyPins']]
    save('proposed-run-config.json', config)
    output = Path('/tmp/nbdp-e02-ordinary-client-api35-v3/runs') / config['runId']
    assert not output.exists()
    save('coordinator-resource-prerequisite.json', {
        'schema': 'e02-api35-v3-coordinator-resource-prerequisite-v1',
        'priorEvidenceAndCondition': pin(PREVIOUS / 'coordinator-resource-prerequisite.json'),
        'configuration': pin(E / 'proposed-run-config.json'), 'plannedOutput': str(output),
        'requiredFreshFreeBytesOnActualOutputFilesystemBeforeGrant': 8 * 1024**3,
        'meaning': 'Existing coordinator conservative margin; not measured minimum or runtime guarantee. Source6GiB/requested2048M unchanged.',
        'actualNewResourceAdmission': 'PENDING_NOT_A_GRANT_OR_LEASE',
    })
    previous_carry = json.loads((PREVIOUS / 'unchanged-control-scope-link.json').read_text())
    for row in previous_carry['actualIndependentReviews']:
        assert pin(Path(row['path'])) == row
    names = ('lease_guard.py', 'test_lease_guard.py', 'fixture.mjs', 'fixture-plan.json', 'test_fixture.mjs')
    assert all((OLD / name).read_bytes() == (NEW / name).read_bytes() for name in names)
    save('unchanged-control-scope-link.json', {
        'schema': 'e02-api35-v3-unchanged-component-control-link-v1',
        'previousByteBoundAcceptedScopeLink': pin(PREVIOUS / 'unchanged-control-scope-link.json'),
        'originalIndependentReviews': previous_carry['actualIndependentReviews'],
        'identicalCurrentFiles': [pin(NEW / name) for name in names],
        'unchangedExternalConsumerSources': [row for row in baseline['sources'] if not Path(row['path']).is_relative_to(OLD)],
        'scopeCountsOnly': {'guard': 29, 'fixture': 27, 'consumer': 14},
        'newExecution': False,
        'limits': 'No new UI/cleanup/runtime pass or author approval; actual newUI49/cleanup26 review/execution remain required. Prior failures preserved.',
    })
    old_ast, new_ast = function_asts(OLD / 'android_driver.py'), function_asts(NEW / 'android_driver.py')
    changed_methods = sorted(name for name in old_ast if old_ast[name] != new_ast.get(name))
    assert changed_methods == ['UI.identity_control_subject'] and set(old_ast) == set(new_ast)
    expected_driver = (OLD / 'android_driver.py').read_text().replace(
        'Keep the same closed field/eye ancestry without freezing multiline geometry.',
        'Closed semantic field/eye shape; no persistent object identity or position.').replace(
        "keys = ('class', 'package', 'resource-id', 'index')", "keys = ('class', 'package', 'resource-id')")
    assert ast.dump(ast.parse(expected_driver), include_attributes=False) == ast.dump(ast.parse((NEW / 'android_driver.py').read_bytes()), include_attributes=False)
    expected_supervisor = (OLD / 'supervisor.py').read_text()
    for before, after in REPLACEMENTS:
        expected_supervisor = expected_supervisor.replace(before, after)
    assert ast.dump(ast.parse(expected_supervisor), include_attributes=False) == ast.dump(ast.parse((NEW / 'supervisor.py').read_bytes()), include_attributes=False)
    expected_cleanup = (OLD / 'test_cleanup.py').read_text()
    for before, after in cleanup_bindings:
        expected_cleanup = expected_cleanup.replace(before, after)
    assert ast.dump(ast.parse(expected_cleanup), include_attributes=False) == ast.dump(ast.parse((NEW / 'test_cleanup.py').read_bytes()), include_attributes=False)
    counts = {path.name: sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_')
        for node in ast.walk(ast.parse(path.read_bytes()))) for path in NEW.glob('test_*.py')}
    assert counts == {'test_android_driver.py': 49, 'test_cleanup.py': 26, 'test_lease_guard.py': 29}
    old_tests, new_tests = function_asts(OLD / 'test_android_driver.py'), function_asts(NEW / 'test_android_driver.py')
    retired = 'IdentityVisibilityControls.test_changed_field_or_button_identity_refuses_after_input'
    assert set(old_tests) - set(new_tests) == {retired}
    assert all(new_tests.get(name) == value for name, value in old_tests.items() if name != retired)
    save('historical-test-intent-ledger.json', {
        'schema': 'e02-api35-v3-historical-index-assumption-ledger-v1',
        'originalCompleteUi47': pin(E / 'baseline-v2/test_android_driver.py'),
        'retiredWrongIndexCaseWithinMethod': retired,
        'newSemanticNegativeMethod': 'IdentityVisibilityControls.test_changed_semantic_field_or_button_metadata_refuses_after_input',
        'preservedIntent': 'Resource-id mismatch negatives retained and expanded with class/package/eye-resource changes; only positional-index-as-identity assumption removed, not hidden or relabelled as correct.',
        'unchangedHistoricalUiMethods': 46, 'newRegressions': 2, 'currentUiDefinitions': 49,
        'newRegressionsMeaning': 'Actual archived ui009->ui010 placeholder disappearance/index3->2; separately synthetic positional metadata changes alone do not claim object identity.',
        'cleanupDefinitions': 26, 'cleanupRebindingOnly': cleanup_bindings, 'executed': False,
    })
    ast_before = ast.dump(ast.parse((OLD / 'android_driver.py').read_bytes()), include_attributes=False, indent=2)
    ast_after = ast.dump(ast.parse((NEW / 'android_driver.py').read_bytes()), include_attributes=False, indent=2)
    save('driver-full-typed-ast.json', {'before': ast_before, 'after': ast_after})
    write(E / 'driver-full-typed-ast.diff', ''.join(difflib.unified_diff(ast_before.splitlines(True), ast_after.splitlines(True),
        fromfile='v2-whole-typed-AST', tofile='v3-whole-typed-AST')).encode())
    proofs, patch = [], []
    sources = []
    for row in baseline['sources']:
        path = Path(row['path'])
        assert pin(path) == row
        if path.is_relative_to(OLD):
            current = NEW / path.relative_to(OLD)
            same = path.read_bytes() == current.read_bytes()
            sources.append(pin(current))
            proofs.append({'before': row, 'after': pin(current), 'byteIdentical': same})
            if not same:
                patch.extend(difflib.unified_diff(path.read_text().splitlines(True), current.read_text().splitlines(True),
                    fromfile=str(path), tofile=str(current)))
        else:
            sources.append(row)
    write(E / 'source.diff', ''.join(patch).encode())
    save('static-checks.json', {
        'schema': 'e02-api35-v3-source-static-v1', 'actor': AUTHOR,
        'method': 'stdlib DATA hashes/full unified and typed AST diff; no project imports, controls, compilation or runtime',
        'protectedV2Subject': pin(PREVIOUS / 'subject.json'), 'protectedV2Config': baseline['configuration'],
        'all21V2SourcePinsUnchanged': True, 'sourceProofs': proofs,
        'onlyChangedDriverMethod': changed_methods,
        'wholeDriverAstEqualsIndexOperandRemovalAndDocstringOnly': True,
        'allOtherDriverFunctionsIncludingWholeInputVisibilityKeyboardDialogLeaseFixtureUnchanged': True,
        'supervisorNamespaceSchemaBindingsOnly': REPLACEMENTS,
        'cleanupOnlyKnownLegacySchemaNameAndTempPrefixBindings': cleanup_bindings,
        'newImportsActionsCapsBudgetsGates': False,
        'currentTestDefinitionsOnly': counts,
        'diagnosis': pin(DIAG / 'subject.json'), 'historicalTestIntent': pin(E / 'historical-test-intent-ledger.json'),
        'driverTypedAstDiff': pin(E / 'driver-full-typed-ast.diff'), 'sourceDiff': pin(E / 'source.diff'),
        'configuration': pin(E / 'proposed-run-config.json'),
        'newExecution': {'tests': 0, 'android': 0, 'services': 0},
    })
    save('subject.json', {
        'schema': 'e02-api35-v3-source-config-subject-v1', 'author': AUTHOR, 'coordinator': '/root',
        'state': 'WRITES_STOPPED_PENDING_ACTUAL_INDEPENDENT_SOURCE_QA_SECURITY',
        'scope': config['scope'], 'sources': sources, 'configuration': pin(E / 'proposed-run-config.json'),
        'baselineV2Subject': pin(E / 'baseline-v2/evidence/subject.json'),
        'structureDiagnosisSubject': pin(DIAG / 'subject.json'),
        'structureDiagnosis': pin(DIAG / 'diagnosis.json'),
        'staticChecks': pin(E / 'static-checks.json'), 'sourceDiff': pin(E / 'source.diff'),
        'driverTypedAstDiff': pin(E / 'driver-full-typed-ast.diff'),
        'historicalTestIntent': pin(E / 'historical-test-intent-ledger.json'),
        'unchangedControlScopeLink': pin(E / 'unchanged-control-scope-link.json'),
        'coordinatorResourcePrerequisite': pin(E / 'coordinator-resource-prerequisite.json'),
        'preparationSource': pin(Path(__file__).resolve()), 'plannedOutput': str(output),
        'executionReleased': False, 'newExecution': {'tests': 0, 'android': 0, 'services': 0},
        'mandatoryPending': ['Exact independent SOURCE QA/security review of v3 single-helper semantic correction and source/config/test pins.',
            'Actual currentUI49/cleanup26 once plus independent result acceptance; guard29/fixture27/consumer14 unchanged pin-bound scopes only.',
            'Fresh current provenance/resources/outputFS>=8GiB and exact original1800s coordinator first-cell-only release before any runtime.',
            'Actual full client operation/received validation/export/cleanup and independent runtime evidence review; no source-to-PASS shortcut.'],
        'limits': ['Semantic role/shape consistency is not persistent object identity; mutable indices are not used as such.',
            'No matrix extension or canonical coverage/gate interpretation introduced here; separate architect reconciliation pending.',
            'CanonicalE02PARTIAL22 and architectural blockers unchanged; failed v2 remains failed/unqualified.'],
    })
    save('execution-plan.json', {
        'schema': 'e02-api35-v3-source-control-execution-plan-v1', 'state': 'SOURCE_ONLY_NO_CURRENT_CONTROLS_OR_RUNTIME',
        'subject': pin(E / 'subject.json'), 'configuration': pin(E / 'proposed-run-config.json'),
        'python': pin(Path('/home/peterhorvath/.miniforge3/bin/python3.13')),
        'proposedControlCommands': [['/home/peterhorvath/.miniforge3/bin/python3.13', '-I', '-B', str(NEW / name)]
            for name in ('test_cleanup.py', 'test_android_driver.py')],
        'expectedSeparateCountsOnly': {'cleanup': 26, 'ui': 49},
        'unchangedAcceptedScopeLink': pin(E / 'unchanged-control-scope-link.json'),
        'noUnchangedScopeRerunForNamespaceOnly': ['guard29', 'fixture27', 'consumer14'],
        'captureRequirements': 'After exact actual SOURCE QA/security: one finite capture per changed scope, raw0600 stdout/stderr, natural exit/signal/force/error/reap/EOF/timing and exact21source/config/Python/archivedUI inputs before-after; first failure stops, no silent retry.',
        'freshResourcePrerequisite': pin(E / 'coordinator-resource-prerequisite.json'),
        'futureRootReleaseSchema': 'e02-api35-v3-first-cell-release-v1',
        'futureOutput': str(output), 'ordinaryRuntimeAuthorizedByThisPlan': False,
        'requiredRuntimeEvidence': 'Existing complete first-cell gates retained: one known eye action, source shown state, exact whole public NSEC actual PNG/XML, actual app1059#p/EOSE generation, received EVENT/wire independent JS/Rust validation, full real raw client export, original first-failure/all-owned cleanup and actual independent result reviews.',
        'canonicalPromotion': False, 'grantLeaseReleaseCreated': False,
    })
    write(E / 'README.md', (prefix + '\nArtifacts: subject/config, full source/typed AST diffs, explicit historical test ledger,\nstructure diagnosis/input copies and execution-plan. No controls or runtime executed.\n').encode())
    save('artifact-manifest.json', {'schema': 'e02-api35-v3-source-preparation-artifact-manifest-v1',
        'subject': pin(E / 'subject.json'), 'artifacts': [pin(p) for p in sorted(E.rglob('*')) if p.is_file()],
        'limits': 'No self hash; SOURCE only, no source self approval or runtime authority.'})
    print(json.dumps({'state': 'WRITES_STOPPED_SOURCE_ONLY', 'subject': pin(E / 'subject.json'),
        'configuration': pin(E / 'proposed-run-config.json'), 'driver': pin(NEW / 'android_driver.py'),
        'supervisor': pin(NEW / 'supervisor.py'), 'newRunId': config['runId'],
        'sourceDiff': pin(E / 'source.diff'), 'driverTypedAstDiff': pin(E / 'driver-full-typed-ast.diff'),
        'definitionsOnly': {'cleanup': 26, 'ui': 49}}))


if __name__ == '__main__':
    main()
