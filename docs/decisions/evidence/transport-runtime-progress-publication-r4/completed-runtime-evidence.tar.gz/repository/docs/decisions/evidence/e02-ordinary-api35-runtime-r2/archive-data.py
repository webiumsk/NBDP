"""Fixed DATA archive. Requires an actual root FINISHED transcription first.

Importing starts nothing. The author must not invoke this script while runtime
is active. No project import, validator, SDK tool or runtime command is used.
"""
from pathlib import Path
import hashlib
import json
import os
import stat
import xml.etree.ElementTree as ET

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
OUT = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-runtime-r2'
PREP = ROOT / 'docs/decisions/evidence/e02-ordinary-api35-preparation-r2'
RUN = Path('/tmp/nbdp-e02-ordinary-client-api35-v2/runs/619a4fedff96433daa90a57ac5d5eb73')
DIRS = ('commands', 'cleanup', 'ownership', 'session', 'evidence', 'ui', 'diagnostics')
PROFILES = ('android-state/avd/ordinary.ini', 'android-state/avd/ordinary.avd/config.ini',
            'android-state/avd/ordinary.avd/hardware-qemu.ini',
            'android-state/avd/ordinary.avd/emu-launch-params.txt',
            'android-state/avd/ordinary.avd/qemu-version.txt')
KNOWN = {
    'sourceSubject': ('subject.json', 9076, '92293d79675c0294a652fc8fe3a0e578c950d2e62a64d4c3862039acf7d5bd51'),
    'runConfig': ('proposed-run-config.json', 3244, '5f29d9724ad1f01a38319106fe3b56b08cb9dc5efead7c8c771c571dedced146'),
}
REQUIRED_BINDINGS = {'sourceSubject', 'runConfig', 'runRelease', 'freshResourceAdmission',
                     'resourcePrerequisite', 'sourceQaReview', 'sourceSecurityReview',
                     'currentControls', 'unchangedScopeLink'}



def pin(path):
    h = hashlib.sha256(); total = 0
    with path.open('rb') as source:
        while block := source.read(1048576): total += len(block); h.update(block)
    return {'path': str(path), 'bytes': total, 'sha256': h.hexdigest()}


def save(name, value):
    raw = (json.dumps(value, indent=2) + '\n').encode()
    fd = os.open(OUT / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def mirror(source, destination):
    info = source.lstat()
    assert stat.S_ISREG(info.st_mode) and not source.is_symlink(), str(source)
    expected = pin(source)
    assert info.st_size <= 32 * 1024**2, 'Unexpected selected raw-file capture size'
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with source.open('rb') as original, os.fdopen(fd, 'wb') as copy:
        while block := original.read(1048576): copy.write(block)
        copy.flush(); os.fsync(copy.fileno())
    assert pin(source) == expected
    actual = pin(destination)
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
    return dict(expected, mirror=str(destination))


def main():
    # This file is created only after the coordinator explicitly confirms the
    # root foreground completed. It is a transcription, never a runtime grant.
    finished = json.loads((OUT / 'root-finished.json').read_text())
    assert finished['state'] == 'FINISHED' and type(finished['foregroundSession']) is int
    assert finished['launchToolChunk'] and finished['run'] == str(RUN)
    assert type(finished['exit']) is int and finished['completionToolChunk']
    assert not (OUT / 'mirror-manifest.json').exists()
    result_path = RUN / 'supervisor-result.json'
    assert pin(result_path) == finished['supervisor'], 'Actual final supervisor pin required'
    bindings = json.loads((OUT / 'actual-input-bindings.json').read_text())
    assert type(bindings) is dict and set(bindings) == REQUIRED_BINDINGS
    for role, (name, size, digest) in KNOWN.items():
        actual = pin(PREP / name)
        assert (actual['bytes'], actual['sha256']) == (size, digest) and bindings[role] == actual
    for role, descriptor in bindings.items():
        assert set(descriptor) == {'path', 'bytes', 'sha256'}
        path = Path(descriptor['path'])
        assert path.resolve(strict=True).is_relative_to(PREP) and not path.is_symlink()
        assert path.suffix == '.json' and descriptor['bytes'] <= 32 * 1024**2
        assert pin(path) == descriptor
    result = json.loads(result_path.read_text())
    files = []; missing = []
    for dirname in DIRS:
        directory = RUN / dirname
        if not directory.exists(): missing.append(dirname); continue
        for source in sorted(directory.rglob('*')):
            if source.is_file(): files.append(mirror(source, OUT / 'actual-run' / source.relative_to(RUN)))
    for name in ('supervisor-result.json', 'driver-result.json', 'driver-partial.json', 'input/run-config.json') + PROFILES:
        source = RUN / name
        if source.is_file(): files.append(mirror(source, OUT / 'actual-run' / name))
        else: missing.append(name)
    for role, descriptor in bindings.items():
        files.append(mirror(Path(descriptor['path']), OUT / 'preparation-inputs' / (role + '.json')))
    assert result['runConfig'] == bindings['runConfig'] and result['runRelease'] == bindings['runRelease']
    subject = json.loads((PREP / 'subject.json').read_text())
    # Complete source subject contains reviewed text files, not SDK/APK/binaries.
    for index, entry in enumerate(subject['sources']):
        source = Path(entry['path']); assert pin(source) == entry
        assert source.suffix.lower() in ('.py', '.mjs', '.json', '.md', '.java', '.xml', '.toml')
        files.append(mirror(source, OUT / 'source-profile' / ('%02d-' % index + source.name)))
    selected = {Path(entry['path']) for entry in files if Path(entry['path']).is_relative_to(RUN)}
    exclusions = []
    for path in sorted(RUN.rglob('*')):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode) or path in selected: continue
        relative = path.relative_to(RUN)
        socket_only = str(relative) == 'session/fixtures/control.sock' and stat.S_ISSOCK(info.st_mode)
        assert relative.parts[0] in ('android-state', 'input', 'docker-config', 'relay-data') or socket_only, str(relative)
        exclusions.append({'path': str(path), 'relative': str(relative), 'bytesFromMetadataOnly': info.st_size,
            'mode': oct(info.st_mode), 'type': 'symlink' if stat.S_ISLNK(info.st_mode) else ('regular' if stat.S_ISREG(info.st_mode) else 'special'),
            'reason': 'Actual ADB/encryption/runtime key files, mutable userdata/images/caches/locks, mounted inputs, Docker config, full relay DB and the fixed owned control socket endpoint are excluded. Contents not read; socket never connected.'})
    save('exclusions.json', {'schema': 'ordinary-api35-v2-explicit-exclusions-v1', 'files': exclusions,
        'count': len(exclusions), 'externalExclusions': ['SDK/APK/ZIP/dependency trees and all external caches not traversed or copied.'],
        'syntheticInputPolicy': 'Preserve reviewed public scalar2 fixture/request/NSEC UI input as synthetic test evidence; no redaction of immutable public test inputs. Actual ADB/encryption/runtime key-file bodies are excluded.'})
    receipts = []
    for path in sorted((RUN / 'commands').glob('*.json')):
        row = json.loads(path.read_text()); receipts.append((path.name, row))
    abnormal = [(name, row) for name, row in receipts if row.get('error') or row.get('forced') or row.get('timedOut')
        or row.get('exit') != 0 or not row.get('reaped') or not row.get('stdoutEOF') or not row.get('stderrEOF')]
    props = {}
    for name in ('ro.build.fingerprint.txt', 'ro.build.version.sdk.txt'):
        path = RUN / 'evidence' / name
        props[name] = {'raw': pin(path), 'actualText': path.read_text().strip()} if path.exists() else 'NOT_ACQUIRED'
    ui = []
    for path in sorted((RUN / 'ui').glob('*.xml')):
        row = {'xml': pin(path)}
        try:
            root = ET.fromstring(path.read_bytes())
            row['anrTitleTexts'] = [n.get('text', '') for n in root.iter('node') if n.get('resource-id') == 'android:id/alertTitle']
        except ET.ParseError as error: row['xmlParseError'] = repr(error)
        ui.append(row)
    profiles = []
    for name in PROFILES:
        path = RUN / name
        if not path.exists(): continue
        parsed = {}
        for line in path.read_text().splitlines():
            if '=' in line:
                key, value = (part.strip() for part in line.split('=', 1)); parsed[key] = value
        profiles.append({'raw': pin(path), 'configurationOnly': {key: parsed[key] for key in
            ('hw.cpu.ncore', 'hw.ramSize', 'hw.gpu.mode', 'disk.dataPartition.size', 'image.sysdir.1', 'target') if key in parsed}})
    driver_path = RUN / 'driver-result.json'
    driver = json.loads(driver_path.read_text()) if driver_path.exists() else None
    raw_export = RUN / 'evidence/client-raw-rumor.json'
    control = RUN / 'session/control/REVOKED'
    observed = {'schema': 'ordinary-api35-v2-runtime-data-observation-v1',
        'actor': '/root/android_health_implementer, DATA archiver not operator or independent reviewer',
        'rootFinalState': result.get('executionState'), 'supervisorError': result.get('error'),
        'secondaryErrors': result.get('secondaryErrors', []),
        'commandCount': len(receipts), 'abnormalCommands': [{'file': name, 'receipt': row} for name, row in abnormal],
        'firstStickyReason': control.read_text() if control.exists() else 'NOT_RETAINED',
        'actualGuestGetprops': props, 'configuredProfilesOnly': profiles, 'rawUiXmlCount': len(ui), 'uiXmlObservations': ui,
        'actualRawExport': pin(raw_export) if raw_export.exists() else 'NOT_ACQUIRED',
        'driverResultPresent': driver is not None, 'driverReportedState': driver.get('executionState') if driver else 'NOT_ACQUIRED',
        'driverReportedObservationRows': driver.get('observations', []) if driver else [],
        'cleanup': result.get('cleanup'), 'missing': missing,
        'ordinaryCellIndependentQualification': 'PENDING_ACTUAL_INDEPENDENT_QA_SECURITY',
        'canonicalE02Changed': False, 'SDKSourceConfigurationOrTimerChanged': False, 'experimentRerun': False,
        'limits': ['Configured API35/Lavapipe/resources are separate from actual getprop/render/export/cleanup observations.',
            'Presence of raw export/driver result is not independent acceptance or full ordinary matrix/canonical PASS.',
            'No healthy baseline, ANR-cause/renderer causality or business-dispatch/approval capability claim.',
            'Public disposable scalar2 test inputs are retained as synthetic evidence; actual key-file bodies are excluded.']}
    save('observation.json', observed)
    for entry in files:
        assert pin(Path(entry['path'])) == {key: entry[key] for key in ('path', 'bytes', 'sha256')}
    save('mirror-manifest.json', {'schema': 'ordinary-api35-v2-selected-mirror-v1', 'run': str(RUN),
        'archiver': pin(Path(__file__).resolve()), 'files': files, 'mirroredFiles': len(files),
        'selectedRunFiles': len(selected), 'mirroredBytes': sum(e['bytes'] for e in files),
        'exclusions': pin(OUT / 'exclusions.json'), 'originalAndMirrorPinsVerified': True,
        'rootFinishedTranscription': pin(OUT / 'root-finished.json'),
        'actualInputBindings': pin(OUT / 'actual-input-bindings.json'),
        'controlMeaning': 'New cleanup26/UI47 actual scopes plus separately carried unchanged29/27/14 only; no rerun or PASS transfer.',
        'noProjectImportsOrRuntimeCommands': True})
    print(json.dumps({'mirroredFiles': len(files), 'mirroredBytes': sum(e['bytes'] for e in files),
        'supervisorState': result.get('executionState'), 'commandCount': len(receipts),
        'rawExportPresent': raw_export.exists(), 'state': 'ARCHIVED_PENDING_INDEPENDENT_REVIEW'}))


if __name__ == '__main__':
    main()
