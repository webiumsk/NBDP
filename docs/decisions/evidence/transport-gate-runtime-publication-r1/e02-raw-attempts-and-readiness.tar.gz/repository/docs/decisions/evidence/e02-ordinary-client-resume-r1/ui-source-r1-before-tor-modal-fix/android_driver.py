"""Closed XML-driven first ordinary-client cell; no subprocesses or import-time work."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import time
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
APP = 'com.vitorpamplona.amethyst.debug'
APP_COMPONENT = APP + '/com.vitorpamplona.amethyst.ui.MainActivity'
HELPER = 'org.nbdp.clipboard.capture'
HELPER_COMPONENT = HELPER + '/.CaptureActivity'
CASE = 'js-to-rust-incoming-rs'
NSEC = 'nsec1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpqptcfk2'
ACCOUNT = 'c6047f9441ed7d6d3045406e95c07cd85c778e4b8cef3ca7abac09b95c709ee5'
PEER = '79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798'
URL = 'ws://localhost:17777'


def need(value, message):
    if not value:
        raise ValueError(message)


def loads(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, 'Duplicate JSON key')
            value[key] = item
        return value
    return json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs,
                      parse_float=lambda _: need(False, 'Integer-only new evidence'),
                      parse_constant=lambda _: need(False, 'Nonfinite JSON refused'))


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return set(a) == set(b) and all(equal(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def read(pin, maximum=2097152):
    need(set(pin) == {'path', 'bytes', 'sha256'}, 'Closed descriptor required')
    path = Path(pin['path'])
    need(path.is_absolute() and path.resolve(strict=True) == path and not path.is_symlink(), 'Canonical evidence path required')
    need(type(pin['bytes']) is int and 0 <= pin['bytes'] <= maximum, 'Bounded evidence required')
    raw = path.read_bytes()
    need(len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'], 'Evidence drift')
    return raw


def fixture(runtime, operation):
    runtime.check()
    raw = runtime.fixture(operation)
    runtime.put_bytes('evidence/fixture-' + operation + '-reply.json', raw)
    value = loads(raw)
    need(value['schema'] == 'e02-fixture-command-v1' and value['operation'] == operation
         and value['caseId'] == CASE and value['ok'] is True, 'Exact successful fixture operation required')
    runtime.check()
    return value['result']


def mapped(runtime, descriptor):
    original = PurePosixPath(descriptor['path'])
    prefix = PurePosixPath('/session/fixtures')
    need(original.is_relative_to(prefix) and '..' not in original.parts, 'Fixed fixture namespace required')
    path = runtime.out / 'session/fixtures' / original.relative_to(prefix)
    value = dict(descriptor, path=str(path))
    read(value, 16777216)
    return value


class UI:
    def __init__(self, runtime):
        self.runtime = runtime
        self.serial = 0
        self.actions = 0
        self.tree = None
        self.current = None
        self.captures = []

    def refresh(self, label):
        self.runtime.check()
        self.serial += 1
        need(self.serial <= 140 and re.fullmatch('[a-z0-9-]{1,40}', label), 'Finite named UI capture limit')
        self.current = self.runtime.snapshot('ui-%03d-' % self.serial + label)
        raw = read(self.current['xml'])
        need(b'<!DOCTYPE' not in raw and b'<!ENTITY' not in raw, 'XML declarations refused')
        self.tree = ET.fromstring(raw)
        need(self.tree.tag == 'hierarchy' and len(list(self.tree.iter())) < 10000, 'Bounded actual UI hierarchy required')
        self.captures.append(self.current)
        self.runtime.check()
        return self.current

    def nodes(self):
        return list(self.tree.iter('node'))

    def find(self, value, description=False, contains=False):
        field = 'content-desc' if description else 'text'
        return [n for n in self.nodes() if (value in n.get(field, '') if contains else n.get(field) == value)]

    def one(self, value, description=False):
        found = self.find(value, description)
        need(len(found) == 1, 'Expected exactly one current UI control: ' + value)
        return found[0]

    def bounds(self, node):
        match = re.fullmatch(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', node.get('bounds', ''))
        need(match is not None, 'Actual control bounds missing')
        x, y, right, bottom = map(int, match.groups())
        need(0 <= x < right <= 1080 and 0 <= y < bottom <= 1920, 'Control outside reviewed display')
        return x, y, right, bottom

    def adb(self, args):
        self.runtime.check()
        self.actions += 1
        need(self.actions <= 120, 'Finite UI action count exceeded')
        value = self.runtime.adb(args)
        self.runtime.check()
        return value

    def tap(self, node, label):
        x, y, right, bottom = self.bounds(node)
        self.adb(['shell', 'input', 'tap', str((x + right) // 2), str((y + bottom) // 2)])
        self.runtime.sleep(1)
        self.refresh(label)

    def click(self, value, label, description=False):
        self.tap(self.one(value, description), label)

    def key_back(self, label):
        self.adb(['shell', 'input', 'keyevent', '4'])
        self.runtime.sleep(1)
        self.refresh(label)

    def scroll_to(self, value, anchor, limit=7, editable_below=False):
        for _ in range(limit):
            if self.find(value):
                heading_bottom = self.bounds(self.one(value))[3]
                if not editable_below or any(n.get('class') == 'android.widget.EditText'
                    and self.bounds(n)[1] > heading_bottom for n in self.nodes()):
                    return
            need(self.find(anchor) or self.find(anchor, True), 'Unrecognized screen; no blind scroll')
            regions = [n for n in self.nodes() if n.get('scrollable') == 'true']
            need(len(regions) == 1, 'Exactly one known scroll region required')
            x, y, right, bottom = self.bounds(regions[0])
            center = (x + right) // 2
            self.adb(['shell', 'input', 'swipe', str(center), str(y + (bottom-y)*4//5),
                      str(center), str(y + (bottom-y)//4), '350'])
            self.runtime.sleep(1)
            self.refresh('known-scroll')
        need(bool(self.find(value)), 'Expected control absent after bounded scroll: ' + value)

    def input_text(self, value, label):
        need(value in (NSEC, URL), 'Only fixed public synthetic identity/local URL may be typed')
        self.adb(['shell', 'input', 'text', value])
        self.refresh(label)
        edits = [n for n in self.nodes() if n.get('class') == 'android.widget.EditText' and n.get('text') == value]
        need(len(edits) == 1, 'Actual input field must contain the whole intended value')
        if any('inputmethod' in n.get('package', '') for n in self.nodes()):
            self.key_back('keyboard-dismissed')


def login(ui):
    need(ui.adb(['shell', 'pm', 'clear', APP]).strip() == b'Success', 'Fresh app clear did not succeed')
    ui.adb(['shell', 'am', 'start', '-W', '-n', APP_COMPONENT])
    ui.refresh('login-start')
    if ui.find("System UI isn't responding"):
        ui.click('Wait', 'system-ui-wait')
    for _ in range(6):
        if ui.find('Adjust Tor Settings'):
            break
        ui.runtime.sleep(1)
        ui.refresh('login-settle')
    ui.click('Adjust Tor Settings', 'privacy-options')
    if ui.find('Use regular connection'):
        ui.click('Use regular connection', 'regular-connection')
    heading = ui.one('Active Tor Engine')
    center = sum(ui.bounds(heading)[1::2]) // 2
    spinners = [n for n in ui.nodes() if n.get('class') == 'android.widget.Spinner']
    candidates = [n for n in spinners if abs(sum(ui.bounds(n)[1::2])//2 - center) <= 100]
    need(len(candidates) == 1, 'Unique Tor selector in actual labeled row required')
    ui.tap(candidates[0], 'tor-engine-menu')
    need(ui.find('Internal') and ui.find('Orbot'), 'Expected Tor choices required')
    ui.click('Off', 'tor-off-selected')
    ui.click('Save', 'login-tor-saved')
    edits = [n for n in ui.nodes() if n.get('class') == 'android.widget.EditText']
    need(len(edits) == 1, 'Fresh single login field required')
    if ui.find('Show Password', True):
        ui.click('Show Password', 'public-identity-visible', True)
        edits = [n for n in ui.nodes() if n.get('class') == 'android.widget.EditText']
    ui.tap(edits[0], 'login-field-focused')
    ui.input_text(NSEC, 'whole-disposable-identity')
    ui.click('Login', 'login-submitted')
    for _ in range(8):
        if ui.find('Your Profile Picture', True):
            return
        ui.runtime.sleep(1)
        ui.refresh('login-await-home')
    raise ValueError('No recognized logged-in home; refuse further actions')


def own_identity(ui):
    ui.click('Your Profile Picture', 'account-drawer', True)
    ui.click('Profile', 'own-profile')
    ui.click('More Options', 'own-profile-actions', True)
    ui.click('Share', 'own-public-share')
    preview = ui.current
    observed = [n.get('text') for n in ui.nodes() if 'nprofile1' in n.get('text', '')]
    need(bool(observed), 'Actual public nprofile GUI preview required')
    ui.key_back('share-closed')
    ui.key_back('profile-closed')
    return {'preview': preview, 'observedPublicProfileText': observed,
            'meaning': 'Actual share GUI retained for independent public-key decoding; no share target opened.'}


def local_relay(ui):
    ui.click('Your Profile Picture', 'relay-drawer', True)
    ui.scroll_to('System', 'Close navigation menu')
    if not ui.find('Relays'):
        ui.click('System', 'system-expanded')
    ui.scroll_to('Relays', 'Close navigation menu')
    ui.click('Relays', 'relay-settings')
    ui.scroll_to('Local Relays', 'Relay Settings', editable_below=True)
    heading = ui.one('Local Relays')
    threshold = ui.bounds(heading)[3]
    below = [n for n in ui.nodes() if n.get('class') == 'android.widget.EditText' and ui.bounds(n)[1] > threshold]
    need(bool(below), 'Local relay field must be visible below its heading')
    field = min(below, key=lambda n: ui.bounds(n)[1])
    for other in ('Trusted Relays', 'Search Relays', 'Indexer Relays'):
        for node in ui.find(other):
            need(not threshold < ui.bounds(node)[1] < ui.bounds(field)[1], 'Adjacent relay section is not Local Relays')
    ui.tap(field, 'local-relay-field')
    ui.input_text(URL, 'local-relay-url')
    field = next(n for n in ui.nodes() if n.get('class') == 'android.widget.EditText' and n.get('text') == URL)
    center = sum(ui.bounds(field)[1::2]) // 2
    adds = [n for n in ui.find('Add') if abs(sum(ui.bounds(n)[1::2])//2 - center) <= 100]
    need(len(adds) == 1, 'Only Add in actual Local Relays row may be used')
    ui.tap(adds[0], 'local-relay-added')
    need(ui.find('localhost:17777') or ui.find('Relay localhost:17777', True), 'Actual local relay row missing')
    ui.click('Save', 'local-relay-saved')
    ui.click('Messages', 'messages', True)
    ui.click('New Requests', 'new-requests')


def helper(ui, action):
    ui.adb(['shell', 'am', 'start', '-W', '-n', HELPER_COMPONENT, '--es', 'caseId', CASE])
    ui.refresh('helper-' + action.lower())
    ui.click('Clear clipboard' if action == 'CLEAR' else 'Capture clipboard', 'helper-' + action.lower() + '-result')
    suffix = '.clear.json' if action == 'CLEAR' else '.receipt.json'
    raw = ui.adb(['exec-out', 'run-as', HELPER, 'cat', 'files/captures/' + CASE + suffix])
    value = loads(raw)
    need(value['schema'] == 'e02-clipboard-capture-v1' and value['caseId'] == CASE
         and value['action'] == action and value['foregroundFocus'] is True, 'Actual focused helper receipt required')
    descriptor = ui.runtime.put_bytes('evidence/helper-' + action.lower() + '.json', raw)
    return value, descriptor


def run(runtime):
    runtime.check()
    plan = loads((HERE / 'ui-plan.json').read_bytes())
    need(plan['caseId'] == CASE and plan['account'] == ACCOUNT and plan['peer'] == PEER
         and plan['localRelay'] == URL and plan['scope'] == 'ONE_REAL_ENVELOPE_FIRST_SLICE_ONLY', 'Fixed UI slice required')
    prepared = fixture(runtime, 'prepare')
    expected_pin = mapped(runtime, prepared['expectedRumor'])
    expected = loads(read(expected_pin))
    content_pin = mapped(runtime, prepared['expectedContent'])
    need(read(content_pin).decode('utf-8') == expected['content'] and expected['pubkey'] == PEER
         and expected['kind'] == 14 and expected['tags'] == [['p', ACCOUNT]], 'Canonical incoming envelope subject required')
    need(plan['visibleToken'] in expected['content'], 'Actual envelope must contain the declared UI token')
    ui = UI(runtime)
    login(ui)
    account_ui = own_identity(ui)
    local_relay(ui)
    need(not ui.find(plan['visibleToken'], contains=True), 'Fresh input already rendered before publication')
    for _ in range(20):
        status_raw = runtime.fixture('status')
        status = loads(status_raw)
        need(status['schema'] == 'e02-fixture-command-v1' and status['operation'] == 'status'
             and status['ok'] is True and status['caseId'] == CASE, 'Exact live subscription status required')
        if status['result']['ready'] is True:
            runtime.put_bytes('evidence/subscription-status.json', status_raw)
            break
        runtime.sleep(2)
    else:
        raise ValueError('No actual matching app REQ/EOSE; nothing published')
    published = fixture(runtime, 'publish')
    for _ in range(12):
        ui.refresh('await-real-envelope')
        if ui.find(plan['visibleToken'], contains=True):
            break
        runtime.sleep(2)
    else:
        raise ValueError('Actual envelope was not rendered')
    previews = ui.find(plan['visibleToken'], contains=True)
    need(len(previews) == 1, 'Unique current incoming conversation preview required')
    ui.tap(previews[0], 'actual-conversation')
    need(ui.find('Back', True) and ui.find('Voice call', True), 'Recognized chat conversation required')
    cleared, clear_pin = helper(ui, 'CLEAR')
    need(cleared['status'] == 'EMPTY_SENTINEL_SET', 'Guest clipboard was not cleared')
    ui.key_back('return-selected-note')
    selected = ui.current
    notes = ui.find(plan['visibleToken'], contains=True)
    need(len(notes) == 1, 'Select one real note, not cached/duplicate content')
    x, y, right, bottom = ui.bounds(notes[0])
    center_x, center_y = (x+right)//2, (y+bottom)//2
    ui.adb(['shell', 'input', 'swipe', str(center_x), str(center_y), str(center_x), str(center_y), '700'])
    ui.refresh('message-action-sheet')
    ui.click('More Options', 'expanded-message-actions')
    ui.click('Copy raw JSON', 'real-copy-raw-json')
    captured, helper_pin = helper(ui, 'CAPTURE')
    need(captured['status'] == 'CAPTURED' and captured['mime'] == 'text/plain'
         and captured['clipboardItemCount'] == 1 and captured['clipboardTimestamp'] >= cleared['wallClockMillis'], 'Fresh copied text required')
    raw = ui.adb(['exec-out', 'run-as', HELPER, 'cat', 'files/captures/' + CASE + '.raw.json'])
    need(len(raw) <= 65536 and captured['bytes'] == len(raw)
         and captured['sha256'] == hashlib.sha256(raw).hexdigest(), 'Whole captured UTF-8 custody required')
    exported = loads(raw)
    if type(exported) is dict and set(exported) == set(expected) | {'sig'}:
        need(type(exported['sig']) is str and exported['sig'] == '', 'Only empty unsigned export signature permitted')
        exported = {key: value for key, value in exported.items() if key != 'sig'}
    need(equal(exported, expected), 'Actual client export differs from expected whole inner rumor')
    raw_pin = runtime.put_bytes('evidence/client-raw-rumor.json', raw)
    transport_original = mapped(runtime, published['transport'])
    transport = loads(read(transport_original, 16777216))
    need(transport['schema'] == 'e02-ordinary-transport-v1', 'Actual received-wire transport proof required')
    transport = dict(transport, **{k: mapped(runtime, v) for k, v in transport.items() if k != 'schema'})
    transport_pin = runtime.put_json('evidence/transport-host-paths.json', transport)
    selection = runtime.put_json('evidence/selection.json', {
        'schema': 'e02-ordinary-selection-v1', 'observationId': CASE, 'account': ACCOUNT,
        'peer': PEER, 'rumorId': expected['id'], 'action': 'COPY_RAW_JSON',
        'method': 'ANDROID_LOCAL_FOREGROUND', 'helperPackage': HELPER,
        'helperArtifact': runtime.plan['helperApk'], 'helperReceipt': helper_pin,
        'capturedMonotonicNs': time.monotonic_ns()})
    runtime.check()
    return {'schema': 'e02-first-slice-driver-result-v1', 'runId': runtime.plan['runId'],
        'runConfig': runtime.plan_pin, 'runRelease': runtime.release_pin,
        'executionState': 'PARTIAL', 'accountIdentityGUI': account_ui,
        'expectedRumor': expected_pin, 'originalTransport': transport_original,
        'clipboardClear': clear_pin, 'allUICaptures': ui.captures,
        'observations': [{'id': CASE, 'status': 'COMPLETE', 'transport': transport_pin,
            'selection': selection, 'uiPng': selected['png'], 'uiXml': selected['xml'],
            'rawClientRumor': raw_pin, 'error': None}],
        'limits': ['One actual first slice only; seven proposed coverage rows remain missing.',
                   'GUI captures are sequential, not atomic. Account public profile needs independent decoding.',
                   'Ordinary JSON rendering/export is not a business-dispatch/approval capability.'],
        'canonicalE02Changed': False}
