"""Prepared inert tests only: never starts Docker, ADB, emulator or a child."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


path = Path(__file__).with_name('lease_guard.py')
spec = importlib.util.spec_from_file_location('e02_tested_lease_guard', path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


class Clock:
    def __init__(self):
        self.value = {'Utc': 1_800_000_000 * guard.NS, 'Mono': 100 * guard.NS,
                      'Boot': 100 * guard.NS, 'bootId': 'synthetic-boot'}
    def __call__(self): return dict(self.value)
    def advance(self, seconds):
        for kind in ('Utc', 'Mono', 'Boot'): self.value[kind] += seconds * guard.NS


class LeaseBoundaryTests(unittest.TestCase):
    def make(self, root):
        clock = Clock(); data = guard.issue('a' * 32, 60, clock)
        path = root / 'lease.json'; raw = (json.dumps(data) + '\n').encode(); path.write_bytes(raw)
        control = root / 'control'; control.mkdir()
        return guard.Lease(path, hashlib.sha256(raw).hexdigest(), control, clock), clock

    def test_nominal_original_lease_dispatch(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            clock.advance(1)
            self.assertEqual(lease.dispatch(lambda: calls.append('payload') or 'actual-result'), 'actual-result')
            self.assertEqual(calls, ['payload'])
            self.assertFalse((lease.control / 'REVOKED').exists())

    def test_already_expired_dispatches_no_payload(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            clock.advance(60)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('forbidden'))
            self.assertEqual(calls, [])
            self.assertTrue((lease.control / 'REVOKED').exists())

    def test_expiry_during_wait_never_accepts_or_dispatches_later(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            def in_flight():
                calls.append('already-in-flight'); clock.advance(60)
                return 'must-not-be-accepted'
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(in_flight)
            clock.advance(-60)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('later-forbidden'))
            self.assertEqual(calls, ['already-in-flight'])
            self.assertTrue((lease.control / 'REVOKED').exists())

    def test_explicit_revoke_is_sticky_after_wait(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            def in_flight():
                calls.append('already-in-flight')
                (lease.control / 'REVOKED').write_text('inert explicit revoke\n')
                return 'must-not-be-accepted'
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(in_flight)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('later-forbidden'))
            self.assertEqual(calls, ['already-in-flight'])


if __name__ == '__main__': unittest.main()
