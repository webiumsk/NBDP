"""Bounded local controls only: no Docker, ADB, emulator or host clock mutation.

Four original pure controls plus small owned Python child lifecycle regressions.
Execution remains a separate root-authorized step after exact source review.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import os
import sys


path = Path(__file__).with_name('lease_guard.py')
spec = importlib.util.spec_from_file_location('e02_tested_lease_guard', path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


class Clock:
    def __init__(self):
        self.value = {'Utc': 1_800_000_000 * guard.NS, 'Mono': 100 * guard.NS,
                      'Boot': 100 * guard.NS, 'bootId': 'synthetic-boot'}
    def __call__(self): return dict(self.value)
    def advance(self, seconds):
        for kind in ('Utc', 'Mono', 'Boot'): self.value[kind] += seconds * guard.NS


class LeaseBoundaryTests(unittest.TestCase):
    def test_only_exact_cold_boot_wait_and_pinned_install_have180s_ceiling(self):
        self.assertTrue(guard.allowed_adb(['wait-for-device']))
        self.assertEqual(guard.adb_timeout(['wait-for-device']), 180)
        self.assertEqual(guard.adb_timeout(['install', '--no-streaming', '/artifact.apk']), 180)
        for args in (['shell', 'getprop', 'sys.boot_completed'],
                     ['install', '-t', '--no-streaming', '/helper.apk'],
                     ['exec-out', 'screencap', '-p'], ['reverse', 'tcp:17777', 'tcp:17777']):
            self.assertTrue(guard.allowed_adb(args)); self.assertEqual(guard.adb_timeout(args), 30)
        self.assertFalse(guard.allowed_adb(['wait-for-device', '--unexpected']))
        self.assertEqual(guard.adb_timeout(['wait-for-device', '--unexpected']), 30)

    def make(self, root):
        clock = Clock(); data = guard.issue('a' * 32, 60, clock)
        path = root / 'lease.json'; raw = (json.dumps(data) + '\n').encode(); path.write_bytes(raw)
        control = root / 'control'; control.mkdir()
        return guard.Lease(path, hashlib.sha256(raw).hexdigest(), control, clock), clock

    def test_nominal_original_lease_dispatch(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            clock.advance(1)
            self.assertEqual(lease.dispatch(lambda: calls.append('payload') or 'actual-result'), 'actual-result')
            self.assertEqual(calls, ['payload'])
            self.assertFalse((lease.control / 'REVOKED').exists())

    def test_already_expired_dispatches_no_payload(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            clock.advance(60)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('forbidden'))
            self.assertEqual(calls, [])
            self.assertTrue((lease.control / 'REVOKED').exists())

    def test_expiry_during_wait_never_accepts_or_dispatches_later(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            def in_flight():
                calls.append('already-in-flight'); clock.advance(60)
                return 'must-not-be-accepted'
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(in_flight)
            clock.advance(-60)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('later-forbidden'))
            self.assertEqual(calls, ['already-in-flight'])
            self.assertTrue((lease.control / 'REVOKED').exists())

    def test_explicit_revoke_is_sticky_after_wait(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); calls = []
            def in_flight():
                calls.append('already-in-flight')
                (lease.control / 'REVOKED').write_text('inert explicit revoke\n')
                return 'must-not-be-accepted'
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(in_flight)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: calls.append('later-forbidden'))
            self.assertEqual(calls, ['already-in-flight'])

    def test_resumption_gap_inside_total_budget_revokes(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); lease.check(); clock.advance(16)
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: self.fail('payload after gap'))

    def test_clock_rollback_inside_original_window_revokes(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-inert-') as directory:
            lease, clock = self.make(Path(directory)); clock.advance(2); lease.check()
            clock.value['Mono'] -= guard.NS
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: self.fail('payload after rollback'))

    def test_owned_child_natural_exit_reaped_full_eof(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-child-') as directory:
            lease, _ = self.make(Path(directory))
            with patch.object(guard.os, 'killpg', wraps=os.killpg) as kill:
                result = lease.run_checked([sys.executable, '-I', '-c',
                    "import sys;sys.stdout.write('actual-out');sys.stderr.write('actual-err')"], 3, {'PATH': '/usr/bin:/bin'})
            self.assertEqual(result['stdout'], b'actual-out'); self.assertEqual(result['stderr'], b'actual-err')
            self.assertEqual(result['exit'], 0); self.assertTrue(result['reaped'])
            self.assertTrue(result['stdoutEOF'] and result['stderrEOF']); self.assertFalse(result['forced'])
            kill.assert_not_called()

    def failed_child_is_sticky(self, code, timeout):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-child-') as directory:
            lease, _ = self.make(Path(directory)); sentinel = []
            original_kill = os.killpg
            def owned_signal(pid, sig):
                self.assertTrue((lease.control / 'REVOKED').exists(), 'Sticky refusal must precede cancellation')
                # WNOWAIT keeps even an exited leader owned until final wait.
                os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
                return original_kill(pid, sig)
            with patch.object(guard.os, 'killpg', side_effect=owned_signal):
                with self.assertRaises(guard.LeaseDenied):
                    lease.run_checked([sys.executable, '-I', '-c', code], timeout, {'PATH': '/usr/bin:/bin'})
            self.assertTrue(lease.last_result['reaped'])
            self.assertTrue((lease.control / 'REVOKED').exists())
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: sentinel.append('forbidden'))
            self.assertEqual(sentinel, [])
            return lease.last_result

    def test_owned_child_timeout_sticky_before_later_payload(self):
        result = self.failed_child_is_sticky('import time;time.sleep(10)', .15)
        self.assertTrue(result['timedOut']); self.assertTrue(result['forced'])

    def test_owned_child_capture_failure_sticky_before_later_payload(self):
        result = self.failed_child_is_sticky("import sys;sys.stderr.buffer.write(b'x'*300000);sys.stderr.flush()", 3)
        self.assertIn('capture exceeded', result['error'])
        self.assertLessEqual(len(result['stderr']), 262144)

    def test_owned_child_nonzero_exit_sticky(self):
        result = self.failed_child_is_sticky('raise SystemExit(7)', 3)
        self.assertEqual(result['exit'], 7)

    def test_post_reap_expiry_never_signals_reaped_numeric_pid(self):
        with tempfile.TemporaryDirectory(prefix='nbdp-e02-child-') as directory:
            lease, clock = self.make(Path(directory)); original = guard.subprocess.Popen
            class ReapThenExpire(original):
                def wait(self, *args, **kwargs):
                    value = super().wait(*args, **kwargs)
                    clock.advance(60)
                    return value
            with patch.object(guard.subprocess, 'Popen', ReapThenExpire), patch.object(guard.os, 'killpg') as kill:
                with self.assertRaises(guard.LeaseDenied):
                    lease.run_checked([sys.executable, '-I', '-c', 'pass'], 3, {'PATH': '/usr/bin:/bin'})
            self.assertTrue(lease.last_result['reaped']); self.assertEqual(lease.last_result['exit'], 0)
            kill.assert_not_called()
            with self.assertRaises(guard.LeaseDenied): lease.dispatch(lambda: self.fail('later payload'))


if __name__ == '__main__': unittest.main()
