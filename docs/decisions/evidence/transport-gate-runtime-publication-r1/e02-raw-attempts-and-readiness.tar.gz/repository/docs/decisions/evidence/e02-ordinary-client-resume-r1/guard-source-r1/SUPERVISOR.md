# E02 finite supervisor preparation

This is incomplete source preparation, not a launch release. `supervisor.py` is
not yet materialized. The prepared guard and four inert tests are a separately
reviewable first subset. No guard tests or runtime were executed by this author.

The existing ingress HIGH expired-action finding and v7 startup negative remain
history. Freed disk does not close either finding. The new lease has immutable
original UTC, MONOTONIC and BOOTTIME deadlines, includes all setup, has a sticky
revoke marker and observes before/after dispatch and continuously while waiting.
There is no shared clock flock across a child. Process-group cancellation occurs
only while the direct child remains unreaped under WNOWAIT ownership; no numeric
group signal follows a consuming wait. Cleanup while the host cannot execute is
not promised. Already dispatched Android/native work is not atomically cancelled.

The in-container guard accepts only fixed synthetic ADB operations, the fixed
helper component/case identifier, and read-only `ss`/`ip` metadata probes. It does
not accept arbitrary shell, URI reads or expected clipboard content. Amethyst's
fixed `/artifact.apk` installation has a180s command ceiling, other ADB commands
30s, read-only probes10s, all within the original total lease. No new deadline is
issued after READY. Expired/revoked result bytes can be retained as raw evidence
but cannot become accepted observations.

The four prepared `test_lease_guard.py` cases are nominal dispatch, already
expired zero payload, expiration during a simulated wait withholding its result
and later payload, and explicit revocation during a simulated wait. They use a
private temporary directory and a callable sentinel, never Docker/ADB/emulator or
a child. Actual independent source review and later authorized execution are
required. They are not Android/native race or hostile-host tests.

## Agreed integration contract, not implemented yet

The future fixed `android_driver.py::run(runtime)` uses `runtime.check()`,
`sleep(seconds)`, `adb(tokens, timeout) -> bytes`, `snapshot(unique_name)` returning
PNG/XML descriptors, `fixture(prepare|status|publish) -> bytes`, and exclusive
`put_bytes`/`put_json` under `runtime.out`. ADB tokens omit the supplied fixed
`-s emulator-5554`. No generic exec or arbitrary shell interface is exposed.

The first scope is JS-to-Rust/peer-incoming/public scalar2/nostr-rs-relay only.
The selected actual inner kind14 note must be exported through Amethyst Copy raw
JSON and the separately built foreground helper. One cell remains PARTIAL.

Fixture worker owns fixed `fixture.mjs serve|prepare|status|publish`, read-only
`/input/fixture-plan.json`, writable `/session/fixtures`, proxy17777→RS8080, and
actual app-subscription/EOSE/delivery plus independent JS/Rust validation. It uses
`lease_guard.py check SHA` with external `NBDP_LEASE_SHA256` instead of duplicating
clock arithmetic in Node. Plan/metadata nanoseconds are Python integer metadata,
not Nostr safe-integer fields; Node should treat the lease file as opaque bytes.

Fresh launch must first verify actual source/helper/APK/tool/image/dependency
pins and independent reviews, recheck6GiB disk/12GiB MemAvailable, then issue one
lease before any Docker action. Containers have exact immutable IDs and fresh
nonce labels; no host network, Docker socket, published ports or personal mounts.
Android6GiB/swap6GiB/PID512/CPU2, guest2048MiB. Other services join the exact owned
network-none namespace and communicate only through its loopback.

Cached emulator help proves `-ports5554,5555` disables implicit gRPC unless
explicitly requested. Use `-no-window`, no grpc/grpc-ui option, no DISPLAY,
WAYLAND_DISPLAY, DBUS, XAUTHORITY or GUI/auth/socket mount. Retain actual private
namespace listener inspection; do not invent an unsupported `-no-clipboard` flag.

The old v7 image may supply tools, but its consumed grant/launch/source authority
does not authorize this new workload. The fixed runtime plan stays `ready:false`
until the supervisor, driver/fixture, helper artifact, actual pins, precise
configuration, guard tests and independent review/release are complete.
