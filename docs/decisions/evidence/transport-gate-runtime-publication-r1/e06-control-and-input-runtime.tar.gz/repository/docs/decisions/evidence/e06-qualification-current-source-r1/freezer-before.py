from pathlib import Path
import hashlib,json,os,stat,time
R=Path('/home/peterhorvath/apps/bitcoin/NBDP');S=R/'experiments/prototypes/e06_relay_https_negative_v1';A=R/'docs/decisions/evidence/invoice-authenticated-carrier/e06-https-acquisition-preparation-r1';O=R/'docs/decisions/evidence/e06-qualification-current-source-r1';PINS={'path','bytes','sha256'}
def need(v,m):
 if not v:raise RuntimeError(m)
def load(p):
 def pairs(rows):
  d={}
  for k,v in rows:need(k not in d,'duplicate JSON');d[k]=v
  return d
 return json.loads(p.read_bytes(),object_pairs_hook=pairs)
def pin(p):
 need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and stat.S_ISREG(p.stat().st_mode),'canonical regular file')
 need(p.stat().st_size<=536870912,'bounded file')
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def checked(d):need(type(d)is dict and set(d)==PINS and pin(Path(d['path']))==d,'pin drift '+str(d.get('path')));return Path(d['path'])
def write(p,v):
 raw=(json.dumps(v,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 return pin(p)
expected={'qualification-schemas.json':(133680,'dcbbbd2c9b84d5cd477718896f287f8abc6f6574e148a04421bc3a9043157a2b'),'admission.py':(52988,'253aa826a8c0a250a3c8bd895207f2552cd45cb5c18295f9dedade383d3ac686'),'qualification.py':(31089,'658e1fba6173d35f18b96316da0de246db442f0691fe375b59f9800fe0e62fbd'),'runner.py':(27072,'a239e2e4e72c222994f9a39c1890930a1cbaf55bae16c287bdcf3e625d2be3a3'),'controls.py':(9591,'377ff80f7e4e729470f364bb667a22fafb4ae2349f71f35c3b04c7aa1de60b8b'),'protocol.mjs':(73552,'8ceb004085d7c86dd2a1cf7f0b8009975ad807c2172d8bd0c7b455b12a3cdceb')}
for n,(size,sha) in expected.items():d=pin(S/n);need(d['bytes']==size and d['sha256']==sha,'worker source changed '+n)
need(not O.exists(),'fresh evidence directory');O.mkdir(mode=0o700)
rows={};origins={};stages=[]
def remember(d,origin):
 need(type(d)is dict and set(d)==PINS,'closed descriptor')
 if d['path'] in rows:need(rows[d['path']]==d,'conflicting live descriptor '+d['path'])
 rows[d['path']]=d;origins.setdefault(d['path'],[]).append(origin)
def addgroup(values,name):
 for d in values:remember(d,name)
 stages.append({'group':name,'totalUnique':len(rows)})
prot=load(S/'protected-deltas.json');baseline=load(checked(prot['baselineClosure']));need(len(baseline)==378,'protected baseline378');addgroup(baseline,'protected378')
inert=load(A/'composition-negative-freeze-r2/source-data-closure.json');need(len(inert)==12,'inert12');addgroup(inert,'inert12')
names=['protocol.mjs','case.mjs','wire.mjs','metadata_loader.mjs','wire_controls.mjs','qualification.py','admission.py','runner.py','checker.py','controls.py','IMPLEMENTATION.md','qualification-schemas.json','test_policy_marker.mjs'];addgroup([pin(S/n) for n in names],'current executable12 and marker test')
plan=A/'composition-negative-native-qualification-plan-r2';mat=A/'composition-negative-native-inputs-r2';inventory=load(plan/'inputs.json');need(len(inventory)==57,'57 roles');addgroup(list(inventory.values()),'current57role inventory')
addgroup([pin(plan/n) for n in ['PLAN.md','inputs.json','plan-data-closure.json','static-checks.json','independent-qa-review.json','independent-security-review.json','acceptance.json']],'explicit current plan7')
addgroup([pin(mat/n) for n in ['request.jsonl','JS.expected.json','RUST.expected.json','derivation.json','static-checks.json','independent-qa-review.json','independent-security-review.json','acceptance.json']],'explicit current materialization8')
def walk(v,origin):
 if type(v)is dict:
  if set(v)==PINS:remember(v,origin)
  else:
   for child in v.values():walk(child,origin)
 elif type(v)is list:
  for child in v:walk(child,origin)
for d in inert:
 if d['path'].endswith('.json'):walk(load(checked(d)),'direct descriptor in inert JSON '+d['path'])
walk(load(S/'qualification-schemas.json'),'direct descriptor in current qualification schema');stages.append({'group':'direct descriptors in inert and current schema only','totalUnique':len(rows)})
need(len(rows)==449,'expected independently derived449 path set')
for d in rows.values():checked(d)
for rel,d in prot['wholeSourcePins'].items():need(pin(R/rel)==dict(path=str(R/rel),**d),'whole source invariant '+rel)
for interval in prot['protectedIntervals']:
 raw=(R/interval['source']).read_bytes()[interval['startByte']:interval['endByteExclusive']];need(len(raw)==interval['bytes'] and hashlib.sha256(raw).hexdigest()==interval['sha256'],'protected interval')
old=load(A/'composition-negative-implementation-r2/source-closure.json');oldmap={d['path']:d for d in old};result=[rows[k] for k in sorted(rows)];closure=write(O/'source-closure.json',result)
manifest={'schema':'e06-current-source-root-manifest-v1','actor':'/root','executionReleased':False,'sourceClosure':closure,'stages':stages,'memberOrigins':origins,'historicalExpansionBoundary':'Historical reports/acceptances/static data are opaque whole-file pins; only inert JSON and current qualification-schema descriptor objects are traversed. No recursive history authority refresh.','deltaFromHistorical443':{'removed':[oldmap[k] for k in sorted(set(oldmap)-set(rows))],'added':[rows[k] for k in sorted(set(rows)-set(oldmap))],'changed':[{'before':oldmap[k],'after':rows[k]} for k in sorted(set(rows)&set(oldmap)) if rows[k]!=oldmap[k]]},'protected':{'baselineMembers':378,'inertMembers':12,'wholeSourcePins':len(prot['wholeSourcePins']),'intervals':len(prot['protectedIntervals']),'allMatch':True},'sourceFreezer':pin(Path(__file__)),'limits':['DATA-only current hash freeze, no project imports/source evaluation/tests/native/relay/crypto execution.','No SOURCE/CONTROL/LOCAL/TARGET release; independent complete-source review remains required.','Old source/runtime acceptance is historical and does not transfer.']};m=write(O/'root-manifest.json',manifest);print(json.dumps({'closure':closure,'manifest':m,'count':len(rows),'stages':stages,'deltaCounts':{k:len(v) for k,v in manifest['deltaFromHistorical443'].items()}}))
