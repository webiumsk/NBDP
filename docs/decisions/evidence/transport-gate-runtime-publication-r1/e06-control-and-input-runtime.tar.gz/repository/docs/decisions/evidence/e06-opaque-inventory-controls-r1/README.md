# Current opaque grammar controls — prepared outer runner

SOURCE/CONFIG ONLY. `outer.py` is derived from the previously reviewed R2 probe's
safe-millisecond, strict metadata/source admission and no-call machinery. Its
selection changes to the fixed unchanged grammar suite, never the full gate probe.
Exact currentR3 SOURCE approval/acceptance/reviews and all449 current descriptors
are checked before either selected module import. No existing control approval is
used to bypass a new control result; this source-first calibration has no circular
future-control prerequisite. Separate outer/suite/config review and a fresh root
`RELEASE_EXACT_OPAQUE_GRAMMAR_CONTROLS_ONLY` grant remain mandatory.

The suite is byte-identical8326/77fb47deff4657ebcd4717f0f8992d350468923aa22c4ee7551588e5acc317ce.
Its original pending proposal is retained unchanged. This NEW config has actual
approved SOURCE descriptors and ready=true meaning operands prepared, with
executionReleased=false. No release, acceptance, review or runtime result is
created by this task. The outer runner, config, suite and reviews remain outside
the449-member source closure; no hash cycle or old PASS transfer is introduced.

Scopes are17 direct actual private-helper grammar calls, one labelled source-AST
loop-order check, and three unchanged raw/output boundary calls. The actual sparse
33554433-byte file exists only in a later released run, exclusively under this
config's new0700 output, mode0600. Its one write-open and one exact truncation are
explicitly permitted/counted; all other gate-time writes/truncations are denied.
Real descriptors/validation are not mocked and no accepted artifact/crypto/payload
is regenerated. Actual source/metadata reads and the sole unchanged suite import
are permitted. Full input-gate/LOCAL/TARGET/transport, native/process/network/
runner/qualification/helper imports remain denied/counted. This is trusted Python
instrumentation, not an OS sandbox or hostile-host guarantee.

The outer keeps actual first/secondary errors and any actual partial suite rows,
without creating unobserved rows or a PASS from a partial result. Root must retain
raw stdout/stderr and actual outer lifecycle. Successful control rows do not prove
the full real inventory gate, native interoperability or E06. A fresh strict real
positive gate probe and required negatives remain separate. Original phase/release
budgets, wire/profile/validators and source files are unchanged by this preparation.

WRITES_STOPPED. No imports, tests, services, native calls, Git or execution occurred
by the author. Exact invocation prefix and closed release fields are in plan.json;
root supplies new reviewed release operands only after independent source/config
acceptance. The proposed external monitor is180s;120s phase and <=360s UTC release
validity use safe integer milliseconds, without renewal or hard-realtime claims.
