# Actual inventory input-gate baseline probe — SOURCE ONLY

**PROPOSED / NOT_EXECUTED / NOT_RELEASED.** This first assignment prepares ONE
strict positive probe of the unchanged `admission.local_worker_inputs` primitive.
It is not a LOCAL configuration/release, complete LOCAL admission, native job or
runtime wiring proof. No project source was imported or evaluated by this author.
The source/configuration must receive independent QA/security review and a fresh
external root probe-only release before activation. No release is created here.

## r2 outer-clock representation remediation

The preserved first r1 attempt exited naturally2 with raw stderr
`Refusal: SAFE_INTEGER` and empty stdout. Its root release encoded epoch
nanoseconds above2^53−1. The unchanged strict metadata parser rejected that field
while reading the outer release, before the admission import or real input-gate
call. That is a harness/pre-import failure, not a demonstrated `SCHEMA_INTEGER`,
Node inventory rejection or completed positive test. Actual input-gate behavior
remains NOT_EXECUTED. The original source/config/release and raw failed attempt
remain unchanged; snapshots and the exact source diff are retained here.

Only the trusted OUTER release clock is now `notAfterUtcMs`: a safe integer of
UTC epoch milliseconds. Runtime comparisons use `time.time_ns()//1000000` and
require an initial remaining validity greater than0 and no greater than360000ms.
The same absolute millisecond expiry is checked before continuation; no renewal or
rebasing is introduced. The strict integer parser, actual449 source/control pins,
120s original monotonic outer phase and proposed180s external monitor are unchanged.
This changes no original LOCAL/native deadline, validator, source constant or
expected result. The positive still requires ACCEPT/continuation1/zero effects;
a genuine unexpected refusal will remain FAIL with all later rows NOT_EXECUTED.

A fresh config, run/output identity and independently reviewed source pin require
a NEW root probe-only release using `notAfterUtcMs`. No old consumed grant is
reused or converted into a new authorization. The nested documentation shape is
NOT a release; this source task creates no authority and runs no code.

## Exact real function and source order

The original fixed interpreter and six-variable environment, own bootstrap/config
pins, current449 closure/actual source reviews, current sourceApproval and actual
fourteen-control approval/reviews are checked with standard-library DATA readers
before the only permitted project import: the fixed current `admission.py`.
The external root release is specifically `RELEASE_EXACT_ADMISSION_INPUT_PROBE_ONLY`;
it is never a forged `RELEASE_EXACT_LOCAL_F_ONLY_RUN_ONLY` grant.

Inside the actual `_with_inventory` context the probe calls, in order, actual
`fixed_source`, actual `qualification_definitions`, and actual
`local_worker_inputs(c,wc,mapping,defs)`. The `c` and `wc` operands are honest plain
function-argument objects assembled from current original artifacts. They are
explicitly not schema-labelled LOCAL configuration documents and do not fabricate
a configuration approval, native qualification or future hash. No original file,
validator, constant, descriptor reader or membership function is monkeypatched.

The actual449 mapping is produced by `fixed_source`. The actual primitive itself
must check the current57-role inventory, its separate current derivation, exact
request and JS/Rust13-key expected objects, all source pointers and lineage. The
probe does not copy that validation logic or force a successful return. After a
normal primitive return only, the in-memory downstream continuation sentinel is
incremented once. A genuine positive requires continuation1 and zero forbidden
side effects. A refusal preserves the actual first error, continuation0 and FAIL.
Rechecking verified referents is secondary and never overwrites the first error.

Full `verify_qualification` order was inspected in source: root LOCAL release and
worker schema checks precede this primitive; shared source/control/configuration
acceptance, primary/QA lineage, fresh outputs and `accepted_transport` follow.
Those enclosing checks are NOT executed here and still need a genuine later LOCAL
configuration/release. This gate probe supplies no LOCAL or TARGET authority.

## Source-inspection suspicion and strict expected result

The current inventory loop validates each role using bridge `@descriptor`, whose
byte bound is33554432, while its pinnedNode role is121613584bytes. The source comment
requires streaming large tools, yet that shape check appears to reject the Node
operand before the separate derivation checks. This is SOURCE INSPECTION ONLY,
not a demonstrated runtime failure. The actual baseline expectation remains
**ACCEPT**, without patching or widening any schema. If the real call refuses
`SCHEMA_INTEGER` or any other error, record that actual unexpected refusal as FAIL.
Do not mark that rejection as a passing negative test or force downstream stages.
Any remediation needs a later narrow source assignment, independent SOURCE review
and renewed current-source joins after the original failure has been preserved.

## No-call instrumentation and capture

All process APIs exposed by the imported subprocess/os interfaces are denied and
counted, backed by audit events. Project source/bytecode/extension loaders permit
exactly one import of the pinned admission module; native, runner, qualification,
metadata/helper or other project imports are refused/counted. A call profiler
refuses full LOCAL/TARGET/transport verifier entry without replacing those methods.
Network audit events, gate-time file writes and gate-time write/send delivery
interfaces are denied/counted. The gate has no worker process, socket or writable
native channel. These are trusted Python tripwires and source inspection, not
hostile-interpreter, hostile-host or OS sandbox containment evidence.

The only activated code in a later released probe would be one outer Python
process and the read-only admission functions. No native/runner/helper, Node,
transport verifier, relay, HTTP(S), browser, encryption, signer or business effect
is permitted. The selected admission import is explicitly accounted as1; every
forbidden-process/project/native/network/request-delivery counter must remain0.

The actual gate argument objects are saved before the call, with request/expected
DESCRIPTORS only; raw payloads and synthetic secret are never printed. The outer
result binds actual bootstrap/config/root release, source/control approvals,
selected function, first/secondary errors, direct verified-referent inventory,
continuation count, no-call counts and elapsed time. Raw stdout is one small JSONL
summary; root must independently capture raw stdout/stderr, command/environment,
actual tool/process exit and full EOF/reap/lifecycle facts. The probe does not
invent host PID or natural-exit evidence. Exit0 requires the strict positive gate
outcome; unexpected refusal is exit1; failed outer admission is exit2/NOT_EXECUTED.
No output record or exit code alone establishes the entire experiment PASS.

Fresh outer observation directory: `/tmp/e6n-inventory-primary-6e8a3fcf81bd`,
mode0700 with exclusive0600 files. The worker namespace operand is never created.
All original sources/materialization files remain unchanged. Output/evidence is
retained after any failure; no broad cleanup or original-file overwrite occurs.
The outer probe phase is finite120s from entry, including DATA checks, additionally
bounded by a fresh root UTC release expiry of at most360s. Root should supply a
separate finite external monitor (proposed180s) and actual lifecycle capture. These
outer probe bounds alter none of the original LOCAL1500s/job/stream/cleanup gates,
which remain unexecuted. No hard realtime or suspended-host cleanup is claimed.

## Dependent matrix — PLAN ONLY, NOT IMPLEMENTED OR EXECUTED

If the strict baseline fails, EVERY row below remains NOT_EXECUTED. No validator or
expected answer is patched merely to reach later stages. After a separately
reviewed remediation and a qualified baseline, prepare these caller-memory/mapping
mutations as a new exact harness/configuration version with independent review:

| Case family | Real mutation and strict expected outcome |
| --- | --- |
| Current inventory and separate derivation | Unchanged current originals pass; continuation1, all native/effect counters0 |
| Wrong/old inventory | Worker inventory descriptor swapped to old/wrong descriptor; refuse before continuation |
| Missing inventory | Remove its current mapping member; refuse |
| Drifted inventory member | Change only the caller mapping descriptor pin; refuse |
| Missing each of57 role members | Bounded57-row sweep deleting one original mapping member at a time; refuse, identifying earlier shared-prerequisite refusal honestly |
| Missing derivation | Remove the distinct current derivation mapping member; refuse |
| Missing three output members | Remove request/JS/Rust output member individually; refuse |
| Wrong request descriptor | Change only worker request reference; refuse |
| Swapped JS/Rust expected refs | Swap caller expected descriptor references; refuse |
| Wrong candidate/stale plan | Change caller candidate or acceptedPlan identity; refuse |
| Identity/job output | Mismatch run/session/role or output-directory joins; refuse |

Caller-memory and mapping mutations are not on-disk drift or filesystem race tests.
No copied path can stand in for a changed immutable original path. Any later
I/O-fault injection must be explicitly labelled SIMULATED descriptor-read observation
faults, leave real validation/membership unchanged and make no actual FS-race claim.

A later independent QA repetition needs an actual separate operator session,
separately reviewed exact config and fresh release. The reserved proposal
`/tmp/e6n-inventory-qa-70a3e1b031f7` is absent and unactivated;
no QA config or pretend operator/release is manufactured. Both runs must retain
original unexpected findings and actual raw lifecycle records; neither operator
may approve their own evidence. Current source/control approval alone grants no
probe activation authority. **WRITES_STOPPED — SOURCE/CONFIG ONLY.**
