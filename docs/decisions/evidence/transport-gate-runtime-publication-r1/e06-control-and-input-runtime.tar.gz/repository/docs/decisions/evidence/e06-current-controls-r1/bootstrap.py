"""SOURCE ONLY: exact external bootstrap for14 already reviewed pure controls.

Importing starts no work. Root must independently review and pin this OUTER
source before invoking its fixed CLI with a separately issued CONTROL release.
No accepted_transport, TARGET/LOCAL verifier, native, relay, crypto or browser
entry is called. This file is outside the current accepted449-member closure.
"""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
HERE=ROOT/'experiments/prototypes/e06_relay_https_negative_v1'
ENV={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
     'WS_NO_BUFFER_UTIL':'1','WS_NO_UTF_8_VALIDATE':'1'}
CONFIG={'path': '/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence/e06-current-controls-r1/config.json', 'bytes': 107459, 'sha256': 'eafa97087e6e0a082c52440b85178537f9a8008a47db444c9bdfc88d7ce69a20'}
SOURCE_ACCEPTANCE={'path': '/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence/e06-qualification-current-source-r2/acceptance.json', 'bytes': 2699, 'sha256': 'c51a8c4589c73f4d98e01f46ca239b4788d40d280e80b245de48283dec2bd420'}
SOURCE_APPROVAL={'path': '/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence/e06-qualification-current-source-r2/source-approval.json', 'bytes': 107717, 'sha256': '97ded2e1607037ee5490c3a27802b7401290e1f4481b4de67a03e590b12b397d'}
SOURCE_CLOSURE={'path': '/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence/e06-qualification-current-source-r2/source-closure.json', 'bytes': 102080, 'sha256': '63b749f5930c1d08fa7ac83dc02be447189eb7d2f9b80cc98fdbe81bd18e94e4'}
QUALIFICATION_SCHEMA={'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_negative_v1/qualification-schemas.json', 'bytes': 133680, 'sha256': 'dcbbbd2c9b84d5cd477718896f287f8abc6f6574e148a04421bc3a9043157a2b'}
ADMISSION={'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_negative_v1/admission.py', 'bytes': 52988, 'sha256': '253aa826a8c0a250a3c8bd895207f2552cd45cb5c18295f9dedade383d3ac686'}
RUNNER={'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_negative_v1/runner.py', 'bytes': 27072, 'sha256': 'a239e2e4e72c222994f9a39c1890930a1cbaf55bae16c287bdcf3e625d2be3a3'}
CONTROLS={'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_negative_v1/controls.py', 'bytes': 9591, 'sha256': '377ff80f7e4e729470f364bb667a22fafb4ae2349f71f35c3b04c7aa1de60b8b'}
PYTHON={'path': '/home/peterhorvath/.miniforge3/bin/python3.13', 'bytes': 32959480, 'sha256': '5e2f62ca6ab9c6992460493de8a8867e84f8e6078f0e5c197b5232b79e4b35f1'}


class Refusal(ValueError):
    pass

def need(value, code):
    if not value:
        raise Refusal(code)

def closed(value, keys):
    need(type(value) is dict and set(value) == set(keys), 'CLOSED_KEYS')
    return value

def equal(a,b):
    if type(a) is not type(b): return False
    if type(a) is dict: return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
    if type(a) is list: return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b

def pairs(rows):
    result={}
    for k,v in rows:
        need(k not in result,'DUPLICATE_KEY');result[k]=v
    return result

def loads(raw, historical=False):
    need(type(raw) is bytes and len(raw)<=33554432,'JSON_BOUND')
    def number(t):
        need(t!='-0','NEGATIVE_ZERO')
        n=int(t);need(abs(n)<=9007199254740991,'SAFE_INTEGER');return n
    def fraction(t):
        need(historical,'INTEGER_TOKEN_ONLY');n=float(t)
        need(math.isfinite(n) and (not n.is_integer() or abs(n)<=9007199254740991),'FINITE_HISTORICAL_TIMING')
        return n
    value=json.loads(raw.decode('utf-8','strict'),object_pairs_hook=pairs,parse_int=number,
                     parse_float=fraction,parse_constant=lambda _:need(False,'NONFINITE'))
    todo=[(value,0)];nodes=0
    while todo:
        v,depth=todo.pop();nodes+=1;need(depth<=64 and nodes<=100000,'JSON_STRUCTURE')
        if type(v) is str:need(not any(0xd800<=ord(c)<=0xdfff for c in v),'UNICODE_SCALAR')
        elif type(v) is dict:todo.extend((x,depth+1) for x in [*v,*v.values()])
        elif type(v) is list:todo.extend((x,depth+1) for x in v)
    return value

def validate(v,g,defs):
    if type(g) is str:
        if g.startswith('@'):need(g[1:] in defs,'SCHEMA_REF');return validate(v,defs[g[1:]],defs)
        need(type(v) is bool if g=='boolean' else g=='null' and v is None,'SCHEMA_TYPE');return v
    if 'union' in g:
        for option in g['union']:
            try:validate(v,option,defs);return v
            except (Refusal,KeyError,TypeError,ValueError):pass
        raise Refusal('SCHEMA_UNION')
    if 'record' in g:
        closed(v,g['record']);[validate(v[k],s,defs) for k,s in g['record'].items()]
    elif 'enum' in g:need(any(equal(v,x) for x in g['enum']),'SCHEMA_ENUM')
    elif 'literal' in g:need(equal(v,g['literal']),'SCHEMA_LITERAL')
    elif 'integer' in g:need(type(v) is int and g['integer'][0]<=v<=g['integer'][1],'SCHEMA_INTEGER')
    elif 'tuple' in g:
        need(type(v) is list and len(v)==len(g['tuple']),'SCHEMA_TUPLE')
        [validate(x,s,defs) for x,s in zip(v,g['tuple'])]
    elif 'array' in g:
        need(type(v) is list and g['length'][0]<=len(v)<=g['length'][1],'SCHEMA_ARRAY')
        [validate(x,g['array'],defs) for x in v]
    else:
        need(type(v) is str and len(v.encode('utf-8'))<=g.get('stringMax',131072),'SCHEMA_STRING')
        if 'pattern' in g:need(re.search(g['pattern'],v) is not None,'SCHEMA_PATTERN')
    return v

def descriptor(path):
    p=Path(path)
    need(p.is_absolute() and str(p.resolve(strict=True))==str(p) and not p.is_symlink(),'CANONICAL_FILE')
    digest=hashlib.sha256();size=0
    with p.open('rb') as handle:
        before=os.fstat(handle.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size<=536870912,'FINITE_REGULAR_FILE')
        while block:=handle.read(1048576):size+=len(block);digest.update(block)
        after=os.fstat(handle.fileno())
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(identity(before)==identity(after) and size==before.st_size,'SOURCE_CHANGED_WHILE_HASHING')
    return dict(path=str(p),bytes=size,sha256=digest.hexdigest())


class OriginalPins:
    """Original expected pins never refresh to replacement bytes."""
    def __init__(self):self.values={};self.bytes=0
    def remember(self,pin):
        closed(pin,('path','bytes','sha256'))
        need(type(pin['bytes']) is int and 0<=pin['bytes']<=536870912
          and type(pin['sha256']) is str and re.fullmatch('[0-9a-f]{64}',pin['sha256']),
          'FINITE_DESCRIPTOR')
        previous=self.values.get(pin['path'])
        if previous is not None:need(equal(previous,pin),'CONFLICTING_ORIGINAL_PIN')
        else:
            need(len(self.values)<2048 and self.bytes+pin['bytes']<=4294967296,'FINITE_ORIGINAL_INVENTORY')
            self.values[pin['path']]=dict(pin);self.bytes+=pin['bytes']
        need(equal(descriptor(pin['path']),pin),'ORIGINAL_PIN_MISMATCH')
        return pin
    def read(self,pin,historical=False):
        self.remember(pin);need(pin['bytes']<=33554432,'BOUNDED_JSON_FILE')
        raw=Path(pin['path']).read_bytes()
        need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'READ_PIN_MISMATCH')
        return loads(raw,historical)
    def recheck(self):
        for pin in self.values.values():need(equal(descriptor(pin['path']),pin),'ORIGINAL_SOURCE_OR_INPUT_DRIFT')


def load_fixed(pin,name,pins):
    pins.remember(pin)
    spec=importlib.util.spec_from_file_location(name,pin['path'])
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def preflight(argv):
    """Only stdlib DATA checks before the first project import, no sentinel/tool."""
    need(len(argv)==6,'CLI bootstrap.py CONFIG CONFIG_SHA RELEASE RELEASE_SHA EXECUTION_SESSION')
    need(dict(os.environ)==ENV,'EXACT_SIX_OUTER_ENVIRONMENT')
    pins=OriginalPins();pins.remember(PYTHON)
    need(str(Path(sys.executable).resolve(strict=True))==PYTHON['path'],'FIXED_OUTER_INTERPRETER')
    # The workflow must check this separately pinned bootstrap before evaluation;
    # this running-instance pin only detects subsequent source drift.
    bootstrap=descriptor(Path(__file__).resolve(strict=True));pins.remember(bootstrap)
    need(argv[1]==CONFIG['path'] and argv[2]==CONFIG['sha256'],'EXACT_EXTERNAL_CONFIG')
    config=pins.read(CONFIG);q=pins.read(QUALIFICATION_SCHEMA);defs=q['workerDefinitions']
    validate(config,'@controlBootstrapConfig',defs)
    release_pin=descriptor(argv[3]);need(release_pin['sha256']==argv[4],'EXTERNAL_RELEASE_SHA')
    release=pins.read(release_pin);validate(release,'@controlBootstrapRelease',defs)
    need(release['decision']=='RELEASE_EXACT_PURE_CONTROLS_ONLY' and release['rootSession']=='/root'
      and release['executionSession']==argv[5]==config['executionSession']
      and equal(release['config'],CONFIG) and equal(release['sourceApproval'],SOURCE_APPROVAL),
      'EXACT_TRUSTED_EXTERNAL_CONTROL_RELEASE')
    need(equal(config['sourceApproval'],SOURCE_APPROVAL)
      and equal(config['qualificationSchema'],QUALIFICATION_SCHEMA) and equal(config['environment'],ENV),
      'FIXED_SOURCE_SCHEMA_ENVIRONMENT')
    subject=pins.read(SOURCE_CLOSURE);approval=pins.read(SOURCE_APPROVAL)
    acceptance=pins.read(SOURCE_ACCEPTANCE)
    need(type(subject) is list and len(subject)==449 and equal(config['sourceClosure'],subject),
         'EXACT_CURRENT_449_SOURCE_CLOSURE')
    validate(approval,'@sourceApproval',defs)
    need(approval['decision']=='ACCEPT_SOURCE_ONLY' and equal(approval['sourceClosure'],subject)
      and acceptance['decision']=='ACCEPT_SOURCE_ONLY' and acceptance['executionReleased'] is False
      and equal(acceptance['subject'],SOURCE_CLOSURE)
      and equal(acceptance['runtimeCompatibleSourceApproval'],SOURCE_APPROVAL),'ACCEPTED_EXACT_SOURCE_PACK')
    rows=approval['reviews']
    need(len(rows)==2 and {r['role'] for r in rows}=={'qa','security'}
      and len({r['session'] for r in rows})==2,'INDEPENDENT_SOURCE_REVIEW_ROLES')
    for row in rows:
        need(row['decision']=='ACCEPT_SOURCE_ONLY' and equal(row['subject'],SOURCE_CLOSURE)
          and row['session'] not in approval['authors'],'NONAUTHOR_COMPLETE_SOURCE_REVIEW')
        actual=pins.read(acceptance['independentReviews'][row['role']],True)
        need(actual['decision']==row['decision'] and actual['session']==row['session']
          and actual['role']==row['role'] and equal(actual['subject'],SOURCE_CLOSURE)
          and actual['findings']==[],'ACTUAL_ACCEPTED_SOURCE_REVIEW')
    mapping={}
    for pin in subject:
        validate(pin,'@closureEntry',defs);need(pin['path'] not in mapping,'DUPLICATE_SOURCE_PATH')
        pins.remember(pin);mapping[pin['path']]=pin
    for fixed in (PYTHON,ADMISSION,RUNNER,CONTROLS,QUALIFICATION_SCHEMA):
        need(equal(mapping.get(fixed['path']),fixed),'FIXED_SOURCE_TOOL_MEMBER')
    # Pin both transport-verifier artifacts WITHOUT importing/invoking their gate.
    # Actual accepted_transport is still mandatory for subsequent LOCAL/TARGET.
    for pin in q['fixedSourcePrerequisites'].values():
        need(equal(mapping.get(pin['path']),pin),'FIXED_CURRENT_PREREQUISITE_MEMBER');pins.remember(pin)
    out=Path(config['outputRoot'])
    need(re.fullmatch('/tmp/e6n-controls-[a-z0-9]{6,12}',str(out)) and out.parent==Path('/tmp')
      and str(out.parent.resolve(strict=True))=='/tmp' and not os.path.lexists(out),'FRESH_PRIVATE_RUNTIME_OUTPUT')
    pins.recheck()
    return config,release_pin,subject,q,pins,bootstrap


def owned_inventory(A,R,out):
    files=[];total=0
    for path in sorted(out.rglob('*')):
        need(not path.is_symlink(),'OWNED_OUTPUT_NO_SYMLINK')
        mode=path.lstat()
        need(mode.st_uid==os.getuid(),'OWNED_OUTPUT_OWNER')
        if path.is_dir():need(stat.S_IMODE(mode.st_mode)==0o700,'OWNED_OUTPUT_DIRECTORY_MODE')
        elif path.is_file():
            need(stat.S_IMODE(mode.st_mode)==0o600,'OWNED_OUTPUT_FILE_MODE')
            pin=A.descriptor(path);total+=pin['bytes']
            need(len(files)<256 and total<=33554432,'FINITE_CONTROL_EVIDENCE_INVENTORY');files.append(pin)
        else:raise Refusal('REGULAR_OWNED_OUTPUT_ONLY')
    return R.put_json(out/'artifact-manifest.json',dict(schema='n02316-control-owned-inventory-v1',
      files=files,bytes=total,excludes=['artifact-manifest.json','bootstrap-capture.json'],
      meaning='Owned pre-finalization artifacts; final inventory and bootstrap capture separately pinned.'))


def main(argv):
    started=time.monotonic()
    config,release_pin,subject,q,pins,bootstrap=preflight(argv)
    # All external release/config/source checks above precede these fixed imports.
    A=load_fixed(ADMISSION,'_n02316_pinned_control_data_helpers',pins)
    evidence=A._VerifiedEvidenceInventory();token=A._admission_evidence.set(evidence)
    try:
        mapping=A.fixed_source(subject)
        defs=A.document(A.DATA['bridge-schemas.json'])['definitions']
        A.source_approval(SOURCE_APPROVAL,subject,defs)
        prerequisites=A.fixed_prerequisites(mapping)
    finally:A._admission_evidence.reset(token)
    # No A.verify, A.verify_qualification, A.accepted_transport or target call.
    pins.recheck();evidence.recheck()
    R=load_fixed(RUNNER,'_n02316_pinned_pure_control_supervisor',pins)
    R.init_owned_case_io(A)
    out=Path(config['outputRoot']);out.mkdir(mode=0o700,exist_ok=False)
    copied=R.put_bytes(out/'source-closure.json',Path(SOURCE_CLOSURE['path']).read_bytes())
    need(copied['bytes']==SOURCE_CLOSURE['bytes'] and copied['sha256']==SOURCE_CLOSURE['sha256'],
         'BYTE_IDENTICAL_COPIED_SOURCE_SUBJECT')
    pins.remember(copied)
    command=[PYTHON['path'],'-I','-B',CONTROLS['path'],copied['path'],copied['sha256'],str(out)]
    def current():
        pins.recheck();evidence.recheck();A.closure(subject)
    current()
    child=R.OwnedCase(command,out,ENV,time.monotonic()+120,current,phase_progress=None)
    errors=[];control_evidence=None;final=False;natural=False
    try:child.run()
    except BaseException as exc:errors.append(R.error_fact(exc))
    # Preserve the first original supervisor error before secondary validation facts.
    if child.primary is not None:errors.insert(0,dict(child.primary))
    try:
        current();final=True
        A.natural(child.life)
        need(child.capture_complete and child.receipt is not None and child.secondary==[]
          and child.secondary_overflow is False,'COMPLETE_NATURAL_OWNED_CONTROL_CAPTURE')
        need(A.checked(child.streams['stdin'])==b'' and A.checked(child.streams['stderr'])==b'',
             'EMPTY_CONTROL_STDIN_STDERR')
        for name in ('stdout','stderr'):
            raw=A.checked(child.streams[name])
            need(type(child.total[name]) is int and child.total[name]==len(raw),'FULL_RAW_CONTROL_BYTE_ACCOUNTING')
        natural=True
    except BaseException as exc:errors.append(R.error_fact(exc))
    invocation=dict(tool=PYTHON,argv=command,cwd=str(out),environment=ENV,
                    **child.streams,lifecycle=dict(child.life))
    if natural and final and not errors:
        try:
            pure=R.one_line(A.checked(child.streams['stdout']))
            A.validate(pure,'@pureControlsCapture',q['workerDefinitions'])
            value=dict(schema='n02316-controls-evidence-v1',sourceApproval=SOURCE_APPROVAL,
              sourceClosure=subject,rows=pure['rows'],invocations=[invocation],finalIntegrity=True)
            A.validate(value,'@controlEvidence',q['workerDefinitions'])
            A.control_evidence(value,SOURCE_APPROVAL,subject,A.closure(subject),defs)
            current();control_evidence=R.put_json(out/'actual-control-evidence.json',value)
        except BaseException as exc:errors.append(R.error_fact(exc))
    capture=dict(schema='n02316-external-control-bootstrap-capture-v1',bootstrap=bootstrap,
      config=CONFIG,release=release_pin,sourceAcceptance=SOURCE_ACCEPTANCE,sourceApproval=SOURCE_APPROVAL,
      sourceClosure=SOURCE_CLOSURE,invocation=invocation,controlEvidence=control_evidence,
      controlReceipt=child.receipt,artifactManifest=None,sourcePrerequisites=prerequisites,
      transportVerifierInvocations=0,targetVerifierInvocations=0,localVerifierInvocations=0,
      finalIntegrity=final,qualified=natural and final and control_evidence is not None and not errors,
      errors=errors,elapsedMilliseconds=round((time.monotonic()-started)*1000),
      limits=['PURE_CONTROLS_ONLY_NO_NATIVE_RELAY_CRYPTO_TARGET_BROWSER_HTTPS',
        'N03_NO_NATIVE_AND_N16_DENY_NO_GENERATION_ARE_DATA_CONSISTENCY_ONLY',
        'R1_ENFORCEMENT_REGRESSIONS_PENDING_NO_LAB_N_OR_NATIVE_RC_QUALIFICATION',
        'ACTUAL_ACCEPTED_TRANSPORT_STILL_REQUIRED_BEFORE_LOCAL_AND_TARGET',
        'ROOT_TOOL_HOST_PID_REAP_AND_HARD_REALTIME_CONTAINMENT_UNKNOWN'])
    try:
        capture['artifactManifest']=owned_inventory(A,R,out)
        current()
    except BaseException as exc:
        errors.append(R.error_fact(exc));capture['qualified']=False;capture['finalIntegrity']=False
    result=R.put_json(out/'bootstrap-capture.json',capture)
    sys.stdout.write(json.dumps(dict(capture=result,qualified=capture['qualified'],
      controlExitCode=child.life['exitCode']),separators=(',',':'))+'\n')
    return 0 if capture['qualified'] else 1


if __name__=='__main__':
    try:code=main(sys.argv)
    except BaseException as exc:sys.stderr.write(type(exc).__name__+': '+str(exc)[:16384]+'\n');code=2
    raise SystemExit(code)
