from pathlib import Path
import hashlib,json,os,subprocess,sys,time
E=Path('/home/peterhorvath/apps/bitcoin/NBDP/docs/decisions/evidence')
kind=sys.argv[1];assert kind in ('controls','marker-controls')
o=E/('e06-current-'+kind+'-r2');c=json.loads((o/'config.json').read_bytes());r=json.loads((o/'release.json').read_bytes())
def pin(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
assert pin(o/'config.json')==r['config']
assert pin(r['sourceApproval']['path'])==r['sourceApproval']
a=json.loads(Path(r['sourceApproval']['path']).read_bytes());assert a['decision']=='ACCEPT_SOURCE_ONLY'
for d in a['sourceClosure']:assert pin(d['path'])==d,d['path']
for role in ('qa','security'):
 v=json.loads((o/('independent-'+role+'-review.json')).read_bytes());assert v['findings']==[] and v['configuration']==r['config']
out=o/('actual' if kind=='marker-controls' else 'outer-actual');out.mkdir(mode=0o700)
if kind=='controls':
 expected={'path':str(o/'bootstrap.py'),'bytes':17802,'sha256':'7fb0a2fc1a14b0b72444fd1eadf7f3664ad5b15608c08cad1a999ae339d69f51'}
 assert pin(o/'bootstrap.py')==expected
 argv=['/home/peterhorvath/.miniforge3/bin/python3.13','-I','-B',str(o/'bootstrap.py'),str(o/'config.json'),r['config']['sha256'],str(o/'release.json'),pin(o/'release.json')['sha256'],'/root']
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','WS_NO_BUFFER_UTIL':'1','WS_NO_UTF_8_VALIDATE':'1'};ceiling=360
else:
 assert time.time_ns()<r['notAfterUtcNs']
 for d in [c['node'],*c['sources']]:assert pin(d['path'])==d
 argv=c['argv'];env=c['environment'];ceiling=c['timeoutSeconds']
start=time.monotonic();p=subprocess.Popen(argv,cwd='/home/peterhorvath/apps/bitcoin/NBDP',env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);forced=False;error=None
try:stdout,stderr=p.communicate(timeout=ceiling)
except subprocess.TimeoutExpired:
 forced=True;error='OUTER_TIMEOUT'
 if p.poll() is None:p.terminate()
 try:stdout,stderr=p.communicate(timeout=5)
 except subprocess.TimeoutExpired:
  if p.poll() is None:p.kill()
  stdout,stderr=p.communicate(timeout=5)
for n,b in [('stdout.bin',stdout),('stderr.bin',stderr)]:
 with (out/n).open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
v=dict(actor='/root',argv=argv,environment=env,config=pin(o/'config.json'),release=pin(o/'release.json'),pid=p.pid,pidMeaning='PID in the tool execution namespace; not asserted host PID',exit=p.returncode,reaped=True,stdoutEOF=True,stderrEOF=True,forced=forced,error=error,durationMs=int((time.monotonic()-start)*1000),stdout=pin(out/'stdout.bin'),stderr=pin(out/'stderr.bin'),scope=('Current14 pure CONTROL only' if kind=='controls' else 'Current10 local marker controls only')+'; no native/network/LOCAL/TARGET qualification.')
with (out/'execution.json').open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps(v));sys.exit(0 if p.returncode==0 and not forced and error is None else 2)
