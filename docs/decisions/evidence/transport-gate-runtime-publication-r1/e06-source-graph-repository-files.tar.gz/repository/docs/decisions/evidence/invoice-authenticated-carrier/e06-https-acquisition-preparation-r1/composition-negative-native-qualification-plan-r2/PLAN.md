# Local F-only native qualification plan — documentation refresh r2

**DATA_ONLY_PLAN / NOT_REVIEWED / NOT_RELEASED.** This proposal is limited to a
57-role descriptor inventory and this source-first plan. It creates no acceptance,
source approval, materialized input, executable source, configuration or release.
No imports, tests, native processes, cryptographic observations or network services
were run. Independent QA/security PLAN_ONLY review is the next dependency.

## Reason for the new version

The accepted [r1 plan](../composition-negative-native-qualification-plan-r1/PLAN.md)
and its acceptance remain immutable historical records. Its `experimentReadme`
role pins the former4909-byte README. Current `experiments/README.md` is4996bytes,
SHA256 `0d00ac17929309077f4c74ce9ed836e13150319e01a810d159b5c8e6f566dc28`.
The coordinator's earlier readiness commit changed that documentation; retain the
current guidance rather than restoring obsolete environment statements.

`inputs.json` has exactly the same57 role names and ordering as r1. Only
`experimentReadme.bytes` and `.sha256` change; its absolute path is unchanged.
All56 other descriptors are identical. This is a documentation reference refresh,
not permission to update any other input after drift. The old inventory and its
captures are not relabeled. The static record reports actual hash checks only.

The accepted inert12-file freeze and protected378-member positive closure remain
byte-identical. The README is outside those protected closures. Existing native
payloads, wire/profile/crypto semantics, adapters, tools and finite schedules are
preserved. A changed input role or any future source change requires its own
reviewed version and renewed joins; current hashes never retroactively attest old
executions. Tool hashes establish availability, not a new build/runtime attestation.

## Subsequent DATA materialization, after actual plan acceptance

After real independent QA/security PLAN_ONLY reviews, the coordinator may record
an acceptance for this exact two-file plan closure. Neither this proposal nor its
static record is that acceptance. Only a later separately assigned materialization
may create a new native-input directory. Copy these existing payloads byte-for-byte:

| Existing payload | Bytes | SHA256 |
| --- | --- | --- |
| `request.jsonl` | 6276 | `dc586e609758fb6656c76ab5698985b9620d91e1852c8abfb85b2aaf9da636b0` |
| `JS.expected.json` | 1477 | `70d6b37cefa44a237a4ba94cdff6745db57222dc79bdbced0979e64c360f363d` |
| `RUST.expected.json` | 1499 | `2c3812c2097bdbb7db69dfc1575a0400f64ef67c47ecc2de46177cc8acfdac3a` |

The existing files are under `composition-negative-native-inputs-r1/`. The new
separate derivation record must bind the actual accepted r2 plan and actual new
output paths while retaining the same `native-oracles.json` source and pointers:
`/N02/requestCandidate`, `/N02/expectedByBackend/JS` and
`/N02/expectedByBackend/RUST`. Do not regenerate a wire, fixture, key or reply.
Do not print the synthetic secret. The worker receives only the exact immutable
request JSONL; expected objects and comparison stay outside the native worker.
The original derivation/input directory remains unchanged and historical.

This assignment creates none of those new files, directories, acceptance records
or derivation claims. New outputs and their hashes remain pending actual work.

## Required source-first gates

Existing derivative sources exist, but their old closure does not qualify changed
bytes. The accepted marker correction and this documentation refresh require a
new complete source graph. The order for future separately assigned work is:

1. Independently review/accept this exact plan closure. Then materialize/review the
   new inert inventory/derivation with byte-identical request/expected payloads.
2. Prepare the bounded descriptor-only refresh: three input/plan descriptors in
   `qualification-schemas.json`; `LOCAL_PLAN` in `admission.py`; `ADMISSION` pins in
   `qualification.py`, `runner.py` and `controls.py`; the schema pin in
   `protocol.mjs`. Any needed `IMPLEMENTATION.md` addendum has its own new pin.
   These six runtime/data files are unchanged by this plan preparation.
3. Reconstruct the complete closure from actual roots and transitive dependencies;
   do not assume a previous member count or edit only a stored list. A single live
   README path cannot carry both old and current content pins. Preserve inert12,
   protected378, native payloads and all other accepted immutable inputs. Exclude
   future approvals/observations/releases from source closure to avoid hash cycles.
4. Obtain actual independent QA/security SOURCE approvals for those exact bytes.
   Both later native qualification graphs and eventual target manifests must bind
   the SAME derivative source approval. Do not relabel old443-member captures or
   attach a new approval retroactively to an old observation.
5. Prepare/review fresh same-source CONTROL bootstrap, exact configuration and root
   release; execute and independently accept the required14 controls. Separately
   run inventory/materialization enforcement regression: the complete57-role
   inventory AND its separate derivation must pass; missing, swapped or drifted
   members must refuse before a native invocation. DATA-only N03/N16 rows are not
   substitutes for these actual enforcement checks.
6. Only after those prerequisites, review/release actual primary JS/RUST LOCAL
   jobs, then a separate actual independent QA JS/RUST repetition. Compare entire
   requests and full replies, preserve owned natural terminal/EOF/custody evidence,
   and build the common aggregate. Two nonauthor/nonoperator QA/security reviews
   must cover the SAME saved whole JS/RUST aggregate before a qualification pack.
7. Before TARGET, execute original/owned-request custody regression: legitimate
   distinct paths with identical bytes pass; missing, foreign or changed originals
   refuse. Then review the exact target manifest/admission/configuration/release.
   Source corrections, compilation, plan/static checks and local metadata results
   never stand in for actual target runtime observations.

The retained r1 plan supplies unchanged local execution discipline: exactly JS
then RUST per run, one F-only request per fresh child; two runs/four native children;
D absent/null and D0/F1; complete typed/key-exact13-field reply comparisons; unchanged
fixed environments, source/tool checks, bounded captures, original1500s phase and
per-job240s/startup15s/write+reply15s/terminal5s/drain2s/failure-cleanup15s limits.
No failed job is silently retried. Unknown/forced/timeout/extra-output/drift or
uncertain cleanup remains unqualified with raw evidence retained. This proposal
changes none of that discipline and grants no process/monitor activation authority.

## Scope and completion boundary

Canonical E06 requires current E01/E02/E05; E04 PASS is not its prerequisite. Only
a specifically named candidate may use the already adopted
`transport-sub-evidence-v1` for its E02 edge under every existing condition. E02
remains PARTIAL, and its ordinary-client control remains mandatory. No gate is
waived by refreshing a documentation descriptor.

Even accepted local F-only metadata evidence would not complete N02/N03/N16
composition or E06. Full qualification still needs both-direction exact originals,
received validated metadata/profile authority, key/nonce/hash/size negatives,
order/duplicate/conflict/revision cases, correlation-ready versus integrity-verified
separation and no unintended business effects. Legacy fixture-derived size/digest
and absent received-profile authority are not repaired by this plan.

No blocker classification, architecture, profile, NIP/kind, SDK, production,
credentials, deployment, Git publication or automatic-merge decision is changed.
Acceptance/reviews and all later materialization/source/control/LOCAL/TARGET work
remain pending their actual evidence. **WRITES_STOPPED — DATA ONLY.**
