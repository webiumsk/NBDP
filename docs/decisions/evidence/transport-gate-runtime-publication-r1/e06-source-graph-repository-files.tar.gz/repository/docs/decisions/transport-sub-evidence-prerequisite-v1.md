# Experimental transport sub-evidence prerequisite — v1

Date: 2026-10-18. **ADOPTED_TECHNICAL_POLICY — EVIDENCE_NOT_YET_SATISFIED.**
Decision owner: NBDP coordinator under the Product Owner's delegated routine technical authority.

Adopt the exact [reviewed proposal](proposals/transport-sub-evidence-prerequisite.md), SHA256 `21efe516605b24a52c45a4b9179b288d22404301712ddfbfe15a373a47831d8a`, as local experimental policy **`transport-sub-evidence-v1`**. The proposal file remains an immutable proposal checkpoint; this later explicit decision supplies adoption. [Actual architecture/QA/security review record](evidence/transport-sub-evidence-policy/proposal-reviews.json), SHA256 `fa99b716bf6082d404b5a857564fb1d8bfb2e453cd90cd6edcbb9a70b75e87fd`.

Only the E02 prerequisite edge for a separately named isolated E04 or E06 candidate may use separately accepted, current-source transport sub-evidence meeting every proposal condition. E02 itself remains **PARTIAL22**. The missing ordinary-client control remains unexecuted and its rendering/retention/safety remain unknown. Ordinary chat software need not understand NBDP business semantics. A harmful incompatibility must still be retained and assessed.

This adoption changes experimental prerequisite policy explicitly, not the approved architecture, canonical status or historical evidence. Existing plan, launcher and results remain byte-for-byte preserved. It grants no PASS inheritance to E08–E15 and no waiver of E01, E05, exact attachment profile, E04 resource/frame requirements, E06 independent full-byte/correlation/negative checks, or actual QA/security acceptance. All five blockers remain BLOCKER. Conditional OptionB, no baseline FS/PCS, parallel authorized devices, Satflux independence and SDK/production limits remain unchanged.

**No candidate currently satisfies this policy. No E04/E06 execution is released.** Before any such execution, a separately reviewed versioned gate must enforce the proposal's exact source/dependency/build/binary/fixture/relay/acceptance pins before importing a dependent module, with actual authorized refusal tests. Unknown policy/target, missing/stale/forged evidence, contradictory or failed mandatory observations and scope expansion fail closed with NOT_EXECUTED/zero dependent checks. No bypass or equivalent workload under another label is permitted.

Next: select/freeze the minimum current independent JS/Rust authenticated carrier candidate and current E01 provenance; prepare source and frozen oracles under bounded review. Build, local network activation and primary/actual-QA runs remain separately released actions. New gate implementation and qualification precede any E04/E06 attempt. Broad delegated authority covers these routine technical steps without another owner questionnaire; any new product risk/architecture/client-support/SDK/production/new-kind decision still needs its own authority.

No experiments, builds, network activation, file-key generation, historical mutation, commits, PRs or publication occurred as part of this adoption.
