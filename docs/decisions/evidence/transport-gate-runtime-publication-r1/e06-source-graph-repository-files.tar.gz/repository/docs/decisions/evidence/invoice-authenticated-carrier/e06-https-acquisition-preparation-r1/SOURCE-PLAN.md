# E06 isolated HTTPS acquisition: source task draft

Status: **DESIGN/TASK PROPOSAL — NOT EXECUTED — NO IMPLEMENTATION OR RUNTIME RELEASE**.
Owner: coordinator; authoring session `/root/archive_context_architect`, 2026-10-19.
This plan is the only assigned new file. Independent QA/security review is still required.

## Purpose and actual checkpoint

Compose internally authenticated invoice/credit-note D/F metadata, one bounded local HTTPS acquisition and existing original-byte consumers. This closes a specific gap between network metadata and local-snapshot recovery; it does not establish whole E06 interoperability, durable receipt, business action or SDK readiness.

Primary recovery tool91436 actually completed its selected48/52 scope, including both B12 routes, in1015.336s. Independent QA tool11981 is RUNNING at this draft checkpoint. Joint acceptance is **PENDING**, not inferred. Implementation of this task is conditional on actual independently accepted48/52 results. Auth8/B08–B11 remain unqualified; preserve raw unknown exceptions and all previous negative evidence.

Inputs, relative to `docs/decisions/evidence/invoice-authenticated-carrier/`:

- `e06-recovery-barecall-source-r1/next-acquisition-architecture-review.json`: actual mailbox report ARCH-E06-NEXT-AFTER-SELECTED-RECOVERY-20261019, conditional recommendation only.
- `e06-recovery-barecall-source-r1/next-acquisition-security-review.json`: SECURITY-E06-NEXT-ACQUISITION-PROPOSAL-20261019, conditional source-preparation assessment only.
- `e06-recovery-barecall-source-r1/next-acquisition-fixture-research.json`: actual researcher record, existing wire/producer/snapshot provenance and changed-URL limitation.
- Accepted metadata212/480, relay metadata8/10 and retained fixture/environment/classifier evidence remain scoped provenance. The later source manifest must identify their exact native acceptance descriptors and subjects; this plan invents no future acceptance or hash.

## Fixed acquisition profile proposed for source preparation

The sole permitted origin is `https://files.invalid:18443`; the object is exactly `/aba67e462b0ef41729c3bb31f1f50b98c4ae2245f20e9f1adb312174d18952c5`. Port18443 is an unprivileged synthetic-lab choice. Require the port to be unused before owned startup, then bind only127.0.0.1. Busy port, unexpected listener or startup failure refuses; no port scan, automatic alternative, listener termination or fallback.

Connect to the explicit peer127.0.0.1:18443, with TLS server name and certificate hostname verification `files.invalid`, and exact HTTP Host `files.invalid:18443`. Use a separately prepared isolated test CA and server certificate for that name, with explicit per-client CA trust and normal certificate validity/hostname verification. Do not modify global trust, DNS/hosts, proxy settings or the historical browser helper. Wrong certificate or peer fails closed. Preparation of CA/private test keys/certificates requires its own later reviewed source/configuration and explicit execution release; none is generated here.

Local configuration must independently enable this exact synthetic acquisition and expected peer/origin/object. A valid URL, D/F signature, key possession or `allowedOrigin` alone does not authorize fetch. Authenticate the complete current D/F and scope internally before any HTTP/TLS attempt. Wrong origin, missing permission or metadata refusal produces zero acquisition connection attempts. No caller-supplied verified-D token or metadata result is accepted.

Use one fixed Node HTTPS client, not a browser business-URL fetch. No environment proxy discovery, cookies, credentials, authorization header, client certificate, referer, credential store, redirects, retry, range requests, alternate URL, decompression or fallback. Request one GET with `Accept-Encoding: identity` and `Connection: close`; no persistent agent/session reuse. Browser loopback harness traffic remains separately identified and is not file acquisition.

Proposed finite workload constants, to be frozen and independently reviewed with source:

| Boundary | Proposed fixed value / rule |
| --- | --- |
| TLS | TLS1.2 minimum; normal verification; isolated CA only |
| Request | At most1 TLS connection and1 GET per case; no retry |
| Success response | HTTP200; Content-Length required and exactly20; no Transfer-Encoding or Content-Encoding; reject duplicate framing headers |
| Headers | At most16384 raw header bytes and64 header fields; parser bound before body processing |
| Entity | Expected20 actual ciphertext bytes; retain at most21 body bytes for overflow evidence; abort overflow immediately; record actual observed chunk count/bytes, not an invented21-byte network limit |
| Body handling | No transformation or second acquisition; complete entity required; truncated/interrupted input refuses |
| Time | Owned server startup5s; connect3s; TLS handshake3s; response headers3s; body idle1s; whole acquisition10s; owned teardown5s |
| Captures | Per-case client/server stderr64KiB each; HTTP/header evidence16KiB; engine/metadata records retain their existing bounded native formats; overflow fails qualification |
| Workload | At most14 cases,11 GET attempts, zero attachment encryption; workload phase300s; separately bounded admission and outer cleanup specified before release |

These are proposed lab scheduling/transport limits, not measured CPU/RAM guarantees or changes to existing recovery limits. Source review must identify parser/socket buffering and bound retained buffers, timers, child streams and owned resources. Do not claim that a small retained prefix proves a small TCP read or process RSS. Missing timers, excess work, incomplete EOF/reap evidence or cleanup uncertainty fail qualification.

## Signed fixture and byte requirements

Reuse the existing20-byte ciphertext at `e06-recovery-fixtures-r1/primary/snapshots/02.bin`; verify its accepted descriptor before use. Its authenticated x is `aba67e462b0ef41729c3bb31f1f50b98c4ae2245f20e9f1adb312174d18952c5`; ox is `6509423fd9da5c225d2f8619ffae394b40f9f7686fee55a38c54b1424ac65f46`; exact original is the retained four octets `00ff8001`. These are public synthetic E05 data, not invoice syntax, real financial data or fresh encryption.

The old signed F URL has no explicit port and cannot truthfully demonstrate this high-port profile. Prepare new canonical kind15 F rumors and peer/archive wrappers independently with the existing JS and original baseline Rust constructors; retain the nine-tag mapping and unchanged attachment tuple. D may be reused only when its complete canonical rumor bytes/identity are unchanged. Check fresh D/F association, expected origin and both baseline inspector results; freeze complete metadata expectations independently before target outputs. A new F identity must never masquerade as the old retained F.

Use the recorded JS `rumor(...,{kind:15,tags,timestamp})`/`wrap` APIs and Rust `file-rumor` then `wrap`, with the exact reviewed binary/tool closure. Both independent inspectors must qualify the new artifacts. Existing108-job preparation release does **not** authorize changed URLs or new fixture construction. A separate small recipe/configuration/source review and explicit preparation release are required. Attachment encryption remains0; signing and NIP44/59 wrapping are separate cryptographic work and require that release.

Retain the authenticated D/F subject and received entity as a private single-assignment snapshot. Count actual complete entity bytes against authenticated20, hash that same snapshot against x, then invoke only the selected existing consumer with authenticated key/nonce/x/ox and derived original count20−16=4. Check returned original count/hash and all four retained octets. No reread, reopened URL, writable substituted file, partial plaintext release or input oracle supplied to the consumer.

The existing admitted recovery worker/controller is not a generic received-snapshot API. Prepare a separate fixed consumer bridge that calls `attachment-crypto.mjs::consumeAttachment` through the accepted local bare binding, or `BrowserCrypto.start/consume/close` on the other route. Preserve the exact accepted strict classifier bytes and raw unknown rethrow; do not label HTTP, TLS, browser, tool or generic provider failures AUTHENTICATION_FAILED. No Rust AES, new dependency or crypto implementation. Retain attempt-before-call journal, actual native errors and per-route provenance.

## Minimal future file ownership and integration

All implementation files below are **proposed future ownership**, not created or authorized by this draft. Use new namespace `experiments/prototypes/e06_https_acquisition_v1/`; keep all existing sources, releases, fixtures, expected objects and captures unchanged.

| Future owner / files | Bounded responsibility |
| --- | --- |
| Fixture implementer: `fixture-recipes.json`, `prepare.py`, `prepare.mjs` | Fixed new-F construction and independent inspection, D reuse checks, fresh full metadata expectations; no target-derived oracle or old108-release reuse |
| Acquisition implementer: `acquisition.mjs` | Fixed owned HTTPS server/client, strict policy/TLS/HTTP/resource handling, one immutable entity snapshot and raw acquisition evidence |
| Recovery bridge implementer: `consumer.mjs` | Fixed existing NodeEVP and ChromeWebCrypto APIs, internal metadata authentication entry binding, same-snapshot checks, accepted bare-call/classifier/journal behavior; no oracle plaintext in private input |
| Coordinator implementer: `run.py`, `admission.py`, `controls.json` | Fixed supported workflow, exact current source/tool/profile/input/review pins, finite refusal controls, actual lifecycle/capture assembly and result qualification; no caller module/command/token |

Disjoint authors must agree one small closed private frame and result contract before source completion. Parent owns raw D/F authentication lifecycle and private subject binding; bridge cannot accept a public claimed-authentication result. Keep original metadata13-key API unchanged. New acquisition/recovery observation is a separately named experimental component; no old gate is claimed to admit it. Do not copy a generic historical walker or build a new plugin framework.

Admission must require joint48/52 acceptance, accepted metadata/relay/fixture/E05 provenance, exact new fixture acceptance, reviewed current source/browser/TLS profile, finite current execution map and an externally pinned concrete release. Verify every current used source/tool/import/asset and actual selected input; old accepted records retain their exact scoped subjects. Independently review a finite dependency-correspondence rule instead of replaying unrelated16k historical negatives,140 or1106 jobs. New preparation must not self-require future acquisition PASS. Actual source/configuration review, meaningful fail-closed controls and positive pure admission precede any target launch.

## Prospective acceptance matrix — every row NOT_EXECUTED

Freeze complete expected outcomes before outputs. Negative success means no externally released VERIFIED_BYTES result; retain actual earlier metadata/engine facts and raw cause. Unknown exceptions fail the case/workload rather than being normalized into an expected protocol refusal. Private drift/cleanup seams are source-bound, not public request flags.

| ID | Fixed case | Required observation |
| --- | --- | --- |
| H01 | Invoice, JS metadata + NodeEVP | One authorized GET; same20-byte snapshot; exact `00ff8001`; complete clean lifecycle |
| H02 | Credit note, Rust metadata + ChromeWebCrypto | Same byte commitments and original; independent metadata/engine route; clean browser and server closure |
| H03 | Acquisition permission absent | Internally scoped input does not grant permission; zero acquisition connections/GETs/consumer calls |
| H04 | Wrong authenticated origin/object or peer policy | Refuse before acquisition; zero acquisition connections/GETs/consumer calls |
| H05 | Wrong/untrusted certificate | TLS refusal; zero HTTP GETs and consumer calls; retain actual certificate error |
| H06 | HTTP redirect | Exactly one GET; no follow-up connection/request; no verified output |
| H07 | Missing object / HTTP404 | One GET; no consumer; raw response retained |
| H08 | Truncated20-byte declaration/body | Actual incomplete entity detected; no consumer or verified output |
| H09 | Oversized framing/entity | Bound violation detected; bounded retention and abort; no consumer |
| H10 | Complete20-byte wrong ciphertext | Actual received count20, x mismatch before consumer; no verified output |
| H11 | Interrupted transfer | Retain actual bytes/error/EOF state; no complete snapshot or verified output |
| H12 | Slow/stalled transfer | Fixed idle/whole timeout; owned abort/cleanup; no retry or verified output |
| H13 | Private snapshot/subject substitution attempt | Detect binding drift before consumer; no reacquisition or verified output |
| H14 | Owned cleanup failure/uncertainty | Preserve any completed internal engine facts, but withhold component qualification/verified release; do not fabricate containment |

Both positive routes compare exact opaque octets. H05 deliberately permits the one TLS attempt; H03/H04 permit none. At most11 GET attempts across the14 cases. Preserve complete raw bounded HTTP/TLS errors, status/header framing, body observed/retained counts and hash, immutable snapshot descriptor, metadata and engine native records, attempts, natural exits/reap/EOF and independent owned cleanup. Browser.close failure must still attempt separate owned loopback-server cleanup; forced parent exit is not proof all descendants were contained.

## Dependencies and remaining gates

This local HTTPS composition starts no relay and does not by itself establish two-relay-plus-blob end-to-end delivery. That later bounded composition may reuse accepted8/10 relay provenance but requires an explicitly reviewed source/configuration/release. Canonical E06 prerequisites are E01/E02/E05 plus the adopted scoped transport evidence rule; there is no E04-PASS edge. E02 remains PARTIAL; E06 remains PARTIAL even after a successful limited component.

Full36/111 coverage, deferred auth8, profile-size/nonempty-AAD-produced vectors, ecosystem compatibility disposition, publication/retry/revision/mirror lifecycle, durable nonce/replay/crash safety, receipts, authority and business effects remain outside this task. No Q blocker, architecture, production grammar, NIP, kind, SDK or Product Owner selection is changed. No new Product Owner question is needed for this fixed synthetic technical preparation; later implementation and runtime need their actual reviews/releases, not inferred permission from this document.
