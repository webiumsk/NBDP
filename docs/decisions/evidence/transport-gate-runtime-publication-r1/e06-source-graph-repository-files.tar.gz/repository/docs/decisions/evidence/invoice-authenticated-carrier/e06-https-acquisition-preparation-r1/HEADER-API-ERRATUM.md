# Header API precision erratum

Status: **DESIGN CLARIFICATION ONLY — NOT EXECUTED — NO RUNTIME RELEASE**.

This erratum supplements the immutable `SOURCE-PLAN.md` (14795 bytes; SHA256 `188ea399eeafa5b2714be81556c26723e55437469f07c62991ff68a8d527c4d4`). Its evidence is the actual researcher record `node22-api-research.json` (7537 bytes; SHA256 `d2dab989f51be6be8da4572815e4acae81324be345df2c9b61ea03744d3f0da9`), session `/root/acquisition_fixture_researcher`. That record is primary documentation/source research, not runtime API qualification.

Supersede **only** the plan's header-bound row and references to raw HTTP/header transcript evidence with these meanings:

- Set Node22.18.0 `maxHeaderSize: 16384` and `insecureHTTPParser: false`. The limit uses the pinned parser's status-text/field/value accounting; it is not an exact16384-byte bound on the serialized network header block, HTTP delimiters or TLS records. [Pinned parser accounting](https://github.com/nodejs/node/blob/v22.18.0/src/node_http_parser.cc#L285).
- Set `request.maxHeadersCount = 0` synchronously before asynchronous socket dispatch to preserve complete parsed-header visibility. Then explicitly reject more than64 `rawHeaders` name/value pairs and case-insensitive duplicate framing fields. Require the existing single Content-Length20 and absence of Transfer-Encoding/Content-Encoding. A finite `maxHeadersCount: 64` is not an adequate substitute: fragmented accumulation and fast-path handling differ; this erratum makes no universal clipping claim. Strict parser errors may occur before the response callback and must retain their actual cause. [Pinned client limit handling](https://github.com/nodejs/node/blob/v22.18.0/lib/_http_client.js#L784-L789), [header accumulation](https://github.com/nodejs/node/blob/v22.18.0/lib/_http_common.js#L49-L98).
- `rawHeaders` means parsed names/values with duplicates retained, not raw wire bytes. Separately cap retained parsed-header evidence at16KiB, counting its actual encoded evidence representation including overhead. Source freeze must specify bounded construction/overflow handling; overflow cannot be reported as a complete transcript. [Node22.18.0 rawHeaders documentation](https://nodejs.org/download/release/v22.18.0/docs/api/http.html#messagerawheaders).

Neither plan nor erratum establishes an exact raw-wire/TLS transcript, network-byte, socket-buffer or RSS guarantee. Actual bounded API handling requires source review and later evidence.

All fixed origin, TLS, body, time, resource, permission,14-case/11-GET, oracle and conditional-implementation requirements remain unchanged. The original plan **and this erratum together** are future implementation inputs, conditional on actual joint48/52 acceptance. No source implementation, certificate preparation, experiment, new gate or runtime permission follows.
