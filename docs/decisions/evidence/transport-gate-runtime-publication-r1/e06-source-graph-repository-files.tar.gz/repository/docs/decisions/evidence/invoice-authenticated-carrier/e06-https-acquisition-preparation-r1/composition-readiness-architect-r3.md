# Proposed finite laboratory composition policy v3

Coordinator summary of the actual read-only v2 report from
`/root/e06_composition_readiness_architect`. Coordinator v3 corrects the JS F_URL citation and labels D1/F1 as a static expectation under the documented valid prefix. Static checks used tool chunks654049/a907f0; no runtime was performed. This is remediation design for the
preserved MEDIUM finding in SECURITY-E06-COMPOSITION-READINESS-20261020, not its
independent closure. HTTPS QA14337 is still RUNNING; source implementation starts
only after accepted primary/QA evidence. No normative architecture adoption.

Use one persistent metadata process per fresh association window, one serial
orchestration lane and fixed role/local/peer/context/origin. No new protocol
message, signature, cryptographic construction or transferable authority token.

1. COLLECT: process the frozen event sequence, retaining actual EVENT spans and
   full authenticated metadata replies. CORRELATED is a candidate, not permission
   to fetch. Orphans, archives, conflicts, refusals and capacity holds grant none.
2. SEAL: after every declared pre-seal job/reply is complete and no corresponding
   input/work is pending, explicitly seal one laboratory frontier. Require exactly
   one eligible incoming authenticated D/F association, permission, current pins
   and no sticky conflict, capacity or lifecycle uncertainty.
3. Record one immutable local generation: canonical D/F IDs, received-span
   descriptors, metadata provenance, scope, URL, descriptors, engine route and
   single acquisition allowance. This is private local bookkeeping only.
4. ACQUIRE: recheck eligibility, then allow at most one fixed HTTPS connection/GET.
   Preserve destination/TLS/HTTP bounds, actual encrypted count/hash and snapshot
   ownership. There is no retry in this minimum profile.
5. PRIVATE_VERIFY: recheck eligibility before the native consumer. Retain actual
   engine journal/result privately; do not populate the shareable original yet.
6. CLOSEOUT: process all frozen post-seal events/checkpoints, complete owned
   cleanup and source/input integrity, then atomically recheck eligibility.
7. RELEASE: publish original only if every requirement succeeded. Otherwise retain
   the exact refusal/hold/unqualified outcome and originalHex:null.

EOSE/Close1000 marks only the declared laboratory frontier. It proves no global
history completeness, future-conflict absence or distributed finality. Later
contradictions append invalidation records; never mutate sealed identity, select
another F or grant another attempt. Stop active work at the next enforceable
checkpoint and attempt owned cleanup, retaining all real earlier counters. An
abort does not guarantee callbacks already in flight cannot complete.

## Proposed duplicate and late-event rules

- Reauthenticate same canonical F, including fresh outer wraps, in the same
  window. Add no generation, GET, consumer allowance or release; a failed first
  attempt does not create a retry. This is local ephemeral suppression only.
- Qualifying distinct F before seal prevents eligibility and fetch.
- Qualifying distinct F after seal/before connection invalidates with zero fetch.
- Qualifying distinct F after GET/before consumer preserves prior GET evidence,
  invokes no consumer and releases no original.
- Qualifying distinct F after private verification/before final publication
  retains actual private consumer success but withholds public release.
- Contradiction after a completed release preserves that earlier observation and
  actual counters; record current conflict and prevent further release. Previously
  disclosed bytes cannot be withdrawn.
- Invalid/wrong-origin traffic is not a qualifying comparand and does not itself
  invalidate a good generation. Retain its exact first-reachable refusal. Source,
  lifecycle or harness uncertainty independently requires HOLD/UNQUALIFIED.

## Correct old-origin and genuine-conflict controls

Static JS metadata.mjs:180 and Rust main.rs:205 confirm that, under unchanged
allowedOrigin=https://files.invalid:18443 and otherwise valid prefix, old
https://files.invalid/<x> produces REFUSED/F_SHAPE/F_URL/UNCHANGED. With supplied
valid D/F, source-derived expected validation counts are D1/F1, with no retained addition and no fetch; this is not a newly observed result.
Earlier authentication/schema/tag/encoding/scope/capacity refusals take precedence.
Do not label this a genuine distinct-qualified-F conflict.

That conflict needs a second authenticated canonical F ID with the SAME exact
:18443/<x> URL, D parent, descriptor, author/recipient and scope. A distinct inner
timestamp is a candidate; its concrete fixture still needs separate preparation
and review. Fresh outer wrapping alone remains a duplicate. No qualified fixture
inventory or runtime case count is asserted here; revision claims require their
own genuine qualified fixtures.

## Complete step oracles

Before execution freeze a closed typed object per step with:
stepId, phase, eventProvenance, metadataRecord, associationState, generation,
eligibility, invalidation, decision, status, stage, reason, counts, snapshot,
nativeConsumerRecord, originalHex, originalReleased, receiptsEmitted,
businessEffects, lifecycle, cleanup, integrity and limitations.

metadataRecord binds the entire native13-key reply, raw request/reply and actual
lifecycle; expected values are frozen independently. Generation references the
same immutable record after seal. Counts are actual cumulative publications,
queries, events, metadata requests/replies, D/F validations, connections, GETs,
received bytes, consumer calls, attachment encryptions and public releases; unknown
stays null. Snapshot binds actual complete count/hash/ownership or null. Public
originalHex is null until final release; restricted native evidence is separate.
Every step has receipts=false, businessEffects=0 and attachmentEncryptions=0.

Coverage obligations are four incoming positive cells through both relays/engines,
orphan then D, missing D/F, archive, same F/fresh wrap, genuine conflicting F before
and after seal/GET/private verification, old-origin refusal, first-reachable
wrong-parent/revision/authentication/permission refusal, network/hash/context seam
failures and cleanup/source uncertainty. Obligations may share finite multi-step
windows only when every relevant complete oracle is frozen. They are not an
approved suite count or a claim that all fixtures currently exist.

## Source-only ownership proposal

New derivative directory: experiments/prototypes/e06_relay_https_composition_v1/.
Keep accepted originals and shared crypto/classifier unchanged. Freeze interfaces
before disjoint implementation.

| Future owner | Exclusive responsibility |
| --- | --- |
| Architecture/data | contract.json, profile.json, selection-map.json, oracles.json, SOURCE.md; policy/availability/gaps/checkpoints/protected deltas. |
| Relay | wire.mjs, metadata_loader.mjs, wire_controls.mjs; raw EVENT spans, fixed mapping, persistent window. |
| Protocol/controller | protocol.mjs, runner.py, admission.py, controls.py; private generation/invalidation, actual received binding, serial checks/accounting/release gates. |
| Acquisition/consumer | acquisition.mjs, consumer.mjs; bind the SAME new protocol WeakMaps, protected native crypto/journal/cleanup and private/public separation. |
| Coordinator | State/roadmap, frozen configurations/releases and evidence; no Git publication authorized. |

An external wrapper cannot mint old private handles. Derivative case-ID/journal
validation and component labels need precise rebinding, not broad copying or
classifier changes. Independently review the complete derivative closure, fixture
mapping and source deltas; qualify controls and exact configuration before a
separate experiment release. HTTPS releases do not release composition.

No new Product Owner decision is needed for this reversible laboratory preparation.
Normative G1, Q08/Q27, other blockers, whole E06, SDK/production, durability/global
exactly-once and parallel-authority gates remain unchanged. No files or runtime
state were changed by the reporting architect.
