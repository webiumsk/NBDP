"""SOURCE PREPARATION ONLY: disposable two-relay carrier laboratory.

Import is inert. A separately reviewed/released controller may use::

    with RelayLab(reviewed_config, new_owned_output_directory) as lab:
        lab.assert_healthy()
        # The controller owns WebSocket/Nostr assertions, sources and case oracles.
        endpoints = lab.endpoints

The caller must pin this file, the exact resolved Python executable, Docker
executable and both configuration files in its release. This module does NOT
admit an experiment, satisfy transport-sub-evidence-v1, prove protocol readiness,
or implement E04/E06. No CLI, Docker command, socket or thread starts on import.
External SIGKILL/power loss cannot provide atomic cleanup. Such interrupted runs
need separately authorized, ownership-checked recovery and remain unqualified.

Closed configuration schema (all keys required, no extras):
  scope: CURRENT_CARRIER_TWO_RELAY_LAB_ONLY
  execution_allowed: true (the enclosing controller must independently admit it)
  run_id: lower ASCII [a-z0-9-], 1..32 characters
  files: {supervisor, python, docker, strfry_config, rs_relay_config}
Each file descriptor is exactly {path: absolute resolved path, bytes: int,
sha256: lowercase SHA256}. supervisor must be this file; python must be the
current interpreter. Image identities, ports, resource limits and timeouts below
are fixed, not caller-overridable. Use fresh output directories for primary/QA.

Trusted boundary: local Docker daemon and same-UID host/filesystem; a hostile
daemon, same-UID concurrent mutation or privileged host is outside this lab.
Docker's internal bridge is not a firewall proof against the trusted host itself.
"""

import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import select
import secrets
import socket
import subprocess
import sys
import threading
import time


IMAGES = {
    "strfry": "sha256:d72c7eb4e19562e22c24924ea51bc345ea5d22d03ada1429a46e0bb90ea97d40",
    "rs-relay": "sha256:d3e7c3f67e513687616f9cddc7b71caa3f5980c798fe6f9a41b7b9534a8a19de",
}
PORTS = {"strfry": (17777, 7777), "rs-relay": (18081, 8080)}
LABEL = "org.nbdp.carrier-lab-owner"
COMMAND_SECONDS = 20
READINESS_SECONDS = 20
MAX_CONNECTIONS = 64
MAX_TOTAL_CONNECTIONS = 4096
CONNECTION_SECONDS = 30


class LabFailure(RuntimeError):
    """Unqualified setup, transport supervision or cleanup; never a case PASS."""


def _pin(path):
    p = Path(path)
    if not p.is_absolute() or p != p.resolve(strict=True) or not p.is_file():
        raise LabFailure("Expected an absolute resolved regular-file path")
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def _json(path, value):
    # Evidence is append-only by filename; never overwrite a previous attempt.
    with Path(path).open("x", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=True, sort_keys=True, indent=2)
        f.write("\n")


class RelayLab:
    """One-use context manager. Its output directory must not exist at entry."""

    def __init__(self, config, output_directory):
        # No I/O at construction. Validation and all activation happen in enter.
        self.config = config
        self.output = Path(output_directory)
        self.endpoints = {}
        self._entered = False
        self._owned = []
        self._listeners = []
        self._sockets = set()
        self._threads = []
        self._events = []
        self._proxy_errors = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._counter = 0
        self._active_connections = 0
        self._total_connections = 0
        self._uncertain = []
        self._token = None

    def _event(self, **fields):
        with self._lock:
            self._events.append({"monotonic": time.monotonic(), **fields})

    def _check_files(self):
        for name, expected in self.config["files"].items():
            if _pin(expected["path"]) != expected:
                raise LabFailure("File pin changed: " + name)

    def _validate(self):
        c = self.config
        if not isinstance(c, dict) or set(c) != {"scope", "execution_allowed", "run_id", "files"}:
            raise LabFailure("Closed lab configuration required")
        if c["scope"] != "CURRENT_CARRIER_TWO_RELAY_LAB_ONLY" or c["execution_allowed"] is not True:
            raise LabFailure("Wrong lab scope or no enclosing release")
        if not isinstance(c["run_id"], str) or re.fullmatch(r"[a-z0-9-]{1,32}", c["run_id"]) is None:
            raise LabFailure("Invalid run identifier")
        if not isinstance(c["files"], dict) or set(c["files"]) != {
                "supervisor", "python", "docker", "strfry_config", "rs_relay_config"}:
            raise LabFailure("Exact five file descriptors required")
        for d in c["files"].values():
            if not isinstance(d, dict) or set(d) != {"path", "bytes", "sha256"}:
                raise LabFailure("Invalid file descriptor")
            if type(d["bytes"]) is not int or d["bytes"] < 1 or not isinstance(d["sha256"], str) or re.fullmatch(r"[0-9a-f]{64}", d["sha256"]) is None:
                raise LabFailure("Invalid file pin")
        self._check_files()
        if c["files"]["supervisor"]["path"] != str(Path(__file__).resolve(strict=True)):
            raise LabFailure("Supervisor descriptor does not identify this source")
        if c["files"]["python"]["path"] != str(Path(sys.executable).resolve(strict=True)):
            raise LabFailure("Python descriptor does not identify this interpreter")
        if os.getuid() == 0 or os.getgid() == 0:
            raise LabFailure("Non-root host UID and GID required")
        if not self.output.is_absolute() or self.output.name in {"", ".", ".."}:
            raise LabFailure("New absolute owned output directory required")
        parent = self.output.parent.resolve(strict=True)
        if parent != self.output.parent or "," in str(self.output):
            raise LabFailure("Output parent must be resolved, without Docker mount delimiters")
        # mkdir rejects files, symlinks and existing directories, including earlier runs.
        self.output.mkdir(mode=0o700)
        self._token = secrets.token_hex(16)
        self._name = "nbdp-carrier-" + c["run_id"] + "-" + self._token
        (self.output / "docker-config").mkdir(mode=0o700)
        (self.output / "commands").mkdir(mode=0o700)
        for relay, source in (("strfry", "strfry_config"), ("rs-relay", "rs_relay_config")):
            (self.output / (relay + "-db")).mkdir(mode=0o700)
            raw = Path(c["files"][source]["path"]).read_bytes()
            dest = self.output / (relay + ".config")
            with dest.open("xb") as f:
                f.write(raw)
            dest.chmod(0o400)
            if _pin(dest)["sha256"] != c["files"][source]["sha256"]:
                raise LabFailure("Copied configuration pin mismatch")
        _json(self.output / "admitted-config.json", c)

    def _docker(self, phase, args, required=True):
        # Explicit local Unix daemon + empty private config: no inherited context,
        # remote host, credentials, plugin, registry login or image pull fallback.
        self._counter += 1
        prefix = self.output / "commands" / (f"{self._counter:04d}-" + phase)
        command = [self.config["files"]["docker"]["path"],
                   "--host", "unix:///var/run/docker.sock", "--config",
                   str(self.output / "docker-config"), *args]
        started = time.monotonic()
        receipt = {"argv": command, "timeout_seconds": COMMAND_SECONDS,
                   "exit": None, "timed_out": False, "error": None}
        with Path(str(prefix) + ".stdout").open("xb") as out, Path(str(prefix) + ".stderr").open("xb") as err:
            try:
                p = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                   timeout=COMMAND_SECONDS, check=False,
                                   env={"PATH": "/usr/bin:/bin", "HOME": str(self.output), "LC_ALL": "C"},
                                   cwd=self.output)
                receipt["exit"] = p.returncode
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
            except OSError as exc:
                receipt["error"] = type(exc).__name__ + ": " + str(exc)
        receipt["elapsed_seconds"] = time.monotonic() - started
        _json(str(prefix) + ".receipt.json", receipt)
        stdout = Path(str(prefix) + ".stdout").read_bytes()
        if required and (receipt["exit"] != 0 or receipt["timed_out"] or receipt["error"]):
            raise LabFailure("Docker phase unqualified: " + phase)
        return receipt, stdout

    def _inspect(self, kind, identity, required=True):
        receipt, data = self._docker("inspect-" + kind, [kind, "inspect", identity], required)
        if receipt["exit"] != 0:
            return None
        value = json.loads(data.decode("utf-8", errors="strict"))
        if not isinstance(value, list) or len(value) != 1:
            raise LabFailure("Unexpected inspect response")
        return value[0]

    def _create(self, kind, name, args):
        # Successful creation owns the immutable ID before any subsequent phase.
        # An interrupted/failed create may have reached the daemon; reconcile only
        # our unpredictable name+label, but retain uncertainty even if now absent.
        try:
            receipt, data = self._docker("create-" + kind, args, required=False)
        except BaseException:
            # Even evidence-write interruption can follow daemon-side creation.
            self._uncertain.append({"kind": kind, "name": name, "phase": "create-command-or-evidence-exception"})
            try:
                found = self._inspect(kind, name, required=False)
                labels = None if found is None else (found.get("Labels") if kind == "network" else found.get("Config", {}).get("Labels"))
                if isinstance(labels, dict) and labels.get(LABEL) == self._token and re.fullmatch(r"[0-9a-f]{64}", found.get("Id", "")):
                    self._owned.append((kind, found["Id"]))
            except Exception:
                # Cleanup remains unqualified; never guess identity or remove by name.
                pass
            raise
        if receipt["exit"] == 0 and not receipt["timed_out"] and not receipt["error"]:
            identity = data.decode("ascii", errors="strict").strip()
            if re.fullmatch(r"[0-9a-f]{64}", identity):
                self._owned.append((kind, identity))
                _json(self.output / (f"owned-{len(self._owned):02d}.json"),
                      {"kind": kind, "id": identity, "name": name, "owner": self._token})
                return identity
        self._uncertain.append({"kind": kind, "name": name, "phase": "create"})
        found = self._inspect(kind, name, required=False)
        labels = None if found is None else (found.get("Labels") if kind == "network" else found.get("Config", {}).get("Labels"))
        if isinstance(labels, dict) and labels.get(LABEL) == self._token:
            identity = found.get("Id", "")
            if re.fullmatch(r"[0-9a-f]{64}", identity):
                self._owned.append((kind, identity))
                _json(self.output / (f"owned-{len(self._owned):02d}.json"),
                      {"kind": kind, "id": identity, "name": name, "owner": self._token,
                       "discovered_after_unqualified_create": True})
        raise LabFailure("Creation failed or ownership outcome uncertain: " + kind)

    def _start(self):
        # Bind before Docker mutation; no SO_REUSEADDR/REUSEPORT, no public binds.
        for relay, (listen, _) in PORTS.items():
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._listeners.append((relay, server))
            server.bind(("127.0.0.1", listen))
        for relay, image in IMAGES.items():
            value = self._inspect("image", image)
            if value.get("Id") != image:
                raise LabFailure("Pinned local image unavailable: " + relay)
        # Explicit collision check, in addition to Docker's atomic create refusal.
        for kind, name in (("network", self._name), ("container", self._name + "-strfry"), ("container", self._name + "-rs-relay")):
            _, raw = self._docker("collision-" + kind, [kind, "ls", *(["--all"] if kind == "container" else []), "--filter", "name=" + name, "--format", "{{json .}}"])
            if raw.strip():
                raise LabFailure("Resource name collision")
        network = self._create("network", self._name, ["network", "create", "--internal", "--driver", "bridge", "--label", LABEL + "=" + self._token, self._name])
        ni = self._inspect("network", network)
        if ni.get("Internal") is not True or ni.get("Driver") != "bridge" or ni.get("Labels", {}).get(LABEL) != self._token:
            raise LabFailure("Network isolation mismatch")
        self._containers = {}
        self._targets = {}
        for relay, image in IMAGES.items():
            name = self._name + "-" + relay
            mount = "/src/strfry.conf" if relay == "strfry" else "/src/config.toml"
            command = ["container", "create", "--pull=never", "--name", name,
                       "--label", LABEL + "=" + self._token, "--network", network,
                       "--user", f"{os.getuid()}:{os.getgid()}", "--cpus", "2", "--memory", "1g",
                       "--pids-limit", "128", "--read-only", "--cap-drop", "ALL",
                       "--security-opt", "no-new-privileges:true", "--tmpfs", "/tmp:rw,noexec,nosuid,size=67108864",
                       "--log-driver", "json-file", "--log-opt", "max-size=10m", "--log-opt", "max-file=1",
                       "--mount", f"type=bind,src={self.output / (relay + '.config')},dst={mount},readonly",
                       "--mount", f"type=bind,src={self.output / (relay + '-db')},dst=/data", image]
            command += ["relay"] if relay == "strfry" else ["--db", "/data"]
            identity = self._create("container", name, command)
            self._containers[relay] = identity
            self._docker("start-" + relay, ["container", "start", identity])
            info = self._inspect("container", identity)
            if info.get("Image") != image or info.get("Config", {}).get("Labels", {}).get(LABEL) != self._token:
                raise LabFailure("Started container identity mismatch")
            nets = info.get("NetworkSettings", {}).get("Networks", {})
            if set(nets) != {self._name} or info.get("HostConfig", {}).get("PortBindings"):
                raise LabFailure("Unexpected container exposure")
            ip = ipaddress.IPv4Address(nets[self._name]["IPAddress"])
            if not ip.is_private or ip.is_loopback or ip.is_link_local:
                raise LabFailure("Unexpected private bridge address")
            self._targets[relay] = (str(ip), PORTS[relay][1])
        deadline = time.monotonic() + READINESS_SECONDS
        pending = set(PORTS)
        while pending and time.monotonic() < deadline:
            for relay in tuple(pending):
                try:
                    with socket.create_connection(self._targets[relay], timeout=0.25):
                        pending.remove(relay)
                except OSError:
                    pass
            if pending:
                time.sleep(0.1)
        if pending:
            raise LabFailure("Bounded private TCP readiness failed")
        for relay, server in self._listeners:
            server.listen(16)
            server.setblocking(False)
            self.endpoints[relay] = "ws://127.0.0.1:" + str(PORTS[relay][0])
        self._accept_thread = threading.Thread(target=self._accept, name="nbdp-lab-accept", daemon=True)
        self._accept_thread.start()
        self.assert_healthy()
        _json(self.output / "tcp-ready.json", {"endpoints": self.endpoints, "internal_targets": self._targets,
              "readiness": "TCP_ONLY_NOT_WEBSOCKET_OR_NOSTR", "owned": self._owned})

    def _accept(self):
        try:
            while not self._stop.is_set():
                ready, _, _ = select.select([s for _, s in self._listeners], [], [], 0.2)
                for server in ready:
                    try:
                        client, address = server.accept()
                    except BlockingIOError:
                        continue
                    with self._lock:
                        if self._active_connections >= MAX_CONNECTIONS or self._total_connections >= MAX_TOTAL_CONNECTIONS:
                            client.close()
                            # A cap refusal makes supervision unqualified; it is
                            # never silently interpreted as target behavior.
                            self._proxy_errors.append("Fixed proxy connection cap reached")
                            self._stop.set()
                            continue
                        self._active_connections += 1
                        self._total_connections += 1
                        self._sockets.add(client)
                    relay = next(r for r, s in self._listeners if s is server)
                    thread = threading.Thread(target=self._forward, args=(relay, client), daemon=True)
                    self._threads.append(thread)
                    thread.start()
        except Exception as exc:
            if not self._stop.is_set():
                self._proxy_errors.append(type(exc).__name__ + ": " + str(exc))

    def _forward(self, relay, client):
        upstream = None
        counts = [0, 0]
        outcome = "closed"
        try:
            upstream = socket.create_connection(self._targets[relay], timeout=2)
            with self._lock:
                self._sockets.add(upstream)
            client.settimeout(0.5)
            upstream.settimeout(0.5)
            deadline = time.monotonic() + CONNECTION_SECONDS
            while not self._stop.is_set() and time.monotonic() < deadline:
                ready, _, _ = select.select([client, upstream], [], [], 0.2)
                for source in ready:
                    data = source.recv(65536)
                    if not data:
                        return
                    target = upstream if source is client else client
                    target.sendall(data)
                    counts[0 if source is client else 1] += len(data)
            outcome = "supervisor-stop" if self._stop.is_set() else "fixed-connection-deadline"
            if not self._stop.is_set():
                self._proxy_errors.append("Proxy fixed connection deadline reached")
        except Exception as exc:
            outcome = type(exc).__name__ + ": " + str(exc)
            if not self._stop.is_set():
                self._proxy_errors.append("Proxy connection error: " + outcome)
        finally:
            with self._lock:
                self._active_connections -= 1
                for sock in (client, upstream):
                    if sock is not None:
                        self._sockets.discard(sock)
                        sock.close()
            self._event(event="proxy-connection", relay=relay, bytes_to_relay=counts[0], bytes_from_relay=counts[1], outcome=outcome)

    def assert_healthy(self):
        """Bounded supervision check; controller still verifies every protocol step."""
        if self._proxy_errors or self._stop.is_set() or not self._accept_thread.is_alive():
            raise LabFailure("Proxy supervision failed")
        for relay, identity in self._containers.items():
            info = self._inspect("container", identity)
            if info.get("State", {}).get("Running") is not True or info.get("State", {}).get("OOMKilled") is True:
                raise LabFailure("Relay not running normally: " + relay)

    def _cleanup(self):
        problems = []
        self._stop.set()
        for _, server in self._listeners:
            server.close()
        with self._lock:
            for sock in tuple(self._sockets):
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                sock.close()
        deadline = time.monotonic() + 5
        accept = self._accept_thread if hasattr(self, "_accept_thread") else None
        if accept is not None and accept.ident is not None:
            accept.join(max(0, deadline - time.monotonic()))
        # The accept thread has stopped producing child threads before snapshot.
        threads = ([accept] if accept is not None else []) + self._threads
        for thread in threads:
            if thread.ident is not None:
                thread.join(max(0, deadline - time.monotonic()))
        if any(t.is_alive() for t in threads):
            problems.append("Owned proxy thread did not terminate")
        for kind, identity in reversed(self._owned):
            try:
                info = self._inspect(kind, identity)
                labels = info.get("Labels") if kind == "network" else info.get("Config", {}).get("Labels")
                if not isinstance(labels, dict) or labels.get(LABEL) != self._token:
                    raise LabFailure("Ownership label mismatch; refusing removal")
                if kind == "container":
                    log_receipt, _ = self._docker("logs", ["container", "logs", "--timestamps", "--tail", "10000", identity], required=False)
                    if log_receipt["exit"] != 0 or log_receipt["timed_out"] or log_receipt["error"]:
                        problems.append("Owned container log capture unqualified: " + identity)
                    self._docker("remove-container", ["container", "rm", "--force", identity])
                else:
                    self._docker("remove-network", ["network", "rm", identity])
                # Successful rm + successful enumeration excluding immutable ID.
                _, raw = self._docker("verify-absence-" + kind, [kind, "ls", *( ["--all"] if kind == "container" else []), "--no-trunc", "--format", "{{.ID}}"])
                if identity in raw.decode("ascii", errors="strict").split():
                    raise LabFailure("Owned resource still present after removal")
            except Exception as exc:
                problems.append(type(exc).__name__ + ": " + str(exc))
        try:
            self._check_files()
        except Exception as exc:
            problems.append(type(exc).__name__ + ": " + str(exc))
        problems.extend(self._proxy_errors)
        if self._uncertain:
            problems.append("Ambiguous creation outcome retained; absence now cannot prove no later daemon creation")
        _json(self.output / "proxy-events.json", self._events)
        _json(self.output / "cleanup.json", {"qualified": not problems, "problems": problems,
              "owned": self._owned, "uncertain_creates": self._uncertain,
              "atomic_cleanup_under_external_kill": False})
        if problems:
            raise LabFailure("Lab cleanup/supervision unqualified: " + "; ".join(problems))

    def __enter__(self):
        if self._entered:
            raise LabFailure("RelayLab cannot be reused")
        self._entered = True
        try:
            self._validate()
            self._start()
            return self
        except BaseException as exc:
            if self.output.is_dir() and self._token is not None:
                try:
                    try:
                        _json(self.output / "startup-failure.json", {"type": type(exc).__name__, "message": str(exc)})
                    finally:
                        self._cleanup()
                except Exception as cleanup_exc:
                    raise LabFailure(str(exc) + "; " + str(cleanup_exc)) from exc
            raise

    def __exit__(self, exc_type, exc, traceback):
        health_error = None
        if exc is None:
            try:
                self.assert_healthy()
            except Exception as problem:
                health_error = problem
        self._cleanup()
        if health_error is not None:
            raise health_error
        return False
