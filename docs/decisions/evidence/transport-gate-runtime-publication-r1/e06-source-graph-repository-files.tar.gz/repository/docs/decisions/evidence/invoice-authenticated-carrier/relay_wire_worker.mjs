// SOURCE ONLY. Fixed local-relay wire I/O, no crypto or consumer/oracle evaluation.
// CLI (only after an independently admitted controller starts its owned lab):
// node relay_wire_worker.mjs ABS_PRIVATE_MANIFEST EXACT_MANIFEST_SHA256
// Evidence preserves whole WebSocket message payloads, not TCP/frame headers.
import {readFileSync, writeFileSync, statSync, realpathSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';
import path from 'node:path';

const endpoints = {strfry:'ws://127.0.0.1:17777', 'rs-relay':'ws://127.0.0.1:18081'};
const requireValue = (yes, reason) => {if (!yes) throw Error(reason);};
const pin = file => {const b=readFileSync(file); return {bytes:b.length,sha256:createHash('sha256').update(b).digest('hex')};};
const samePin = (a,b) => a?.bytes===b?.bytes && a?.sha256===b?.sha256;
const same = (a,b) => {
  if(typeof a!==typeof b || (a===null)!==(b===null) || Array.isArray(a)!==Array.isArray(b)) return false;
  if(a===null || typeof a!=='object') return a===b;
  if(Array.isArray(a)) return a.length===b.length && a.every((v,i)=>same(v,b[i]));
  return Object.keys(a).length===Object.keys(b).length && Object.keys(a).every(k=>Object.hasOwn(b,k)&&same(a[k],b[k]));
};
const save = (file,value) => writeFileSync(file,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});
let sockets = new Set();

async function main() {
  requireValue(process.argv.length===4,'Fixed manifest/hash CLI required');
  const [manifestPath,expected]=process.argv.slice(2);
  requireValue(path.isAbsolute(manifestPath) && /^[0-9a-f]{64}$/.test(expected),'Absolute manifest and external SHA256 required');
  requireValue(pin(manifestPath).sha256===expected,'Manifest pin mismatch');
  const directory=path.dirname(manifestPath);
  requireValue(realpathSync(directory)===directory && (statSync(directory).mode&0o077)===0,'Private resolved manifest directory required');
  const manifest=JSON.parse(readFileSync(manifestPath,'utf8'));
  requireValue(manifest.execution_released===true && manifest.scope==='CURRENT_CARRIER_RELEASED_LOCAL_RELAY_WIRE_IO_ONLY'
    && ['primary','qa'].includes(manifest.label),'Wire manifest scope mismatch');
  requireValue(endpoints[manifest.relay]===manifest.endpoint,'Only exact loopback relay endpoints allowed');
  requireValue(samePin(pin(manifest.release.path),manifest.release.pin),'Parent release changed');
  const release=JSON.parse(readFileSync(manifest.release.path,'utf8'));
  requireValue(release.execution_released===true && release.scope==='CURRENT_CARRIER_BOTH_RELAY_CONTROLS_ONLY','No enclosing relay release');
  const self=fileURLToPath(import.meta.url);
  requireValue(self===release.wire_worker_file && samePin(pin(self),manifest.self_pin) && samePin(manifest.self_pin,release.wire_worker_pin),'Worker source not released');
  requireValue(manifest.release_label===manifest.label && release.labels?.includes(manifest.label),'Run label not released');
  requireValue(manifest.publications.length===16 && new Set(manifest.publications.map(x=>x.event.id)).size===16,'Exactly16 distinct planned events required');
  requireValue(new Set(manifest.publications.map(x=>x.template)).size===16,'Duplicate publication template');
  requireValue(same(manifest.publications,release.publication_cohorts[manifest.relay]),'Publication cohort differs from exact enclosing release');
  requireValue(same(manifest.pins,release.wire_runtime_pins) && manifest.ws_entry===release.ws_entry
    && manifest.node_modules_real_path===release.node_modules_real_path,'Wire runtime closure differs from enclosing release');
  const verify=()=>{
    requireValue(pin(manifestPath).sha256===expected,'Manifest changed');
    for(const [file,expectedPin] of Object.entries(manifest.pins)) {
      requireValue(path.isAbsolute(file) && realpathSync(file)===file && samePin(pin(file),expectedPin),'Pinned runtime closure changed: '+file);
    }
    requireValue(realpathSync(process.execPath)===manifest.node && manifest.node===release.node,'Node identity mismatch');
    requireValue(realpathSync(manifest.ws_entry)===manifest.ws_entry && manifest.ws_entry.startsWith(manifest.node_modules_real_path+'/ws/'),'Pinned ws entry layout mismatch');
    requireValue(samePin(manifest.pins[manifest.node],pin(manifest.node)) && samePin(manifest.pins[manifest.ws_entry],pin(manifest.ws_entry)), 'Executable/ws entry missing from closure');
  };
  verify();
  // Optional native accelerators are disabled by the parent's closed environment.
  requireValue(process.env.WS_NO_BUFFER_UTIL==='1' && process.env.WS_NO_UTF_8_VALIDATE==='1','Fixed pure-JS ws environment required');
  const {default:WebSocket}=await import(pathToFileURL(manifest.ws_entry).href);
  const report={qualified:false,relay:manifest.relay,endpoint:manifest.endpoint,publicationCount:0,retrievalCount:0,rows:[],
    captureScope:'Complete sent/received WebSocket message payloads; no physical frame-header claim'};
  try {
    for(const publication of manifest.publications) {
      verify();
      const row={template:publication.template,eventId:publication.event.id,qualified:false,frames:[],event:null,wireHex:null};
      report.rows.push(row);
      save(path.join(directory,publication.template+'-planned-event.json'),publication.event);
      const ws=new WebSocket(manifest.endpoint,{handshakeTimeout:3000,maxPayload:200000,followRedirects:false,perMessageDeflate:false});
      sockets.add(ws);
      const queue=[]; let wake=null, terminal=null;
      ws.on('message',(data,isBinary)=>{
        const raw=Buffer.from(data); const frame={direction:'RECEIVE',binary:isBinary,rawHex:raw.toString('hex'),parsed:null};
        row.frames.push(frame);
        if(row.frames.length>64 || raw.length>200000 || isBinary) {terminal=Error('Unexpected/bounded WebSocket message'); ws.terminate();}
        else {try {frame.parsed=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw)); queue.push(frame);} catch(e){terminal=e;ws.terminate();}}
        if(wake) {wake();wake=null;}
      });
      ws.on('error',e=>{terminal=e;if(wake){wake();wake=null;}});
      ws.on('close',(code,reason)=>{row.close={code,reasonHex:Buffer.from(reason).toString('hex')};terminal??=Error('WebSocket closed');if(wake){wake();wake=null;}});
      const receive=async()=>{
        const deadline=Date.now()+3000;
        while(!queue.length) {
          if(terminal) throw terminal;
          const remaining=deadline-Date.now();requireValue(remaining>0,'Response deadline');
          await new Promise(resolve=>{const timer=setTimeout(()=>{wake=null;resolve();},remaining);wake=()=>{clearTimeout(timer);resolve();};});
        }
        const frame=queue.shift();requireValue(Array.isArray(frame.parsed),'Expected Nostr array');return frame;
      };
      const send=value=>{const raw=Buffer.from(JSON.stringify(value),'utf8');row.frames.push({direction:'SEND',binary:false,rawHex:raw.toString('hex'),parsed:value});ws.send(raw,{binary:false});};
      try {
        await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Open deadline')),3000);ws.once('open',()=>{clearTimeout(timer);resolve();});ws.once('error',e=>{clearTimeout(timer);reject(e);});});
        send(['EVENT',publication.event]);
        const ok=(await receive()).parsed;
        requireValue(ok.length===4 && ok[0]==='OK' && ok[1]===publication.event.id && ok[2]===true && typeof ok[3]==='string','Publication did not receive exact OK true');
        row.ok=ok;report.publicationCount++;
        const subscription='nbdp-'+publication.template;
        send(['REQ',subscription,{ids:[publication.event.id],limit:1}]);
        const received=await receive();
        requireValue(received.parsed.length===3 && received.parsed[0]==='EVENT' && received.parsed[1]===subscription
          && received.parsed[2]?.id===publication.event.id,'Missing, unsolicited or wrong retrieval EVENT');
        row.event=received.parsed[2];row.eventFrameRawHex=received.rawHex;
        row.wireHex=Buffer.from(JSON.stringify(row.event),'utf8').toString('hex');
        const eose=(await receive()).parsed;
        requireValue(eose.length===2 && eose[0]==='EOSE' && eose[1]===subscription,'Missing or unexpected EOSE');
        row.eose=eose;send(['CLOSE',subscription]);report.retrievalCount++;
        // No queued duplicate/unsolicited response may be ignored as success.
        requireValue(queue.length===0 && !terminal,'Unexpected pending relay response');
        await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{ws.terminate();reject(Error('Close deadline'));},1000);ws.once('close',()=>{clearTimeout(timer);resolve();});ws.close(1000);});
        requireValue(queue.length===0 && row.close?.code===1000,'Late unsolicited response or unclean close');
        verify();row.qualified=true;
      } catch(error) {
        row.error=error.name+': '+error.message;
        throw error;
      } finally {
        ws.terminate();sockets.delete(ws);
        save(path.join(directory,publication.template+'-wire.json'),row);
      }
    }
    requireValue(report.publicationCount===16 && report.retrievalCount===16,'Incomplete relay cohort');
    verify();report.qualified=true;
  } catch(error) {report.error=error.name+': '+error.message;}
  finally {
    for(const ws of sockets) ws.terminate();
    sockets.clear();
    try {verify();} catch(error){report.qualified=false;report.integrity_error=error.message;}
    save(path.join(directory,'wire-result.json'),report);
  }
  process.stdout.write(JSON.stringify({qualified:report.qualified,publications:report.publicationCount,retrievals:report.retrievalCount})+'\n');
  return report.qualified?0:1;
}

main().then(code=>{process.exitCode=code;}).catch(error=>{
  for(const ws of sockets) ws.terminate();
  process.stderr.write(error.name+': '+error.message+'\n');process.exitCode=1;
});
