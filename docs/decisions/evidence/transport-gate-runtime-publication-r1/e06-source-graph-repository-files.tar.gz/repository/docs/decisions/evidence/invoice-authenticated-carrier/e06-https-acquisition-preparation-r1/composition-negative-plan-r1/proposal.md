# N02/N03/N16: bounded next-lane source/design proposal

State: **NONEXECUTABLE_PROPOSAL / NOT_FROZEN / NOT_RUNTIME_READY**.
Execution authority: **NONE**. Author: `/root/negative_lane_architect`.
Only this file is owned by this assignment. No accepted source, fixture, evidence,
state/roadmap or Git publication is changed. This is neither an independent
security acceptance nor a runtime release.

## Scope and prerequisite

The assigned scope permits this reversible design while independent LAB-I4 QA
runs. At this proposal's preparation, exact primary evidence is accepted;
independent QA completion and exact positive-pair acceptance are still required.
No QA outcome is assumed. A later coordinator acceptance must pin the actual QA
evidence/reviews and unchanged positive source/configuration, preserving both
earlier primary failures. That acceptance is a dependency for downstream negative
source work, not authority created by this proposal.

Propose only existing-fixture N02 `MISSING_D`, N03 `MISSING_F`, and N16
`LOCAL_PERMISSION_REFUSAL`. Local permission means this laboratory's permission
to acquire attachment bytes; it is not invoice approval, payment state, device
delegation or business authority. No new normative rule is adopted.

Approved PO-001–PO-006 scope remains vendor-independent conditional Option B,
parallel device authority, static NIP-44 without FS/PCS and canonical Q/E IDs.
Q01/Q08/Q13/Q15/Q27 remain BLOCKER. No custom cryptography, new NIP/kind, fresh
F2/wrap/nonce/ciphertext generation, SDK, production, real data/keys or deployment
is proposed. E06 still depends on E01/E02/E05 and its adopted candidate-specific
E02 evidence policy; E04 PASS is not added as a dependency. Canonical E06 remains
NOT_EXECUTED; the overlay remains PARTIAL.

## Evidence and immutable positive baseline

Read sources: AGENTS.md, PROJECT_STATE.md/ROADMAP.md current overlays,
[PO decisions](../../../../PRODUCT_OWNER_DECISIONS_2026-10-11.md), ADR0001,
architecture-risk-register; the nine composition inputs below; accepted R5
materialization/input evidence; native JS/Rust metadata source read as text.
The [reviewed design r3](../composition-readiness-architect-r3.md) supplies the
finite-frontier/no-retry/private-public policy. Historical source-plan headers
are contemporaneous source-only descriptions, not an override of later actual
primary acceptance.

Paths in this table are relative to `experiments/prototypes/e06_relay_https_composition_v1/`.
These current bytes were inventoried statically and must remain protected.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| SOURCE.md | 9366 | fc2c8a6fecf374094c970088213765873f1f511804d812f86f8fb3266ffcaab5 |
| contract.json | 21113 | c15e87802d199e049eb535b130b0db420cc869982deeb51911239ab803924bc3 |
| selection-map.json | 35919 | f523aee4be1e4b5fa5adc51723c414f859465517bf99f79f0e91d1e13a26c1d2 |
| oracles.json | 94166 | c8c2830334342c771e959d94fc3b8e6e2d91d8139679a85c63819ce92df618e0 |
| control-scope.json | 11456 | 49e6439be698a29e77c48e4217510cb92a808f3bb622c739495b6c6a4ee4c0b2 |
| interfaces.md | 13134 | a4025f32f0f1c42280edc83a7efbcd0ed82f6592ffc95203ced07d204f2fcff9 |
| BRIDGE.md | 10113 | 03df5e47ba6a1acf9d47444b61999c6d854005dce92852dc72d2d984e939eac6 |
| bridge-schemas.json | 25275 | 927c4536b32efaba37908a31f7e428a84fe333994ce84052610806322aaeb8c1 |
| protocol.mjs | 78090 | a1c5a88ef79202d3c60297018aa08fda04f324ff94db9bd05b1359dcfef8789e |

The [primary manifest](../composition-execution-r3/primary-manifest.json)
79719 / `71d58aa857ffaf09568100d3750e5dd6b6aed21767b055ce44b1373773640748`
is the reference to the full positive source/tool/input closure, not an executable
negative manifest. [Actual primary evidence](../composition-primary-runtime-r1/evidence.json)
227104 / `92191f29211eda7f5ffac44d7da67c5511395eaf33d835743175fc1fe0135271`
and [its acceptance](../composition-primary-runtime-r1/acceptance.json)
1286 / `d3594e69de90ff4df0813cc154ee9b23bd82ab7b08474835d47568e34658e7f0`
bind four positive windows/28 steps only. Acceptance, not the earlier evidence's
pending-review text or `qaRelease` field, records current primary review status.
This proposal does not update historical files.

I4 accepts C01–C04 only, requires D and F for its native request/subject projection,
and closes metadata only after private consumer success. Its seven-step success
and failure paths cannot honestly express qualified missing-pair/permission
negatives. Leave that interface unchanged. Propose a separate derivative directory
`experiments/prototypes/e06_relay_https_negative_v1/` with a distinct closed lane
label, proposed `LAB-N-02-03-16`, admitting only the frozen cells below. Neither
I4 releases nor this proposed label authorize it. No fallback, mixed I4/N cases,
arbitrary event schedules, caller commands or imports are allowed.

## Exact existing fixture selection

Use invoice only: Rust-produced D/F with native JS and Rust metadata. This avoids
adding a document-family matrix to a test of absence/local policy. The unchanged
positive lane retains credit-note and engine coverage. Define `R` as repository
root, `P=/tmp/e6https-prepare-prepr501/PREPARE`,
`D=R/docs/decisions/evidence/invoice-authenticated-carrier/e06-metadata-materialization-r3/primary`.
These are existing saved operands, not newly generated objects.

| Operand | Exact path | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| D record | D/artifacts/000.json | 10082 | ca54582cc8a315615bea807d934389812a902d2df2bda135614e703037fe7f4d |
| incoming D wire | D/artifacts/000.incoming.wire | 3921 | 9a7c53306aca263d8fcf9da83f2a09725d2198c223c54b201efa967319045283 |
| F record | P/invoice.F.json | 826 | c3d939e95ff21dbaadc322259a60e34f9d35549b082faa87c980afc8c6e81e29 |
| incoming F wire | P/invoice.incoming.wire | 2897 | 06a372bca1fadd8f028203289cda89bca49b9d43a89e2b31c1ba3d69228b0bb3 |
| JS/RUST scope/request reference (each) | P/invoice.JS.request.json; P/invoice.RUST.request.json | 14116 | ecd5f4cf9f9f1ae5c3d46cc5edd7135404f6a4b8b0728bfc781b0889d4049ff4 |
| JS paired expected | P/invoice.JS.expected.json | 7746 | b2af6ebd64434c3541bad82ffbee9b664377931c0984f87fcb7b92ef8f697cc1 |
| Rust paired expected | P/invoice.RUST.expected.json | 7770 | 4bb1c8965d80e44233775334a08f22ceb3fb64a883a3f458b20a68e93977413d |
| F/native preparation proofs | P/proofs.json | 11002 | 761f25658113941c8c7cace0a15d40a53c71d84aa3007235296f2f63cb4aed37 |
| D/native preparation proofs | D/proofs.json | 740469 | cf7e9455e15a2dddd46785ca702e72dd779ced3941de0e14a596dc8da576af49 |
| catalogue | P/catalogue.json | 5653 | 3741ed00a14095d43a3f312177672ccccf2d240aba8592577e2d4637d4a03d12 |

Canonical D ID: `c4f3f2a08ad09ef7f9be6a0e82efaa5b136b54016fd1a4db2d4d92bf4cb704e7`.
Canonical F ID: `66221fc9dd752034847a48d68a8904d528a8b8a26cc333bc317614a437c9aaeb`.
Scope remains `enabled=true`, `role=incoming`, local
`c6047f9441ed7d6d3045406e95c07cd85c778e4b8cef3ca7abac09b95c709ee5`, peer
`79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798`, context
`3333333333333333333333333333333333333333333333333333333333333333`, origin
`https://files.invalid:18443`. Actual received EVENT spans replace request wire
fields without reserialization. Reference paired request files are not submitted
as prepared authenticated results. No blob or original oracle is needed by these
no-acquisition paths; any inherited attachment descriptor is a protected input,
never a reason to open/download/decrypt it.

[R5 materialization acceptance](../fixture-materialization-acceptance-r5.json)
1595 / `11ae5a7d69e7b3c99a6262e50e7aa4824b9ca54fdf0e465adce79bc435e52afc`
and [R5 input acceptance](../fixture-input-acceptance-r5.json)
2524 / `a80d6272492f395f36d8afea0d3283a07e406eecfc6243fd4eaeea3fef85ceae`
retain their original limits. All selected operands above matched their saved
descriptors in this static read. This is not fresh native qualification. Before
later use, recheck exact acceptance joins and bytes. Missing temporary operands
refuse; a durable mirror mapping needs separate byte-exact review. Do not silently
rematerialize them or search/run historical matrices as a substitute.

## Proposed finite cells and schedules

Freeze both relays × both backends for N02 and N16, so backend and relay are not
confounded. N03 has no metadata backend and needs one cell per relay. Proposed
cell IDs are `N02-SF-JS`, `N02-SF-RUST`, `N02-RS-JS`, `N02-RS-RUST`,
`N03-SF`, `N03-RS`, `N16-SF-JS`, `N16-SF-RUST`, `N16-RS-JS`, `N16-RS-RUST`;
SF=strfry, RS=rs-relay. Window ID is `W-` plus cell ID. Keep canonical N identifiers
and candidate step IDs below; qualify a step by cell ID in records/paths. Each
window is a fresh process/context with fresh native state when applicable. Fixed
serial cell order is exactly this list. No post-frontier events are scheduled.

| Subprofile | Exact proposed step schedule | Required boundary |
| --- | --- | --- |
| N02 | N02-S01: receive F through fixed relay, start one owned metadata child, invoke F-only auth once with `dWireHex=null`; N02-S02: close native stdin, verify terminal lifecycle, closeout without seal | Retain actual whole native reply. Source predicts ORPHAN_PENDING / ASSOCIATION / ORPHAN_F / PENDING_NO_D, D0/F1; complete backend-specific expected objects remain NOT_FROZEN. No fabricated D handle or eligible pair. |
| N03 | N03-S01: receive D through fixed relay; N03-S02: closeout without metadata or seal | D is relay-received only, not freshly authenticated D. Native API requires F: no native child, request, reply, validation or metadata expected object. `metadataRecord=null`; absence is not a successful native reply. |
| N16 | N16-S01: receive D then F through fixed relay and authenticate once with `enabled=true`; N16-S02: record separate local acquisition-permission deny; N16-S03: explicit seal attempt refuses because of that deny; N16-S04: close native stdin, verify terminal lifecycle, closeout | Paired CORRELATED full reply must first match accepted backend-specific R5 object with D1/F1. Deny is a source-local scheduled policy action, never `config.enabled=false`, a forged auth handle or a generic thrown error. No generation may be minted. |

Every receive means one fixed publication/query/EVENT with complete bounded
ACK/EVENT/EOSE/CLOSE/Close1000 transcript and exact raw span/outer identity joins.
Each N16-S01 retains ordered suboperation evidence for D, F, then native request;
each N02-S01 retains F then native request. Expanded internal actions do not add
unlisted public steps. Native child remains owned and quiescent until terminal
close; no restart, additional request or hidden revalidation is allowed. EOSE is
only this laboratory frontier, not proof that D/F is absent globally.

Proposed denominator: **10 windows / 28 whole steps / 14 wire jobs / 8 native
requests and replies**, D validations4/F validations8. This is source arithmetic,
not an observed run count. Terminal cumulative count targets per qualified cell:

| Cell family | Publications/queries/events each | Metadata req/reply each | D/F validations |
| --- | ---: | ---: | --- |
| N02 (four cells) | 1 | 1 | 0/1 |
| N03 (two cells) | 1 | 0 | 0/0 |
| N16 (four cells) | 2 | 1 | 1/1 |

All qualified cells require attemptReservations/acquisitionConnections/httpGets/
receivedEntityBytes/consumerAttempts/attachmentEncryptions/publicReleases = 0.
No HTTPS listener/server/client, acquisition transport, consumer or browser starts.
Relay networking and native carrier authentication still occur where declared;
zero attachment encryption is not zero metadata decryption/cryptographic work.

## Missing source, schema and oracle work

All three subprofiles remain NOT_READY/NOT_FROZEN today. The downstream source
assignment should first freeze inert plan/selection/profile/bridge/schema/oracle/
protected-delta files in the new directory; no executable/import permission is
inferred. Required design work:

- A distinct closed manifest/release/frame/worker/result grammar admits only the
  ten cells and their exact step/slot/backend cardinalities. N03 explicitly has
  backend/channel/metadata terminal absent; do not start an unused native child.
  Reject I4 releases, mixed/unknown cells, enabled=false, unresolved markers,
  stale pins, arbitrary commands and source-author self-review before dependent
  imports/spawns. Recheck current prerequisite/source/tool/image/fixture joins.
- Native requests retain unchanged exact five keys. Add a derivative nullable-D
  branch for N02 and nullable D receive/native provenance only where required.
  Native full 13-key reply grammar must support actual F-only replies, including
  nested JS/Rust differences and null D fields, without weakening paired parsing.
  Source inspection predicts scalar orphan behavior only. Independently derive
  and freeze entire backend-specific F-only expected objects, then separately
  qualify them with actual admitted native evidence before target release; no
  paired expected-object editing presented as observed output. N16 uses existing
  paired full native expected objects unchanged. Workers receive no expectations.
- Preserve raw request/reply bytes and failure-reply custody before shape,
  projection or post-integrity refusal; bind every handle to actual owned pipes,
  received spans and one private derivative module instance. Add an orphan fact
  distinct from an eligible paired subject. N03 never receives an auth handle.
- Design an explicit source-local policy record and expected seal-refusal record
  for N16; local deny changes neither native scope nor authenticated identity.
  Freeze exact composition phase/status/stage/reason values and precedence.
  Missing D/F no-seal closeout is an expected terminal path, not I4's generic
  error-to-UNQUALIFIED shortcut. N16 seal refusal must be specifically attributed
  to permission after successful auth, with no generation/reservation artifact.
- Add qualified terminal closeout without generation/private result: N02/N16
  close one-request metadata channel naturally (exit0, reaped, both EOF, empty
  stderr, no timeout/forced close or extra reply/output); N03 records NOT_STARTED.
  All wire children must already be naturally terminal. Never invent lifecycle
  PIDs/receipts or manufacture a dummy generation/consumer to reuse I4 success.
  Retain the existing ownership/deadline/cleanup/error-preservation protections.
- Freeze all28 whole objects using the complete existing closedStepKeys and14
  counters, plus reviewed cell/policy/terminal bindings. Record phase, exact
  decision/refusal, real provenance/native records, comparands, null generation/
  snapshot/consumer/invalidation where absent, eligibility, lifecycle, cleanup,
  integrity and limits at every step. Public `originalHex=null`,
  `originalReleased=false`, `receiptsEmitted=false`, `businessEffects=0` throughout.
  Schema success must distinguish a qualified negative observation from application
  acquisition success. A nonzero exit or matching substring is never acceptance.
- Counters become unknown/null when an owned operation is attempted but not fully
  observed. Verified no-call branches can retain zero; uncertainty may not erase
  earlier measured work. Unknown lifecycle/cleanup/integrity produces UNQUALIFIED,
  keeps original withheld and preserves raw partial evidence plus primary error
  and separate secondary diagnostics. Do not conflate absent with unknown.

The accepted metadata implementations, N12, shared crypto and exact2937-byte
classifier (`c6a5135c877f2cb041b4c7ac515795826097f6ba520e00e89bffa2ca3a5b5840`)
remain immutable. Source closure/diffs must justify any derivative wiring, guards,
bounded resources and result schemas. No acquisition/consumer algorithm change is
needed to establish these no-call paths. Exact budgets/stream bounds, environment,
images/tools, endpoint ownership and finite cleanup limits still need a new
profile freeze; do not inherit executable authority from accepted I4 limits.

## Evidence gates and limits

1. Coordinator records actual successful positive primary/QA pair acceptance with
   current descriptors. Independent QA/security review this proposal and exact
   downstream inert interface/oracle freeze. Author cannot close security findings.
2. Separately authorize bounded derivative source work with exclusive files and
   protected originals. Freeze complete source/import/tool/data closure; obtain
   independent QA/security source review. No implementation is authorized here.
3. Separately authorize actual F-only oracle qualification if needed, then fresh
   meaningful controls for exact derivative: missing pair cannot mint generation,
   N16 authenticates before deny, disabled native config refuses, no-call paths
   refuse reserved transport/consumer entry, current-source drift and uncertain/
   extra/failed terminal capture prevent qualification. Freeze controls with
   calibration/native coverage separated; review actual CONTROL-only evidence.
4. Review exact new configuration, full28 oracles, workload/resource counts,
   no-acquisition checks, fresh outputs and isolated relay lifecycle. Fresh positive
   admission is required before owned lab setup. No automatic repair/retry.
5. Root separately releases exact primary manifest/session/role/output; archive
   all raw/whole evidence and independently review it. Only after primary
   acceptance may root issue distinct independent QA release. Review actual pair
   equality, real counters, terminal cleanup and final integrity before accepting
   only these selected negative observations. No target/runtime release exists.

Minimum useful future evidence is ten actual full-window observations and all28
whole steps per run, fourteen raw relay transcript/span/lifecycle sets, eight
complete native request/reply/terminal sets, explicit N03 no-native facts, four
N16 policy-deny/seal-refusal records, zero generation/reservation/acquisition/
consumer/release evidence with current-source no-call joins, exact closed outputs,
owned cleanup/integrity and separately executed independent repeat. Capture actual
outer lifecycle where available; host PID/reap/clock unknowns remain explicit.
Shared host/harness/fixtures and common attachment API remain limitations.

The accepted I4 control envelope retains **11 native NOT_EXECUTED and3 native
NOT_READY (RC08–RC10), all native results null**; executed pure calibrations are
separate evidence. These14 RC rows are not the19 deferred LAB-N obligations.
N02/N03/N16 map only selected RC05/RC12 aspects: missing-pair no-seal, authenticated
local permission refusal, and their actual lifecycle/accounting. Even successful
new traces would not establish every RC05 pending/archive/conflict/capacity branch
or RC12 timeout/forced/overflow/fault branch. Do not mark those whole native rows
PASS, edit I4 control scope, or qualify the remaining16 LAB-N subprofiles by proxy.

This finite lane does not establish orphan completion, archive/revision/auth
negatives, duplicate/fresh-wrap behavior, genuine F2/late conflict, network/hash/
snapshot/OS-fault/cleanup injection, global missingness/finality, retention,
durability, receipts, business decisions, FS/PCS, whole E06, Q closure or SDK
readiness. Missing future fixtures remain gates; none is generated here.

Recommended next scope after positive-pair acceptance: separately assign only the
new lane's inert interface/oracle/protected-delta freeze and independent review,
then decide its exact bounded source assignment. No new PO normative decision is
identified for that lab planning; technical evidence and runtime gates still apply.

Static validation only: selected fixture descriptors and JSON references read;
proposed count arithmetic checked; no project module/control/admission/experiment,
network, container, cryptographic helper, Git mutation or publication executed.
Git status was unavailable through the local mounted `.git`; coordinator retains
Git ownership and reports its own verified repository status.

**WRITES_STOPPED** — handoff for independent review; no acceptance claimed.
