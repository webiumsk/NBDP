# Conditional composition code boundaries

Coordinator summary of the actual read-only report from
`/root/https_prepare_empty_reply_explorer`. No code, imports, target execution,
ports or Git changes. HTTPS independent QA14337/pair acceptance remain pending.

An external wrapper alone cannot connect actual relay-received bytes to the
accepted HTTPS capability and snapshot chain:

| Existing boundary | Observed source behavior |
| --- | --- |
| HTTPS acquisition.mjs:150,439,545 | Private ownedTransport/main, no exports; CLI guard makes import inert. |
| HTTPS protocol.mjs:64–73 | Fixed H01–H14 routing; request D/F bytes bound to catalogue wires at line70. |
| HTTPS protocol.mjs:76–89 | authenticateFixture(ctx) reads stored request, takes no received-wire input; privately mints authenticated handle. |
| HTTPS protocol.mjs:91–95 | WeakMaps bind handle/context/one-use snapshot; complete received bytes and ciphertext commitment checked. |
| HTTPS consumer.mjs:14,178,282 | consumeOriginal export uses old protocol WeakMaps; new bridge cannot manufacture compatible handles. Import inert; direct execution refuses. |

Minimum proposed separate derivative ownership, preserving the accepted N12 files:

- New protocol.mjs: composition admission/context/private maps; freshly authenticate
  actual received D/F before minting the subject, retaining complete typed checks.
- Derivative acquisition.mjs: retain transport logic and sequence, using the new
  internal subject and actual received entity to create a snapshot.
- Derivative consumer.mjs: rebind protocol import while retaining native engine,
  same-snapshot, journal, cleanup and original-commitment behavior. Shared
  attachment-crypto.mjs remains unchanged.
- Composition wire.mjs/metadata_loader.mjs: bind the new selection. Existing relay
  executables are pinned to the old selection and cannot consume new HTTPS F
  fixtures unchanged.
- Separate runner/admission/controls, contract/profile, fixture mapping, full
  oracles and SOURCE documentation.

Useful unchanged relay APIs: wire.mjs:108–140 validateEventFrame retains the original
EVENT byte span, and createProtocolState accepts an explicit fixture. Existing
e06_invoice_file_v1/js/metadata.mjs:307 accepts bounded JSONL raw-wire requests with
an internal window; use a fresh admitted process per window and keep multi-step
orphan/conflict cases in that process. Rust metadata stays its persistent RPC child.

Preserve acquisition.mjs:453–501 ordering: fresh metadata authentication, local
policy, HTTPS, complete snapshot, native consumer, original commitment verification.
Retain public-original withholding on integrity/cleanup failure at lines528–535.

Use exact accepted HTTPS D/new-F mapping with :18443. Old relay F IDs stay distinct;
URL rewriting or historical fixture substitution is not received-byte provenance.
This is source-preparation advice, not composition implementation/experiment release
or acceptance. Further independent source and execution gates remain required.
