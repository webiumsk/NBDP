# Concrete I4 bridge freeze

NON_EXECUTABLE_INTERFACE_FREEZE / NOT_RUNTIME_READY. This freezes source contracts,
not implementation, fixture generation, controls or runtime release. Existing six
planning files remain immutable. Selected I4 grammar is concrete here and in the
three new JSON files; historical planning placeholders are not runtime operands.
LAB-N remains unsupported/NOT_READY. No new Product Owner lab decision is needed.

## Process and authority

Python owns isolated relay lab startup/cleanup, outer case monitor and later
independent checker. It sequentially launches exactly C01-C04 using pinned Node:
`node acquisition.mjs ABS_CASE_FRAME EXTERNAL_FRAME_SHA256`. No arbitrary script,
command or module comes from the frame. Frame/manifest/release/workerData conform
to bridge-schemas; paths are canonical, fresh owned directories and current pins.
External root release is a trusted workflow authorization, not a self-signed JSON
claim or cryptographic attestation. Later actual source/control/config/release
descriptors must exist and match before dependent imports/spawns. Missing authority
refuses; this freeze provides none. Expected replies/original oracle never enter
frame, workerData, loader binding or native requests. Checker data is separate.

One Node case owns protocol WeakMaps, direct wire ChildProcess objects, persistent
native metadata child and HTTPS/browser resources. Python cannot send serialized
handles/auth results. Case environment is the six profile variables plus exactly
`NBDP_CHROME=/opt/google/chrome/chrome`; wire/native children receive only the six
profile variables explicitly. Browser setup retains the accepted profile/closure.
No inherited proxy/credentials or extra environment selects behavior.

## Owned provenance

`runOwnedWire(ctx, slot)` spawns the fixed derivative wire CLI with a newly written
wireBinding and its SHA. Before spawn register a private pending record against
the actual ChildProcess object; launch uncertainty is UNKNOWN. Own its pipes,
capture exact stdin/stdout/stderr and close/reap/EOF events. Require natural0,
empty stderr, one strict wireCLIReply line and current binding/source pins. Read
its reported owned result only through that spawn record, never a caller path.
Revalidate complete report: same case/slot/relay/outer ID, exactly one publication/
query/EVENT, strict ACK/EVENT/EOSE/CLOSE/Close1000 sequence, finite frames/bytes.
Re-run protected `validateEventFrame` on the actual RECEIVE EVENT frame; independently
check span offsets and exact eventSpan bytes. Typed fixture equality alone is not
provenance. Mint a private receive handle only after all joins succeed.

`startNative(ctx)` owns one admitted fixed JS-loader or Rust process and its real
pipes in another WeakMap. For I4, retain it after the one response, with stdin open.
`authenticateReceived(ctx,dHandle,fHandle)` accepts only those private same-case
receivers. Build the unchanged exact nativeRequest from their actual span bytes
and fixed worker scope/secret; retain request before writing. Observe one complete
strict JSONL reply on that owned channel within15s, no extra/pending output or
stderr/exit. Persist complete bytes and nativeCallRecord before minting an auth
handle. A JSON spawn receipt/nativeCallRecord is evidence, never handle authority.

Require the full nativeReply closed shape, exact13 top keys, CORRELATED/
ASSOCIATION/EXACT_D_F_METADATA/ONE_CANONICAL_F, actual D1/F1 counts and matching
native IDs. D rawReply must be CARRIER_RESULT/S5, CHAIN_AND_ENDPOINT_VALIDATED,
kind14, STRUCTURALLY_VALID delivery. Derive message from codec.message. JS F is
rawReply.ok=true then rawReply.value.rumor; Rust F requires outer rawReply.ok=true,
rawReply.value.ok=true then rawReply.value.value.rumor. Require kind15, native
recomputed IDs/author/recipient, expected local/peer/context and exact nine-tag
parent/descriptor/URL equality. Derive the13-field subject from these authenticated
facts, not stored expectations. Retain original full reply unchanged. Type-only
native shape grammar contains no expected scalar reply. External checker alone
deep-compares the full actual reply with the accepted native expected object.

This protects source-local provenance under the admitted same-UID workflow, not
hostile-process attestation or a cryptographic guarantee against local tampering.

## Frozen module contracts

Relay owns `wire.mjs`, `metadata_loader.mjs`, `wire_controls.mjs`. Preserve exports
`typedEqual`, `parseStrict`, `validateEventFrame`, `createProtocolState`; wire CLI
is `node wire.mjs ABS_BINDING SHA`, emits one wireCLIReply. Loader CLI is
`node metadata_loader.mjs ABS_BINDING SHA`, then exactly one nativeRequest/reply
JSONL; no expected-response input. Fixed admitted Rust CLI remains unchanged.

Protocol/controller owns `protocol.mjs`, `runner.py`, `admission.py`, `controls.py`.
Protocol exports these exact private functions, with opaque results never serialized:

- `loadCaseContext(framePath,sha) -> ctx`; reject all but exact I4 cell joins.
- `runOwnedWire(ctx,slot) -> receiveHandle`; `startNative(ctx) -> channelHandle`.
- `authenticateReceived(ctx,dHandle,fHandle) -> authHandle` through that channel.
- `sealWindow(ctx,authHandle) -> generationHandle`; one immutable generation only.
- `reserveAcquisition(ctx,generation) -> attemptHandle`; fsync reservation BEFORE
  transport listener/server/client/connection side effects; UNKNOWN consumes it.
- `getAuthenticated(generation,ctx) -> frozen {subject,metadata,record}`.
- `checkpointEligible(ctx,generation) -> void`; throws before any further work
  if invalid/current closure uncertain. Insert directly before each journal.begin.
- `createSnapshot(generation,receivedBuffer,record,ctx) -> snapshotHandle`;
  `readSnapshot(generation,snapshot,ctx) -> {bytes,descriptor,subject}`.
- `assertCurrent(ctx) -> Promise<void>`; `writeRecord(ctx,name,value) -> descriptor`.
- `publishConsumerFact(ctx,nativeFact) -> Promise<descriptor>` stores PRIVATE only;
  `getConsumerFact(ctx) -> nativeFact|null` preserves existing consumer contract.
- `closeMetadata(ctx) -> terminalReceipt`; close stdin, exact request count,
  natural0/reap/bothEOF/unforced/no timeout/empty stderr, no extra reply.
- `closeoutAndPublish(ctx,generation,privateResult) -> stepDescriptor`; does not
  close children itself. I4 requires prior qualified closeMetadata and all other
  owned cleanup/current integrity, then synchronous final eligible publication.

Acquisition/consumer owns `acquisition.mjs`, `consumer.mjs`; both import the SAME
new protocol instance. Acquisition exports `acquireSnapshot(ctx,generation,attempt)`
and owns the fixed seven-step CLI orchestration. Consumer keeps
`consumeOriginal(generation,snapshot,ctx)` and accepted native/private-fact behavior.
Ctx.id is C01-C04, ctx.route is selected engine; ctx.profile projects profile.https
plus commitments={blobBytes:20,x:byteFacts.blob.sha256,originalBytes:4,ox:byteFacts.ox}.
Ctx.browserProfile is checked input; ctx.blob/tls are pinned lab server inputs,
never consumer snapshot substitutes. New protocol can provide required frozen
consumer view without importing old protocol/private maps.

## Steps, results and completion

I4 runs S01 receiveD, S02 receiveF, S03 authenticate, S04 seal, S05 reserve/acquire,
S06 private verify, S07 closeout/release. Exact23-key shapes, enums/null semantics,
14 counters and seven successful whole predicates are in the JSON freeze. One
window/channel/generation/attempt/snapshot/consumer/release per case; two owned
wire children, one native request. No post-seal input jobs, retry or extra steps.

The channel stays live/quiescent through S06. During S07 first terminal-close it,
then require all relay/HTTPS/browser/native owned cleanup and current evidence/
input/source integrity, then logically release. Release and terminal close are
separate APIs; I4 does not permit live-child public-original release. Future
post-release LAB-N steps need separate profile review, never this frame grammar.

Capture/receipt descriptors always name immutable snapshots; a launch receipt may
not pin an output file later appended in place. Each phase gets a new snapshot;
terminal receipt joins the same owned child. Pin the engine journal only after
finalization. `writeRecord` accepts only fixed per-case names received-D,
received-F, native-call, generation, reservation, acquisition, snapshot,
private-consumer, metadata-terminal and that case's S01-S07; never caller paths.

Actual entity count/x precedes SAME-snapshot native use; consumer journal precedes
native API. Public original stays null through S06; private bytes are restricted
evidence. Unknown counts are null, not planned zeros. Counters have safe-integer
storage bounds, so an actual budget violation remains visible, never clamped.
Any failed step stops target work, records actual boundary and unexecuted suffix,
attempts owned cleanup and emits qualified=false/exit1. Invalid pre-admission
frame emits bounded error/exit2 without dependent work. Success emits one caseCLIReply
line/exit0 after all seven record joins and final integrity. Outer Python reap is
separate evidence; the case cannot attest its own future exit/reap.

Source/cleanup failure after an already persisted release cannot erase that
disclosure: retain S07 and counts, final case unqualified. No fake zero-egress or
retroactive withholding. Receipts=false/businessEffects=0 always. Negative native
target traces are not established by four positive I4 traces or pure controls.

## Assignment boundary

`protected-deltas.json` fixes original half-open byte intervals/hashes and the
allowed derivative bindings; source code remains absent. The exact classifier,
shared crypto/native engine/browser and protected TLS/HTTP/span algorithms stay
unchanged. Independent review of this freeze precedes bounded disjoint source
assignment. Later exact closure/source review, meaningful RC controls, fixtures,
config/admission, primary release and independent QA release remain required.
G1/Q08/Q27 and all existing blockers/E06/SDK gates are unchanged.
