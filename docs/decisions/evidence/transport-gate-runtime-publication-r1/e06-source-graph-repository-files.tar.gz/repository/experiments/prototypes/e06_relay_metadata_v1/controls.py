"""Pure local predicates only; never creates children, sockets, or containers."""
import copy
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent

def fixed(name, filename):
    spec=importlib.util.spec_from_file_location(name,HERE/filename)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

A=fixed('relay_control_admission','admission.py')
R=fixed('relay_control_runner','runner.py')

def run():
    c=A.loads((HERE/'source-contract.json').read_bytes())
    s=A.document(c['selection']);rows=[]
    def check(identity,fn):
        fn();rows.append({'id':identity,'qualified':True,'scope':'PURE_HELPER_ONLY'})
    def refuses(fn):
        try:fn()
        except (A.Refusal,ValueError,KeyError,IndexError):return
        raise AssertionError('Expected refusal')
    def wrong_pin(path):
        d=A.descriptor(path);d['bytes']+=1;A.checked(d)
    check('source-pin',lambda:refuses(lambda:wrong_pin(HERE/'runner.py')))
    check('tool-pin',lambda:refuses(lambda:wrong_pin(c['tools']['node']['path'])))
    check('manifest-sha',lambda:refuses(lambda:A.external_document(HERE/'selection.json','0'*64)))
    check('release-sha',lambda:refuses(lambda:A.external_document(HERE/'source-contract.json','0'*64)))
    def mutated_route():
        bad=copy.deepcopy(s);bad['routes'][0]['relay']='rs-relay';A.validate_selection(bad)
    def mutated_role():
        bad=copy.deepcopy(s);bad['routes'][0]['role']='archive';A.validate_selection(bad)
    def mutated_projection():
        bad=copy.deepcopy(s);bad['routes'][0]['steps'][0]['sourceExpectedArrayIndex']=1;A.validate_selection(bad)
    def mutated_proof():
        bad=copy.deepcopy(s);bad['historicalProofs'][0]['value']['fullChainSuccess']=False;A.validate_selection(bad)
    check('route',lambda:refuses(mutated_route));check('role',lambda:refuses(mutated_role))
    check('projection',lambda:refuses(mutated_projection));check('proof',lambda:refuses(mutated_proof))
    # Distinct formatting is retained from frame, never regenerated from decoded fixture.
    span=b'{ "id" : "a", "content":"\\u00e9" }'
    frame=b'["EVENT","nbdp-S1-F", '+span+b' ]'
    def rawspan():
        actual=R.received_span(frame,'nbdp-S1-F')
        assert actual==span.hex()
        assert actual!=json.dumps(A.loads(span),ensure_ascii=True,separators=(',',':')).encode().hex()
    check('raw-span-substitution',rawspan)
    check('premature-d',lambda:refuses(lambda:R.check_sequence(s['routes'][0],{},'D')))
    check('changed-f',lambda:refuses(lambda:R.require_same_f('11','22')))
    check('missing-response',lambda:refuses(lambda:R.require_reply_count(s['routes'][0],{0:{}})))
    check('extra-response',lambda:refuses(lambda:R.require_reply_count(s['routes'][0],{0:{},1:{},2:{}})))
    # Injected in-memory callbacks exercise constructor non-return without Popen.
    def fresh_counts():
        return {key:0 for key in (*R.NETWORK_COUNTS,'wireChildren','eventJobs','metadataChildren','routeWindows')}
    def before_acquisition_failure():
        counts=fresh_counts();launch=R.new_launch('wire','S1-F','/pure/no-files')
        ledger=[launch];R.latch_wire_counts(counts)
        def no_handle():raise ValueError('in-memory acquisition failure')
        refuses(lambda:R.acquire_process(launch,counts,no_handle))
        assert ledger[0] is launch and launch['launchAttempt'] is True
        assert launch['acquisition']=='UNKNOWN' and launch['pid'] is None
        assert all(counts[k] is None for k in (*R.NETWORK_COUNTS,'wireChildren','eventJobs'))
    def after_acquisition_failure():
        counts=fresh_counts();launch=R.new_launch('wire','S1-F','/pure/no-files')
        ledger=[launch];R.latch_wire_counts(counts)
        class Handle:pid=123
        def constructor_does_not_return():
            R.acquire_process(launch,counts,lambda:Handle())
            raise ValueError('in-memory failure after acquisition')
        refuses(constructor_does_not_return)
        assert ledger[0] is launch and launch['launchAttempt'] is True
        assert launch['acquisition']=='ACQUIRED' and launch['pid']==123
        assert counts['wireChildren']==counts['eventJobs']==1
        assert all(counts[k] is None for k in R.NETWORK_COUNTS)
    fixture={'id':'a'*64,'pubkey':'b'*64,'created_at':1,'kind':1059,
             'tags':[['p','c'*64]],'content':'pure-control','sig':'d'*128}
    job={'id':'S1-F','route':'S1','relay':'strfry','slot':'F','artifactId':'pure',
         'role':'incoming','outerId':fixture['id'],'wire':{'path':'/pure/no-files','bytes':1,'sha256':'0'*64}}
    event_raw=json.dumps(fixture,separators=(',',':')).encode()
    frame_raw=b'["EVENT","nbdp-S1-F",'+event_raw+b']'
    valid={'schema':'e06-relay-metadata-wire-result-v1','job':job,'qualified':True,'error':None,
           'publicationCount':1,'queryCount':1,'eventCount':1,'wireHex':event_raw.hex(),
           'close':{'code':1000,'reason':''},'frames':[{'direction':'RECEIVE','kind':'EVENT','rawHex':frame_raw.hex()}]}
    summary=b'{"qualified":true,"job":"S1-F"}\n'
    def restore_valid():
        counts=fresh_counts();previous=R.latch_wire_counts(counts)
        assert R.restore_wire_counts(counts,previous,valid,job,summary,fixture)==event_raw.hex()
        assert all(counts[k]==1 for k in R.NETWORK_COUNTS)
    def restore_missing():
        counts=fresh_counts();previous=R.latch_wire_counts(counts)
        refuses(lambda:R.restore_wire_counts(counts,previous,None,job,summary,fixture))
        assert all(counts[k] is None for k in R.NETWORK_COUNTS)
    def restore_invalid():
        variants=[]
        negative=copy.deepcopy(valid);negative['qualified']=False;variants.append(negative)
        bad=copy.deepcopy(valid);bad['frames']=[];variants.append(bad)
        bad=copy.deepcopy(valid);bad['job']['id']='OTHER';variants.append(bad)
        bad=copy.deepcopy(valid);bad['publicationCount']=True;variants.append(bad)
        for result in variants:
            counts=fresh_counts();previous=R.latch_wire_counts(counts)
            refuses(lambda:R.restore_wire_counts(counts,previous,result,job,summary,fixture))
            assert all(counts[k] is None for k in R.NETWORK_COUNTS)
    def restore_sticky():
        counts=fresh_counts();counts['publications']=None
        previous=R.latch_wire_counts(counts)
        R.restore_wire_counts(counts,previous,valid,job,summary,fixture)
        assert counts['publications'] is None and counts['queries']==counts['events']==1
    check('launch-before-return-unknown',before_acquisition_failure)
    check('launch-before-return-acquired',after_acquisition_failure)
    check('network-count-restoration',restore_valid)
    check('network-count-missing',restore_missing)
    check('network-count-invalid',restore_invalid)
    check('network-count-sticky',restore_sticky)
    check('positive-selection',lambda:A.validate_selection(s))
    return {'schema':'e06-relay-metadata-parent-pure-controls-v1','component':A.COMPONENT,
            'qualified':True,'scope':'PURE_HELPER_ONLY','subjects':A.current_sources(c),'rows':rows,
            'limits':['No OS fault, process lifecycle, network, relay, metadata or cleanup execution.']}

if __name__=='__main__':
    if len(sys.argv)!=1:raise SystemExit('No arbitrary control arguments')
    print(json.dumps(run(),sort_keys=True,separators=(',',':')))
