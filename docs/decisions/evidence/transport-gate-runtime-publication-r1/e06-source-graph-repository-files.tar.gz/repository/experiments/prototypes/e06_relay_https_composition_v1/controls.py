"""SOURCE ONLY: real pure guard calibrations; never native negative coverage.

The fixed v2 coverage companion separates actual predicate calibrations from
unexecuted native remainders. It is source documentation, never execution authority.
A later approved bootstrap must pin this source/closure before invoking main. No target, context mint, crypto, socket, metadata
engine, relay or browser is called by these pure calibrations.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time
import types
import errno

HERE=Path(__file__).resolve().parent
ADMISSION={'path':str(HERE/'admission.py'),'bytes':26884,
           'sha256':'1242661a310cc4e54f21846dbe19f5fdc556d9ff8c2c057942850fc152c966ab'}
ENV={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
     'WS_NO_BUFFER_UTIL':'1','WS_NO_UTF_8_VALIDATE':'1'}
A=None
SCOPE={'path':str(HERE/'control-scope.json'),'bytes':11456,'sha256':'49e6439be698a29e77c48e4217510cb92a808f3bb622c739495b6c6a4ee4c0b2'}

# Fixed source text, not caller-provided code. Imports only fixed, pre-pinned inert
# helpers. All async protocol calls below receive foreign objects and must refuse
# before an owned context, I/O, spawn, engine or authentication can be reached.
NODE_PURE = r'''
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root='/home/peterhorvath/apps/bitcoin/NBDP',here=root+'/experiments/prototypes/e06_relay_https_composition_v1';
const closurePath=process.argv[1],sha=process.argv[2];
const source=fs.readFileSync(closurePath);assert.equal(crypto.createHash('sha256').update(source).digest('hex'),sha);
const closure=JSON.parse(source),map=new Map();
for(const d of closure){assert(!map.has(d.path));const b=fs.readFileSync(d.path);assert.equal(b.length,d.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),d.sha256);map.set(d.path,d);}
for(const f of ['protocol.mjs','wire.mjs','wire_controls.mjs','bridge-schemas.json','selection-map.json'])assert(map.has(here+'/'+f));
const p=await import(pathToFileURL(here+'/protocol.mjs').href);
const w=await import(pathToFileURL(here+'/wire_controls.mjs').href);
const selection=p.parse(fs.readFileSync(here+'/selection-map.json')),defs=p.parse(fs.readFileSync(here+'/bridge-schemas.json')).definitions;
const rows=[];const check=(id,body)=>{body();rows.push({id,matched:true,scope:'PURE_HELPER_ONLY'});};
const rejection=(fn,code)=>assert.throws(fn,error=>error.code===code);
const asyncRejection=async(fn,code)=>assert.rejects(fn,error=>error.code===code);
const wire=w.runPureControls();assert.equal(wire.qualified,true);assert(wire.rows.length>0);
check('RC03-wire-actual-helper-controls',()=>assert.equal(wire.rows.every(r=>r.qualified&&r.scope==='PURE_HELPER_ONLY'),true));
await asyncRejection(()=>p.authenticateReceived({}, {}, {}),'CASE_CONTEXT');
rejection(()=>p.getAuthenticated({}, {}),'CASE_CONTEXT');rows.push({id:'RC04-forged-capability-refusal',matched:true,scope:'PURE_HELPER_ONLY'});
await asyncRejection(()=>p.sealWindow({}, {}),'CASE_CONTEXT');rows.push({id:'RC05-forged-seal-refusal',matched:true,scope:'PURE_HELPER_ONLY'});
check('RC06-foreign-snapshot-refusal',()=>{rejection(()=>p.readSnapshot({}, {}, {}),'CASE_CONTEXT');rejection(()=>p.checkpointEligible({}, {}),'CASE_CONTEXT');});
check('RC07-attempt-entry-predicate',()=>{
 const good={sameContext:true,sameGeneration:true,sameToken:true,atReservedStep:true,consumed:true,entered:false};assert.equal(p.pureAttemptEntryAllowed(good),true);
 for(const key of Object.keys(good)){const changed={...good,[key]:!good[key]};assert.equal(p.pureAttemptEntryAllowed(changed),false);}
 assert.equal(p.pureAttemptEntryAllowed({...good,extra:true}),false);assert.equal(p.pureAttemptEntryAllowed({...good,consumed:1}),false);
});
check('RC08-unsupported-case-excluded',()=>{rejection(()=>p.validate('N01','@case',defs),'SCHEMA_ENUM');assert.deepEqual(p.pureFailurePolicy(4,{code:'ELIGIBILITY_REFUSED'}),{reason:'ELIGIBILITY_REFUSED',stage:'association',phase:'HELD'});});
check('RC09-consumed-entry-not-renewed',()=>{const v={sameContext:true,sameGeneration:true,sameToken:true,atReservedStep:true,consumed:true,entered:false};assert(p.pureAttemptEntryAllowed(v));v.entered=true;assert.equal(p.pureAttemptEntryAllowed(v),false);assert.equal(p.pureAttemptEntryAllowed(v),false);});
const cell=selection.initialWindows[0],family=selection.families[cell.family],e=cell.metadataExpected;
assert(map.has(e.path));const raw=fs.readFileSync(e.path);assert.equal(raw.length,e.bytes);assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),e.sha256);
const native=p.parse(raw),view={definitions:defs,backend:'JS',scope:family.scope,commitments:{x:family.blob.sha256,ox:'6509423fd9da5c225d2f8619ffae394b40f9f7686fee55a38c54b1424ac65f46'},family:cell.family};
const untrusted=p.untrustedNativeSubjectProjection(native,view);assert.equal(untrusted.dRumorId,family.dRumorId);rejection(()=>p.getAuthenticated(untrusted,{}),'CASE_CONTEXT');
await asyncRejection(()=>p.closeoutAndPublish({}, {}, {}),'CASE_CONTEXT');rows.push({id:'RC11-forged-release-refusal',matched:true,scope:'PURE_HELPER_ONLY'});
check('RC12-core-r2-failure-and-pin-regressions',()=>{
 // Read actual historical captures ONLY through the independently pinned
 // acceptance and its exact nested descriptors. Predicate calibration only:
 // no verifier replay, native authentication, process or cleanup claim.
 const acceptancePin={path:root+'/docs/decisions/evidence/invoice-authenticated-carrier/relay-close-v1-completion-and-next-action.json',bytes:13241,sha256:'33bf874c9c5080bcec762a83fec5002930bce1eab7b7d7a1a37e260a36fbf58e'};
 assert.deepEqual(map.get(acceptancePin.path),acceptancePin);
 const pinnedHistorical=d=>{assert.deepEqual(Object.keys(d).sort(),['bytes','path','sha256']);assert.equal(fs.realpathSync(d.path),d.path);assert(fs.lstatSync(d.path).isFile());assert(!fs.lstatSync(d.path).isSymbolicLink());const raw=fs.readFileSync(d.path);assert.equal(raw.length,d.bytes);assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),d.sha256);return p.parse(raw,33554432,true);};
 const acceptance=pinnedHistorical(acceptancePin);
 for(const label of ['primary','qa']){
  const cap=pinnedHistorical(acceptance.runs[label].capture),original=JSON.stringify(cap);
  assert.equal(p.historicalFull40CaptureReady(cap,label),true);
  const changes={qualified:false,executedRows:39,failures:1,noticeCalls:5,notExecutedRows:1,label:'foreign',scope:'FOREIGN_SCOPE'};
  for(const [key,value]of Object.entries(changes)){
   const missing=structuredClone(cap);delete missing[key];assert.equal(p.historicalFull40CaptureReady(missing,label),false);
   const changed=structuredClone(cap);changed[key]=value;assert.equal(p.historicalFull40CaptureReady(changed,label),false);
  }
  for(const key of ['error','integrity_error'])for(const value of [null,false,0,'',undefined,{name:'InjectedError'}]){
   const changed=structuredClone(cap);changed[key]=value;assert(Object.hasOwn(changed,key));assert.equal(p.historicalFull40CaptureReady(changed,label),false);
  }
  assert.equal(JSON.stringify(cap),original);
 }
 // Real opaque tool pin uses the SAME standalone streaming inventory class,
 // not a private invocation inventory/capability. No Docker/tool is executed.
 const opaque=map.get('/usr/bin/docker');assert(opaque&&opaque.bytes>33554432);
 assert.deepEqual(p.descriptor(opaque.path),opaque);
 const streamed=new p.VerifiedEvidenceInventory();streamed.remember(opaque);streamed.recheck();
 const wrong={...opaque,sha256:opaque.sha256==='0'.repeat(64)?'1'.repeat(64):'0'.repeat(64)};
 rejection(()=>streamed.remember(wrong),'EVIDENCE_CONFLICTING_PIN');
 const bad=new p.VerifiedEvidenceInventory();bad.remember(wrong);rejection(()=>bad.recheck(),'EVIDENCE_SOURCE_OR_INPUT_DRIFT');
 rejection(()=>p.checked(wrong),'PIN_MISMATCH');
 rejection(()=>p.checked(opaque),'DATA_READ_BOUND'); // raw cap stays32MiB AFTER streamed hash verification.
 const driftPath=process.cwd()+'/rc12-streamed-evidence-drift.bin';let created=false;
 try{
  fs.writeFileSync(driftPath,Buffer.from('before'),{flag:'wx',mode:0o600});created=true;
  const originalPin=p.descriptor(driftPath),inventory=new p.VerifiedEvidenceInventory();inventory.remember(originalPin);inventory.recheck();
  assert.equal(p.checked(originalPin).toString(),'before');
  fs.writeFileSync(driftPath,Buffer.from('after!'),{flag:'r+'});rejection(()=>inventory.recheck(),'EVIDENCE_SOURCE_OR_INPUT_DRIFT');
  rejection(()=>p.checked(originalPin),'PIN_MISMATCH');
  fs.unlinkSync(driftPath);created=false;rejection(()=>p.checked(originalPin),'ENOENT');rejection(()=>inventory.recheck(),'ENOENT');
 }finally{if(created)fs.unlinkSync(driftPath);}
 const pin={path:'/synthetic/authority',bytes:1,sha256:'a'.repeat(64)};assert(p.pureEvidencePinCompatible(pin,{...pin}));
 assert.equal(p.pureEvidencePinCompatible(pin,{...pin,sha256:'b'.repeat(64)}),false);assert.equal(p.pureEvidencePinCompatible(pin,{...pin,bytes:2}),false);
 const cases=[['SERVER_STARTUP_TIMEOUT','server'],['LOCAL_ACQUISITION_DISABLED','policy'],['TLS_CERTIFICATE_REFUSED','tls'],['HEADERS_TIMEOUT','headers'],['TRANSFER_INTERRUPTED','body'],['SNAPSHOT_HASH','snapshot']];
 for(const [code,stage]of cases){const error={name:'SyntheticRefusal',code,message:'preserve primary',stack:'synthetic stack'};const original=structuredClone(error);assert.deepEqual(p.pureFailurePolicy(5,error),{reason:'RAW_METADATA_OR_TRANSPORT_FAILURE',stage,phase:'UNQUALIFIED'});assert.deepEqual(error,original);}
 assert.deepEqual(p.pureFailurePolicy(6,{code:'EPIPE'}),{reason:'OWNED_LIFECYCLE_OR_CAPTURE_UNQUALIFIED',stage:'lifecycle',phase:'UNQUALIFIED'});
 assert.deepEqual(p.pureFailurePolicy(7,{code:'OWNED_CLEANUP_UNQUALIFIED'}),{reason:'OWNED_CLEANUP_UNQUALIFIED',stage:'cleanup',phase:'UNQUALIFIED'});
 assert.deepEqual(p.pureFailurePolicy(4,{code:'EVIDENCE_SOURCE_OR_INPUT_DRIFT'}),{reason:'SOURCE_OR_INPUT_DRIFT',stage:'integrity',phase:'UNQUALIFIED'});
 assert.deepEqual(p.pureFailurePolicy(3,{code:'NATIVE_REPLY_DEADLINE'}),{reason:'DEADLINE_OR_BUDGET',stage:'budget',phase:'UNQUALIFIED'});
});
check('RC14-native-object-projection-refusals',()=>{
 const mutation=(change,code)=>{const v=structuredClone(native);change(v);rejection(()=>p.untrustedNativeSubjectProjection(v,view),code);};
 mutation(v=>v.status='REFUSED','CORRELATED_EXACT_ONE');
 mutation(v=>v.validation.D.rawReply.transportVerification='UNVERIFIED','FULL_D_AUTHENTICATION');
 mutation(v=>v.validation.D.rawReply.rumor.pubkey='0'.repeat(64),'AUTHENTICATED_NATIVE_IDS');
 rejection(()=>p.untrustedNativeSubjectProjection(native,{...view,scope:{...view.scope,expectedLocal:'0'.repeat(64)}}),'AUTHENTICATED_NATIVE_IDS');
 mutation(v=>v.validation.F.rawReply.value.rumor.tags[1][1]='0'.repeat(64),'AUTHENTICATED_NATIVE_IDS');
});
// No actual metadata API, producer, signature/decryption, networking or valid context.
fs.writeSync(1,Buffer.from(JSON.stringify({schema:'i4-node-predicate-calibrations-v1',rows,wireRows:wire.rows,authority:false})+'\n'));
'''


def import_pinned(name,path,pins):
    d=pins.get(str(path));raw=path.read_bytes()
    if not d or d['bytes']!=len(raw) or d['sha256']!=hashlib.sha256(raw).hexdigest() or path.resolve(strict=True)!=path or path.is_symlink():raise ValueError('PREIMPORT_SOURCE_PIN')
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def put(p,value):
    raw=value if type(value) is bytes else (json.dumps(value,separators=(',',':'))+'\n').encode()
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(raw);f.flush();os.fsync(fd)
    finally:os.close(fd)
    return A.descriptor(p)


def refuse(callback,code):
    try:callback()
    except (A.Refusal,ValueError,UnicodeError) as exc:
        if str(exc)!=code:raise AssertionError('WRONG_REFUSAL:'+str(exc)) from exc
        return
    raise AssertionError('EXPECTED_REFUSAL:'+code)


def python_calibrations(out,ds,defs):
    rows=[]
    def row(ident,body):body();rows.append({'id':ident,'matched':True,'scope':'PURE_PREDICATE_NO_TARGET'})
    fixture=out/'pin-fixture.bin';d=put(fixture,b'original synthetic authority')
    def pins():
        changed=dict(d,sha256='0'*64);refuse(lambda:A.checked(changed),'PIN_MISMATCH:'+d['path'])
        inventory=A._VerifiedEvidenceInventory();inventory.remember(d)
        refuse(lambda:inventory.remember(changed),'EVIDENCE_CONFLICTING_PIN')
        fixture.write_bytes(b'changed synthetic authority')
        refuse(inventory.recheck,'EVIDENCE_SOURCE_OR_INPUT_DRIFT')
    row('RC01-current-original-pin-refusal',pins)
    def authority():
        refuse(lambda:A.validate('LAB-N',{'enum':['LAB-I4']},defs),'SCHEMA_ENUM')
        refuse(lambda:A.validate({'schema':'i4-root-exact-release-v1'},'@release',defs),'CLOSED_KEYS')
        author='/root/e06_i4_relay_implementer';review={'role':'qa','session':author,'decision':'ACCEPT_SOURCE_ONLY','subject':d}
        pack={'reviews':[review,dict(review,role='security',session='/root/independent_security')],'authors':[author]}
        refuse(lambda:A.reviews(pack,'ACCEPT_SOURCE_ONLY',ds,[author],defs),'AUTHOR_OR_SCOPE')
    row('RC02-release-and-self-review-refusal',authority)
    def scope():
        selection=A.document(A.DATA['selection-map.json']);bad=copy.deepcopy(selection['families']['invoice']['scope']);bad['enabled']=False
        refuse(lambda:A.validate(bad,'@scope',defs),'SCHEMA_ENUM')
    row('RC05-disabled-scope-refusal',scope)
    def unsupported_cases():
        refuse(lambda:A.validate('N01','@case',defs),'SCHEMA_ENUM')
        frame={'schema':'i4-case-private-frame-v1','lane':'LAB-I4','caseId':'C01','windowId':'W-C01','manifest':d,'release':d,'workerData':d,'output':str(out)}
        A.validate(frame,'@frame',defs);frame['caseId']='N01';refuse(lambda:A.validate(frame,'@frame',defs),'SCHEMA_ENUM')
    row('RC08-lab-n-case-frame-exclusion',unsupported_cases)
    def fresh_wrap_exclusion():
        selection=A.document(A.DATA['selection-map.json']);cell=selection['initialWindows'][0];wire=cell['jobs'][1]['wire']
        binding={'schema':'i4-wire-binding-v1','caseId':'C01','slot':'F','relay':'strfry','outerId':'a'*64,'wire':wire,'closure':ds,'output':str(out)}
        A.validate(binding,'@wireBinding',defs);binding['freshWrap']=True
        refuse(lambda:A.validate(binding,'@wireBinding',defs),'CLOSED_KEYS')
    row('RC09-extra-fresh-wrap-field-exclusion',fresh_wrap_exclusion)
    def old_origin_scope():
        selection=A.document(A.DATA['selection-map.json']);bad=copy.deepcopy(selection['families']['invoice']['scope']);bad['allowedOrigin']='https://files.invalid'
        refuse(lambda:A.validate(bad,'@scope',defs),'SCHEMA_ENUM')
    row('RC10-old-origin-scope-exclusion',old_origin_scope)
    def lifecycle():
        nested=out/'nested-authority.bin';original=put(nested,b'original nested authority')
        inventory=A._VerifiedEvidenceInventory();inventory.remember(original);nested.write_bytes(b'changed nested authority')
        refuse(inventory.recheck,'EVIDENCE_SOURCE_OR_INPUT_DRIFT')
        natural={'launchAttempt':True,'acquisition':'ACQUIRED','pid':1,'exitCode':0,'signal':None,'reaped':True,'stdoutEOF':True,'stderrEOF':True,
                 'timedOut':False,'forced':False,'error':None};A.natural(natural)
        for key,value in [('acquisition','UNKNOWN'),('pid',None),('exitCode',None),('reaped',False),('stdoutEOF',False),('stderrEOF',False),('timedOut',True),('forced',True),('error',{})]:
            bad=dict(natural);bad[key]=value;refuse(lambda:A.natural(bad),'NATURAL_OWNED_CHILD')
        for raw,code in [(b'{"x":1,"\\u0078":2}','DUPLICATE_KEY'),(b'{"x":9007199254740992}','SAFE_INTEGER'),(b'{"x":-0}','NEGATIVE_ZERO'),(b'{"x":1.0}','INTEGER_TOKEN_ONLY')]:refuse(lambda:A.loads(raw),code)
    row('RC12-lifecycle-and-raw-parser-refusals',lifecycle)
    def ownership():
        wrong=out/'foreign-mode';wrong.mkdir(mode=0o700);wrong.chmod(0o755)
        refuse(lambda:A.private_dir(wrong),'OWNED_0700_DIRECTORY')
        link=out/'aliased-file';link.symlink_to(fixture)
        refuse(lambda:A.descriptor(link),'CANONICAL_FILE')
        link.unlink()
    row('RC13-owned-filesystem-refusals',ownership)
    return rows


def supervisor_calibrations(runner,out):
    """Actual shared supervisor/policy with inert syscalls, never an acquired OS PID.

    These probes test branching, retention and bounded attempts. The fabricated
    API objects are not process provenance and never enter target evidence.
    """
    def need(value,message):
        if not value:raise AssertionError(message)
    clock=[0];calls=[]
    def tick():clock[0]+=1000000000;return clock[0]
    def exited(pid):return types.SimpleNamespace(si_pid=pid,si_code=os.CLD_EXITED,si_status=0)
    def descriptor(p,raw):return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    io={'waitid':lambda kind,pid,flags:exited(pid),'killpg':lambda pid,sig:calls.append(('signal',pid,sig)),
        'clockNs':tick,'writeBytes':descriptor,'writeJSON':lambda p,v:descriptor(p,json.dumps(v).encode()),'stderr':lambda b:calls.append(('stderr',b))}
    def instance(custom=None):
        supplied=dict(io);supplied.update(custom or {})
        obj=runner.OwnedCase([],out,ENV,999,lambda:None,io=supplied)
        obj.process=types.SimpleNamespace(pid=12345,returncode=None,stdin=None,stdout=None,stderr=None)
        obj.ownership='HELD';obj.life.update(launchAttempt=True,acquisition='ACQUIRED',pid=12345)
        return obj
    def denied(callback):
        try:callback()
        except (ValueError,OSError,KeyboardInterrupt):return
        raise AssertionError('INERT_OWNERSHIP_REFUSAL_REQUIRED')
    for state in ('NOT_ACQUIRED','REAPING','REAPED','UNKNOWN'):
        need(not runner.pure_group_signal_allowed(state,'RUNNING',None),'POST_REAP_POLICY')
    need(runner.pure_group_signal_allowed('HELD','EXITED',None),'RETAINED_ZOMBIE_GROUP_POLICY')
    need(not runner.pure_group_signal_allowed('HELD','RUNNING',0),'RETURN_CODE_OWNERSHIP_ENDED')
    stale=instance();stale.ownership='REAPED';stale.life['reaped']=False
    denied(lambda:stale.signal_owned_group(15));need(not calls,'STALE_LEDGER_CANNOT_SIGNAL')
    def echild(*args):raise ChildProcessError(errno.ECHILD,'inert ownership already lost')
    lost=instance({'waitid':echild});denied(lost.observe_owned);need(lost.ownership=='UNKNOWN','ECHILD_MUST_BE_UNKNOWN')
    denied(lambda:lost.signal_owned_group(9));need(not calls,'ECHILD_CANNOT_SIGNAL')
    def interrupted(kind,pid,flags):
        if flags&os.WNOWAIT:return exited(pid)
        raise KeyboardInterrupt('inert interruption after consuming syscall entry')
    ambiguous=instance({'waitid':interrupted});denied(ambiguous.reap_exited)
    need(ambiguous.ownership=='UNKNOWN' and not ambiguous.life['reaped'],'AMBIGUOUS_REAP_UNKNOWN')
    denied(lambda:ambiguous.signal_owned_group(9));need(not calls,'AMBIGUOUS_REAP_CANNOT_SIGNAL')
    # Signal/close/storage faults are distinct; all subsequent cleanup and raw
    # writes are attempted, with the original primary left byte-for-byte intact.
    attempts=[]
    class Pipe:
        closed=False
        def __init__(self,name,fail=False):self.name=name;self.fail=fail
        def close(self):
            attempts.append(('close',self.name))
            if self.fail:raise OSError('inert first pipe close failure')
            self.closed=True
    def fail_signal(pid,sig):attempts.append(('signal',sig));raise PermissionError('inert signal denied')
    def write_stream(p,raw):
        attempts.append(('raw',p.name))
        if p.name=='stdin.bin':raise OSError('inert stdin evidence storage failure')
        return descriptor(p,raw)
    def fail_receipt(p,value):attempts.append(('receipt',p.name));raise OSError('inert receipt storage failure')
    broken=instance({'killpg':fail_signal,'writeBytes':write_stream,'writeJSON':fail_receipt})
    broken.process.stdin=Pipe('stdin',True);broken.process.stdout=Pipe('stdout');broken.process.stderr=Pipe('stderr')
    broken.primary_error(ValueError('original inert primary'))
    primary=copy.deepcopy(broken.life['error']);broken.cleanup();broken.capture()
    need(broken.life['error']==primary and broken.primary==primary,'PRIMARY_CHANGED_BY_CLEANUP')
    need(all(('close',n) in attempts for n in ('stdin','stdout','stderr')),'COLLECT_ALL_CLOSES')
    need(all(('raw',n+'.bin') in attempts for n in ('stdin','stdout','stderr')),'COLLECT_ALL_RAW_WRITES')
    need(('receipt','receipt.json') in attempts and broken.receipt is None and not broken.capture_complete,'STORAGE_FAILURE_UNQUALIFIED')
    need(broken.secondary and any(owner['owner']=='capture:receipt' for owner in broken.secondary),'SEPARATE_RECEIPT_FAILURE')
    # Use the real policy called by watch_phases. Completion cannot rebase or
    # clear an expired interval; the optional pure-Node monitor has no anchors.
    base={'acquisition':{'startedNs':None,'completedNs':None},'consumer':{'startedNs':None,'completedNs':None}}
    need(runner.pure_phase_timeout(1,1000,base) is None,'GENERIC_NO_PHASE_PROFILE')
    need(runner.pure_phase_timeout(1000,1000,base)=='CASE_OUTER_DEADLINE','WHOLE_WINDOW_BOUND')
    acquire=copy.deepcopy(base);acquire['acquisition']['startedNs']=100
    need(runner.pure_phase_timeout(149000000100,999999999999,acquire) is None,'ACQUISITION_WITHIN_BOUND')
    need(runner.pure_phase_timeout(150000000100,999999999999,acquire)=='CASE_ACQUISITION_DEADLINE','ACQUISITION_150_BOUND')
    acquire['acquisition']['completedNs']=150000000101
    need(runner.pure_phase_timeout(150000000102,999999999999,acquire)=='CASE_ACQUISITION_DEADLINE','LATE_COMPLETION_CANNOT_CLEAR_BOUND')
    consume=copy.deepcopy(base);consume['consumer']['startedNs']=500
    need(runner.pure_phase_timeout(119000000500,999999999999,consume) is None,'CONSUMER_WITHIN_BOUND')
    need(runner.pure_phase_timeout(120000000500,999999999999,consume)=='CASE_CONSUMER_DEADLINE','CONSUMER_120_BOUND')
    consume['consumer']['completedNs']=120000000501
    need(runner.pure_phase_timeout(120000000502,999999999999,consume)=='CASE_CONSUMER_DEADLINE','CONSUMER_NOT_REBASED')
    return {'id':'RC12-owned-supervisor-and-phase-policies','matched':True,'scope':'PURE_PREDICATE_NO_TARGET'}


def main(argv):
    global A
    if len(argv)!=4:raise ValueError('CLI controls.py SOURCE_CLOSURE SHA OWNED_CONTROL_DIRECTORY')
    source=Path(argv[1]);
    if source.stat().st_size>1048576:raise ValueError('CONTROL_SUBJECT_BOUND')
    raw=source.read_bytes()
    if not re.fullmatch('[0-9a-f]{64}',argv[2]) or hashlib.sha256(raw).hexdigest()!=argv[2] or len(raw)>1048576:raise ValueError('EXTERNAL_CONTROL_SUBJECT')
    if dict(os.environ)!=ENV:raise ValueError('EXACT_CONTROL_ENVIRONMENT')
    # JSON duplicate/type checks are repeated by the fixed admission after its own trusted pin.
    pre=json.loads(raw);pins={d['path']:d for d in pre};admission_raw=Path(ADMISSION['path']).read_bytes()
    if len(admission_raw)!=ADMISSION['bytes'] or hashlib.sha256(admission_raw).hexdigest()!=ADMISSION['sha256']:raise ValueError('FIXED_CONTROL_ADMISSION_PIN')
    if pins.get(ADMISSION['path'])!=ADMISSION:raise ValueError('CONTROL_ADMISSION_CLOSURE')
    A=import_pinned('_i4_controls_fixed_admission',Path(ADMISSION['path']),pins)
    ds=A.loads(raw);mapping=A.closure(ds);A.member(mapping,A.descriptor(HERE/'controls.py'));A.member(mapping,A.PYTHON);A.member(mapping,A.NODE)
    A.need(A.equal(A.descriptor(sys.executable),A.PYTHON),'CONTROL_FIXED_PYTHON')
    for d in A.DATA.values():A.member(mapping,d);A.checked(d)
    A.member(mapping,SCOPE);A.checked(SCOPE)
    out=Path(argv[3]);A.need(re.fullmatch('/tmp/e6i4-controls-[a-z0-9]{6,12}',str(out)),'CONTROL_OUTPUT_NAMESPACE');A.private_dir(out)
    A.need(source==out/'source-closure.json','FIXED_CONTROL_SOURCE_SUBJECT_PATH')
    defs=A.document(A.DATA['bridge-schemas.json'])['definitions'];rows=python_calibrations(out,ds,defs)
    runner=import_pinned('_i4_controls_owned_process_helper',HERE/'runner.py',mapping)
    runner.A=A  # The already pinned pure guard module; no runner/bootstrap/target entry is called.
    rows.append(supervisor_calibrations(runner,out))
    child_dir=out/'node-predicates';child_dir.mkdir(mode=0o700)
    def current():
        A.closure(ds);A.need(hashlib.sha256(source.read_bytes()).hexdigest()==argv[2],'CONTROL_SOURCE_CHANGED')
    current();command=[A.NODE['path'],'--input-type=module','--eval',NODE_PURE,str(source),argv[2]]
    child=runner.OwnedCase(command,child_dir,ENV,time.monotonic()+30,current);actual=child.run();A.natural(child.life)
    A.need(child.total['stderr']==0,'PURE_NODE_STDERR');native=runner.one_line(actual)
    A.closed(native,('schema','rows','wireRows','authority'));A.need(native['schema']=='i4-node-predicate-calibrations-v1' and native['authority'] is False,'PURE_NODE_CAPTURE')
    rows.extend(native['rows']);current()
    # Every fixed check aggregates its actual listed Python/Node guard probes.
    # A calibration never supplies a native result or waives its broader obligation.
    A.member(mapping,SCOPE);scope=A.document(SCOPE)
    A.need(scope['schema']=='i4-fixed-control-scope-v1' and scope['executionReleased'] is False and scope['normativeAdoption'] is False,'FIXED_CONTROL_SCOPE')
    expected_python={'RC01-current-original-pin-refusal','RC02-release-and-self-review-refusal','RC05-disabled-scope-refusal',
                     'RC08-lab-n-case-frame-exclusion','RC09-extra-fresh-wrap-field-exclusion','RC10-old-origin-scope-exclusion',
                     'RC12-lifecycle-and-raw-parser-refusals','RC12-owned-supervisor-and-phase-policies','RC13-owned-filesystem-refusals'}
    expected_node={'RC03-wire-actual-helper-controls','RC04-forged-capability-refusal','RC05-forged-seal-refusal','RC06-foreign-snapshot-refusal',
                   'RC07-attempt-entry-predicate','RC08-unsupported-case-excluded','RC09-consumed-entry-not-renewed','RC11-forged-release-refusal',
                   'RC12-core-r2-failure-and-pin-regressions','RC14-native-object-projection-refusals'}
    python_ids={r['id'] for r in rows if r['scope']=='PURE_PREDICATE_NO_TARGET'}
    node_ids={r['id'] for r in native['rows']}
    A.need(python_ids==expected_python and node_ids==expected_node and len(native['rows'])==len(expected_node)
           and all(r['matched'] is True for r in rows),'EXACT_ACTUAL_CALIBRATION_SET')
    fixed_rows=[]
    A.need([r['id'] for r in scope['rows']]==[f'RC{i:02d}' for i in range(1,15)],'FOURTEEN_FIXED_SCOPE_ROWS')
    for row in scope['rows']:
        checks=[c['id'] for c in row['calibration']['checks']]
        A.need(checks==[row['id']+'-P01'] and row['calibration']['kind']=='SOURCE_PREDICATE_ONLY'
               and row['native']['status'] in ('NOT_EXECUTED','NOT_READY') and row['native']['result'] is None,'FIXED_UNEXECUTED_NATIVE_REMAINDER')
        fixed_rows.append({'id':row['id'],'calibration':{'kind':'SOURCE_PREDICATE_ONLY','checks':checks,'matched':True},
                           'native':{'status':row['native']['status'],'result':None}})
    diagnostics={'schema':'i4-control-calibration-detail-v2','sourceClosure':ds,'controlScope':SCOPE,
                 'calibrations':rows,'nativeInvocation':child.receipt,'nativeCoverage':'NOT_EXECUTED_NOT_READY',
                 'authority':False,'limits':scope['limits']}
    put(out/'calibration-diagnostics.json',diagnostics);current()
    capture={'schema':'i4-control-native-capture-v2','sourceClosure':ds,'controlScope':SCOPE,'rows':fixed_rows,'finalIntegrity':True}
    raw=(json.dumps(capture,separators=(',',':'))+'\n').encode();A.need(len(raw)<=16777216,'CONTROL_CAPTURE_BOUND')
    A.need(os.write(1,raw)==len(raw),'CONTROL_COMPLETE_STDOUT')


if __name__=='__main__':
    try:main(sys.argv)
    except BaseException as exc:sys.stderr.write(type(exc).__name__+': '+str(exc)[:16384]+'\n');raise SystemExit(1)
