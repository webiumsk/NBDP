"""SOURCE ONLY. Pure fixed-I4 admission; importing this file launches no work.

verify(MANIFEST, SHA, RELEASE, SHA, execution_session, run_role) is the sole
admission entry. External SHA/session arguments originate in reviewed workflow,
not from a JSON self-assertion. This module never runs a target/control/experiment.
"""
import hashlib
import contextvars
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = {'BRIDGE.md': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/BRIDGE.md', 'bytes': 10113, 'sha256': '03df5e47ba6a1acf9d47444b61999c6d854005dce92852dc72d2d984e939eac6'}, 'bridge-schemas.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/bridge-schemas.json', 'bytes': 25275, 'sha256': '927c4536b32efaba37908a31f7e428a84fe333994ce84052610806322aaeb8c1'}, 'i4-oracle-rules.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/i4-oracle-rules.json', 'bytes': 9017, 'sha256': '1b410aae0f1d8457c18dfeaf2a2f05b01d956ee28ad82c548f1d16bacbd4a0d3'}, 'protected-deltas.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/protected-deltas.json', 'bytes': 7387, 'sha256': 'c299b3b4078dd0c75a428d34c82ae92ca69903be67c98f0db563d9cb99adb2e9'}, 'contract.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/contract.json', 'bytes': 21113, 'sha256': 'c15e87802d199e049eb535b130b0db420cc869982deeb51911239ab803924bc3'}, 'profile.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/profile.json', 'bytes': 5749, 'sha256': '0b1f2ef54e2dc89c3555c30b48b815d999b84958877a5603d9cd27a52533346c'}, 'selection-map.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/selection-map.json', 'bytes': 35919, 'sha256': 'f523aee4be1e4b5fa5adc51723c414f859465517bf99f79f0e91d1e13a26c1d2'}, 'oracles.json': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/oracles.json', 'bytes': 94166, 'sha256': 'c8c2830334342c771e959d94fc3b8e6e2d91d8139679a85c63819ce92df618e0'}, 'interfaces.md': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/interfaces.md', 'bytes': 13134, 'sha256': 'a4025f32f0f1c42280edc83a7efbcd0ed82f6592ffc95203ced07d204f2fcff9'}, 'SOURCE.md': {'path': '/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/SOURCE.md', 'bytes': 9366, 'sha256': 'fc2c8a6fecf374094c970088213765873f1f511804d812f86f8fb3266ffcaab5'}}
CONTROL_SCOPE = dict(path=str(HERE/'control-scope.json'),bytes=11456,
                     sha256='49e6439be698a29e77c48e4217510cb92a808f3bb622c739495b6c6a4ee4c0b2')
NODE = dict(path='/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node', bytes=121613584,
            sha256='ccacb2d6d87ba6d118b2bffc1ae33747a05cc5fc6b1f1ec4fc1d420b687e952d')
PYTHON = dict(path='/home/peterhorvath/.miniforge3/bin/python3.13',bytes=32959480,
              sha256='5e2f62ca6ab9c6992460493de8a8867e84f8e6078f0e5c197b5232b79e4b35f1')
RUST = dict(path='/tmp/nbdp-e06-build-tv5zqp4j/target/debug/nbdp-experiment-rust', bytes=26400472,
            sha256='55205961550c66467be356b13adeafaf43599ca6f59f2db5ebf1de9293c3045d')
POLICY = dict(path=str(ROOT/'docs/decisions/transport-sub-evidence-prerequisite-v1.md'), bytes=3073,
              sha256='0ed885e41d3cbb2d38af33cdd060e5ad5bea3327d0ce2a4306c123c170a15a25')
CURRENT_E01 = dict(path=str(ROOT/'docs/decisions/evidence/invoice-authenticated-carrier/e01-completion-and-next-action.json'),bytes=14812,
                   sha256='52619ef1137a78937f0ab079655e05ac11c7b07d45f5bade6439eed72c7899c5')
TRANSPORT_GATE = dict(path=str(ROOT/'experiments/prototypes/e04_prerequisite_gate_v1/prerequisite_gate.py'), bytes=30015,
                      sha256='fe23d255352863ca2872028116dbac506e85b766d3455972ff775da3773c6f9f')
TRANSPORT_RELEASE = dict(path=str(ROOT/'docs/decisions/evidence/invoice-authenticated-carrier/e04-gate-qualification-r2/runtime-release.json'), bytes=3560,
                         sha256='4dc61f0dc054a5f70a9d42578cd19ad711cf30a21dd14d83884f7be560ced04c')
EXCLUDED = ['/root', '/root/recovery_fixture_parent', '/root/e06_i4_relay_implementer',
            '/root/archive_context_architect', '/root/https_acquisition_implementer',
            '/root/https_consumer_implementer']
FUTURE_SOURCE_NAMES = ['protocol.mjs','admission.py','acquisition.mjs','consumer.mjs',
                       'wire.mjs','metadata_loader.mjs','wire_controls.mjs','runner.py','controls.py']

class Refusal(ValueError):
    pass

def need(value, code):
    if not value:
        raise Refusal(code)

def closed(value, keys):
    need(type(value) is dict and set(value) == set(keys), 'CLOSED_KEYS')
    return value

def equal(a,b):
    if type(a) is not type(b): return False
    if type(a) is dict: return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
    if type(a) is list: return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b

def pairs(rows):
    result={}
    for k,v in rows:
        need(k not in result,'DUPLICATE_KEY');result[k]=v
    return result

def loads(raw, historical=False):
    need(type(raw) is bytes and len(raw)<=33554432,'JSON_BOUND')
    def number(t):
        need(t!='-0','NEGATIVE_ZERO')
        n=int(t);need(abs(n)<=9007199254740991,'SAFE_INTEGER');return n
    def fraction(t):
        need(historical,'INTEGER_TOKEN_ONLY');n=float(t)
        need(math.isfinite(n) and (not n.is_integer() or abs(n)<=9007199254740991),'FINITE_HISTORICAL_TIMING')
        return n
    value=json.loads(raw.decode('utf-8','strict'),object_pairs_hook=pairs,parse_int=number,
                     parse_float=fraction,parse_constant=lambda _:need(False,'NONFINITE'))
    todo=[(value,0)];nodes=0
    while todo:
        v,depth=todo.pop();nodes+=1;need(depth<=64 and nodes<=100000,'JSON_STRUCTURE')
        if type(v) is str:need(not any(0xd800<=ord(c)<=0xdfff for c in v),'UNICODE_SCALAR')
        elif type(v) is dict:todo.extend((x,depth+1) for x in [*v,*v.values()])
        elif type(v) is list:todo.extend((x,depth+1) for x in v)
    return value

def descriptor(p):
    p=Path(p);need(p.is_absolute() and str(p.resolve(strict=True))==str(p) and p.is_file() and not p.is_symlink(),'CANONICAL_FILE')
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        while block:=f.read(1048576):size+=len(block);h.update(block)
    return dict(path=str(p),bytes=size,sha256=h.hexdigest())


# Per-verify direct verified referents, independent of sourceClosure/self-reference.
# Finite2048 unique canonical files,512MiB/file,4GiB declared aggregate. Rechecks
# stream; checked JSON reads remain bounded32MiB. No historical graph expansion.
EVIDENCE_MAX_FILES = 2048
EVIDENCE_MAX_FILE_BYTES = 536870912
EVIDENCE_MAX_BYTES = 4294967296
_admission_evidence = contextvars.ContextVar('i4_admission_evidence',default=None)

class _VerifiedEvidenceInventory:
    def __init__(self):self._pins={};self._bytes=0
    def remember(self,d):
        closed(d,('path','bytes','sha256'));p=Path(d['path'])
        need(p.is_absolute() and str(p.resolve(strict=True))==str(p),'EVIDENCE_CANONICAL_PATH')
        need(type(d['bytes']) is int and 0<=d['bytes']<=EVIDENCE_MAX_FILE_BYTES
             and type(d['sha256']) is str and re.fullmatch('[0-9a-f]{64}',d['sha256']),'EVIDENCE_DESCRIPTOR_BOUND')
        previous=self._pins.get(d['path'])
        if previous is not None:need(previous==(d['path'],d['bytes'],d['sha256']),'EVIDENCE_CONFLICTING_PIN');return
        need(len(self._pins)<EVIDENCE_MAX_FILES and self._bytes+d['bytes']<=EVIDENCE_MAX_BYTES,'EVIDENCE_INVENTORY_BOUND')
        self._pins[d['path']]=(d['path'],d['bytes'],d['sha256']);self._bytes+=d['bytes']
    def recheck(self):
        for name,size,sha in self._pins.values():
            expected=dict(path=name,bytes=size,sha256=sha)
            need(equal(descriptor(name),expected),'EVIDENCE_SOURCE_OR_INPUT_DRIFT')

def checked(d):
    closed(d,('path','bytes','sha256'))
    need(type(d['bytes']) is int and d['bytes']>=0 and type(d['sha256']) is str and re.fullmatch('[0-9a-f]{64}',d['sha256']),'DESCRIPTOR')
    need(equal(descriptor(d['path']),d),'PIN_MISMATCH:'+d['path'])
    need(d['bytes']<=33554432,'DATA_READ_BOUND');raw=Path(d['path']).read_bytes()
    need(len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256'],'PIN_MISMATCH:'+d['path'])
    inventory=_admission_evidence.get()
    if inventory is not None:inventory.remember(d)
    return raw

def document(d,historical=False):return loads(checked(d),historical)

def validate(v,g,defs):
    if type(g) is str:
        if g.startswith('@'):need(g[1:] in defs,'SCHEMA_REF');return validate(v,defs[g[1:]],defs)
        need(type(v) is bool if g=='boolean' else g=='null' and v is None,'SCHEMA_TYPE');return v
    if 'union' in g:
        for option in g['union']:
            try:validate(v,option,defs);return v
            except (Refusal,KeyError,TypeError,ValueError):pass
        raise Refusal('SCHEMA_UNION')
    if 'record' in g:
        closed(v,g['record']);[validate(v[k],s,defs) for k,s in g['record'].items()]
    elif 'enum' in g:need(any(equal(v,x) for x in g['enum']),'SCHEMA_ENUM')
    elif 'literal' in g:need(equal(v,g['literal']),'SCHEMA_LITERAL')
    elif 'integer' in g:need(type(v) is int and g['integer'][0]<=v<=g['integer'][1],'SCHEMA_INTEGER')
    elif 'tuple' in g:
        need(type(v) is list and len(v)==len(g['tuple']),'SCHEMA_TUPLE')
        [validate(x,s,defs) for x,s in zip(v,g['tuple'])]
    elif 'array' in g:
        need(type(v) is list and g['length'][0]<=len(v)<=g['length'][1],'SCHEMA_ARRAY')
        [validate(x,g['array'],defs) for x in v]
    else:
        need(type(v) is str and len(v.encode('utf-8'))<=g.get('stringMax',131072),'SCHEMA_STRING')
        if 'pattern' in g:need(re.search(g['pattern'],v) is not None,'SCHEMA_PATTERN')
    return v

def closure(ds):
    need(type(ds) is list and 1<=len(ds)<=1024,'FINITE_CLOSURE');result={}
    for d in ds:
        need(d['path'] not in result,'DUPLICATE_CLOSURE_PATH')
        need(equal(descriptor(d['path']),d),'CURRENT_SOURCE_PIN');result[d['path']]=d
    return result

def member(mapping,d):need(equal(mapping.get(d['path']),d),'MISSING_OR_DRIFTED_MEMBER:'+d['path'])

def private_dir(p):
    p=Path(p);s=p.lstat()
    need(str(p.resolve(strict=True))==str(p) and p.is_dir() and s.st_mode&0o777==0o700 and s.st_uid==os.getuid(),'OWNED_0700_DIRECTORY')

def reviews(pack,decision,subject,exclude,defs):
    rows=pack['reviews'];need(len(rows)==2 and len({r['session'] for r in rows})==2 and {r['role'] for r in rows}=={'qa','security'},'DISTINCT_REVIEW_ROLES')
    for r in rows:
        validate(r,'@approvalReview',defs)
        need(r['decision']==decision and r['session'] not in exclude and r['session'] not in pack['authors'],'AUTHOR_OR_SCOPE')
        need(equal(document(r['subject']),subject),'REVIEW_NATIVE_SUBJECT')

def natural(l):
    need(l['launchAttempt'] is True and l['acquisition']=='ACQUIRED' and type(l['pid']) is int and l['pid']>0 and l['exitCode']==0
         and l['signal'] is None and l['reaped'] is True and l['stdoutEOF'] is True and l['stderrEOF'] is True
         and l['timedOut'] is False and l['forced'] is False and l['error'] is None,'NATURAL_OWNED_CHILD')

def control_evidence(e,ds,mapping,defs,env):
    # Exact future controls.py SOURCE interface; no arbitrary eval/command receipt.
    # Exact immutable scope: calibration matched=True never claims native PASS.
    member(mapping,CONTROL_SCOPE);scope=document(CONTROL_SCOPE)
    need(scope['schema']=='i4-fixed-control-scope-v1' and scope['scope']=='LAB-I4_ONLY'
         and equal(scope['originalObligations'],DATA['contract.json']) and len(scope['rows'])==14,'FIXED_CONTROL_SCOPE')
    rows=[dict(id=r['id'],calibration=dict(kind=r['calibration']['kind'],checks=[c['id'] for c in r['calibration']['checks']],matched=True),
               native=dict(status=r['native']['status'],result=None)) for r in scope['rows']]
    closed(e,scope['envelopeFields'])
    need(e['schema']==scope['evidenceSchema'] and equal(e['sourceClosure'],ds) and equal(e['controlScope'],CONTROL_SCOPE)
         and e['finalIntegrity'] is True,'CURRENT_CONTROL_CAPTURE')
    need(equal(e['rows'],rows),'EXACT_SCOPED_CALIBRATION_ROWS')
    need(type(e['invocations']) is list and 1<=len(e['invocations'])<=2,'FINITE_CONTROL_INVOCATIONS');kinds=set()
    for r in e['invocations']:
        closed(r,('tool','argv','cwd','environment','stdin','stdout','stderr','lifecycle'))
        validate(r['tool'],'@closureEntry',defs);member(mapping,r['tool']);validate(r['lifecycle'],'@lifecycle',defs);natural(r['lifecycle'])
        need(equal(r['environment'],env) and re.fullmatch('/tmp/e6i4-controls-[a-z0-9]{6,12}',r['cwd']),'CONTROL_ENV_CWD');private_dir(r['cwd'])
        need(checked(r['stdin'])==b'' and checked(r['stderr'])==b'','CONTROL_RAW_STREAMS')
        b=checked(r['stdout']);need(b.endswith(b'\n') and b.count(b'\n')==1,'CONTROL_ONE_REPLY');v=loads(b[:-1])
        if equal(r['tool'],PYTHON):
            need('python' not in kinds,'ONE_RC_INVOCATION');subject=descriptor(Path(r['cwd'])/'source-closure.json')
            need(equal(document(subject),ds) and equal(r['argv'],[PYTHON['path'],'-I','-B',str(HERE/'controls.py'),subject['path'],subject['sha256'],r['cwd']]),'FIXED_RC_SOURCE_SUBJECT_COMMAND')
            closed(v,scope['captureFields'])
            need(v['schema']==scope['nativeCaptureSchema'] and equal(v['sourceClosure'],ds) and equal(v['controlScope'],CONTROL_SCOPE)
                 and equal(v['rows'],rows) and v['finalIntegrity'] is True,'ACTUAL_NATIVE_RC_BINDING');kinds.add('python')
        else:
            need(equal(r['tool'],NODE) and 'node' not in kinds and equal(r['argv'],[NODE['path'],str(HERE/'wire_controls.mjs')]),'FIXED_PURE_WIRE_COMMAND')
            closed(v,('schema','qualified','scope','rows'))
            need(v['schema']=='i4-wire-pure-controls-v1' and v['qualified'] is True and v['scope']=='PURE_HELPER_ONLY' and type(v['rows']) is list and 1<=len(v['rows'])<=64,'WIRE_CONTROL_CAPTURE')
            need(len({row['id'] for row in v['rows']})==len(v['rows']),'WIRE_CONTROL_IDS')
            for row in v['rows']:closed(row,('id','qualified','scope'));need(type(row['id']) is str and row['qualified'] is True and row['scope']=='PURE_HELPER_ONLY','WIRE_CONTROL_ROW')
            kinds.add('node')
    need('python' in kinds,'ACTUAL_FOURTEEN_RC_OUTPUT_REQUIRED')

def approval_packs(m,mapping,defs,env):
    s=document(m['sourceReviews']);validate(s,'@sourceApproval',defs)
    need(equal(s['sourceClosure'],m['sourceClosure']) and set(EXCLUDED)<=set(s['authors']),'EXACT_SOURCE_CLOSURE_AUTHORS')
    reviews(s,'ACCEPT_SOURCE_ONLY',m['sourceClosure'],EXCLUDED,defs)
    c=document(m['controlAcceptance']);validate(c,'@controlApproval',defs)
    need(equal(c['sourceApproval'],m['sourceReviews']),'CONTROL_SOURCE_APPROVAL')
    e=document(c['actualControlEvidence']);control_evidence(e,m['sourceClosure'],mapping,defs,env)
    reviews(c,'ACCEPT_CONTROLS_ONLY',e,EXCLUDED+s['authors'],defs)
    a=document(m['configurationAcceptance']);validate(a,'@configurationApproval',defs)
    core={k:v for k,v in m.items() if k!='configurationAcceptance'}
    need(equal(a['configuration'],core),'EXACT_CONFIGURATION_CORE')
    reviews(a,'ACCEPT_CONFIGURATION_ONLY',core,EXCLUDED+s['authors']+c['authors'],defs)

def native_prerequisites(m,data,mapping):
    c=data['contract.json'];ev=c['evidence'];old=document(c['sourceLineage']['experiments/prototypes/e06_https_acquisition_v1/contract.json'])
    wanted=dict(httpsPair=ev['runtime-acceptance.json'],relayComponent=ev['relay-runtime'],recoveryComponent=ev['recovery-runtime'],
                candidateE02Policy=POLICY,sourceRelevantE01=CURRENT_E01,sourceRelevantE05=old['prerequisites']['e05']['descriptor'])
    need(equal(m['prerequisites'],wanted),'EXACT_PREREQUISITES')
    for d in wanted.values():member(mapping,d);checked(d)
    need(b'ADOPTED_TECHNICAL_POLICY' in checked(POLICY) and b'transport-sub-evidence-v1' in checked(POLICY),'ADOPTED_POLICY')
    for name,key in [('relayComponent','relayMetadata'),('recoveryComponent','recovery'),('sourceRelevantE05','e05')]:
        spec=old['prerequisites'][key];v=document(wanted[name],True)
        for k,expected in spec['nativeFields'].items():need(equal(v.get(k),expected),'PREREQUISITE_NATIVE_SCOPE')
        for k in spec['absentNativeFields']:need(k not in v,'PREREQUISITE_NATIVE_ABSENT')
    h=document(wanted['httpsPair'],True)
    need(h['schema']=='e06-https-selected-component-runtime-acceptance-v1' and h['decision']=='ACCEPT_EXACT_PRIMARY_QA_COMPONENT_PAIR_ONLY'
         and h['scope']=='HTTPS_ACQUISITION_AND_ORIGINAL_RECOVERY_ONLY','HTTPS_PAIR_SCOPE')
    v=document(old['prerequisites']['e02']['descriptor'],True);need(v['status']=='PARTIAL' and v['exit_status']==0,'E02_REMAINS_PARTIAL')
    f=data['selection-map.json']['fixtureAcceptance'];member(mapping,f)
    need(document(f)['decision']=='ACCEPT_FIXTURE_MATERIALIZATION_ONLY','EXACT_FIXTURE_ACCEPTANCE')
    v=document(CURRENT_E01,True)
    need(v['decision']=='ACCEPT_CURRENT_CARRIER_LEGACY140_RUNTIME_SCOPE_ONLY' and v['qa_decision']=='ACCEPT_CURRENT_CARRIER_REFERENCE140_RUNTIME_SCOPE_ONLY'
         and v['security_decision']=='ACCEPT_CURRENT_CARRIER_LEGACY140_RUNTIME_SCOPE_ONLY' and v['material_findings']==[],'CURRENT_SOURCE_E01_ACCEPTANCE')
    for run in v['runs'].values():need(run['qualified'] is True and run['natural_outer_exit']==0 and run['checks']==140 and run['failures']==0,'CURRENT_E01_BOTH140')
    return old

def accepted_transport(mapping):
    # Only this exact fixed read-only prerequisite verifier is imported, after
    # external root/source/control/configuration authority has already passed.
    # Never call its qualification/main/E04/sentinel or any historical experiment.
    member(mapping,TRANSPORT_GATE);member(mapping,TRANSPORT_RELEASE)
    checked(TRANSPORT_GATE);checked(TRANSPORT_RELEASE)
    spec=importlib.util.spec_from_file_location('_i4_pinned_transport_prerequisites',TRANSPORT_GATE['path'])
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=module.verify_transport_prerequisites(TRANSPORT_RELEASE['path'],TRANSPORT_RELEASE['sha256'])
    need(type(result) is dict and type(result.get('verifiedFiles')) is int and result['verifiedFiles']>0
         and type(result.get('verifiedArchives')) is int and result['verifiedArchives']>0,'ACTUAL_TRANSPORT_PREREQUISITE')
    return result

def certificates(tls,old,mapping):
    p=document(tls['acceptance']);closed(p,('schema','decision','ca','server','wrongSan','reviews'))
    need(p['schema']=='e06-https-certificate-acceptance-v1' and p['decision']=='ACCEPT_ISOLATED_TEST_CERTIFICATES_ONLY'
         and equal(tls['ca'],p['ca']) and equal(tls['key'],p['server']['key']) and equal(tls['cert'],p['server']['cert']),'EXACT_CERT_INPUTS')
    e=p['reviews'];closed(e,('schema','materialization','sourceReviews','acceptance'));n=document(e['materialization']);spec=old['tlsFixtureBinding']
    need(n['schema']=='e06-isolated-cert-materialization-v1' and n['qualified'] is True and equal(n['outputs'],{k:p[k] for k in ('ca','server','wrongSan')})
         and equal(n['sourcePins'],spec['sourcePins']) and equal(n['toolClosure'],spec['toolClosure']),'ACTUAL_CERT_MATERIALIZATION')
    need(len(n['calls'])==11,'CERT_ELEVEN_STAGES')
    for i,r in enumerate(n['calls']):
        l=r['lifecycle'];need(r['ordinal']==i and equal(r['argv'],spec['operations'][i]['argv']) and r['cwd']==spec['root'],'CERT_STAGE_OPERANDS')
        need(l['acquisition']=='ACQUIRED' and l['reaped'] is True and l['stdoutEOF'] is True and l['stderrEOF'] is True and l['forced'] is False
             and l['timedOut'] is False and l['signal'] is None and l['error'] is None and l['ownershipRetainedUntilReap'] is True
             and l['ownedCleanupQualified'] is True and (l['exitCode']==0 if i<10 else type(l['exitCode']) is int and l['exitCode']>0),'CERT_STAGE_LIFECYCLE')
        for k in ('stdin','stdout','stderr'):checked(r[k])
        if i==9:need(checked(r['stdout'])==(spec['root']+'/wrong-host.cert.pem: OK\n').encode() and checked(r['stderr'])==b'','CERT_OWN_HOST_POSITIVE')
        if i==10:need(checked(r['stdout'])==b'' and re.fullmatch(rb'CN\s*=\s*wrong\.files\.invalid\nerror 62 at 0 depth lookup: hostname mismatch\nerror '+re.escape(spec['root'].encode())+rb'/wrong-host.cert.pem: verification failed\n',checked(r['stderr'])),'CERT_HOSTNAME_NEGATIVE')
    v=n['validity'];closed(v,('notBefore','notAfter','earliestExpiry'));now=time.time_ns()//1000000
    for side in ('notBefore','notAfter'):closed(v[side],('ca','server','wrongSan'));need(all(type(a) is int for a in v[side].values()),'CERT_EPOCH_MS')
    need(v['earliestExpiry']==min(v['notAfter'].values()) and max(v['notBefore'].values())<=now and v['earliestExpiry']-now>=300000,'CURRENT_CERT_VALIDITY')
    subjects={k:p[k] for k in ('ca','server','wrongSan')};subjects.update(materialization=e['materialization'],sourceReviews=e['sourceReviews'])
    a=e['acceptance'];need(a['decision']=='ACCEPT_CURRENT_SOURCES_ONLY' and equal(a['subjects'],subjects),'CERT_ACCEPTANCE_SUBJECTS')
    rows=a['reviews'];need(len(rows)==2 and {r['role'] for r in rows}=={'qa','security'} and len({r['session'] for r in rows})==2,'CERT_INDEPENDENT_ROLES')
    for r in rows:need(r['decision']=='ACCEPT_SOURCE_ONLY' and equal(r['subjects'],subjects) and r['session'] not in EXCLUDED+n['authors'],'CERT_INDEPENDENT_REVIEW')
    for d in [p['ca'],p['server']['key'],p['server']['cert'],p['wrongSan']['key'],p['wrongSan']['cert'],e['materialization'],e['sourceReviews']]:member(mapping,d);checked(d)

def verify(manifest_path,manifest_sha,release_path,release_sha,execution_session,run_role):
    inventory=_VerifiedEvidenceInventory();token=_admission_evidence.set(inventory)
    try:return _verify_with_evidence(manifest_path,manifest_sha,release_path,release_sha,execution_session,run_role,inventory)
    finally:_admission_evidence.reset(token)

def _verify_with_evidence(manifest_path,manifest_sha,release_path,release_sha,execution_session,run_role,verified_evidence):
    md=descriptor(manifest_path);rd=descriptor(release_path)
    need(md['sha256']==manifest_sha and rd['sha256']==release_sha,'EXTERNAL_MANIFEST_RELEASE_SHA')
    data={name:document(DATA[name]) for name in ('contract.json','profile.json','selection-map.json','bridge-schemas.json','protected-deltas.json')};defs=data['bridge-schemas.json']['definitions']
    m=document(md);r=document(rd);validate(m,'@manifest',defs);validate(r,'@release',defs)
    need(r['rootSession']=='/root' and r['decision']=='RELEASE_EXACT_I4_RUN_ONLY' and r['executionSession']==execution_session
         and r['runRole']==run_role and run_role in ('primary','qa') and equal(r['manifest'],md),'EXACT_TRUSTED_ROOT_RELEASE')
    for k in ('sourceReviews','controlAcceptance','configurationAcceptance'):need(equal(r[k],m[k]),'RELEASE_ARTIFACT_BINDING')
    mapping=closure(m['sourceClosure'])
    for d in DATA.values():member(mapping,d)
    member(mapping,CONTROL_SCOPE)
    for name in FUTURE_SOURCE_NAMES:member(mapping,descriptor(HERE/name))
    for d in (NODE,RUST):member(mapping,d)
    for relative,pin in data['protected-deltas.json']['wholeSourcePins'].items():member(mapping,dict(path=str(ROOT/relative),**pin))
    need(equal(m['profile'],DATA['profile.json']) and equal(m['bridgeSchema'],DATA['bridge-schemas.json']) and equal(m['protectedDeltas'],DATA['protected-deltas.json']),'FIXED_PROFILE_SCHEMAS')
    env=data['profile.json']['environments']['childProposal'];approval_packs(m,mapping,defs,env)
    member(mapping,data['contract.json']['sourceLineage']['experiments/prototypes/e06_https_acquisition_v1/contract.json'])
    old=native_prerequisites(m,data,mapping)
    member(mapping,old['tools']['python']);need(equal(descriptor(sys.executable),old['tools']['python']),'FIXED_ADMISSION_PYTHON')
    need(re.fullmatch('/tmp/e6i4-'+run_role+'-[a-z0-9]{6,12}',m['outputRoot']) and not os.path.lexists(m['outputRoot']),'FRESH_EXACT_OUTPUT')
    private_dir(Path(m['outputRoot']).parent) if str(Path(m['outputRoot']).parent)!='/tmp' else need(Path('/tmp').resolve()==Path('/tmp'),'CANONICAL_TMP')
    workers={}
    for cell in data['selection-map.json']['initialWindows']:
        ident=cell['caseId'];w=document(m['workerInputs'][ident]);validate(w,'@workerData',defs);family=data['selection-map.json']['families'][cell['family']]
        need(w['caseId']==ident and w['windowId']==cell['windowId'] and w['relay']==cell['relay'] and w['backend']==cell['metadataBackend']
             and w['engine']==cell['engine'] and equal(w['scope'],family['scope']) and equal(w['dWire'],family['rawWires']['D']['incoming'])
             and equal(w['fWire'],family['rawWires']['F']['incoming']) and equal(w['blob'],family['blob']) and w['secretHex']=='0'*63+'2','EXACT_I4_CELL_JOIN')
        for k in ('dWire','fWire','blob','browserProfile'):member(mapping,w[k]);checked(w[k])
        need(equal(w['browserProfile'],old['browserProfile']),'EXACT_BROWSER_PROFILE')
        bp=document(w['browserProfile'])
        for pin in (bp['executable'],bp['cryptoSource'],bp['node']):member(mapping,pin)
        for group in (bp['assets'],bp['playwrightSources']):
            for name,pin in group.items():member(mapping,dict(path=name,**pin))
        certificates(w['tls'],old,mapping);workers[ident]=w
    # This prerequisite-only invocation is deliberately after every current
    # root/source/control/config/input check and before any target-dependent import.
    verified_transport=accepted_transport(mapping)
    closure(m['sourceClosure'])  # Fresh current I4 closure after relevant historical reads.
    for worker in workers.values():certificates(worker['tls'],old,mapping)
    verified_evidence.recheck()  # Original nested authority pins AFTER historical verification.
    return dict(manifest=m,manifestDescriptor=md,releaseDescriptor=rd,profile=data['profile.json'],
                sourceClosure=m['sourceClosure'],workers=workers,output=m['outputRoot'],transportPrerequisites=verified_transport,
                # Private Python callable retains ORIGINAL invocation pins after
                # ContextVar reset; runner calls after cleanup, never JSON-serializes
                # this capability or reruns admission against existing outputs.
                recheckAuthorityEvidence=verified_evidence.recheck)
