// SOURCE_PREPARED_NOT_EXECUTED. Explicit JSONL CLI, inert when imported.
import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';
import { carrierHandle } from './transport.mjs';
export { carrierHandle };

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const lines = createInterface({ input: process.stdin, crlfDelay: Infinity, terminal: false });
  for await (const line of lines) {
    if (Buffer.byteLength(line, 'utf8') > 5_000_000) {
      process.stdout.write(`${JSON.stringify(carrierHandle(null))}\n`);
      continue;
    }
    let request;
    try { request = JSON.parse(line); }
    catch (error) {
      if (!(error instanceof SyntaxError)) throw error;
      process.stdout.write(`${JSON.stringify(carrierHandle(null))}\n`);
      continue;
    }
    process.stdout.write(`${JSON.stringify(carrierHandle(request))}\n`);
  }
}
