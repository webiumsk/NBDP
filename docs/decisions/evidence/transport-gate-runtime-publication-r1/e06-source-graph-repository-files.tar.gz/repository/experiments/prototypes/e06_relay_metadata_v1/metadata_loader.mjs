// Persistent one-route metadata window. Module import is inert.
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import path from 'node:path';
import { parseStrict, typedEqual } from './wire.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
const selectionPath = path.join(here, 'selection.json');
const selectionSHA = '8e67ab182f155a853a1a9c3f3149a0e31a5e582d018d7976777c786d7fe93c1f';
const keys = (o, names) => o !== null && typeof o === 'object' && !Array.isArray(o)
  && Object.keys(o).length === names.length && names.every(k => Object.hasOwn(o,k));
const need = (ok, reason) => { if (!ok) throw Error(reason); };
function checkPins(pins) {
  need(keys(pins[selectionPath], ['bytes','sha256']) && pins[selectionPath].sha256 === selectionSHA, 'SELECTION_PIN');
  for (const [p,d] of Object.entries(pins)) {
    need(path.isAbsolute(p) && fs.realpathSync(p) === p && keys(d,['bytes','sha256']), 'PIN_SHAPE');
    const raw = fs.readFileSync(p);
    need(raw.length === d.bytes && crypto.createHash('sha256').update(raw).digest('hex') === d.sha256, 'PIN_CHANGED');
  }
}
export function validateInput(line, route, index) {
  need(index < route.steps.length, 'EXTRA_REQUEST');
  const req = parseStrict(Buffer.from(line)).value;
  const template = parseStrict(Buffer.from(route.steps[index].rawLine.hex,'hex')).value;
  need(keys(req,['op','secretHex','config','dWireHex','fWireHex']), 'REQUEST_KEYS');
  for (const k of ['op','secretHex','config']) need(typedEqual(req[k],template[k]), 'NONWIRE_TEMPLATE');
  for (const slot of ['D','F']) {
    const k = slot.toLowerCase()+'WireHex';
    if (template[k] === null) { need(req[k] === null, 'PREMATURE_D'); continue; }
    need(typeof req[k] === 'string' && /^(?:[0-9a-f]{2})+$/.test(req[k]) && req[k].length <= 32748, 'WIRE_HEX');
    const event = route.networkEvents.find(e => e.slot === slot);
    const fixture = parseStrict(fs.readFileSync(event.wire.path)).value;
    need(typedEqual(parseStrict(Buffer.from(req[k],'hex')).value, fixture), 'WHOLE_EVENT');
  }
  return req;
}
async function main() {
  need(process.argv.length === 4 && /^[0-9a-f]{64}$/.test(process.argv[3]), 'CLI');
  const raw = fs.readFileSync(process.argv[2]);
  need(crypto.createHash('sha256').update(raw).digest('hex') === process.argv[3], 'BINDING_SHA');
  const b = parseStrict(raw).value;
  need(keys(b,['schema','route','sourcePins','metadataEntry','maxRequests'])
    && b.schema === 'e06-relay-metadata-loader-binding-v1', 'BINDING');
  const env = {LANG:'C.UTF-8',LC_ALL:'C.UTF-8',TZ:'UTC',WS_NO_BUFFER_UTIL:'1',WS_NO_UTF_8_VALIDATE:'1'};
  need(typedEqual(process.env, env), 'ENVIRONMENT');
  checkPins(b.sourcePins);
  need(Object.hasOwn(b.sourcePins, fileURLToPath(import.meta.url)) && Object.hasOwn(b.sourcePins,process.execPath)
    && b.metadataEntry === path.resolve(here,'../e06_invoice_file_v1/js/metadata.mjs')
    && Object.hasOwn(b.sourcePins,b.metadataEntry), 'LOADER_TARGET');
  const selection = parseStrict(fs.readFileSync(selectionPath)).value;
  const route = selection.routes.find(r => r.id === b.route);
  need(route && route.consumer === 'JS' && b.maxRequests === route.steps.length, 'ROUTE');
  const metadata = await import(pathToFileURL(b.metadataEntry).href);
  need(typeof metadata._handleLine === 'function', 'METADATA_EXPORT');
  let pending=Buffer.alloc(0), count=0, total=0, firstF=null;
  for await (const chunk of process.stdin) {
    total += chunk.length;
    need(total <= 262146, 'TOTAL_STDIN_BOUND');
    pending=Buffer.concat([pending,chunk]);
    let lf;
    while ((lf=pending.indexOf(10)) !== -1) {
      const line=pending.subarray(0,lf); pending=pending.subarray(lf+1);
      need(line.length <= 131072, 'LINE_BOUND');
      const req=validateInput(line,route,count);
      if (firstF === null) firstF=req.fWireHex;
      else need(req.fWireHex === firstF, 'CHANGED_F_SPAN');
      checkPins(b.sourcePins);
      const reply=await metadata._handleLine(new TextDecoder('utf-8',{fatal:true}).decode(line));
      process.stdout.write(JSON.stringify(reply)+'\n');
      count++;
      checkPins(b.sourcePins);
    }
    need(pending.length <= 131072, 'LINE_BOUND');
  }
  need(pending.length === 0 && count === b.maxRequests, 'EOF_REQUEST_COUNT');
  checkPins(b.sourcePins);
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(e => { process.stderr.write(String(e.stack || e)+'\n'); process.exitCode=1; });
}
