"""Fixed PREPARE-only entry, using externally pinned inert sibling loading."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent

def main(argv):
    if len(argv)!=4:raise ValueError('CLI: prepare.py MANIFEST SHA RELEASE SHA')
    raw=Path(argv[0]).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=argv[1]:raise ValueError('MANIFEST_SHA')
    m=json.loads(raw)
    if m.get('phase')!='PREPARE':raise ValueError('PREPARE_ONLY')
    p=HERE/'run.py';b=p.read_bytes()
    if m.get('sourcePins',{}).get(str(p))!={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}:raise ValueError('FIXED_RUN_PIN')
    spec=importlib.util.spec_from_file_location('_https_fixed_runner',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod.main(argv)

if __name__=='__main__':
    try:result=main(sys.argv[1:])
    except BaseException as exc:print(type(exc).__name__+': '+str(exc),file=sys.stderr);result=1
    raise SystemExit(result)
