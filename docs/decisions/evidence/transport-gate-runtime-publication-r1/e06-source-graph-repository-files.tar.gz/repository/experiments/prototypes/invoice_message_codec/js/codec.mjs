// SOURCE_PREPARED_NOT_EXECUTED. Independent structural codec, no authentication.
// Contract SHA256: 690b1be32f4eb9cbc6df4db522be95c59f168131e7f4b874058461fdf891bd8d
// No corpus loading, copied transport helpers, cryptography or store integration.
import { createInterface } from 'node:readline';
import { pathToFileURL } from 'node:url';

const PROTOCOL = 'NBDP/invoice-delivery-draft';
const AUTH = 'NOT_EVALUATED';
const MAX_INTEGER = '9007199254740991';
const COMMON = ['protocol', 'version', 'type', 'id', 'from', 'to', 'context', 'required'];
const DELIVERY = [...COMMON, 'document', 'file'];
const RECEIPT = [...COMMON, 'subject', 'stage', 'persistence'];
const DOCUMENT = ['id', 'kind', 'revision', 'sha256', 'bytes', 'media'];
const FILE = ['profile', 'x', 'ox', 'bytes', 'key', 'nonce'];
const CONFIG = ['enabled', 'role', 'expectedLocal', 'expectedPeer', 'expectedContext'];
const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
const own = (value, key) => Object.hasOwn(value, key);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const keys = (value, expected) => object(value) && Object.keys(value).length === expected.length
  && expected.every(key => own(value, key));
const hex = (value, length) => typeof value === 'string' && value.length === length && !/[^0-9a-f]/.test(value);
const h64 = value => hex(value, 64);
const integer = (value, low, high) => Number.isSafeInteger(value) && value >= low && value <= high;
const refused = (reason, path = '$') => ({ status: 'REFUSED', authentication: AUTH, reason, path });
const noDispatch = reason => ({ status: 'NO_DISPATCH', authentication: AUTH, reason });

class ParseFault extends Error {
  constructor(reason) { super(reason); this.reason = reason; }
}

// All syntax is consumed before any policy flag is reported. Numeric values stay
// as raw tokens in slots until every accepted token is proven exactly safe.
function parseJson(text) {
  let offset = 0;
  let maximumDepth = 0;
  let duplicate = false;
  let nonScalar = false;
  let badNumber = false;
  const stack = [];
  const numbers = [];
  const numberPattern = /-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/y;
  const escapes = { '"': '"', '\\': '\\', '/': '/', b: '\b', f: '\f', n: '\n', r: '\r', t: '\t' };
  const syntax = () => { throw new ParseFault('JSON'); };
  const whitespace = () => {
    while (text[offset] === ' ' || text[offset] === '\t' || text[offset] === '\n' || text[offset] === '\r') offset++;
  };
  function string() {
    if (text[offset++] !== '"') syntax();
    let value = '';
    while (offset < text.length) {
      const character = text[offset++];
      if (character === '"') {
        for (const scalar of value) {
          const point = scalar.codePointAt(0);
          if (point >= 0xd800 && point <= 0xdfff) nonScalar = true;
        }
        return value;
      }
      if (character.charCodeAt(0) < 0x20) syntax();
      if (character !== '\\') { value += character; continue; }
      const escape = text[offset++];
      if (escape === 'u') {
        const digits = text.slice(offset, offset + 4);
        if (digits.length !== 4 || /[^0-9a-fA-F]/.test(digits)) syntax();
        value += String.fromCharCode(Number.parseInt(digits, 16));
        offset += 4;
      } else if (own(escapes, escape)) value += escapes[escape];
      else syntax();
    }
    syntax();
  }
  function value() {
    whitespace();
    const character = text[offset];
    if (character === '{' || character === '[') {
      offset++;
      const isObject = character === '{';
      const container = isObject ? Object.create(null) : [];
      stack.push({ container, isObject, state: isObject ? 'keyOrEnd' : 'valueOrEnd', seen: new Set(), key: null });
      maximumDepth = Math.max(maximumDepth, stack.length);
      return { value: container };
    }
    if (character === '"') return { value: string() };
    for (const [token, literal] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(token, offset)) { offset += token.length; return { value: literal }; }
    }
    numberPattern.lastIndex = offset;
    const match = numberPattern.exec(text);
    if (!match) syntax();
    const raw = match[0];
    offset += raw.length;
    if (!/^(?:0|[1-9][0-9]*)$/.test(raw) || raw.length > MAX_INTEGER.length
        || (raw.length === MAX_INTEGER.length && raw > MAX_INTEGER)) badNumber = true;
    return { value: null, rawNumber: raw };
  }
  function put(container, key, parsed) {
    container[key] = parsed.value;
    if (parsed.rawNumber !== undefined) numbers.push({ container, key, raw: parsed.rawNumber });
  }
  const root = value();
  while (stack.length) {
    const frame = stack[stack.length - 1];
    whitespace();
    const character = text[offset];
    if (frame.isObject) {
      if (frame.state === 'keyOrEnd' || frame.state === 'key') {
        if (character === '}' && frame.state === 'keyOrEnd') { offset++; stack.pop(); continue; }
        if (character !== '"') syntax();
        frame.key = string();
        if (frame.seen.has(frame.key)) duplicate = true;
        frame.seen.add(frame.key);
        frame.state = 'colon';
      } else if (frame.state === 'colon') {
        if (character !== ':') syntax();
        offset++;
        frame.state = 'value';
      } else if (frame.state === 'value') {
        frame.state = 'comma';
        put(frame.container, frame.key, value());
      } else if (character === '}') { offset++; stack.pop(); }
      else if (character === ',') { offset++; frame.state = 'key'; }
      else syntax();
    } else if (frame.state === 'valueOrEnd' || frame.state === 'value') {
      if (character === ']' && frame.state === 'valueOrEnd') { offset++; stack.pop(); continue; }
      frame.state = 'comma';
      put(frame.container, frame.container.length, value());
    } else if (character === ']') { offset++; stack.pop(); }
    else if (character === ',') { offset++; frame.state = 'value'; }
    else syntax();
  }
  whitespace();
  if (offset !== text.length) syntax();
  if (maximumDepth > 32) throw new ParseFault('DEPTH');
  if (duplicate) throw new ParseFault('DUPLICATE_KEY');
  if (nonScalar) throw new ParseFault('UNICODE_SCALAR');
  if (badNumber) throw new ParseFault('NUMBER');
  for (const slot of numbers) slot.container[slot.key] = Number(slot.raw);
  return root.value;
}

function rootTypes(message, kind) {
  if (!keys(message, kind === 'delivery' ? DELIVERY : RECEIPT)) return false;
  if (!['protocol', 'type', 'id', 'from', 'to', 'context'].every(key => typeof message[key] === 'string')
      || !Number.isSafeInteger(message.version) || !Array.isArray(message.required)) return false;
  return kind === 'delivery' ? object(message.document) && object(message.file)
    : object(message.subject) && typeof message.stage === 'string' && object(message.persistence);
}

function deliverySchema(message, path, topLevel = false) {
  if (!rootTypes(message, 'delivery')) return refused('SCHEMA', path);
  if (topLevel && message.required.length) return refused('UNSUPPORTED_REQUIRED', '$.required');
  if (message.protocol !== PROTOCOL || message.version !== 1 || message.type !== 'delivery'
      || message.required.length || !['id', 'from', 'to', 'context'].every(key => h64(message[key]))) return refused('SCHEMA', path);
  const document = message.document;
  if (!keys(document, DOCUMENT) || !h64(document.id) || !['invoice', 'credit-note'].includes(document.kind)
      || !integer(document.revision, 1, Number.MAX_SAFE_INTEGER) || !h64(document.sha256)
      || !integer(document.bytes, 0, 1048576) || document.media !== 'application/octet-stream') return refused('SCHEMA', `${path}.document`);
  const file = message.file;
  if (!keys(file, FILE) || file.profile !== 'aes256gcm-12-empty-v1' || !h64(file.x) || !h64(file.ox)
      || !integer(file.bytes, 16, 1048592) || !h64(file.key) || !hex(file.nonce, 24)
      || file.ox !== document.sha256 || file.bytes !== document.bytes + 16) return refused('SCHEMA', `${path}.file`);
  return null;
}

function schema(message) {
  if (message.type === 'delivery') return deliverySchema(message, '$', true);
  if (!rootTypes(message, 'receipt')) return refused('SCHEMA');
  if (message.required.length) return refused('UNSUPPORTED_REQUIRED', '$.required');
  if (!['id', 'from', 'to', 'context'].every(key => h64(message[key])) || message.stage !== 'verified-durable') return refused('SCHEMA');
  const subject = message.subject;
  if (!keys(subject, ['delivery_rumor', 'file_rumor', 'delivery']) || !h64(subject.delivery_rumor)
      || !h64(subject.file_rumor) || !object(subject.delivery)) return refused('SCHEMA', '$.subject');
  const nested = deliverySchema(subject.delivery, '$.subject.delivery');
  if (nested) return nested;
  if (!keys(message.persistence, ['domain']) || !h64(message.persistence.domain)) return refused('SCHEMA', '$.persistence');
  return null;
}

function application(bodyHex) {
  if (typeof bodyHex !== 'string' || bodyHex.length % 2 !== 0 || /[^0-9a-f]/.test(bodyHex)) return { result: refused('INPUT_HEX') };
  if (bodyHex.length / 2 > 8192) return { result: refused('BYTES') };
  let text;
  try { text = decoder.decode(Buffer.from(bodyHex, 'hex')); }
  catch (error) { if (error instanceof TypeError) return { result: refused('UTF8') }; throw error; }
  if (text[0] !== '{') return { result: noDispatch('NON_CANDIDATE') };
  if (text[text.length - 1] !== '}') return { result: refused('JSON_FRAMING') };
  let message;
  try { message = parseJson(text); }
  catch (error) { if (error instanceof ParseFault) return { result: refused(error.reason) }; throw error; }
  if (message.protocol !== PROTOCOL) return { result: noDispatch('FOREIGN_PROTOCOL') };
  if (!own(message, 'version') || !Number.isSafeInteger(message.version)
      || !own(message, 'type') || typeof message.type !== 'string') return { result: refused('SCHEMA') };
  if (message.version !== 1) return { result: refused('UNSUPPORTED_VERSION', '$.version') };
  if (message.type !== 'delivery' && message.type !== 'receipt') return { result: refused('UNSUPPORTED_TYPE', '$.type') };
  const failure = schema(message);
  return failure ? { result: failure } : { message };
}

function direction(config) {
  return config.role === 'incoming' ? { from: config.expectedPeer, to: config.expectedLocal }
    : { from: config.expectedLocal, to: config.expectedPeer };
}

function binding(message, config) {
  const expected = direction(config);
  for (const field of ['from', 'to', 'context']) {
    const value = field === 'context' ? config.expectedContext : expected[field];
    if (message[field] !== value) return { reason: 'BINDING', path: `$.${field}` };
  }
  if (message.type === 'receipt' && own(config, 'expectedReceiptDomain')
      && message.persistence.domain !== config.expectedReceiptDomain) return { reason: 'BINDING', path: '$.persistence.domain' };
  return null;
}

function relation(message) {
  if (message.type !== 'receipt') return null;
  const delivery = message.subject.delivery;
  for (const [field, expected] of [['from', message.to], ['to', message.from], ['context', message.context]]) {
    if (delivery[field] !== expected) return { reason: 'RECEIPT_RELATION', path: `$.subject.delivery.${field}` };
  }
  return null;
}

function equal(left, right) {
  if (typeof left !== typeof right) return false;
  if (left === null || right === null || typeof left !== 'object') return left === right;
  if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right)
    && left.length === right.length && left.every((value, index) => equal(value, right[index]));
  const fields = Object.keys(left);
  return fields.length === Object.keys(right).length && fields.every(key => own(right, key) && equal(left[key], right[key]));
}

// Pure COMMON_JSON handler. No source/corpus lookup or effects are performed here.
export function handle(request) {
  if (!object(request) || (request.method !== 'validate' && request.method !== 'matchReceipt')) return refused('RPC');
  const matching = request.method === 'matchReceipt';
  const requestKeys = matching ? ['method', 'config', 'bodyHex', 'originalDeliveryHex', 'deliveryRumorId', 'fileRumorId']
    : ['method', 'config', 'bodyHex'];
  if (!keys(request, requestKeys) || !object(request.config)) return refused('RPC');
  const config = request.config;
  if (!own(config, 'role') || (config.role !== 'incoming' && config.role !== 'archive')) return refused('LOCAL_ROLE', '$.config.role');
  for (const [field, reason] of [['expectedLocal', 'LOCAL_PIN'], ['expectedPeer', 'LOCAL_PEER'], ['expectedContext', 'LOCAL_CONTEXT']]) {
    if (!own(config, field) || !h64(config[field])) return refused(reason, `$.config.${field}`);
  }
  if (own(config, 'expectedReceiptDomain') && !h64(config.expectedReceiptDomain)) return refused('LOCAL_DOMAIN', '$.config.expectedReceiptDomain');
  if (!own(config, 'enabled') || typeof config.enabled !== 'boolean') return refused('LOCAL_ENABLED', '$.config.enabled');
  const configKeys = own(config, 'expectedReceiptDomain') ? [...CONFIG, 'expectedReceiptDomain'] : CONFIG;
  if (!keys(config, configKeys)) return refused('LOCAL_CONFIG', '$.config');
  if (matching) {
    for (const field of ['deliveryRumorId', 'fileRumorId']) {
      if (!h64(request[field])) return refused('ORIGINAL_IDENTIFIERS', `$.${field}`);
    }
  }
  if (!config.enabled) return noDispatch('DISABLED');
  let original;
  if (matching) {
    const parsed = application(request.originalDeliveryHex);
    if (parsed.result || parsed.message.type !== 'delivery') return refused('ORIGINAL_DELIVERY', '$original');
    original = parsed.message;
    const expected = direction(config);
    if (original.from !== expected.to || original.to !== expected.from || original.context !== config.expectedContext) return refused('ORIGINAL_DELIVERY', '$original');
  }
  const parsed = application(request.bodyHex);
  if (parsed.result) return parsed.result;
  const message = parsed.message;
  if (!matching) {
    const mismatch = binding(message, config) || relation(message);
    return mismatch ? refused(mismatch.reason, mismatch.path)
      : { status: 'STRUCTURALLY_VALID', authentication: AUTH, rawBodyHex: request.bodyHex, message };
  }
  if (message.type !== 'receipt') return refused('MATCH_RECEIPT_REQUIRED', '$.type');
  let mismatch = binding(message, config) || relation(message);
  if (!mismatch && message.subject.delivery_rumor !== request.deliveryRumorId) mismatch = { reason: 'SUBJECT_ID', path: '$.subject.delivery_rumor' };
  if (!mismatch && message.subject.file_rumor !== request.fileRumorId) mismatch = { reason: 'SUBJECT_ID', path: '$.subject.file_rumor' };
  if (!mismatch && !equal(message.subject.delivery, original)) mismatch = { reason: 'SUBJECT_VALUE', path: '$.subject.delivery' };
  const result = { status: mismatch ? 'STRUCTURAL_SUBJECT_MISMATCH' : 'STRUCTURAL_SUBJECT_MATCH', authentication: AUTH,
    rawBodyHex: request.bodyHex, message, originalDeliveryRawHex: request.originalDeliveryHex, originalDelivery: original,
    deliveryRumorId: request.deliveryRumorId, fileRumorId: request.fileRumorId };
  return mismatch ? { ...result, reason: mismatch.reason, path: mismatch.path } : result;
}

// Only the explicit executable entry point opens standard RPC streams.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const lines = createInterface({ input: process.stdin, crlfDelay: Infinity, terminal: false });
  for await (const line of lines) {
    let request;
    try { request = JSON.parse(line); }
    catch (error) {
      if (!(error instanceof SyntaxError)) throw error;
      process.stdout.write(`${JSON.stringify(refused('RPC'))}\n`);
      continue;
    }
    process.stdout.write(`${JSON.stringify(handle(request))}\n`);
  }
}
