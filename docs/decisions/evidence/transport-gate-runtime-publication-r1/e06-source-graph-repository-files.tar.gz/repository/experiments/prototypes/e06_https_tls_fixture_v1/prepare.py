"""Fixed11-stage disposable TLS materialization. SOURCE ONLY / NOT_EXECUTED.

No import-time work. CLI requires a separately reviewed externally pinned root
release. This module grants no permission to run itself or acquire a blob.
"""
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).absolute().parent
ROOT = Path('/tmp/nbdp-e06-https-tls-r2')
SOURCE_NAMES = ('prepare.py', 'recipe.json', 'openssl.cnf', 'leaf-extensions.cnf',
                'SOURCE.md', 'capture.py', 'pure_controls.py')
AUTHORS = ['/root/https_acquisition_implementer', '/root']
FILE_MAX, PACK_MAX, RESERVE = 65536, 2097152, 131072
GENERATED = ('ca.key.pem', 'ca.cert.pem', 'server.key.pem', 'server.csr.pem',
             'server.cert.pem', 'wrong-host.key.pem', 'wrong-host.csr.pem', 'wrong-host.cert.pem')
NEW_OUTPUTS = (GENERATED[:2], GENERATED[2:4], (GENERATED[4],),
               GENERATED[5:7], (GENERATED[7],), (), (), (), (), (), ())


def need(ok, message):
    if not ok:
        raise ValueError(message)


def closed(value, keys):
    need(type(value) is dict and set(value) == set(keys), 'CLOSED_KEYS')


def decode(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            need(key not in value, 'DUPLICATE_JSON_KEY')
            value[key] = item
        return value
    return json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs,
                      parse_constant=lambda _: need(False, 'NONFINITE_JSON'))


def read_regular(path, limit=None):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'CANONICAL_PATH')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        st = os.fstat(fd)
        need(stat.S_ISREG(st.st_mode) and (limit is None or st.st_size <= limit), 'FILE_BOUND')
        data = bytearray()
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            data.extend(chunk)
            need(limit is None or len(data) <= limit, 'FILE_BOUND')
        need(os.fstat(fd).st_size == st.st_size and len(data) == st.st_size, 'FILE_CHANGED')
        return bytes(data)
    finally:
        os.close(fd)


def descriptor(path):
    raw = read_regular(path)
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def checked(value, limit=None):
    closed(value, ('path', 'bytes', 'sha256'))
    need(type(value['bytes']) is int and value['bytes'] >= 0 and
         re.fullmatch('[a-f0-9]{64}', value['sha256']) is not None, 'DESCRIPTOR')
    raw = read_regular(value['path'], limit)
    need(len(raw) == value['bytes'] and hashlib.sha256(raw).hexdigest() == value['sha256'], 'PIN_CHANGED')
    return raw


def verify_map(pins):
    need(type(pins) is dict and pins, 'PIN_MAP')
    for name, pin in pins.items():
        closed(pin, ('bytes', 'sha256'))
        checked({'path': name, **pin})


def utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write_new(path, raw):
    need(len(raw) <= FILE_MAX, 'RECORD_FILE_BOUND')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        view = memoryview(raw)
        while view:
            written = os.write(fd, view)
            need(written > 0, 'SHORT_WRITE')
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    return descriptor(path)


def encode(value):
    return (json.dumps(value, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def inspect_tree(final=False):
    allowed = set(GENERATED) | {'openssl.cnf', 'leaf-extensions.cnf', 'stdin.bin',
                                'execution.json', 'materialization.json'}
    allowed |= {f'TLS{i:02d}.{stream}' for i in range(1, 12) for stream in ('stdout', 'stderr')}
    total = 0
    root_stat = ROOT.lstat()
    need(stat.S_ISDIR(root_stat.st_mode) and stat.S_IMODE(root_stat.st_mode) == 0o700 and
         root_stat.st_uid == os.getuid(), 'OWNED_ROOT')
    for path in ROOT.iterdir():
        st = path.lstat()
        if path.name in ('providers-empty', 'engines-empty'):
            need(stat.S_ISDIR(st.st_mode) and stat.S_IMODE(st.st_mode) == 0o700 and
                 st.st_uid == os.getuid() and not any(path.iterdir()), 'EMPTY_PROVIDER_DIRECTORY')
        else:
            need(path.name in allowed and stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and
                 stat.S_IMODE(st.st_mode) == 0o600 and st.st_uid == os.getuid() and
                 st.st_size <= FILE_MAX, 'OWNED_FILE')
            total += st.st_size
    need(total <= (PACK_MAX if final else PACK_MAX - RESERVE), 'PACK_BOUND')
    return total


def admit(release_path, release_sha):
    need(Path(release_path).is_absolute() and re.fullmatch('[a-f0-9]{64}', release_sha), 'PRIVATE_CLI')
    release_d = descriptor(Path(release_path))
    need(release_d['bytes'] <= FILE_MAX and release_d['sha256'] == release_sha, 'EXTERNAL_RELEASE_SHA')
    release = decode(checked(release_d, FILE_MAX))
    closed(release, ('schema', 'decision', 'rootSession', 'output', 'sourcePins',
                     'toolClosure', 'sourceReviews', 'authors'))
    need(release['schema'] == 'e06-isolated-tls-materialization-release-v1' and
         release['decision'] == 'RELEASE_EXACT_ELEVEN_OFFLINE_TLS_STAGES' and
         release['rootSession'] == '/root' and release['output'] == str(ROOT) and
         release['authors'] == AUTHORS, 'RUNTIME_RELEASE_REQUIRED')
    need(set(release['sourcePins']) == {str(HERE / name) for name in SOURCE_NAMES}, 'EXACT_SOURCE_SET')
    verify_map(release['sourcePins'])
    recipe = decode(read_regular(HERE / 'recipe.json', FILE_MAX))
    need(recipe['sourceNames'] == list(SOURCE_NAMES) and recipe['outer'] == {
        'output': '/tmp/nbdp-e06-https-tls-outer-r2', 'wholeSeconds': 195, 'workSeconds': 190,
        'cleanupSeconds': 5, 'stdoutBytes': FILE_MAX, 'stderrBytes': FILE_MAX,
        'fileBytes': FILE_MAX, 'packBytes': 196608}, 'SEVEN_SOURCES_AND_FIXED_OUTER')
    research = decode(checked(recipe['research'], FILE_MAX))
    need(recipe['schema'] == 'e06-isolated-tls-recipe-v1' and recipe['state'] == 'NOT_EXECUTED' and
         recipe['output'] == str(ROOT) and recipe['limits'] == {
             'childSeconds': 30, 'phaseSeconds': 180, 'cleanupSeconds': 5,
             'stdoutBytes': FILE_MAX, 'stderrBytes': FILE_MAX, 'fileBytes': FILE_MAX,
             'packBytes': PACK_MAX, 'finalRecordReserveBytes': RESERVE}, 'FIXED_RECIPE')
    old = research['futureRoot']
    expected_operations = [{**op, 'argv': [s.replace(old, str(ROOT)) for s in op['argv']]}
                           for op in research['futureSubprocesses']]
    need(recipe['operations'] == expected_operations and len(expected_operations) == 11, 'EXACT_ELEVEN_ARGV')
    need(recipe['environment'] == {k: v.replace(old, str(ROOT))
                                  for k, v in research['futureEnvironment'].items()}, 'REPLACEMENT_ENVIRONMENT')
    need(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode and
         dict(os.environ) == recipe['environment'], 'ISOLATED_CONTROLLER_REPLACEMENT_ENVIRONMENT')
    for name, text in research['futureConfigs'].items():
        need(read_regular(HERE / name, FILE_MAX) == text.encode(), 'LITERAL_OPENSSL_CONFIGURATION')
    tool_closure = {p['path']: {k: p[k] for k in ('bytes', 'sha256')} for p in research['pins']}
    python = recipe['python']
    checked(python)
    need(Path(sys.executable).resolve() == Path(python['path']), 'PINNED_CONTROLLER_PYTHON')
    tool_closure[python['path']] = {k: python[k] for k in ('bytes', 'sha256')}
    need(recipe['toolClosure'] == tool_closure == release['toolClosure'], 'EXACT_TOOL_CLOSURE')
    verify_map(tool_closure)
    need(not os.path.lexists('/etc/ld.so.preload'), 'UNREVIEWED_LOADER_PRELOAD')
    subjects = {**release['sourcePins'], **tool_closure}
    pack = decode(checked(release['sourceReviews'], FILE_MAX))
    closed(pack, ('schema', 'decision', 'subjects', 'reviews'))
    need(pack['schema'] == 'e06-https-current-source-reviews-v1' and
         pack['decision'] == 'ACCEPT_CURRENT_SOURCES_ONLY' and pack['subjects'] == subjects and
         type(pack['reviews']) is list and len(pack['reviews']) == 2, 'SOURCE_REVIEWS')
    need({r['role'] for r in pack['reviews']} == {'qa', 'security'} and
         len({r['session'] for r in pack['reviews']}) == 2, 'TWO_REVIEWERS')
    for review in pack['reviews']:
        closed(review, ('role', 'session', 'decision', 'subjects'))
        need(type(review['session']) is str and review['session'] not in AUTHORS and
             review['decision'] == 'ACCEPT_SOURCE_ONLY' and review['subjects'] == subjects, 'INDEPENDENT_REVIEW')
    return release, release_d, recipe


def observe_owned_exit(child, ownership, waitid=os.waitid):
    """Observe without releasing the owned leader's numeric PID (WNOWAIT)."""
    need(child is not None and child.returncode is None and ownership['confirmed'], 'LEADER_OWNERSHIP_UNKNOWN')
    try:
        event = waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    except BaseException:
        ownership['confirmed'] = False
        raise
    if event is not None:
        if getattr(event, 'si_pid', None) != child.pid:
            ownership['confirmed'] = False
            raise ValueError('WRONG_WAITID_CHILD')
    return event is not None


def signal_owned(child, ownership, signal_group=os.killpg, waitid=os.waitid):
    """Accepted cleanup_owned guard derivative; never signal a reaped PID.

    Sole-thread WNOWAIT observations retain ownership until explicit final wait.
    A failed ownership observation disables group operations rather than guessing.
    """
    state = {'forced': False, 'terminationAttempted': False, 'cleanupErrors': []}
    if child is not None and child.returncode is None and ownership['confirmed']:
        try:
            observe_owned_exit(child, ownership, waitid)
            state['terminationAttempted'] = True
            signal_group(child.pid, signal.SIGKILL)
            state['forced'] = True
        except BaseException as error:
            state['cleanupErrors'].append(type(error).__name__ + ': ' + str(error))
    return state


def reap_observed(child, ownership, lifecycle):
    # This is the single reap location. All numeric group operations must already
    # be over. No group inspection or signaling occurs after this call.
    need(ownership['confirmed'] and lifecycle['leaderExitObserved'] and child.returncode is None,
         'REAP_REQUIRES_OWNED_OBSERVED_LEADER')
    lifecycle['ownershipRetainedUntilReap'] = True
    rc = child.wait(timeout=0)
    ownership['confirmed'] = False
    lifecycle['reaped'] = True
    lifecycle['exitCode'] = rc if rc >= 0 else None
    lifecycle['signal'] = None if rc >= 0 else -rc


def native_call(operation, ordinal, environment, phase_deadline, calls):
    out = ROOT / (operation['id'] + '.stdout')
    err = ROOT / (operation['id'] + '.stderr')
    life = {'launchAttempted': False, 'acquisition': 'NOT_ATTEMPTED', 'pid': None,
            'exitCode': None, 'signal': None, 'reaped': False, 'stdoutEOF': False,
            'stderrEOF': False, 'forced': False, 'forceAttempted': False,
            'timedOut': False, 'streamOverflow': False, 'leaderExitObserved': False,
            'ownershipRetainedUntilReap': False, 'ownedCleanupQualified': False,
            'stdoutObservedBytes': 0, 'stderrObservedBytes': 0, 'error': None,
            'cleanupErrors': [], 'startedUTC': utc_now(), 'finishedUTC': None}
    call = {'ordinal': ordinal, 'argv': operation['argv'], 'cwd': str(ROOT),
            'stdin': descriptor(ROOT / 'stdin.bin'), 'stdout': None, 'stderr': None, 'lifecycle': life}
    calls.append(call)  # Preserve partial acquisition/capture failures in caller.
    handles, child, sel = {}, None, selectors.DefaultSelector()
    ownership, forced_at = {'confirmed': False}, None
    retained = {'stdout': 0, 'stderr': 0}

    def force_once():
        nonlocal forced_at
        if forced_at is None:
            forced_at = time.monotonic()
            state = signal_owned(child, ownership)
            life['forceAttempted'] = state['terminationAttempted']
            life['forced'] = state['forced']
            life['cleanupErrors'].extend(state['cleanupErrors'])

    def drain_once():
        for key, _ in sel.select(0.025):
            name = key.data
            try:
                chunk = os.read(key.fileobj.fileno(), 65536)
            except BlockingIOError:
                continue
            if not chunk:
                life[name + 'EOF'] = True
                sel.unregister(key.fileobj)
                key.fileobj.close()
                continue
            life[name + 'ObservedBytes'] += len(chunk)
            view = memoryview(chunk[:max(0, FILE_MAX - retained[name])])
            while view:
                count = os.write(handles[name], view)
                need(count > 0, 'STREAM_SHORT_WRITE')
                view = view[count:]
                retained[name] += count
            if life[name + 'ObservedBytes'] > FILE_MAX:
                life['streamOverflow'] = True

    def observe():
        life['leaderExitObserved'] = observe_owned_exit(child, ownership)

    try:
        for name, target in [('stdout', out), ('stderr', err)]:
            handles[name] = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        need(time.monotonic() < phase_deadline, 'PHASE_DEADLINE_BEFORE_LAUNCH')
        with open(ROOT / 'stdin.bin', 'rb', buffering=0) as stdin:
            life['launchAttempted'], life['acquisition'] = True, 'UNKNOWN'
            child = subprocess.Popen(operation['argv'], cwd=ROOT, env=environment, stdin=stdin,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     shell=False, close_fds=True, start_new_session=True)
        life['pid'], life['acquisition'], ownership['confirmed'] = child.pid, 'ACQUIRED', True
        for name, pipe in [('stdout', child.stdout), ('stderr', child.stderr)]:
            os.set_blocking(pipe.fileno(), False)
            sel.register(pipe, selectors.EVENT_READ, name)
        child_deadline = min(time.monotonic() + 30, phase_deadline)
        while True:
            observe()  # Never poll()/wait() while further group cleanup may occur.
            if life['leaderExitObserved'] and not sel.get_map():
                break
            if time.monotonic() >= child_deadline:
                life['timedOut'] = True
            if life['timedOut'] or life['streamOverflow']:
                force_once()
            if forced_at is not None and time.monotonic() >= forced_at + 5:
                raise TimeoutError('EOF_OR_EXIT_OBSERVATION_UNCERTAIN')
            drain_once()
            inspect_tree()
    except BaseException as error:
        life['error'] = {'name': type(error).__name__, 'message': str(error),
                         'errno': getattr(error, 'errno', None)}
    finally:
        # Cleanup while the owned leader remains unreaped. One absolute five-
        # second allowance includes both ordinary and exceptional cleanup paths.
        if child is not None and child.returncode is None:
            try:
                if not (life['leaderExitObserved'] and not sel.get_map()):
                    force_once()
                    until = forced_at + 5
                    while time.monotonic() < until:
                        observe()
                        if life['leaderExitObserved'] and not sel.get_map():
                            break
                        drain_once()
                if ownership['confirmed'] and life['leaderExitObserved']:
                    reap_observed(child, ownership, life)
            except BaseException as error:
                life['cleanupErrors'].append(type(error).__name__ + ': ' + str(error))
        # No numeric PID/PGID operation from here onward. Unknown live ownership
        # remains unreaped/UNQUALIFIED for the outer observer; never invent EOF.
        for key in list(sel.get_map().values()):
            key.fileobj.close()
        sel.close()
        for fd in handles.values():
            os.fsync(fd)
            os.close(fd)
        if out.exists():
            call['stdout'] = descriptor(out)
        if err.exists():
            call['stderr'] = descriptor(err)
        life['ownedCleanupQualified'] = bool(life['reaped'] and life['leaderExitObserved'] and
            life['ownershipRetainedUntilReap'] and life['stdoutEOF'] and life['stderrEOF'] and
            not life['forceAttempted'] and not life['forced'] and not life['cleanupErrors'])
        life['finishedUTC'] = utc_now()
    return call


def validate_call(call, ordinal):
    life = call['lifecycle']
    need(life['acquisition'] == 'ACQUIRED' and life['reaped'] and life['stdoutEOF'] and life['stderrEOF'] and
         not life['forced'] and not life['streamOverflow'] and life['signal'] is None and
         life['error'] is None and life['ownedCleanupQualified'] is True, 'NATIVE_LIFECYCLE_UNQUALIFIED')
    stdout, stderr = checked(call['stdout'], FILE_MAX), checked(call['stderr'], FILE_MAX)
    if ordinal < 10:
        need(life['exitCode'] == 0, 'EXPECTED_NATURAL_ZERO')
    else:
        need(type(life['exitCode']) is int and life['exitCode'] > 0 and len(stdout) + len(stderr) <= FILE_MAX,
             'EXPECTED_SPECIFIC_HOSTNAME_REFUSAL')
        lines = stderr.splitlines()
        need(stdout == b'' and len(lines) == 3 and
             re.fullmatch(rb'CN\s*=\s*wrong\.files\.invalid', lines[0]) is not None and
             lines[1] == b'error 62 at 0 depth lookup: hostname mismatch' and
             lines[2] == b'error ' + str(ROOT / 'wrong-host.cert.pem').encode() + b': verification failed',
             'NOT_THE_SPECIFIC_NATIVE_HOSTNAME_MISMATCH')
    if ordinal in (8, 9):
        target = 'server.cert.pem' if ordinal == 8 else 'wrong-host.cert.pem'
        need(stdout == (str(ROOT / target) + ': OK\n').encode() and stderr == b'', 'NATIVE_HOST_VERIFY_NOT_EXACT_OK')
    if ordinal in (5, 6, 7):
        need(stderr == b'', 'CERT_INSPECTION_STDERR')


def validated_extensions(text, san):
    """Parse only individual entries inside one native enclosing section.

    The enclosing 'X509v3 extensions:' is structural evidence, never an entry.
    Unexpected headers/indentation, duplicates, missing and unknown entries fail.
    """
    need(type(text) is str and len(text) <= FILE_MAX, 'EXTENSION_TEXT_BOUND')
    lines = text.splitlines()
    containers = [(index, match) for index, line in enumerate(lines)
                  if (match := re.fullmatch(r'([ \t]*)X509v3 extensions:[ \t]*', line))]
    need(len(containers) == 1, 'ONE_X509_EXTENSION_SECTION')
    begin, container = containers[0]
    container_indent = len(container[1])
    extensions, current, value_lines, current_indent, closed_section = {}, None, [], None, False

    def finish_entry():
        if current is not None:
            key, critical = current
            need(key not in extensions and value_lines, 'DUPLICATE_OR_EMPTY_X509_EXTENSION')
            extensions[key] = (critical, ' '.join(' '.join(value_lines).split()))

    for line in lines[begin + 1:]:
        if not line.strip():
            continue
        indentation = len(line) - len(line.lstrip(' \t'))
        if re.fullmatch(r'[ \t]*Signature Algorithm:.*', line):
            need(indentation <= container_indent, 'EXTENSION_SECTION_TERMINATOR')
            finish_entry(); closed_section = True
            break
        entry = re.fullmatch(r'([ \t]+)X509v3 ([^:\r\n]+):([^\r\n]*)', line)
        if entry is not None:
            need(len(entry[1]) > container_indent, 'INDIVIDUAL_EXTENSION_INDENT')
            finish_entry()
            current, current_indent = (entry[2].strip(), entry[3].strip()), len(entry[1])
            value_lines = []
        else:
            need(current is not None and indentation > current_indent, 'UNKNOWN_EXTENSION_LINE')
            value_lines.append(line.strip())
    need(closed_section, 'UNTERMINATED_EXTENSION_SECTION')
    expected = {'Basic Constraints': ('critical', 'CA:TRUE, pathlen:0' if san is None else 'CA:FALSE'),
                'Key Usage': ('critical', 'Certificate Sign, CRL Sign' if san is None else 'Digital Signature, Key Encipherment')}
    if san is not None:
        expected.update({'Extended Key Usage': ('', 'TLS Web Server Authentication'),
                         'Subject Alternative Name': ('', 'DNS:' + san)})
    need(set(extensions) == set(expected) | {'Subject Key Identifier'} |
         (set() if san is None else {'Authority Key Identifier'}), 'EXACT_X509_EXTENSION_SET')
    for key, value in expected.items():
        need(extensions[key] == value, 'EXACT_X509_EXTENSION_VALUE')
    ski = extensions['Subject Key Identifier']
    need(ski[0] == '' and re.fullmatch(r'(?:[0-9A-F]{2}:){19}[0-9A-F]{2}', ski[1]), 'X509_SKI')
    aki = None
    if san is not None:
        aki = extensions['Authority Key Identifier']
        need(aki[0] == '' and re.fullmatch(r'(?:[0-9A-F]{2}:){19}[0-9A-F]{2}', aki[1]), 'X509_AKI')
    return {'subjectKeyIdentifier': ski[1], 'authorityKeyIdentifier': None if aki is None else aki[1]}


def certificate_validity(text):
    """Parse the observed native English/GMT rows with exact known labels.

    This is locale independent. Calendar validation uses an explicit UTC
    datetime; integer arithmetic avoids platform time_t and float conversion.
    """
    need(type(text) is str and len(text) <= FILE_MAX, 'NATIVE_VALIDITY_BOUND')
    fields = {'Not Before': [], 'Not After': []}
    for line in text.splitlines():
        if line.lstrip(' ').startswith('Not '):
            match = re.fullmatch(r' {0,16}(Not Before|Not After) ?: (.+)', line)
            need(match is not None, 'NATIVE_VALIDITY_LABEL')
            fields[match[1]].append(match[2])
    need(all(len(values) == 1 for values in fields.values()), 'NATIVE_VALIDITY_UNIQUE_LABELS')
    months = {name: index for index, name in enumerate(
        ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'), 1)}
    epoch = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)
    result = {}
    for label, values in fields.items():
        match = re.fullmatch(r'([A-Za-z]{3}) ( [1-9]|[0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}) ([0-9]{4}) GMT', values[0])
        need(match is not None and match[1] in months, 'NATIVE_GMT_DATE_FORMAT')
        try:
            stamp = dt.datetime(int(match[6]), months[match[1]], int(match[2]),
                int(match[3]), int(match[4]), int(match[5]), tzinfo=dt.timezone.utc)
        except (ValueError, OverflowError) as error:
            raise ValueError('NATIVE_GMT_CALENDAR') from error
        delta = stamp - epoch
        value = (delta.days * 86400 + delta.seconds) * 1000
        need(abs(value) <= 9007199254740991, 'NATIVE_VALIDITY_OVERFLOW')
        result['notBefore' if label == 'Not Before' else 'notAfter'] = value
    return result


def inspect_certificate(call, name, serial, subject, issuer, san):
    text = checked(call['stdout'], FILE_MAX).decode('ascii', 'strict')
    def one(pattern):
        found = re.findall(pattern, text, re.MULTILINE)
        need(len(found) == 1, 'CERT_TEXT_FIELD_' + name)
        return found[0].strip()
    need(one(r'^\s*Version:\s*(.+)$') == '3 (0x2)', 'X509_VERSION')
    need(one(r'^\s*Serial Number:\s*(\d+ \(0x[0-9a-fA-F]+\))$') == f'{serial} (0x{serial:x})', 'X509_SERIAL')
    for label, wanted in [('Subject', subject), ('Issuer', issuer)]:
        actual = one(r'^\s*' + label + r':\s*(.+)$')
        need(re.sub(r'\s*=\s*', '=', actual) == 'CN=' + wanted, 'X509_DISTINGUISHED_NAME')
    need(one(r'^\s*Public Key Algorithm:\s*(.+)$') == 'rsaEncryption' and
         one(r'^\s*Public-Key:\s*(.+)$') == '(2048 bit)', 'X509_RSA_2048')
    signatures = re.findall(r'^\s*Signature Algorithm:\s*(.+)$', text, re.MULTILINE)
    need(signatures == ['sha256WithRSAEncryption', 'sha256WithRSAEncryption'], 'X509_SIGNATURE_ALGORITHMS')
    key_ids = validated_extensions(text, san)
    validity = certificate_validity(text)
    fingerprint = one(r'^\s*[Ss][Hh][Aa]256 Fingerprint=(.+)$')
    pem_name = {'ca': 'ca.cert.pem', 'server': 'server.cert.pem', 'wrongSan': 'wrong-host.cert.pem'}[name]
    pem = read_regular(ROOT / pem_name, FILE_MAX)
    match = re.fullmatch(rb'-----BEGIN CERTIFICATE-----\s+([A-Za-z0-9+/=\r\n]+)-----END CERTIFICATE-----\s*', pem)
    need(match is not None, 'SINGLE_PEM_CERTIFICATE')
    der = base64.b64decode(re.sub(rb'\s', b'', match[1]), validate=True)
    need(re.fullmatch(r'(?:[0-9A-F]{2}:){31}[0-9A-F]{2}', fingerprint) and
         fingerprint.replace(':', '').lower() == hashlib.sha256(der).hexdigest(), 'NATIVE_DER_FINGERPRINT')
    return {**validity, 'fingerprint': fingerprint, **key_ids}


def main():
    need(len(sys.argv) == 3, 'CLI_REQUIRES_ABSOLUTE_RELEASE_EXTERNAL_SHA')
    started, started_utc = time.monotonic(), utc_now()
    release, release_d, recipe = admit(sys.argv[1], sys.argv[2])
    # Atomic no-overwrite ownership boundary. Neither output nor keys are created
    # during SOURCE preparation; this code requires its later concrete release.
    os.umask(0o077)
    ROOT.mkdir(mode=0o700)
    calls, protected, certificates, failure = [], {}, {}, None
    native = {'schema': 'e06-isolated-cert-materialization-v1', 'qualified': False,
              'sourcePins': release['sourcePins'], 'toolClosure': release['toolClosure'],
              'sourceReviews': release['sourceReviews'], 'calls': calls,
              'outputs': None, 'validity': None, 'authors': AUTHORS}
    execution = {'schema': 'e06-isolated-tls-execution-v1', 'release': release_d,
                 'startedUTC': started_utc, 'finishedUTC': None, 'elapsedSeconds': None,
                 'limits': recipe['limits'], 'certificateInspection': certificates,
                 'error': None, 'postIntegrity': False, 'actualFileBytes': None}
    try:
        resource.setrlimit(resource.RLIMIT_FSIZE, (FILE_MAX, FILE_MAX))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        for name in ('providers-empty', 'engines-empty'):
            (ROOT / name).mkdir(mode=0o700)
        for name in ('openssl.cnf', 'leaf-extensions.cnf'):
            protected[name] = write_new(ROOT / name, read_regular(HERE / name, FILE_MAX))
        protected['stdin.bin'] = write_new(ROOT / 'stdin.bin', b'')
        for index, operation in enumerate(recipe['operations']):
            need(time.monotonic() - started < 180, 'PHASE_DEADLINE')
            verify_map(release['sourcePins']); verify_map(release['toolClosure'])
            need(not os.path.lexists('/etc/ld.so.preload'), 'UNREVIEWED_LOADER_PRELOAD')
            for pin in protected.values():
                checked(pin, FILE_MAX)
            for name in NEW_OUTPUTS[index]:
                need(not os.path.lexists(ROOT / name), 'NO_OUTPUT_OVERWRITE')
            inspect_tree()
            call = native_call(operation, index, recipe['environment'], started + 180, calls)
            validate_call(call, index)
            inspect_tree()
            for pin in protected.values():
                checked(pin, FILE_MAX)
            for name in NEW_OUTPUTS[index]:
                protected[name] = descriptor(ROOT / name)
            if index in (5, 6, 7):
                name, serial, subject, san = [('ca', 1, 'NBDP E06 disposable synthetic CA', None),
                    ('server', 2, 'files.invalid', 'files.invalid'),
                    ('wrongSan', 3, 'wrong.files.invalid', 'wrong.files.invalid')][index - 5]
                certificates[name] = inspect_certificate(call, name, serial, subject,
                    'NBDP E06 disposable synthetic CA', san)
        need(len(calls) == 11, 'EXACT_ELEVEN_COMPLETED')
        need(all(certificates[k]['authorityKeyIdentifier'] == certificates['ca']['subjectKeyIdentifier']
                 for k in ('server', 'wrongSan')), 'CA_KEY_IDENTIFIER_ASSOCIATION')
        before = {k: v['notBefore'] for k, v in certificates.items()}
        after = {k: v['notAfter'] for k, v in certificates.items()}
        now = int(time.time() * 1000)
        need(all(before[k] <= now < after[k] and after[k] - before[k] == 86400000
                 for k in before) and min(after.values()) - now >= 300000, 'ACTUAL_CURRENT_ONE_DAY_VALIDITY')
        native['outputs'] = {'ca': protected['ca.cert.pem'],
            'server': {'key': protected['server.key.pem'], 'cert': protected['server.cert.pem']},
            'wrongSan': {'key': protected['wrong-host.key.pem'], 'cert': protected['wrong-host.cert.pem']}}
        native['validity'] = {'notBefore': before, 'notAfter': after, 'earliestExpiry': min(after.values())}
        verify_map(release['sourcePins']); verify_map(release['toolClosure'])
        checked(release_d, FILE_MAX); checked(release['sourceReviews'], FILE_MAX)
        checked(recipe['research'], FILE_MAX)
        for pin in protected.values():
            checked(pin, FILE_MAX)
        inspect_tree()
        need(time.monotonic() - started < 180, 'PHASE_DEADLINE')
        execution['postIntegrity'] = True
        native['qualified'] = True
    except BaseException as error:
        failure = error
        execution['error'] = {'name': type(error).__name__, 'message': str(error), 'errno': getattr(error, 'errno', None)}
    finally:
        execution['finishedUTC'] = utc_now()
        execution['elapsedSeconds'] = time.monotonic() - started
        # Failure evidence stays partial and qualifiedfalse. No review or accepted
        # certificate envelope is manufactured by this materializer.
        execution['actualFileBytes'] = inspect_tree(final=True)
        need(execution['actualFileBytes'] + len(encode(execution)) + len(encode(native)) <= PACK_MAX, 'FINAL_PACK_BOUND')
        execution_d = write_new(ROOT / 'execution.json', encode(execution))
        # Publish the materialization only after execution evidence has actually
        # been written. This is never an independent acceptance/review envelope.
        materialization_d = write_new(ROOT / 'materialization.json', encode(native))
        inspect_tree(final=True)
        print(json.dumps({'qualified': native['qualified'], 'materialization': materialization_d,
                          'execution': execution_d}, separators=(',', ':')))
    return 0 if native['qualified'] and failure is None else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except BaseException as error:
        if isinstance(error, SystemExit):
            raise
        sys.stderr.write(json.dumps({'name': type(error).__name__, 'message': str(error),
                                     'errno': getattr(error, 'errno', None)}) + '\n')
        sys.exit(1)
