// SOURCE ONLY / NOT_EXECUTED. No import-time target, crypto or browser work.
// The existing shared API is imported only after private ownership and pins pass.
// Protected classifier copied verbatim (including indentation/trailing LF) from
// recovery_subset_barecall_admitted_v2.mjs (44796B/84ce438fa49ae9ef5f1f5a4b7c8360c38f1fad6b9ea6d9a4efc8b2631aa62ac6).
// Classifier: 2937B/c6a5135c877f2cb041b4c7ac515795826097f6ba520e00e89bffa2ca3a5b5840.
// Shared source: 4164B/e52aaa588b4ff6315bbc7ebc08b2d8786965687e18c6c9f56a75d4b08cc05f16.
// No admitted worker import: its top-level bootstrap is not a reusable API.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {inspect} from 'node:util';
import {performance} from 'node:perf_hooks';
import {getAuthenticated,readSnapshot,assertCurrent,publishConsumerFact,getConsumerFact} from './protocol.mjs';

const HERE=path.dirname(fileURLToPath(import.meta.url));
const CRYPTO_PATH=path.resolve(HERE,'../../shared/attachment-crypto.mjs');
const CRYPTO_PIN={bytes:4164,sha256:'e52aaa588b4ff6315bbc7ebc08b2d8786965687e18c6c9f56a75d4b08cc05f16'};
const MAX_RECORD=16777216;
function need(ok,reason){if(!ok)throw Error(reason);}
function sha256(bytes){return createHash('sha256').update(bytes).digest('hex');}
function clone(value){return JSON.parse(JSON.stringify(value));}
function errorText(error){
  try{return typeof error?.stack==='string'?error.stack:inspect(error,{customInspect:false,getters:false,depth:4,maxArrayLength:64});}
  catch{return '[UNREADABLE_THROWN_VALUE]';}
}
function rawError(error){
  const prop=name=>{try{const value=error?.[name];return value===undefined?null:String(value);}catch{return '[UNREADABLE_PROPERTY]';}};
  return {type:typeof error,name:prop('name'),message:prop('message'),code:prop('code'),stack:prop('stack'),raw:errorText(error)};
}
function browserReceipt(){
  return {started:false,startError:null,version:null,requests:[],browserCloseAttempted:false,
    browserCloseSucceeded:null,browserCloseError:null,serverCloseAttempted:false,
    serverCloseSucceeded:null,serverCloseError:null,cleanupUncertain:false};
}
async function bounded(promise,milliseconds,label){
  need(Number.isFinite(milliseconds)&&milliseconds>0,'HTTPS_CONSUMER_UNFROZEN_TIMER');
  let timer;
  try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(label)),milliseconds);})]);}
  finally{clearTimeout(timer);}
}

// Adaptation of the accepted durable attempt-before-call/final journal pattern.
// Counts refer only to this actual one-call component, never historical18/26.
class AttemptJournal{
  #name;#fd=null;#value;
  constructor(ctx,subject,snapshot){
    this.#name=path.join(ctx.outputDir,'engine-attempt.json');
    this.#value={schema:'e06-https-engine-attempt-v1',id:ctx.id,route:ctx.route,
      subject:clone(subject),snapshot:clone(snapshot),fileConsumerCalls:0,attachmentEncryptions:0,
      outcome:'NOT_CALLED',nativeError:null,componentError:null,captureErrors:[],finalized:false};
    this.#fd=fs.openSync(this.#name,fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);
    try{this.#write();}catch(error){fs.closeSync(this.#fd);this.#fd=null;throw error;}
  }
  #write(){
    need(this.#fd!==null,'HTTPS_CONSUMER_JOURNAL_CLOSED');
    const opened=fs.fstatSync(this.#fd),named=fs.lstatSync(this.#name);
    need(opened.isFile()&&named.isFile()&&!named.isSymbolicLink()&&opened.dev===named.dev&&opened.ino===named.ino,'HTTPS_CONSUMER_JOURNAL_FILE');
    const raw=Buffer.from(JSON.stringify(this.#value)+'\n');
    need(raw.length<=MAX_RECORD,'HTTPS_CONSUMER_JOURNAL_BOUND');
    let offset=0;while(offset<raw.length){const n=fs.writeSync(this.#fd,raw,offset,raw.length-offset,offset);need(n>0,'HTTPS_CONSUMER_JOURNAL_WRITE');offset+=n;}
    fs.ftruncateSync(this.#fd,raw.length);fs.fsyncSync(this.#fd);
  }
  begin(){
    need(this.#value.fileConsumerCalls===0&&this.#value.outcome==='NOT_CALLED'&&!this.#value.finalized,'HTTPS_CONSUMER_JOURNAL_ONCE');
    this.#value.fileConsumerCalls=1;this.#value.outcome='PENDING';this.#write();
  }
  returned(){need(this.#value.outcome==='PENDING','HTTPS_CONSUMER_JOURNAL_RETURN');this.#value.outcome='RETURNED';this.#write();}
  threw(error){need(this.#value.outcome==='PENDING','HTTPS_CONSUMER_JOURNAL_THROW');this.#value.outcome='THREW';this.#value.nativeError=rawError(error);this.#write();}
  failed(error){this.#value.componentError??=rawError(error);this.#write();}
  captureFailed(error){this.#value.captureErrors.push(rawError(error));}
  snapshot(){return clone(this.#value);}
  finalize(){try{this.#value.finalized=true;this.#write();}finally{if(this.#fd!==null){fs.closeSync(this.#fd);this.#fd=null;}}}
}

async function pinnedCrypto(ctx){
  await assertCurrent(ctx);
  const pin=ctx.sourcePins[CRYPTO_PATH];
  need(pin?.bytes===CRYPTO_PIN.bytes&&pin.sha256===CRYPTO_PIN.sha256,'HTTPS_CONSUMER_CRYPTO_MEMBER');
  const stat=fs.lstatSync(CRYPTO_PATH);need(stat.isFile()&&!stat.isSymbolicLink()&&stat.size===CRYPTO_PIN.bytes,'HTTPS_CONSUMER_CRYPTO_FILE');
  const raw=fs.readFileSync(CRYPTO_PATH);
  need(raw.length===CRYPTO_PIN.bytes&&sha256(raw)===CRYPTO_PIN.sha256,'HTTPS_CONSUMER_CRYPTO_PIN');
  return import(pathToFileURL(CRYPTO_PATH).href);
}

// These are the accepted start/close adapters, with explicit millisecond limits
// and ownership confirmations. BrowserCrypto itself is used unchanged, including
// its original evaluate source/lineage on which the strict classifier depends.
async function startBrowser(instance,receipt,operation){
  let expired=false,rejectListen;
  const failedListen=new Promise((_,reject)=>{rejectListen=reject;});
  const started=instance.start(); // Existing source creates server before await.
  if(instance.server)instance.server.on('error',error=>rejectListen(error));
  const tracked=Promise.resolve(started).then(()=>{if(expired){receipt.cleanupUncertain=true;throw Error('HTTPS_CONSUMER_LATE_BROWSER_START');}});
  try{
    await operation(Promise.race([tracked,failedListen]),30000,'HTTPS_CONSUMER_BROWSER_START_DEADLINE');
    need(instance.browser?.isConnected()===true&&instance.page?.isClosed()===false,'HTTPS_CONSUMER_BROWSER_OPEN');
    receipt.started=true;receipt.version=instance.browser.version();
    need(typeof receipt.version==='string'&&receipt.version.isWellFormed(),'HTTPS_CONSUMER_BROWSER_VERSION');
  }catch(error){expired=true;receipt.startError=errorText(error);receipt.cleanupUncertain=true;throw error;}
  finally{tracked.catch(()=>{});}
}
async function closeOwnedBrowser(instance,receipt){
  // Do not use chained BrowserCrypto.close: its browser throw skips server.close.
  // Independent attempts preserve BOTH actual errors; this server is the browser
  // helper's loopback server, separate from acquisition's HTTPS5s cleanup.
  if(instance.browser){
    receipt.browserCloseAttempted=true;
    try{await bounded(instance.browser.close(),15000,'HTTPS_CONSUMER_BROWSER_CLOSE_DEADLINE');need(instance.browser.isConnected()===false,'HTTPS_CONSUMER_BROWSER_CLOSE_UNCONFIRMED');receipt.browserCloseSucceeded=true;}
    catch(error){receipt.browserCloseSucceeded=false;receipt.browserCloseError=errorText(error);receipt.cleanupUncertain=true;}
  }
  if(instance.server){
    receipt.serverCloseAttempted=true;
    try{
      await bounded(new Promise((resolve,reject)=>instance.server.close(error=>error?reject(error):resolve())),5000,'HTTPS_CONSUMER_BROWSER_SERVER_CLOSE_DEADLINE');
      need(instance.server.listening===false,'HTTPS_CONSUMER_SERVER_CLOSE_UNCONFIRMED');receipt.serverCloseSucceeded=true;
    }catch(error){receipt.serverCloseSucceeded=false;receipt.serverCloseError=errorText(error);receipt.cleanupUncertain=true;}
  }
  if(Array.isArray(instance.requests)){
    // Bound construction before serializing any complete requests array. The
    // partial prefix is evidence only; overflow always leaves uncertainty.
    let retainedBytes=2,overflow=instance.requests.length>64;
    for(const request of instance.requests.slice(0,64)){
      if(typeof request!=='string'||request.length>4096){overflow=true;break;}
      const added=Buffer.byteLength(JSON.stringify(request))+(receipt.requests.length?1:0);
      if(retainedBytes+added>16384){overflow=true;break;}
      receipt.requests.push(request);retainedBytes+=added;
    }
    if(overflow){receipt.cleanupUncertain=true;throw Error('HTTPS_CONSUMER_BROWSER_REQUEST_EVIDENCE_BOUND');}
  }

}

      function classifyNativeFailure(route,error){
        // Fixed-build sampled Error shape and engine-owned prefix only. Caller
        // stack suffixes vary; no expected result, case ID or external predicate.
        // This pure definition depends only on its two explicit inputs and JS
        // intrinsics, so later reviewed controls can use these exact source bytes.
        try{
          // Constructor name and property facts were captured; descriptor/getter
          // attributes and cross-realm prototype identity were not observed.
          if(error===null||typeof error!=='object'||error.constructor?.name!=='Error'||'code' in error)return null;
          const node=route==='JS_NODE_EVP',web=route==='RUST_CHROME_WEBCRYPTO';
          if(!node&&!web)return null;
          const keys=Reflect.ownKeys(error),wanted=node?['stack','message']:['stack','message','name'];
          if(keys.length!==wanted.length||!wanted.every(key=>keys.includes(key))
              ||Object.hasOwn(error,'name')!==web||error.name!=='Error'
              ||typeof error.message!=='string'||typeof error.stack!=='string'
              ||!error.message.isWellFormed()||!error.stack.isWellFormed())return null;
          const message=error.message,stack=error.stack;
          let refusal=null,prefix=null;
          if(node&&message==='Unsupported state or unable to authenticate data'){
            // Even the exact sampled final/decrypt stack cannot distinguish
            // invalid authentication from provider/operational rejection.
            // Preserve the raw throw and attempted1; no AEAD cause is proved.
            return null;
          }else if(node&&message==='plaintext commitment'){
            refusal='ORIGINAL_HASH';
            prefix='Error: plaintext commitment\n'
              +'    at consumeAttachment (file:///home/peterhorvath/apps/bitcoin/NBDP/experiments/shared/attachment-crypto.mjs:22:93)\n    at ';
          }else if(web&&message==='page.evaluate: OperationError\n'
              +'    at eval (eval at evaluate (:302:30), <anonymous>:4:112)\n'
              +'    at async <anonymous>:328:30'){
            // This exact OperationError/decrypt prefix is also ambiguous;
            // engine rejection alone does not establish an invalid tag.
            return null;
          }else if(web&&message==='page.evaluate: Error: plaintext commitment\n'
              +'    at eval (eval at evaluate (:302:30), <anonymous>:5:85)\n'
              +'    at async <anonymous>:328:30'){
            refusal='ORIGINAL_HASH';
            prefix=message+'\n    at BrowserCrypto.consume (/home/peterhorvath/apps/bitcoin/NBDP/experiments/shared/attachment-crypto.mjs:44:20)\n    at ';
          }
          if(refusal===null||!stack.startsWith(prefix)||stack.length===prefix.length)return null;
          return {kind:'QUALIFIED_NATIVE_REFUSAL',refusal,fileConsumerCalls:1};
        }catch{return null;}
      }

export async function consumeOriginal(authenticatedHandle,snapshotHandle,caseContext){
  // Parent's WeakMaps establish same-case, actual metadata authentication and
  // one actual received immutable body. No public verified token is accepted.
  const ctx=caseContext,auth=getAuthenticated(authenticatedHandle,ctx);
  const snapshot=readSnapshot(authenticatedHandle,snapshotHandle,ctx),subject=auth.subject;
  need(snapshot.subject===subject,'HTTPS_CONSUMER_SNAPSHOT_SUBJECT');
  need(Object.isFrozen(ctx)&&Object.isFrozen(auth)&&Object.isFrozen(subject),'HTTPS_CONSUMER_PRIVATE_OWNERSHIP');
  const fact={schema:'e06-https-native-consumer-fact-v1',route:ctx.route,status:'UNQUALIFIED',
    stage:'CONSUMER',reason:'NOT_COMPLETED',originalHex:null,fileConsumerCalls:0,attachmentEncryptions:0,
    journal:null,browser:browserReceipt(),cleanupQualified:true,record:null};
  // Parent must also enforce the120s owned case-process deadline: JS timers do
  // not interrupt synchronous Node EVP, pin hashing, fsync or module evaluation.
  // A timed-out start can expose a late browser handle; uncertainty remains true
  // even if presently visible browser/server closes return. No containment claim.
  const deadline=performance.now()+100000; // 100s operation + independent15s/5s =120s.
  const operation=(promise,maximum,label)=>bounded(promise,Math.min(maximum,deadline-performance.now()),label);
  let journal=null,instance=null,failed=false,failure;
  try{
    need(['NodeEVP','ChromeWebCrypto'].includes(ctx.route),'HTTPS_CONSUMER_ROUTE');
    need(ctx.profile.timersMs.consumer===120000&&ctx.profile.timersMs.browserStart===30000
      &&ctx.profile.timersMs.browserClose===15000&&ctx.profile.timersMs.browserServerClose===5000,'HTTPS_CONSUMER_PROFILE_TIMERS');
    need(Buffer.isBuffer(snapshot.bytes)&&snapshot.bytes.length===20&&snapshot.descriptor.bytes===20
      &&subject.blobBytes===20&&subject.bytes===4&&subject.blobBytes-16===subject.bytes,'HTTPS_CONSUMER_RECEIVED_COUNT');
    need(snapshot.descriptor.sha256===subject.x&&sha256(snapshot.bytes)===subject.x,'HTTPS_CONSUMER_RECEIVED_HASH');
    need(/^[0-9a-f]{64}$/.test(subject.key)&&/^[0-9a-f]{24}$/.test(subject.nonce)
      &&/^[0-9a-f]{64}$/.test(subject.x)&&/^[0-9a-f]{64}$/.test(subject.ox),'HTTPS_CONSUMER_AUTHENTICATED_TUPLE');
    journal=new AttemptJournal(ctx,subject,snapshot.descriptor);
    const tuple={key:subject.key,nonce:subject.nonce,blob:snapshot.bytes,x:subject.x,ox:subject.ox,bytes:subject.blobBytes-16};
    const crypto=await operation(pinnedCrypto(ctx),100000,'HTTPS_CONSUMER_IMPORT_DEADLINE');
    let original=null,refusal=null;
    if(ctx.route==='NodeEVP'){
      const {consumeAttachment}=crypto;need(typeof consumeAttachment==='function','HTTPS_CONSUMER_EXISTING_NODE_API');
      journal.begin(); // Durable attempt BEFORE accepted bare local API call.
      try{original=consumeAttachment(tuple);}
      catch(caught){
        try{journal.threw(caught);}catch(captureError){journal.captureFailed(captureError);fact.cleanupQualified=false;throw caught;}
        refusal=classifyNativeFailure('JS_NODE_EVP',caught);if(refusal===null)throw caught;
      }
      if(refusal===null)journal.returned();
    }else{
      const profile=ctx.browserProfile;
      need(profile?.schema==='e06-recovery-browser-profile-v1'&&profile.engine==='Chrome WebCrypto/BoringSSL'
        &&profile.executable?.path==='/opt/google/chrome/chrome'&&process.env.NBDP_CHROME===profile.executable.path
        &&profile.cryptoSource?.path===CRYPTO_PATH&&profile.cryptoSource.bytes===CRYPTO_PIN.bytes
        &&profile.cryptoSource.sha256===CRYPTO_PIN.sha256,'HTTPS_CONSUMER_BROWSER_PROFILE');
      await operation(assertCurrent(ctx),100000,'HTTPS_CONSUMER_BROWSER_PIN_DEADLINE');
      need(typeof crypto.BrowserCrypto==='function','HTTPS_CONSUMER_EXISTING_BROWSER_API');
      instance=new crypto.BrowserCrypto();await startBrowser(instance,fact.browser,operation);
      need(instance.browser.isConnected()===true&&instance.page.isClosed()===false,'HTTPS_CONSUMER_NATIVE_PAGE_PRECONDITIONS');
      journal.begin();
      // Tag settlement separately: a harness timeout is PENDING, not native THREW.
      let settled=false,closed=false;
      const actual=Promise.resolve().then(()=>instance.consume(tuple)).then(
        value=>({returned:true,value}),error=>({returned:false,error}));
      let observed;
      try{observed=await operation(actual,100000,'HTTPS_CONSUMER_NATIVE_DEADLINE');settled=true;}
      finally{closed=true;if(!settled){fact.browser.cleanupUncertain=true;actual.then(()=>{if(closed)fact.browser.cleanupUncertain=true;});}}
      if(!observed.returned){
        try{journal.threw(observed.error);}catch(captureError){journal.captureFailed(captureError);fact.cleanupQualified=false;throw observed.error;}
        refusal=classifyNativeFailure('RUST_CHROME_WEBCRYPTO',observed.error);if(refusal===null)throw observed.error;
      }
      else{
        journal.returned();const hex=observed.value;
        need(typeof hex==='string'&&hex.length%2===0&&!/[^0-9a-f]/.test(hex),'HTTPS_CONSUMER_BROWSER_ORIGINAL_HEX');original=Buffer.from(hex,'hex');
      }
    }
    if(refusal!==null){
      // The exact classifier currently qualifies ORIGINAL_HASH only; both
      // authentication branches are deliberately null and unknown throws rethrow.
      need(refusal.kind==='QUALIFIED_NATIVE_REFUSAL'&&refusal.refusal==='ORIGINAL_HASH'&&refusal.fileConsumerCalls===1,'HTTPS_CONSUMER_NATIVE_REFUSAL');
      fact.status='REFUSED';fact.stage='ORIGINAL_COMMITMENT';fact.reason='ORIGINAL_HASH';
    }else{
      need(Buffer.isBuffer(original)&&original.length===subject.bytes&&original.length===tuple.bytes,'HTTPS_CONSUMER_RETURNED_ORIGINAL_COUNT');
      need(sha256(original)===subject.ox,'HTTPS_CONSUMER_RETURNED_ORIGINAL_HASH');
      need(tuple.blob===snapshot.bytes&&sha256(tuple.blob)===subject.x,'HTTPS_CONSUMER_SAME_BYTES_AFTER_CALL');
      fact.status='VERIFIED_BYTES';fact.stage='ORIGINAL_COMMITMENT';fact.reason='EXACT_ORIGINAL_NO_DURABILITY_CLAIM';fact.originalHex=original.toString('hex');
    }
    await operation(assertCurrent(ctx),100000,'HTTPS_CONSUMER_FINAL_PIN_DEADLINE');
  }catch(caught){
    failed=true;failure=caught;fact.status='UNQUALIFIED';fact.reason='RAW_COMPONENT_FAILURE';
    // A completed internal original remains an actual fact even if final pins or
    // cleanup fail. Acquisition may release only when this whole fact qualifies.
    if(journal)try{journal.failed(caught);}catch(captureError){journal.captureFailed(captureError);fact.cleanupQualified=false;}
  }finally{
    if(instance)try{await closeOwnedBrowser(instance,fact.browser);}catch(caught){
      fact.browser.cleanupUncertain=true;fact.cleanupQualified=false;
      if(journal)try{journal.failed(caught);}catch(captureError){journal.captureFailed(captureError);}
      if(!failed){failed=true;failure=caught;}
    }
    if(fact.browser.cleanupUncertain)fact.cleanupQualified=false;
    // Finalize even after browser cleanup failure; finalization is bookkeeping.
    if(journal){
      try{journal.finalize();}catch(caught){journal.captureFailed(caught);fact.cleanupQualified=false;if(!failed){failed=true;failure=caught;}}
      fact.journal=journal.snapshot();fact.fileConsumerCalls=fact.journal.fileConsumerCalls;
    }
    try{await publishConsumerFact(ctx,fact);}catch(caught){if(!failed){failed=true;failure=caught;}}
  }
  // Preserve the exact thrown value, including null/undefined, and partial fact.
  if(failed)throw failure;
  const published=getConsumerFact(ctx);need(published!==null&&published.record!==null,'HTTPS_CONSUMER_FACT_PUBLICATION');
  return published;
}

// Direct invocation has no frame/bootstrap/API path and always refuses.
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  process.stderr.write('SOURCE_ONLY_CONSUMER_PRIVATE_EXPORT_REQUIRED\n');process.exitCode=1;
}
