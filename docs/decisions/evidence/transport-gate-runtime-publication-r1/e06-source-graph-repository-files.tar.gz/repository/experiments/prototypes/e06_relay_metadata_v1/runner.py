"""Separately released 8-window/10-reply network composition; inert on import."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent

def load_fixed(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

A = load_fixed('e06_relay_admission', HERE/'admission.py')

def write_json(path, value):
    raw = (json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2)+'\n').encode()
    with Path(path).open('xb') as f:
        f.write(raw)
    return A.descriptor(path)

def write_bytes(path, raw):
    with Path(path).open('xb') as f:
        f.write(raw)
    return A.descriptor(path)

NETWORK_COUNTS = ('publications','queries','events')

def latch_wire_counts(counts):
    previous={key:counts[key] for key in NETWORK_COUNTS}
    counts.update({key:None for key in NETWORK_COUNTS})
    return previous

def new_launch(kind, job, directory):
    return {'kind':kind,'job':job,'directory':str(directory),'launchAttempt':False,
            'acquisition':'NOT_ATTEMPTED','pid':None,'constructorError':None,'cleanupError':None}

def acquire_process(launch, counters, spawn):
    # A fallible spawn call has unknown acquisition until an actual handle returns.
    keys=[launch['kind']+'Children']+(['eventJobs'] if launch['kind']=='wire' else ['routeWindows'])
    previous={key:counters[key] for key in keys}
    launch['launchAttempt']=True;launch['acquisition']='UNKNOWN'
    counters.update({key:None for key in keys})
    process=spawn()
    launch['acquisition']='ACQUIRED';launch['pid']=process.pid
    counters.update({key:None if previous[key] is None else previous[key]+1 for key in keys})
    return process

class Child:
    """Own exactly one process, three pipes and raw streams; unknown remains null."""
    def __init__(self, argv, directory, env, pins, counters, kind, deadline, launch):
        self.directory=directory; self.argv=argv; self.pins=pins; self.counters=counters
        self.kind=kind; self.deadline=deadline; self.start=time.monotonic(); self.launch=launch
        self.proc=None; self.forced=False; self.reaped=False; self.exit=None
        self.error=None; self.eof={'stdout':False,'stderr':False}; self.total={'stdout':0,'stderr':0}
        self.pending=bytearray(); self.stdin_closed=False; self.selector=selectors.DefaultSelector()
        self.files={}
        try:
            for name in ('stdin','stdout','stderr'):self.files[name]=(directory/(name+'.bin')).open('xb')
            A.check_map(pins)
            A.need(A.descriptor(argv[0]) == {'path':argv[0],**pins[argv[0]]},'EXECUTABLE_FINAL_PIN')
            self.proc=acquire_process(launch,counters,lambda:subprocess.Popen(
                argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                cwd=directory,env=env,start_new_session=True,bufsize=0))
            for name in ('stdout','stderr'):
                pipe=getattr(self.proc,name);os.set_blocking(pipe.fileno(),False)
                self.selector.register(pipe,selectors.EVENT_READ,name)
            os.set_blocking(self.proc.stdin.fileno(),False)
            write_json(directory/'started.json',{'argv':argv,'pid':self.proc.pid,'startedMonotonic':self.start,'kind':kind})
        except BaseException as exc:
            self.error=type(exc).__name__+': '+str(exc);self.launch['constructorError']=self.error
            try:self.close(False)
            except BaseException as cleanup_exc:
                self.launch['cleanupError']=type(cleanup_exc).__name__+': '+str(cleanup_exc)
            raise
    def pump(self, until, data=None):
        offset=0
        if data is not None:
            A.need(not self.stdin_closed,'STDIN_CLOSED')
            self.selector.register(self.proc.stdin,selectors.EVENT_WRITE,'stdin')
        try:
            while True:
                now=time.monotonic();A.need(now < min(until,self.deadline),'CHILD_DEADLINE')
                events=self.selector.select(min(0.1,until-now))
                for key,_ in events:
                    name=key.data
                    if name=='stdin':
                        n=os.write(key.fileobj.fileno(),data[offset:offset+65536])
                        self.files['stdin'].write(data[offset:offset+n]);self.files['stdin'].flush();offset+=n
                        if offset==len(data):self.selector.unregister(self.proc.stdin)
                    else:
                        raw=os.read(key.fileobj.fileno(),65536)
                        if not raw:
                            self.eof[name]=True;self.selector.unregister(key.fileobj);continue
                        self.files[name].write(raw);self.files[name].flush();self.total[name]+=len(raw)
                        A.need(self.total[name] <= (16777216 if name=='stdout' else 65536),'STREAM_BOUND')
                        if name=='stdout' and self.kind=='metadata':self.pending.extend(raw)
                if data is not None and offset==len(data):return
                if data is None:return
        finally:
            if data is not None:
                try:self.selector.unregister(self.proc.stdin)
                except (KeyError,ValueError):pass
    def send(self, raw):
        A.need(raw.endswith(b'\n') and raw.count(b'\n')==1 and len(raw)<=131073,'JSONL_STDIN')
        self.pump(time.monotonic()+15,raw)
        self.counters['metadataRequests']+=1
    def reply(self):
        until=time.monotonic()+15
        while 10 not in self.pending:
            A.need(not self.eof['stdout'],'MISSING_RESPONSE')
            self.pump(until)
        i=self.pending.index(10);raw=bytes(self.pending[:i+1]);del self.pending[:i+1]
        A.need(len(raw)<=131073,'REPLY_LINE_BOUND')
        value=A.loads(raw);A.need(type(value) is dict and len(value)==13,'WHOLE_REPLY_SHAPE')
        self.counters['metadataReplies']+=1
        return raw,value
    def no_extra(self):
        self.pump(min(self.deadline,time.monotonic()+0.1))
        A.need(not self.pending and not self.eof['stdout'] and self.proc.poll() is None,'EXTRA_OR_EARLY_RESPONSE')
    def close(self, success):
        try:
            if self.proc is not None:
                if not self.stdin_closed:
                    self.proc.stdin.close();self.stdin_closed=True
                until=time.monotonic()+15
                while (self.proc.poll() is None or not all(self.eof.values())) and time.monotonic()<until:
                    # Cleanup is independent of the expired workload deadline.
                    saved=self.deadline;self.deadline=until
                    try:self.pump(until)
                    except Exception as exc:self.error=self.error or str(exc);break
                    finally:self.deadline=saved
                if self.proc.poll() is None:
                    self.forced=True
                    try:os.killpg(self.proc.pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                    try:self.proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        try:os.killpg(self.proc.pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        self.proc.wait(timeout=2)
                self.exit=self.proc.wait(timeout=2);self.reaped=True
                # Drain final bytes/EOF after natural or forced reap.
                until=time.monotonic()+2
                while not all(self.eof.values()) and time.monotonic()<until:
                    saved=self.deadline;self.deadline=until
                    try:self.pump(until)
                    except Exception as exc:self.error=self.error or str(exc);break
                    finally:self.deadline=saved
        finally:
            self.selector.close()
            for f in self.files.values():f.close()
            for name in ('stdin','stdout','stderr'):
                pipe=getattr(self.proc,name,None) if self.proc else None
                if pipe and not pipe.closed:pipe.close()
            self.record={'argv':self.argv,'pid':self.proc.pid if self.proc else None,'exit':self.exit,
                'reaped':self.reaped,'forced':self.forced,'stdoutEOF':self.eof['stdout'],'stderrEOF':self.eof['stderr'],
                'stdoutBytes':self.total['stdout'],'stderrBytes':self.total['stderr'],'elapsedSeconds':time.monotonic()-self.start,
                'error':self.error,'launch':dict(self.launch),'streams':{n:A.descriptor(self.directory/(n+'.bin')) for n in self.files}}
            write_json(self.directory/'lifecycle.json',self.record)
        if success:
            A.need(self.reaped and not self.forced and self.exit==0 and all(self.eof.values())
                and self.total['stderr']==0 and not self.pending and self.error is None,'CHILD_LIFECYCLE')
            A.check_map(self.pins)

def bind(path, value):
    d=write_json(path,value)
    return d['path'],d['sha256']

def check_sequence(route, observed, slot):
    event=next(e for e in route['networkEvents'] if e['slot']==slot)
    prerequisite=event['publishAfterRetainedStep']
    A.need(prerequisite is None or (prerequisite in observed and observed[prerequisite]['matched'] is True),'PREMATURE_D_PUBLICATION')

def received_span(raw, subscription):
    value=A.loads(raw)
    A.need(type(value) is list and len(value)==3 and value[0]=='EVENT' and value[1]==subscription,'EVENT_FRAME')
    text=raw.decode('utf-8','strict'); decoder=json.JSONDecoder();i=1
    for _ in range(2):
        while text[i].isspace():i+=1
        _,i=decoder.raw_decode(text,i)
        while text[i].isspace():i+=1
        A.need(text[i]==',','EVENT_SEPARATOR');i+=1
    while text[i].isspace():i+=1
    start=i;_,end=decoder.raw_decode(text,i)
    return text[start:end].encode('utf-8').hex()

def restore_wire_counts(counts, previous, result, job, summary_raw, fixture):
    A.need(result is not None and result['schema']=='e06-relay-metadata-wire-result-v1'
        and result['qualified'] is True and result['job']==job and result['error'] is None
        and result['publicationCount']==result['queryCount']==result['eventCount']==1
        and result['close']['code']==1000,'WIRE_RESULT')
    for key in ('publicationCount','queryCount','eventCount'):
        A.need(type(result[key]) is int and result[key]==1,'WIRE_OBSERVED_COUNT')
    A.closed(result,('schema','job','qualified','error','publicationCount','queryCount','eventCount','wireHex','close','frames'))
    A.need(summary_raw.endswith(b'\n') and summary_raw.count(b'\n')==1,'WIRE_STDOUT_JSONL')
    summary=A.loads(summary_raw)
    A.need(A.typed_equal(summary,{'qualified':True,'job':job['id']}),'WIRE_STDOUT_SUMMARY')
    wirehex=result['wireHex'];A.need(type(wirehex) is str and len(wirehex)%2==0,'RECEIVED_SPAN')
    # Independently bind retained span to exact frame bytes; never substitute fixture serialization.
    matching=[]
    for frame in result['frames']:
        if frame['direction']=='RECEIVE':
            raw=bytes.fromhex(frame['rawHex']);v=A.loads(raw)
            if type(v) is list and len(v)==3 and v[0]=='EVENT':matching.append(raw)
    A.need(len(matching)==1 and received_span(matching[0],'nbdp-'+job['id'])==wirehex,'ACTUAL_SPAN_BINDING')
    actual=A.loads(bytes.fromhex(wirehex))
    A.need(A.typed_equal(actual,fixture),'WHOLE_EVENT_MATCH')
    counts.update({key:None if previous[key] is None else previous[key]+1 for key in NETWORK_COUNTS})
    return wirehex

def require_reply_count(route, observed):
    A.need(set(observed)=={step['index'] for step in route['steps']},'REPLY_CARDINALITY')

def require_same_f(first, following):
    A.need(first==following,'CHANGED_F_SPAN')

def actual_request(route, step, received):
    template=A.loads(bytes.fromhex(step['rawLine']['hex']))
    request=dict(template)
    for slot in ('D','F'):
        key=slot.lower()+'WireHex'
        if template[key] is not None:
            A.need(slot in received,'MISSING_RECEIVED_EVENT')
            request[key]=received[slot]
        else:A.need(slot not in received,'PREMATURE_D')
    for key in ('op','secretHex','config'):
        A.need(A.typed_equal(request[key],template[key]),'NONWIRE_CHANGE')
    return (json.dumps(request,ensure_ascii=True,separators=(',',':'))+'\n').encode()

def run(ctx):
    m=ctx['manifest'];c=ctx['contract'];s=ctx['selection'];pins=ctx['pins'];output=Path(m['output'])
    output.mkdir(mode=0o700); (output/'jobs').mkdir(mode=0o700);(output/'contexts').mkdir(mode=0o700)
    counts={k:0 for k in ('routeWindows','metadataChildren','wireChildren','metadataRequests','metadataReplies','eventJobs','publications','queries','events')}
    capture={'schema':'e06-relay-metadata-capture-v1','component':A.COMPONENT,'qualified':False,
        'counts':counts,'launches':[],'routes':[],'error':None,'labStartupSeconds':None,'cleanupSeconds':None,'finalIntegrity':False}
    started=time.monotonic();deadline=started+600; lab=None; inside=False; workload_error=None
    def active():A.need(time.monotonic()<deadline,'PHASE_DEADLINE');A.check_map(pins)
    try:
        write_json(output/'admission.json',{'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],'pins':pins})
        A.check_map(pins)
        helper=load_fixed('e06_unchanged_relay_lab',s['relayProvenance']['assets']['supervisor']['path'])
        assets=s['relayProvenance']['assets']
        config={'scope':'CURRENT_CARRIER_TWO_RELAY_LAB_ONLY','execution_allowed':True,'run_id':m['runId'],
            'files':{'supervisor':assets['supervisor'],'python':c['tools']['python'],'docker':c['tools']['docker'],
                     'strfry_config':assets['strfryConfig'],'rs_relay_config':assets['rsRelayConfig']}}
        lab=helper.RelayLab(config,output/'lab');t=time.monotonic();lab.__enter__();inside=True
        capture['labStartupSeconds']=time.monotonic()-t
        A.need(capture['labStartupSeconds']<=360,'LAB_STARTUP_QUALIFICATION_BOUND');active()
        ordinal=0
        for route in s['routes']:
            active();lab.assert_healthy();window_deadline=min(deadline,time.monotonic()+90)
            directory=output/'contexts'/route['id'];directory.mkdir(mode=0o700)
            rcap={'id':route['id'],'observed':{},'events':{},'qualified':False};capture['routes'].append(rcap)
            child=None;received={};observed={};first_f=None
            try:
                if route['consumer']=='JS':
                    binding={'schema':'e06-relay-metadata-loader-binding-v1','route':route['id'],'sourcePins':pins,
                             'metadataEntry':c['metadataEntry'],'maxRequests':len(route['steps'])}
                    bp,sha=bind(directory/'binding.json',binding)
                    argv=[c['tools']['node']['path'],str(HERE/'metadata_loader.mjs'),bp,sha]
                else:argv=[c['tools']['metadataRust']['path']]
                launch=new_launch('metadata',route['id'],directory);capture['launches'].append(launch)
                child=Child(argv,directory,c['environment'],pins,counts,'metadata',window_deadline,launch)
                for step in route['steps']:
                    for event in route['networkEvents']:
                        slot=event['slot']
                        if slot in received or step['eventIdsUsed'][slot] is None:continue
                        child.no_extra();check_sequence(route,observed,slot);active()
                        job=next(j for j in c['jobs'] if j['route']==route['id'] and j['slot']==slot)
                        jd=output/'jobs'/f'{ordinal:03d}';ordinal+=1;jd.mkdir(mode=0o700)
                        binding={'schema':'e06-relay-metadata-wire-binding-v1','job':job,'sourcePins':pins,
                                 'wsEntry':c['wsEntry'],'output':str(jd)}
                        bp,sha=bind(jd/'binding.json',binding)
                        wire=None;result=None
                        launch=new_launch('wire',job['id'],jd);capture['launches'].append(launch)
                        prior_counts=latch_wire_counts(counts)
                        try:
                            wire=Child([c['tools']['node']['path'],str(HERE/'wire.mjs'),bp,sha],jd,c['environment'],pins,counts,'wire',min(window_deadline,time.monotonic()+20),launch)
                            wire.close(True)
                        finally:
                            original_error=sys.exc_info()[1]
                            if wire is not None and not wire.reaped:
                                try:wire.close(False)
                                except BaseException as cleanup_exc:
                                    launch['cleanupError']=type(cleanup_exc).__name__+': '+str(cleanup_exc)
                                    if original_error is None:raise
                        if (jd/'result.json').is_file():
                            result=A.loads((jd/'result.json').read_bytes());rcap['events'][slot]=A.descriptor(jd/'result.json')
                        wirehex=restore_wire_counts(counts,prior_counts,result,job,(jd/'stdout.bin').read_bytes(),
                            A.loads(A.checked(event['wire'])))
                        received[slot]=wirehex
                        child.no_extra()
                    active();child.no_extra()
                    request=actual_request(route,step,received)
                    write_bytes(directory/(str(step['index'])+'.request.jsonl'),request)
                    request_f=A.loads(request)['fWireHex']
                    if first_f is None:first_f=request_f
                    else:require_same_f(first_f,request_f)
                    child.send(request);raw,reply=child.reply()
                    write_bytes(directory/(str(step['index'])+'.reply.jsonl'),raw)
                    expected=A.document(step['expected']);matched=A.typed_equal(reply,expected)
                    observation={'matched':matched,'expected':step['expected'],'reply':A.descriptor(directory/(str(step['index'])+'.reply.jsonl'))}
                    write_json(directory/(str(step['index'])+'.observation.json'),observation)
                    observed[step['index']]=observation;rcap['observed'][str(step['index'])]=observation
                    A.need(matched,'WHOLE_METADATA_MISMATCH')
                require_reply_count(route,observed)
                child.close(True);rcap['qualified']=True
            finally:
                original_error=sys.exc_info()[1]
                if child is not None and not child.reaped:
                    try:child.close(False)
                    except BaseException as cleanup_exc:
                        child.launch['cleanupError']=type(cleanup_exc).__name__+': '+str(cleanup_exc)
                        if original_error is None:raise
        active()
        for key,value in c['counts'].items():
            if key in counts:A.need(counts[key]==value,'OBSERVED_COUNT:'+key)
        A.need(counts['wireChildren']==16,'WIRE_CHILD_COUNT')
    except BaseException as exc:
        workload_error=exc;capture['error']=type(exc).__name__+': '+str(exc)
    finally:
        if lab is not None and inside:
            t=time.monotonic()
            try:lab.__exit__(type(workload_error) if workload_error else None,workload_error,None)
            except BaseException as exc:capture['error']=(capture['error'] or '')+'; CLEANUP:'+str(exc)
            capture['cleanupSeconds']=time.monotonic()-t
            if capture['cleanupSeconds']>240:capture['error']=(capture['error'] or '')+'; CLEANUP_QUALIFICATION_BOUND'
        try:A.check_map(pins);capture['finalIntegrity']=True
        except BaseException as exc:capture['error']=(capture['error'] or '')+'; FINAL_PIN:'+str(exc)
        capture['elapsedSeconds']=time.monotonic()-started
        capture['qualified']=capture['error'] is None and capture['finalIntegrity']
        write_json(output/'capture.json',capture)
        # Complete owned output inventory, including negative/partial raw work; no historical tree walk.
        archive={str(p):A.descriptor(p) for p in sorted(output.rglob('*')) if p.is_file()}
        write_json(output/'artifact-manifest.json',{'schema':'e06-relay-metadata-owned-archive-v1','files':archive})
    return 0 if capture['qualified'] else 1

def main(argv):
    A.need(len(argv)==5,'CLI: runner.py MANIFEST SHA RELEASE SHA')
    ctx=A.verify(argv[1],argv[2],argv[3],argv[4])
    return run(ctx)

if __name__=='__main__':
    try:exit_code=main(sys.argv)
    except BaseException as exc:
        sys.stderr.write(type(exc).__name__+': '+str(exc)+'\n');exit_code=1
    sys.exit(exit_code)
