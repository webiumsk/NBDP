// SOURCE PREPARATION ONLY. Execution requires the enclosing independent gate/release.
// One fixed already-signed event per process. No crypto, metadata or attachment work.
import {readFileSync, writeFileSync, statSync, realpathSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';
import path from 'node:path';

const ROOT = '/home/peterhorvath/apps/bitcoin/NBDP';
const SELECTION = ROOT + '/experiments/prototypes/e06_relay_metadata_v1/selection.json';
const SELECTION_PIN = {bytes:387416,sha256:'8e67ab182f155a853a1a9c3f3149a0e31a5e582d018d7976777c786d7fe93c1f'};
const WS_ENTRY = ROOT + '/experiments/node_modules/ws/wrapper.mjs';
const NODE = '/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node';
const NODE_PIN = {bytes:121613584,sha256:'ccacb2d6d87ba6d118b2bffc1ae33747a05cc5fc6b1f1ec4fc1d420b687e952d'};
const ENDPOINTS = Object.freeze({strfry:'ws://127.0.0.1:17777','rs-relay':'ws://127.0.0.1:18081'});
const ENV = Object.freeze({LANG:'C.UTF-8',LC_ALL:'C.UTF-8',TZ:'UTC',WS_NO_BUFFER_UTIL:'1',WS_NO_UTF_8_VALIDATE:'1'});
const MAX_FRAME = 262144, MAX_FRAMES = 16, MAX_RAW = 2097152;
const assert = (ok, message) => {if (!ok) throw Error(message);};
const keys = (value, names) => value!==null && typeof value==='object' && !Array.isArray(value)
  && Object.keys(value).length===names.length && names.every(k=>Object.hasOwn(value,k));
const hash = b => createHash('sha256').update(b).digest('hex');
const pin = file => {const b=readFileSync(file);return {bytes:b.length,sha256:hash(b)};};
const samePin = (a,b) => keys(a,['bytes','sha256']) && keys(b,['bytes','sha256'])
  && a.bytes===b.bytes && a.sha256===b.sha256;

export function typedEqual(a,b) {
  if (typeof a!==typeof b || (a===null)!==(b===null) || Array.isArray(a)!==Array.isArray(b)) return false;
  if (a===null || typeof a!=='object') return Object.is(a,b);
  if (Array.isArray(a)) return a.length===b.length && a.every((v,i)=>typedEqual(v,b[i]));
  return Object.keys(a).length===Object.keys(b).length
    && Object.keys(a).every(k=>Object.hasOwn(b,k)&&typedEqual(a[k],b[k]));
}

function scalar(s) {
  for(let i=0;i<s.length;i++) {
    const c=s.charCodeAt(i);
    if(c>=0xd800&&c<=0xdbff) {const d=s.charCodeAt(++i);assert(d>=0xdc00&&d<=0xdfff,'Unpaired high surrogate');}
    else assert(!(c>=0xdc00&&c<=0xdfff),'Unpaired low surrogate');
  }
  return s;
}

// Inert strict JSON parser. Spans are UTF-8 byte offsets, including nested objects.
// Numeric grammar intentionally admits decimal safe integers only, without -0.
export function parseStrict(raw, limit=MAX_RAW) {
  assert(Buffer.isBuffer(raw)||raw instanceof Uint8Array,'Raw bytes required');
  const bytes=Buffer.from(raw);assert(bytes.length<=limit,'JSON byte bound');
  const text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);
  let i=0,nodes=0;
  const white=()=>{while(i<text.length&&/[\x20\x09\x0a\x0d]/.test(text[i]))i++;};
  const offsets=new Uint32Array(text.length+1);let byteOffset=0;
  for(let j=0;j<text.length;j++){offsets[j]=byteOffset;const c=text.codePointAt(j);if(c>0xffff){offsets[++j]=byteOffset;byteOffset+=4;}else byteOffset+=c<0x80?1:c<0x800?2:3;}
  offsets[text.length]=byteOffset;const position=x=>offsets[x];
  function string() {
    const start=i;assert(text[i++]==='"','Expected string');
    while(i<text.length) {
      const c=text.charCodeAt(i++);
      if(c===34)return scalar(JSON.parse(text.slice(start,i)));
      assert(c>=32,'Control in string');
      if(c===92) {
        assert(i<text.length,'Incomplete escape');const e=text[i++];
        if(e==='u') {assert(/^[0-9a-fA-F]{4}$/.test(text.slice(i,i+4)),'Invalid Unicode escape');i+=4;}
        else assert('"\\/bfnrt'.includes(e),'Invalid escape');
      }
    }
    throw Error('Unterminated string');
  }
  function value(depth=0) {
    assert(depth<=64&&++nodes<=100000,'JSON structural bound');white();const start=i;let result,children=null;
    const c=text[i];
    if(c==='"')result=string();
    else if(c==='[') {
      i++;result=[];children=[];white();
      if(text[i]!==']')while(true) {
        const child=value(depth+1);result.push(child.value);children.push(child);white();
        if(text[i]!==',')break;i++;
      }
      assert(text[i++ ]===']','Invalid array');
    } else if(c==='{') {
      i++;result=Object.create(null);children=Object.create(null);white();
      if(text[i]!=='}')while(true) {
        white();const key=string();assert(!Object.hasOwn(result,key),'Duplicate object key');white();
        assert(text[i++]===':','Missing colon');const child=value(depth+1);result[key]=child.value;children[key]=child;white();
        if(text[i]!==',')break;i++;
      }
      assert(text[i++]==='}','Invalid object');
    } else if(text.startsWith('true',i)){result=true;i+=4;}
    else if(text.startsWith('false',i)){result=false;i+=5;}
    else if(text.startsWith('null',i)){result=null;i+=4;}
    else {
      const match=/^-?(?:0|[1-9][0-9]*)/.exec(text.slice(i));assert(match,'Invalid JSON value');
      i+=match[0].length;result=Number(match[0]);
      assert(match[0]!=='-0'&&Number.isSafeInteger(result),'Unsupported integer');
    }
    return {value:result,start:position(start),end:position(i),children};
  }
  const root=value();white();assert(i===text.length,'Trailing JSON content');
  return {value:root.value,spans:root,raw:bytes};
}

export function validateAck(raw,id) {
  const a=parseStrict(raw,MAX_FRAME).value;
  assert(Array.isArray(a)&&a.length===4&&a[0]==='OK'&&a[1]===id&&a[2]===true&&typeof a[3]==='string','Exact OK true required');return a;
}
export function validateEose(raw,sub) {
  const a=parseStrict(raw,MAX_FRAME).value;
  assert(Array.isArray(a)&&a.length===2&&a[0]==='EOSE'&&a[1]===sub,'Exact EOSE required');return a;
}
export function validateEventFrame(raw,sub,fixture) {
  const parsed=parseStrict(raw,MAX_FRAME),a=parsed.value;
  assert(Array.isArray(a)&&a.length===3&&a[0]==='EVENT'&&a[1]===sub,'Exact EVENT frame required');
  assert(typedEqual(a[2],fixture),'Whole EVENT mismatch');
  const span=parsed.spans.children[2];
  assert(span.value!==null&&typeof span.value==='object'&&!Array.isArray(span.value),'EVENT object required');
  return {event:a[2],wireHex:parsed.raw.subarray(span.start,span.end).toString('hex')};
}
export function validateClose(code,reason) {
  assert(code===1000,'Strict Close1000 required');
  assert(Buffer.isBuffer(reason)||reason instanceof Uint8Array,'Raw close reason required');
  return {code,reason:scalar(new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(reason))};
}

// The same pure state machine is used by callbacks and refusal controls.
export function createProtocolState(id,sub,fixture) {
  let phase='OPEN',wireHex=null,eventCount=0,publicationCount=0,queryCount=0;
  return {
    sent(kind) {
      if(kind==='EVENT'){assert(phase==='OPEN','Premature EVENT publication');phase='ACK';publicationCount++;}
      else if(kind==='REQ'){assert(phase==='ACK_RETAINED','REQ before ACK');phase='EVENT';queryCount++;}
      else if(kind==='CLOSE'){assert(phase==='EOSE_RETAINED','CLOSE before EOSE');phase='CLOSING';}
      else throw Error('Unknown send kind');
    },
    received(raw,binary=false) {
      assert(!binary,'Binary payload refused');
      if(phase==='ACK'){validateAck(raw,id);phase='ACK_RETAINED';return 'OK';}
      if(phase==='EVENT'){const event=validateEventFrame(raw,sub,fixture);wireHex=event.wireHex;eventCount++;phase='EOSE';return 'EVENT';}
      if(phase==='EOSE'){validateEose(raw,sub);phase='EOSE_RETAINED';return 'EOSE';}
      throw Error('Unexpected or premature relay payload in '+phase);
    },
    closed(code,reason) {assert(phase==='CLOSING','Premature socket close');const close=validateClose(code,reason);phase='CLOSED';return close;},
    snapshot() {return {phase,wireHex,eventCount,publicationCount,queryCount};}
  };
}

function absoluteFile(file) {assert(path.isAbsolute(file)&&realpathSync(file)===file&&statSync(file).isFile(),'Resolved regular absolute file required: '+file);}
function privateDir(dir) {assert(path.isAbsolute(dir)&&realpathSync(dir)===dir,'Resolved absolute directory required');const s=statSync(dir);assert(s.isDirectory()&&(s.mode&0o777)===0o700&&s.uid===process.getuid(),'Owned mode0700 directory required');}
function validateBinding(binding) {
  assert(keys(binding,['schema','job','sourcePins','wsEntry','output'])&&binding.schema==='e06-relay-metadata-wire-binding-v1','Closed wire binding required');
  assert(keys(binding.job,['id','route','relay','slot','artifactId','role','outerId','wire']),'Closed job required');
  assert(binding.wsEntry===WS_ENTRY,'Only fixed ws entry allowed');privateDir(binding.output);
  assert(keys(binding.sourcePins,Object.keys(binding.sourcePins))&&Object.keys(binding.sourcePins).length<=1024,'Finite pin map required');
  const selection=parseStrict(readFileSync(SELECTION)).value;
  assert(samePin(pin(SELECTION),SELECTION_PIN)&&samePin(binding.sourcePins[SELECTION],SELECTION_PIN),'Fixed accepted DATA required');
  assert(selection.schema==='e06-relay-metadata-selection-v1'&&selection.routes.length===8,'Fixed route selection required');
  const catalogue=selection.routes.flatMap(r=>r.networkEvents.map(e=>({id:r.id+'-'+e.slot,route:r.id,relay:r.relay,slot:e.slot,artifactId:e.artifactId,role:e.role,outerId:e.outerId,wire:e.wire})));
  assert(catalogue.length===16&&catalogue.filter(x=>typedEqual(x,binding.job)).length===1,'Job not in fixed selected catalogue');
  assert(Object.hasOwn(ENDPOINTS,binding.job.relay),'Unknown relay');
  const desc=binding.job.wire;assert(keys(desc,['path','bytes','sha256']),'Flat wire descriptor required');
  const fixturePath=path.resolve(ROOT,desc.path);assert(fixturePath.startsWith(ROOT+'/'),'Wire outside repository');
  assert(samePin(binding.sourcePins[fixturePath],{bytes:desc.bytes,sha256:desc.sha256}),'Wire absent from current closure');
  absoluteFile(fixturePath);assert(samePin(pin(fixturePath),binding.sourcePins[fixturePath]),'Wire fixture changed');
  const fixture=parseStrict(readFileSync(fixturePath),MAX_FRAME).value;
  assert(fixture?.id===binding.job.outerId,'Fixture outer ID mismatch');
  return fixture;
}

async function main() {
  assert(process.argv.length===4,'CLI: node wire.mjs ABS_BINDING SHA256');
  const [bindingPath,sha]=process.argv.slice(2);absoluteFile(bindingPath);privateDir(path.dirname(bindingPath));
  assert(/^[a-f0-9]{64}$/.test(sha)&&pin(bindingPath).sha256===sha,'External binding SHA mismatch');
  const binding=parseStrict(readFileSync(bindingPath)).value;
  // Parent admission fixes the COMPLETE map and release before starting this child.
  // This worker additionally pins itself, Node, ws, selection and the exact job.
  const fixture=validateBinding(binding),self=fileURLToPath(import.meta.url);
  const verify=()=>{
    assert(pin(bindingPath).sha256===sha,'Binding changed');
    assert(typedEqual(process.env,ENV),'Closed minimal environment required');
    assert(realpathSync(process.execPath)===NODE&&samePin(pin(NODE),NODE_PIN),'Fixed Node binary required');
    for(const [file,expected] of Object.entries(binding.sourcePins)) {
      absoluteFile(file);assert(keys(expected,['bytes','sha256'])&&Number.isSafeInteger(expected.bytes)&&expected.bytes>=0&&/^[a-f0-9]{64}$/.test(expected.sha256),'Invalid pin descriptor');
      assert(samePin(pin(file),expected),'Current source/runtime pin changed: '+file);
    }
    for(const file of [self,NODE,WS_ENTRY])assert(Object.hasOwn(binding.sourcePins,file),'Required runtime absent from pins');
    assert(samePin(binding.sourcePins[NODE],NODE_PIN),'Node map pin mismatch');
    assert(samePin(pin(SELECTION),SELECTION_PIN),'Selection changed');privateDir(binding.output);
  };
  const report={schema:'e06-relay-metadata-wire-result-v1',job:binding.job,qualified:false,error:null,publicationCount:0,queryCount:0,eventCount:0,wireHex:null,close:null,frames:[]};
  let ws=null,terminal=null,wake=null,totalBytes=0,closed=false;
  const sub='nbdp-'+binding.job.route+'-'+binding.job.slot;
  const state=createProtocolState(binding.job.outerId,sub,fixture);
  const signal=()=>{if(wake){const fn=wake;wake=null;fn();}};
  const fail=error=>{terminal??=error;signal();if(ws&&!closed)ws.terminate();};
  const capture=(direction,raw,kind)=>{
    const remaining=Math.max(0,MAX_RAW-totalBytes);
    if(report.frames.length>=MAX_FRAMES)throw Error('Frame count bound');
    report.frames.push({direction,kind:raw.length>remaining?'BOUND_EXCEEDED_PREFIX':kind,rawHex:raw.subarray(0,remaining).toString('hex')});
    totalBytes+=Math.min(raw.length,remaining);
    assert(raw.length<=MAX_FRAME&&raw.length<=remaining,'Raw stream bound');
  };
  const waitFor=async(predicate,ms,label)=>{
    const deadline=Date.now()+ms;
    while(!predicate()) {
      if(terminal)throw terminal;const remaining=deadline-Date.now();assert(remaining>0,label+' deadline');
      await new Promise(resolve=>{const timer=setTimeout(()=>{wake=null;resolve();},remaining);wake=()=>{clearTimeout(timer);resolve();};});
    }
    if(terminal)throw terminal;
  };
  const send=(kind,raw)=>{
    assert(!terminal&&ws.readyState===1,'Socket not available');state.sent(kind);capture('SEND',raw,kind);ws.send(raw,{binary:false});
  };
  try {
    verify();const {default:WebSocket}=await import(pathToFileURL(WS_ENTRY).href);verify();
    ws=new WebSocket(ENDPOINTS[binding.job.relay],{handshakeTimeout:3000,maxPayload:MAX_FRAME,followRedirects:false,perMessageDeflate:false});
    ws.on('message',(data,binary)=>{
      const raw=Buffer.from(data);
      try {
        capture('RECEIVE',raw,binary?'BINARY':'UNVALIDATED');
        const kind=state.received(raw,binary);report.frames[report.frames.length-1].kind=kind;signal();
      } catch(error){fail(error);}
    });
    ws.on('error',fail);
    ws.on('close',(code,reason)=>{
      closed=true;
      try {report.close={code,reason:Buffer.from(reason).toString('hex')};report.close=state.closed(code,Buffer.from(reason));}
      catch(error){terminal??=error;}
      signal();
    });
    ws.on('open',signal);
    await waitFor(()=>ws.readyState===1,3000,'Open');
    // Publication keeps original signed object bytes; no fixture reserialization.
    const signed=readFileSync(path.resolve(ROOT,binding.job.wire.path));
    send('EVENT',Buffer.concat([Buffer.from('["EVENT",'),signed,Buffer.from(']')]));
    await waitFor(()=>state.snapshot().phase==='ACK_RETAINED',3000,'ACK');
    send('REQ',Buffer.from(JSON.stringify(['REQ',sub,{ids:[binding.job.outerId],limit:1}])));
    // EVENT and EOSE may arrive back-to-back; state retains both without discarding.
    await waitFor(()=>state.snapshot().eventCount===1,3000,'EVENT');
    await waitFor(()=>state.snapshot().phase==='EOSE_RETAINED',3000,'EOSE');
    send('CLOSE',Buffer.from(JSON.stringify(['CLOSE',sub])));ws.close(1000);
    await waitFor(()=>closed,1000,'Close');
    assert(state.snapshot().phase==='CLOSED','Incomplete wire sequence');verify();report.qualified=true;
  } catch(error){report.error=error.name+': '+error.message;}
  finally {
    if(ws&&!closed)ws.terminate();
    const s=state.snapshot();for(const k of ['publicationCount','queryCount','eventCount','wireHex'])report[k]=s[k];
    try{verify();}catch(error){report.qualified=false;report.error??=error.name+': '+error.message;}
    assert(report.publicationCount===1||!report.qualified,'Incomplete publication count');
    assert(report.queryCount===1&&report.eventCount===1||!report.qualified,'Incomplete retrieval count');
    writeFileSync(path.join(binding.output,'result.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
  }
  process.stdout.write(JSON.stringify({qualified:report.qualified,job:binding.job.id})+'\n');return report.qualified?0:1;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  main().then(code=>{process.exitCode=code;}).catch(error=>{process.stderr.write(error.name+': '+error.message+'\n');process.exitCode=1;});
}
