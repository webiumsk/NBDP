"""Fixed HTTPS workload coordinator. Inert import; concrete release required."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import threading

HERE = Path(__file__).resolve().parent

def load_admission(manifest, sha):
    raw=Path(manifest).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=sha:
        raise ValueError('EXTERNAL_MANIFEST_SHA')
    # The external hash covers the native manifest. This pre-import parse grants
    # no execution authority; the fixed pure gate subsequently strictly reparses.
    m=json.loads(raw);p=HERE/'admission.py';b=p.read_bytes()
    pin={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    if m.get('sourcePins',{}).get(str(p))!=pin:
        raise ValueError('FIXED_GATE_PIN')
    spec=importlib.util.spec_from_file_location('_https_fixed_admission',p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def put(path,obj):
    with open(path,'xb') as f:
        f.write((json.dumps(obj,separators=(',',':'))+'\n').encode());f.flush();os.fsync(f.fileno())

def child(adm,tool,argv,cwd,env,timeout,stdin=b'',watch_consumer=False):
    # Acquisition is latched UNKNOWN before fallible Popen. A non-returning
    # constructor cannot be represented as zero work/zero child acquisition.
    ledger={'launchAttempt':True,'acquisition':'UNKNOWN','pid':None,'exitCode':None,
            'signal':None,'reaped':False,'stdoutEOF':False,'stderrEOF':False,
            'forced':False,'timedOut':False,'error':None}
    stdout=cwd/'stdout.bin';stderr=cwd/'stderr.bin';proc=None
    threads=[];pump_errors=[]
    def pump(stream, target, limit, eof_key):
        seen=0
        try:
            with open(target,'xb') as f:
                while True:
                    block=stream.read(65536)
                    if not block:
                        ledger[eof_key]=True;break
                    before=seen;seen+=len(block)
                    if before<limit:f.write(block[:max(0,limit-before)])
                    if seen>limit:
                        ledger['forced']=True;ledger['streamOverflow']=True
                        if proc is not None:proc.kill()
                f.flush();os.fsync(f.fileno())
        except BaseException as exc:
            pump_errors.append({'name':type(exc).__name__,'message':str(exc)})
            ledger['forced']=True
            if proc is not None:
                try:proc.kill()
                except OSError:pass
        finally:
            stream.close()
    try:
        adm.need(adm.equal(adm.descriptor(tool['path']),tool),'FINAL_TOOL_PIN')  # Last read before Popen.
        proc=subprocess.Popen([tool['path'],*argv],cwd=cwd,env=env,stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        ledger['acquisition']='ACQUIRED';ledger['pid']=proc.pid
        for stream,target,limit,eof in [(proc.stdout,stdout,16777216,'stdoutEOF'),
                                       (proc.stderr,stderr,65536,'stderrEOF')]:
            t=threading.Thread(target=pump,args=(stream,target,limit,eof),daemon=True);t.start();threads.append(t)
        proc.stdin.write(stdin);proc.stdin.close()
        deadline=time.monotonic()+timeout;consumer_seen=None
        while proc.poll() is None:
            now=time.monotonic()
            if watch_consumer and consumer_seen is None and (cwd/'engine-attempt.json').exists():
                consumer_seen=now;ledger['consumerJournalObserved']=True
            consumer_timeout=consumer_seen is not None and now-consumer_seen>=120
            if now>=deadline or consumer_timeout:
                ledger['timedOut']=True;ledger['consumerTimedOut']=consumer_timeout
                ledger['forced']=True;proc.kill();proc.wait(timeout=5);break
            try:proc.wait(timeout=min(0.1,max(0.001,deadline-now)))
            except subprocess.TimeoutExpired:pass
        ledger['exitCode']=proc.returncode if proc.returncode>=0 else None
        ledger['signal']=-proc.returncode if proc.returncode<0 else None
        ledger['reaped']=True
    except BaseException as exc:
        ledger['error']={'name':type(exc).__name__,'message':str(exc)}
        if proc is not None and proc.poll() is None:
            ledger['forced']=True
            try:proc.kill();proc.wait(timeout=5);ledger['reaped']=True
            except BaseException as cleanup:
                ledger['cleanupError']={'name':type(cleanup).__name__,'message':str(cleanup)}
    finally:
        for t in threads:t.join(timeout=5)
        if any(t.is_alive() for t in threads):ledger['forced']=True
        if pump_errors:ledger['pumpErrors']=pump_errors
        for target in (stdout,stderr):
            if not target.exists():target.touch(mode=0o600,exist_ok=False)
    ledger['stdout']=adm.descriptor(stdout);ledger['stderr']=adm.descriptor(stderr)
    ledger['streamsWithinBound']=ledger['stdout']['bytes']<=16777216 and ledger['stderr']['bytes']<=65536
    ledger['descendantContainment']='UNQUALIFIED_IF_FORCED_OR_UNKNOWN_ACQUISITION'
    put(cwd/'outer-child.json',ledger)
    return ledger

def main(argv):
    if len(argv)!=4:
        raise ValueError('CLI: run.py MANIFEST SHA RELEASE SHA')
    adm=load_admission(argv[0],argv[1]);ctx=adm.verify(*argv);m=ctx['manifest'];c=ctx['contract']
    output=Path(ctx['output']);output.mkdir(mode=0o700,exist_ok=False)
    put(output/'admission.json',{'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],'sourcePins':ctx['sourcePins']})
    phase_budget_seconds=900 if m['phase']=='ACQUIRE' else 300
    started=time.monotonic();rows=[];qualified=False;error=None;integrity=False
    counts={k:0 for k in ('cases','metadataCalls','fileConsumerCalls','acquisitionConnections','httpGets','attachmentEncryptions')}
    try:
        cases=['PREPARE'] if m['phase']=='PREPARE' else [r['id'] for r in c['caseExpectations']['cases']]
        for ident in cases:
            remaining=phase_budget_seconds-(time.monotonic()-started);adm.need(remaining>0,'PHASE_TIMEOUT')
            adm.check_map(ctx['sourcePins']);cwd=output/ident;cwd.mkdir(mode=0o700)
            for name in ('home','xdg-config','xdg-cache','tmp'):(cwd/name).mkdir(mode=0o700)
            frame={'schema':'e06-https-acquisition-private-frame-v1','phase':m['phase'],'id':ident,
                   'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],
                   'sourcePins':ctx['sourcePins'],'inputs':m['inputs'],'output':str(cwd)}
            put(cwd/'frame.json',frame);fd=adm.descriptor(cwd/'frame.json')
            profile=adm.document(m['profile']);env=dict(profile['environment']);env.update({
                'NBDP_CHROME':c['tools'].get('chrome',{}).get('path','/opt/google/chrome/chrome'),
                'HOME':str(cwd/'home'),'XDG_CONFIG_HOME':str(cwd/'xdg-config'),
                'XDG_CACHE_HOME':str(cwd/'xdg-cache'),'TMPDIR':str(cwd/'tmp')})
            entry=HERE/('prepare.mjs' if m['phase']=='PREPARE' else 'acquisition.mjs')
            # Counters remain unknown until a complete qualified native result is
            # retained and validated. Later validated results cannot erase null.
            if m['phase']=='ACQUIRE':
                prior=dict(counts)
                for k in counts:counts[k]=None
            else:prior=None
            ledger=child(adm,m['tools']['node'],[str(entry),fd['path'],fd['sha256']],cwd,env,
                         min(remaining,150 if ident!='PREPARE' else 295),watch_consumer=ident!='PREPARE')
            row={'id':ident,'frame':fd,'child':ledger,'matched':False,'result':None};rows.append(row)
            adm.need(ledger['acquisition']=='ACQUIRED' and ledger['reaped'] and ledger['stdoutEOF']
                     and ledger['stderrEOF'] and not ledger['forced'] and ledger['signal'] is None
                     and ledger['streamsWithinBound'] and not ledger.get('streamOverflow',False) and not ledger.get('pumpErrors') and ledger['error'] is None,'NATURAL_CHILD')
            adm.need(ledger['stderr']['bytes']==0,'NATIVE_STDERR')
            raw=adm.checked(ledger['stdout']);adm.need(raw.endswith(b'\n') and raw.count(b'\n')==1,'ONE_RESULT')
            result=adm.loads(raw[:-1]);adm.closed(result,('schema','phase','id','qualified','observation','records','cleanup','error'))
            adm.need(result['schema']=='e06-https-acquisition-private-result-v1' and result['phase']==m['phase'] and result['id']==ident,'RESULT_ID')
            rd=adm.descriptor(cwd/'result.json');adm.need(adm.equal(adm.document(rd),result),'RETAINED_NATIVE_RESULT');row['result']=rd
            adm.need(result['cleanup']['harnessOwnedCleanupQualified'] is True,'REAL_HARNESS_CLEANUP')
            if m['phase']=='PREPARE':
                adm.need(ledger['exitCode']==0 and result['qualified'] is True
                         and result['observation']['rpcCalls']==16 and result['observation']['attachmentEncryptions']==0,'PREPARATION_RESULT')
            else:
                expected=next(z for z in c['caseExpectations']['cases'] if z['id']==ident)
                adm.need(ledger['exitCode']==expected['expectedExitCode']
                         and result['qualified'] is expected['expectedComponentQualified']
                         and result['cleanup']['qualified'] is expected['componentCleanupQualified']
                         and adm.equal(result['observation'],expected['expectedObservation']),'WHOLE_CASE_RESULT')
                for name,d in result['records'].items():
                    if d is not None:
                        adm.need(Path(d['path']).parent==cwd,'OWNED_RECORD');adm.checked(d)
                adm.need(result['records']['metadata'] is not None and result['records']['acquisition'] is not None,'ACTUAL_RECORDS')
                acquisition=adm.document(result['records']['acquisition'])
                adm.need(acquisition['harnessCleanupQualified'] is True,'ACTUAL_TRANSPORT_CLEANUP')
                if ident in ('H01','H02','H14'):
                    adm.need(result['records']['consumer'] is not None,'RETAINED_ENGINE_FACT')
                    fact=adm.document(result['records']['consumer'])
                    adm.need(fact['schema']=='e06-https-native-consumer-fact-v1'
                             and fact['route']==expected['engine'] and fact['status']=='VERIFIED_BYTES'
                             and fact['originalHex']=='00ff8001' and fact['fileConsumerCalls']==1
                             and fact['attachmentEncryptions']==0 and fact['cleanupQualified'] is True
                             and fact['record'] is None,'ACTUAL_NATIVE_SUCCESS')
                    journal=fact['journal']
                    adm.need(journal['outcome']=='RETURNED' and journal['finalized'] is True
                             and journal['captureErrors']==[] and journal['nativeError'] is None
                             and journal['componentError'] is None,'ACTUAL_ATTEMPT_JOURNAL')
                    adm.need(adm.equal(adm.loads((cwd/'engine-attempt.json').read_bytes()),journal),'DURABLE_JOURNAL_MATCH')
                    adm.need(acquisition['completeSnapshot'] is True
                             and acquisition['bodyObservedBytes']==20 and acquisition['bodySha256']==profile['commitments']['x'],
                             'ACTUAL_RECEIVED_SNAPSHOT')
                if ident=='H14':
                    adm.need(acquisition['componentFault'] is True and result['observation']['originalHex'] is None,
                             'POST_ENGINE_COMPONENT_FAULT_WITHHELD')
                for k in counts:
                    value=1 if k=='cases' else result['observation'][k]
                    adm.need(type(value) is int and value>=0,'KNOWN_COUNT')
                    counts[k]=None if prior[k] is None else prior[k]+value
            row['matched']=True
        adm.need(time.monotonic()-started<=phase_budget_seconds,'PHASE_TIMEOUT')
        if m['phase']=='ACQUIRE':adm.need(adm.equal(counts,c['caseExpectations']['counts']),'ACTUAL_COUNTS')
        adm.check_map(ctx['sourcePins']);integrity=True;qualified=all(r['matched'] for r in rows)
    except BaseException as exc:
        error={'name':type(exc).__name__,'message':str(exc)}
    # Bounded inventory of every actual owned frame/raw request/reply/journal.
    entries={};total=0
    for p in sorted(output.rglob('*')):
        if p.is_file():
            adm.need(not p.is_symlink(),'ARCHIVE_SYMLINK');d=adm.descriptor(p);total+=d['bytes'];entries[str(p)]=d
    archive={'schema':'e06-https-owned-archive-v1','entries':entries,'bytes':total}
    put(output/'artifact-manifest.json',archive)
    if total>33554432:qualified=False;error=error or {'name':'CaptureBound','message':'PACK_BOUND'}
    capture={'schema':'e06-https-capture-v1','phase':m['phase'],'component':m['component'],
             'qualified':qualified,'overallE06':'PARTIAL','rows':rows,'counts':counts,
             'elapsedSeconds':time.monotonic()-started,'finalIntegrity':integrity,
             'archive':adm.descriptor(output/'artifact-manifest.json'),'error':error,
             'limits':['A matching negative is a harness result; it does not release VERIFIED_BYTES.',
                       'Forced or unknown child lifecycle never establishes descendant cleanup.']}
    put(output/'capture.json',capture);print(json.dumps({'qualified':qualified,'capture':adm.descriptor(output/'capture.json')}))
    return 0 if qualified else 1

if __name__=='__main__':
    try:
        result=main(sys.argv[1:])
    except BaseException as exc:
        print(type(exc).__name__+': '+str(exc),file=sys.stderr);result=1
    raise SystemExit(result)
