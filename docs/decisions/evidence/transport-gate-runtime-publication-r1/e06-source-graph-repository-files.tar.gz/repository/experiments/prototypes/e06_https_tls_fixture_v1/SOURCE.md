# Fixed isolated TLS fixture source

SOURCE ONLY — NOT_EXECUTED. This namespace prepares source for E06's isolated
synthetic certificate prerequisite. It does not authorize its own execution,
produce certificate acceptance or prove Node TLS interoperability. All14 HTTPS
cases remain NOT_EXECUTED and E06 remains PARTIAL.

Owned files (exact7): prepare.py, recipe.json, openssl.cnf, leaf-extensions.cnf,
SOURCE.md, capture.py and pure_controls.py.
The acquisition namespace and previous evidence are read-only dependencies.
The pinned research input is14307B/SHA256
c998e4f23935b342d97d2276c791421a64e7d3c69fe063c06ba4b233c79b52de,
under docs/decisions/evidence/invoice-authenticated-carrier/
e06-https-acquisition-preparation-r1/tls-certificate-recipe-research.json.
The source-only root release is tls-source-preparation-release.json beside it.

The concrete proposed output is `/tmp/nbdp-e06-https-tls-r2`. It must be absent;
the controller creates it atomically0700 and refuses reuse, symlinks or overwrite.
SOURCE authoring does not create that path. Disposable unencrypted keys remain
0600 inside this owned root. They are synthetic test keys, retained with native
evidence until the coordinator separately arranges disposal. Global trust,
DNS/hosts and services are untouched.

The literal recipe contains exactly11 absolute argv arrays from the corrected
research: provider/default property options immediately after each subcommand;
verify certificate operand last. TLS01 makes the one-day CA(serial1), TLS02–05
make/sign the files.invalid(serial2) and wrong.files.invalid(serial3) leaves;
TLS06–08 inspect actual native certificate text/fingerprint/UTC dates. TLS09
verifies the normal host; TLS10 verifies the wrong-SAN leaf for its own host;
TLS11 verifies that same otherwise-valid leaf for files.invalid. The controller
uses no shell and a replacement six-variable environment, closed empty-file
stdin, explicit owned OpenSSL config and empty provider/engine directories.
No default trust search is requested: verification uses the explicit `-trusted`
CA. This has not been tested in this task.

Ten calls require actual natural exit0, complete stdout/stderr EOF and reap,
no force/signal/error/overflow, both actual EOFs and an observed owned leader
exit followed by the single actual final reap.
TLS11 requires actual natural positive nonzero plus the specific native error62
at depth0 with `hostname mismatch`, exact failed certificate operand and no
stdout. It never treats generic nonzero, timeout or setup failure as the expected
negative. Raw actual stdout/stderr, native exit code and all partial lifecycle
fields survive. Unknown acquisitions/counts/cleanup remain unknown/unqualified;
force attempts are retained even if the child races to a natural exit.

Bounds: each direct child30s, whole phase180s, failed-child cleanup5s; stdout and
stderr each64KiB, each output file64KiB, complete owned pack2MiB. A131072B reserve
protects the two final records. RLIMIT_FSIZE enforces the per-file write ceiling
for controller and children; stream handling counts full actual chunks and copies
only remaining retained bytes. A strict source-bound file inventory, ownership,
mode, link, size and aggregate checks run between and during stages. Each stage
must preserve all existing generated files/configuration byte-for-byte. A failure
stops the finite sequence, preserves partial calls and writes qualifiedfalse when
capture remains possible. Cleanup uncertainty never becomes a successful record.

The proposed later invocation is the exact pinned recipe Python executable with
`-I -S -B prepare.py ABS_EXTERNAL_RELEASE EXTERNAL_RELEASE_SHA256`. The outer
runner must supply exactly the recipe's replacement environment also to this
controller. Isolated/no-site/no-bytecode flags and that exact environment are
checked before output creation. The external root
release is an independently reviewed actual artifact, not included or fabricated
here. Its exact keys are schema, decision, rootSession, output, sourcePins,
toolClosure, sourceReviews and authors. Required values are:

- schema `e06-isolated-tls-materialization-release-v1`;
- decision `RELEASE_EXACT_ELEVEN_OFFLINE_TLS_STAGES`, rootSession `/root`;
- the single output path above, exact seven-file current source map and exact
  recipe tool map, without future output hashes;
- authors `/root/https_acquisition_implementer` and `/root` in that order;
- sourceReviews: an actual flat descriptor for the independent QA/security
  `e06-https-current-source-reviews-v1` pack over the union of source/tool maps.

The interpreter and OpenSSL/loader/shared-library/cache pins are finite observed
metadata. Python standard-library imports, kernel/vDSO/CPU, entropy, clocks,
filesystem scheduling and actual dynamic accesses remain host assumptions. The
controller is not a sandbox or hermetic runtime proof. Event-loop scheduling and
Popen/OS calls are not hard realtime. The new fixed capture.py derivative
observes preparation for190s with a reserved5s cleanup inside its195s total
scheduling guard. It records complete actual EOF/reap/forced/unknown facts,
checks final source/tool/release/review/research pins and caps each retained
stream/file64KiB and its separate owned pack196608B. Its fresh0700 output is
`/tmp/nbdp-e06-https-tls-outer-r2`; it supplies the same exact six-variable
replacement environment and empty-file stdin. No controller is executed or
authorized here. Only the11 direct OpenSSL children and one direct preparation
process are observed. Forced or unknown outer containment remains UNQUALIFIED,
with no claim about arbitrary escaped descendants or injected OS faults.

Native text inspection checks exact subjects/issuers, serials, RSA2048/SHA256,
critical usage/basic constraints, leaf serverAuth/SAN, key identifiers and actual
DER fingerprint. Unexpected native output/profile is refused rather than guessed.
Actual read-only researcher clarification supports the exact configured3 root
and6 leaf extensions: shared OpenSSL3.6.1 signing source preserves explicit key
identifiers and adds no default AKI for a certificate signed by its own key.
The researcher did not retrieve req.c; that linkage uses official req docs plus
shared signing-source inspection. This is source evidence, not API/runtime
qualification. The literal extension policy remains fail-closed. Dates are parsed from observed native
fixed-English-month/GMT text with explicit UTC, retaining raw observations; final current time must lie in each
one-day interval with at least300000ms until earliest expiry. No backdating,
expiry bypass or future validity hash is invented. Downstream protocol also
independently parses actual X509 dates/signatures and leaf keypairs before use.

Successful future materialization emits the existing exact9-key protocol envelope
`e06-isolated-cert-materialization-v1`: schema, qualified, sourcePins, toolClosure,
sourceReviews, calls, outputs, validity, authors. Each of11 calls has exactly7
keys: ordinal, argv, cwd, stdin, stdout, stderr, lifecycle. Descriptor paths/hashes,
validity epoch-ms maps and earliest expiry come only from actual produced bytes
and observed dates. Separate execution.json retains actual UTC/elapsed time,
certificate inspection, native failure and final integrity. The output map is
ca plus server/wrongSan key/cert descriptors. No certificate acceptance or
materialization review is generated: actual independent evidence review must
create the downstream certificate-evidence/acceptance envelope separately.

Next gates: actual independent SOURCE/configuration review, exact external
materialization release, one separately authorized actual11-call generation,
independent materialization review and separately released acquisition work.
No Nostr wrapping, attachment encryption, browser/server/client/network activity,
SDK, production, Git publication or architecture/Q change is part of this task.

The initial five sources and independent HOLD reports are preserved by root under
initial-tls-source. This remediation addresses the actual union of two MEDIUM
findings: unsafe group operations after leader reap and the enclosing extension
header being counted as an individual extension. The parser now delimits one
enclosing section, recognizes individual headers only and retains exact3/6 sets,
duplicate refusal, criticality/value and unknown-line checks.

Technical model delta requiring independent delta review: the prior unsafe
post-reap numeric groupAbsent predicate is removed, not replaced with a fabricated
true. waitid(WNOWAIT) retains the original leader until the last possible group
cleanup; every signal first confirms that unreaped owned leader. ECHILD, missing
or changed identity disables signaling and remains unknown. Final wait is the
single reap location, after all group decisions. There is no later numeric PID/
PGID probe, signal, poll or process-group-absence claim. Natural qualification
requires actual exit observation, EOFs and confirmed reap without force, error or
unknown ownership. This does not assert descendant containment.

capture.py derives only its guarded owned-process cleanup pattern from accepted
e06-recovery-barecall-source-r1/capture_execution.py (6557B; SHA256
d03bed5fdd1496cbdbde4deb9605768af1bb5cddd6e7d8cea86a657bfe90eeac),
read and hashed during source preparation. It uses the same private inert
ownership helpers as prepare.py.

The concrete outer command template is the pinned recipe Python executable with
`-I -S -B /home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_https_tls_fixture_v1/capture.py ABS_EXTERNAL_RELEASE EXTERNAL_RELEASE_SHA256`,
with closed stdin and exactly recipe.environment as the replacement environment.
The release path/SHA must identify the actual separately issued root artifact;
none is invented here. capture.py constructs only the fixed matching prepare.py
command; no caller command/module/case is accepted.

The one pure_controls.py source preserves the original28 prospective controls: three native-
format synthetic extension profiles, each with positive/missing/extra/duplicate/
changed-criticality/changed-value variants, two structural section negatives and
eight explicit fake-handle ownership sequences. The enclosing native header is
present in all three positives. The controls never generate certificates, invoke
a real process, wait on an OS child, signal a real PID/group or run a TLS API.
Their explicit fake callbacks exercise the same ownership helper used by both
controllers. These are NOT_EXECUTED expected checks, not actual observations.
A separate actual pure-controls release, execution and independent evidence
review remain required after independent delta/configuration acceptance.

## R2 date-format correction after actual R1 negative

The root-retained actual R1 attempt exited outer1 after six natural native
exit0/EOF/reap/unforced calls. The materialization remained qualifiedfalse.
TLS06.stdout contained `Not Before: Oct 19 22:26:41 2026 GMT` and the controlled
label padding `Not After : Oct 20 22:26:41 2026 GMT`; the prior ISO-only/date-label
expectation refused this actual text. Both the ISO assumption and the exact
pre-colon label assumption are corrected at SOURCE level only. Root retained
all48 evidence subjects byte-identically in tls-materialization-negative-r1/
evidence.json (19486B; SHA256
977b7c544d322d78d3034539878c628a8810a19cec04d3031db135434c273471).
The historical `/tmp/nbdp-e06-https-tls-r1` and outer-r1 outputs remain unchanged.

certificate_validity now requires exactly one each of the two known labels,
ASCII indentation up to16 spaces and at most one space immediately before the
colon. It accepts the fixed English month names and native two-column day with
GMT only, constructs a calendar-valid datetime with explicit UTC and derives
epoch milliseconds by integer arithmetic with a JavaScript-safe-integer bound.
Unknown labels/zones/months, duplicate/missing labels, excessive padding, invalid
calendar values, oversized inputs/fields and nonnative date formats refuse.
There is no locale-dependent strptime, timezone inference or validity override.
The existing one-day interval/current-time/minimum300000ms-until-earliest-expiry
checks remain unchanged. The11 OpenSSL argv arrays change only the owned root;
provider ordering, -dateopt and all other arguments remain unchanged.

The proposed fresh generation and outer paths are now r2 as specified above.
No r2 output is created during this correction. All7 source names, native
materialization9/call7 key shapes, toolClosure9 and authors remain unchanged.
The existing28 pure-control source cases remain intact. Exactly20 new inert
date cases append retained native literal rows, padded single-day and leap-day
positives, and unknown month/zone/label, impossible/nonleap/time values,
zero/overflow year, oversized text, duplicate/missing labels, padding and
nonnative-format refusals. The new prospective total is48, all NOT_EXECUTED
in this source task. Existing actual R1 and earlier control evidence is not
rewritten or promoted. Independent delta/configuration review, a new explicit
pure-controls release and fresh generation release precede any further execution.
