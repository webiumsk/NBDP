# E06 isolated HTTPS acquisition source

State: **SOURCE PREPARED / NOT EXECUTED / NO RUNTIME AUTHORITY**.
Component: `HTTPS_ACQUISITION_AND_ORIGINAL_RECOVERY_ONLY`.
All fourteen cases remain NOT_EXECUTED. Compilation establishes syntax only.

This new namespace implements the separately released source task in
`docs/decisions/evidence/invoice-authenticated-carrier/e06-https-acquisition-preparation-r1/source-implementation-release.json`.
The immutable SOURCE-PLAN and mandatory HEADER-API-ERRATUM are both inputs.
Selected recovery48/52 acceptance is a satisfied prerequisite; it does not admit
new HTTPS, fixture or certificate work. E02 and overall E06 remain PARTIAL.
Q01/Q08/Q13/Q15/Q27, SDK and production boundaries remain unchanged.

## Ownership and unchanged source

The parent `/root/recovery_fixture_parent` owns contract/profile/recipes,
protocol, preparation, admission, coordinator, controls and this document.
`/root/https_acquisition_implementer` owns only acquisition.mjs;
`/root/https_consumer_implementer` owns only consumer.mjs.
Existing sources, evidence, architecture, state, roadmap and Git are untouched.
Independent reviews exclude all three authors, coordinator `/root`, and the plan
architect. Future certificate reviews additionally exclude their actual authors.

consumer.mjs dynamically imports the unchanged shared attachment-crypto.mjs.
Node uses the local bare consumeAttachment binding, after durable journal.begin.
Browser uses unchanged BrowserCrypto.start/consume and independent browser/server
cleanup attempts. The accepted2937-byte strict native classifier is copied
verbatim; both ambiguous authentication branches return null, and unknown thrown
values are rethrown unchanged. No crypto algorithm implementation is added.
Browser startup30s, close15s and independent loopback-server close5s remain
separate from the HTTPS5s cleanup budget.

## Fixed interfaces and admission

Public entry points (fixed files loaded under Python `-I -B`):

- `run.py MANIFEST MANIFEST_SHA RELEASE RELEASE_SHA`
- `prepare.py MANIFEST MANIFEST_SHA RELEASE RELEASE_SHA` (PREPARE only)
- `admission.py MANIFEST MANIFEST_SHA RELEASE RELEASE_SHA` (pure admission)
- `controls.py MANIFEST MANIFEST_SHA FRESH_OUTPUT` (pure controls, later release)

Private Node entries:

- `prepare.mjs ABS_FRAME FRAME_SHA`
- `prepare.mjs --rpc ABS_BINDING BINDING_SHA` (fixed ordinal0..15 only)
- `acquisition.mjs ABS_FRAME FRAME_SHA`

consumer.mjs is an inert private export; direct execution refuses. Shared protocol
exports are enumerated in contract.json. Root creates future actual manifests,
review/qualification packs and external releases after independent source review;
no future hashes, certificates, wire IDs or generated output descriptors exist
in this source package.

The native manifest has the exact fifteen fields listed in contract.json.
It binds the component, phase, label, fresh `/tmp/e6https-...` output, exact tools,
current map, source reviews, contract/profile, inputs, qualification, prerequisites,
observer-only expected descriptor and fixed guard IDs. The release binds that
manifest descriptor, phase, source reviews and qualification. It must be SHA-bound
externally. Current maps cover the finite actual transport/metadata/browser
imports/assets, tools, current files and accepted scoped prerequisites/provenance.
There is no old932/917 map, recursive16k history walk or replay of140/1106 jobs.
Full metadata212/480 and fixture108 acceptance remain provenance; the smaller
relay8/10 component does not replace them. Pinned E02 PARTIAL is retained under
the adopted transport evidence rule rather than silently converted to PASS.

Both Python and private Node admission independently verify the fixed source
map/reviews/release and required inputs before target APIs. Reviews have distinct
actual QA/security sessions and exact native subjects. Review packs are external
coordinator transcriptions of real reports; they are not cryptographic identity
attestations. Old qualifications cannot authorize this namespace. Pure common
admission may omit future qualification during guard preparation; workload
admission always requires the exact current qualified guard pack and root release.

The eight-field private frame contains no expected plaintext, public claimed
metadata/subject token, arbitrary module, command or URL. ACQUIRE inputs are only
fixtureAcceptance and certificateAcceptance descriptors. The manifest's whole
expected observations stay observer-only; none is sent to a metadata/native crypto
API. protocol authenticates fresh raw D/F internally and retains the exact child
stdin/stdout/stderr/lifecycle. Whole13-key metadata replies must match the
independently frozen proofs. Subject values derive from actual authenticated D/F.

WeakMap handles establish local source ownership and same-case identity; they
are not cryptographic network attestation. acquisition owns the actual HTTP
callback/chunk lineage. Only its complete actual20-byte entity enters createSnapshot;
count/x and D.document.bytes agreement are checked again before one consumer read.
The server's prepared blob is never substituted as a consumer input. No URL
reopen/reread, caller-authorized snapshot or partial plaintext release is allowed.
Consumer record files contain record:null; the in-memory published fact carries
the descriptor of that exact file, avoiding a self-hash cycle.

## Future fixed fixture preparation

fixture-recipes.json pins the actual old20-byte blob, unchanged invoice and
credit-note D payloads/wires, selected old proof rows and retained whole metadata
templates. Existing D is neither reconstructed nor rewrapped.

Both existing JS and original baseline Rust constructors must produce BOTH new
canonical F families and agree on complete typed rumor, canonical bytes and ID.
Use Rust invoice F and JS credit-note F for incoming/archive wrappers. Exact future
work is4 construct +4 wrap +8 independent inspections =16 RPCs, eight JS/eight Rust;
attachment encryption remains0. Eight retained D and eight new F raw proofs feed
four independently derived whole metadata expectations. New F URLs contain the
explicit high port and cannot reuse old F identities. Metadata target answers do
not generate their own oracles. All RPC raw streams and lifecycle facts are retained;
partial preparation cannot qualify the full catalogue. PREPARE result counts describe
its16 RPCs; outer acquisition count fields do not claim zero total preparation work.

Actual fixture acceptance is external and independently reviewed. Old108 release
is not generic construction authority. A new exact PREPARE manifest/release and
qualified current source/controls must precede any constructor/wrap/inspect call.

## Future certificate prerequisite

No certificate generator is implemented or run here. Research is provenance only.
A later separately reviewed/released preparation must supply actual isolated CA,
files.invalid leaf and wrong.files.invalid leaf/key descriptors. The six-field
certificate acceptance contains schema, decision, ca, server, wrongSan and reviews;
its closed evidence envelope binds materialization, certificate-source reviews and
actual independent acceptance. Exact nested schemas are in contract.json.

Materialization must identify actual authors, current source/tool closure, output
subjects and eleven raw stages: first ten natural0, final natural nonzero specifically
hostname mismatch after otherwise-valid wrong-SAN own-host verification0. All stages
require real reaped/EOF/unforced records; a generic failing command is insufficient.
Source-only acceptance is insufficient for generated certificate bytes.

Before acquisition the child independently parses actual X509 bytes, requires exact
SANs, CA signatures and private/public key agreement, derives notBefore/notAfter and
earliestExpiry, compares captured validity facts, and requires current validity with
at least300s remaining. Dates originate from future actual generation; no backdating
or current certificate/runtime success is claimed. The normal TLS client additionally
performs ordinary CA/hostname validation with explicit isolated CA and SNI.

## Fixed cases and truthful results

contract.json freezes fourteen whole twelve-key observations before target execution.
H01 is JS metadata/NodeEVP invoice; H02 is Rust metadata/ChromeWebCrypto credit note.
Expected maximums:14 metadata calls,3 native consumer calls,12 acquisition connection
attempts,11 GETs and0 attachment encryptions. H03/H04 authenticate then refuse policy
before any acquisition. H05 permits one TLS attempt and no GET. H09 rejects Content-
Length21 framing; it does not claim that a21st entity byte under Content-Length20
was delivered. H13 invokes the actual private snapshot ownership predicate after an
actual complete GET. H14 injects a source-bound component cleanup fault after native
engine success; it is not a claim of real OS cleanup failure.

The positive component results naturally exit0. Declared negative component results
naturally exit1 and remain unqualified; the parent qualifies a negative only when
its entire observation, exact case/exit, cleanup and retained provenance match.
H14 additionally requires retained actual successful engine/journal/snapshot facts,
componentFault:true, no public original and independently real harness cleanup.
Any setup failure, unknown error, missing result, changed count or uncertain cleanup
fails the harness. A matching negative does not become VERIFIED_BYTES.

## Bounds and retained evidence

HTTPS uses only files.invalid:18443 mapped explicitly to127.0.0.1, one GET, no retry,
redirect/proxy/cookie/credentials/decompression or alternate address. Busy port refuses.
Node parser maxHeaderSize16384 is parser accounting, not raw serialized/TLS/network
bytes. maxHeadersCount0 is set synchronously, followed by explicit64-pair/duplicate-
framing checks. Encoded parsed-header evidence has its own bounded16KiB construction.
Actual body chunks are counted fully; a separate fixed21-byte copy buffer bounds
retention, not incoming chunk size, socket allocation or process RSS.

ACQUIRE has a900s cumulative phase budget; PREPARE remains300s with a295s child bound.
The per-case acquisition outer bound150s includes metadata/HTTPS/native work.
The parent watches the durable consumer journal at100ms intervals and imposes a120s
consumer deadline, subject to scheduling; native async operation100s plus independent
15s/5s cleanup are separate. Forced direct-child cleanup/reap is bounded5s and each
stream pump joins at most5s. These bounds are not realtime guarantees and do not prove
OS descendant containment. Any forced/unknown lifecycle remains unqualified.

Raw child streams retain bounded16MiB stdout/64KiB stderr prefixes with observed EOF,
natural status, acquisition ledger and overflow/failure facts. Network/consumer counters
latch unknown before fallible launches and are restored only from fully validated retained
native results; prior unknown remains unknown. Every actual owned frame/raw reply/journal
is inventoried with size/hash; a forced failure inventory may be incomplete and cannot
qualify the workload. The owned pack limit is32MiB. Capture/manifest describe actual
outputs rather than planned counts. No plaintext oracle crosses a private API.

## Validation and remaining gates

Only source/data read/write/hash derivation, byte-lineage checks and Python compile-only/
pinned Node --check are authorized/performed in this task. A preparatory JSON derivation
shape error and an initial prepare.mjs syntax error were corrected; no target ran.

Remaining: independent whole-source QA/security; exact external source/config/release
subjects; separately authorized certificate/fixture materialization; actual pure HG01–HG14
controls (including actual Node parser/private-handle predicates); independent guard review
and positive pure admission; concrete primary and independent QA runtime releases;
actual fourteen-case acquisition/capture review. Compilation is not interoperability.
No certificate, constructor, control, metadata, crypto consumer, browser, server, network
or experiment has executed in this assignment. No approval of our own findings is claimed.


## Bounded remediation after initial independent HOLD

The initial twelve-file source freeze and both initial QA/security reports remain
retained by the coordinator. Changes are restricted to protocol.mjs, admission.py,
controls.py, contract.json and this document; both worker bodies stay byte-identical.
These are source corrections, not executed regressions or accepted runtime results.

Prerequisites now use exact descriptor-bound native schema/decision/component/scope
fields. The immutable relay acceptance has PASS/perRun evidence and no qualified
field; the adapter explicitly recognizes that native schema. Other accepted records
retain qualified:true. Legacy E01/E02/E05 retain their exact PASS/PARTIAL statuses.
Only these pinned historical-native records permit finite fractional observer timing
values; duplicate/scalar/nonfinite/unsafe integer checks remain. Private frames,
wire/oracle/control evidence continue to require the strict integer reader.

Qualification v2 subjects are exactly {sourcePins,actualControlEvidence}. The actual
evidence binds the fourteen-row capture, external Python tool receipt/stdin/stdout/
stderr and the HG14 Node receipt with actual fixed argv/environment/cwd, raw streams,
natural status, PID, EOF and reap. Capture/source review names alone are insufficient.
Distinct independent reviews must say ACCEPT_PURE_CONTROL_EVIDENCE_ONLY with scope
PURE_CONTROL_EVIDENCE_ONLY over those exact subjects. Source-only review replay
refuses. Timing fields in new evidence, if present, must be integer milliseconds.
The coordinator supplies the actual external receipt after the later released control
run; this source package invents no successful receipt or qualification artifact.

Public consumer counts are normalized in the published copy from the complete,
finalized raw journal: consistent RETURNED/THREW retains1; NOT_CALLED is0;
PENDING/unfinalized/capture-uncertain/incomplete facts remain null. The raw journal
and genuine native THREW evidence stay unchanged. Failed durable begin writes
therefore cannot turn a PENDING1 journal into a claimed known API invocation.

Certificate provenance binds the separately prepared TLS source inventory and exact
recipe/tool closure to all eleven argv/cwd/stdin/config/output paths. TLS10 must be
the wrong-SAN certificate's own-host positive verification; TLS11 must use that same
certificate with files.invalid and the specific native hostname error. Arbitrary
commands printing a matching substring cannot qualify. Actual config-copy bytes and
empty provider/engine directories are checked before use. Lifecycle requires safe
ownership retained until actual reap and qualified cleanup; no post-reap PGID probe
or global descendant-containment claim is required or inferred.

Existing HG06/HG10/HG13/HG14 include focused pure regressions for all four findings,
including actual native-schema positives, deliberate scope/descriptor/argv/operand/
raw-output drift, source-review replay, incomplete evidence, and uncertain counters.
Synthetic in-memory predicate calibrations are never certificate/API/OS outcomes.
All fourteen IDs are retained; execution and independent delta review remain pending.


The current certificate binding pins the final seven-file TLS source inventory
(prepare/capture/pure_controls/recipe/configs/SOURCE) and its nine-member actual tool
closure. This is source correspondence, not certificate materialization acceptance;
all certificate outputs and TLS operations remain NOT_EXECUTED. The coordinator's
new freeze must record the complete current native source map, and actual independent
source/control review subjects must adopt that full map explicitly. The initial
263-member map remains historical; the current deduplicated union has278 members.


## TLS r2 source binding after retained r1 negative

The actual r1 preparation stopped after six natural-zero stages with
NATIVE_ISO_UTC_VALIDITY; TLS07–TLS11 did not run. Its complete negative evidence
remains at tls-materialization-negative-r1/evidence.json under the preparation
evidence directory. A text-date parser assumption failed on actual GMT and padded
Not After labels; this is not accepted certificate materialization.

The current contract now binds the corrected seven-file TLS r2 source inventory,
recipe and exact /tmp/nbdp-e06-https-tls-r2 root/environment/eleven argv/operands.
Only those source pins and recipe-derived paths changed; tool closure, config
bytes, 278-member map cardinality, fourteen HTTPS cases and all prior gate/counter/
evidence algorithms are unchanged. The TLS package adds twenty prospective date
predicate fixtures to its retained twenty-eight controls; no r2 control or TLS
operation has executed at this source-binding handoff. Source acceptance for r1
is historical and does not admit r2. Fresh independent source review and concrete
controls/materialization reviews/releases remain required.


## Completion-lifetime source repair after diagnostic r1

The separately released first-JS-file-rumor diagnostic completed all instrumented
stages in actual root session27133 (natural0,4.858121540979482s), returning only an
846-byte candidate. Its evidence is diagnostic-r1/evidence.json under the preparation
evidence directory (3943 bytes, SHA256
838ccb1aa2b40ced050e7aa6a1f94df6c1abb25baa73b4e3a96b5e9aea9b2686).
Independent diagnostic evidence audit is pending at this source handoff. This is
not accepted fixture preparation, and the original silent-exit cause remains
UNDETERMINED. Instrumentation, top-level await and a referenced timer changed
process lifetime; success under that instrumentation is only plausibility evidence.

Only prepare.mjs entry dispatch now explicitly awaits the selected helper/main
promise at top level. RPC mode alone adds a referenced14_000ms completion watchdog.
At the deadline it writes the unique RPC_COMPLETION_DEADLINE marker, then self-exits124
once that stderr write completes. A finally block clears the timer after resolution
or rejection; the existing caught stack/exit1 behavior is retained. A blocked event
loop or stderr sink can delay the timer/write, so there is no hard realtime guarantee.
The parent's existing15_000ms deadline remains independent.

Exit124 is always unqualified, even when the outer receipt says forced:false:
that field concerns outer intervention, not this child's own deadline. All existing
functions/APIs/constructor/wrap/validator calls, sixteen-RPC plan, whole oracles,
ONE_REPLY/EOF/reap/natural-exit qualification and bounds remain unchanged. Old failed
captures and old source copies remain retained. No automatic fixture rerun follows.
Fresh source review, current278-map/source/qualification/configuration/release binding
and actual subsequent evidence are required. This repair is SOURCE ONLY; only pinned
Node --check is performed here, with no imports, controls or project API execution.


## Explicit helper output-completion source repair

The paired actual nested-entry observations differ: the exact bare helper under
Python Popen returned846 bytes, while the minimal Node parent launching the same
helper/argv/environment/cwd/stdin observed natural0 with empty stdout/stderr.
Mechanism remains UNKNOWN. Retained evidence is nested-entry-diagnostic-r1/evidence.json
(4466 bytes, SHA25689a5cd0c7abae7683cdd79aa5ef930cc4aedb3c8b030a5286c740ea0e63e203c).
These paired outcomes do not prove the original cause or qualify fixture preparation.

A concrete completion gap exists independently of that unexplained behavior:
helper previously returned after enqueueing process.stdout.write, before its callback.
Only that one write now awaits a Promise resolving from the existing write callback
or rejecting its error. Exact serialized bytes and constructor/API calls are unchanged.
The existing referenced14s RPC watchdog is cleared in finally only after this callback
completes or fails; write errors retain rejection/stack/exit1. Callback completion is
not durable storage or recipient receipt. The parent15s deadline, stdin, main flow,
ONE_REPLY, sixteen-RPC plan, all whole oracles/profiles/contracts and failure gates
are unchanged. No cause claim, forced pass or automatic rerun follows.

This is a two-file SOURCE ONLY correction. Only pinned Node --check is performed;
no imports, runtime/API/control/diagnostic rerun or evidence mutation occurs. Fresh
independent source/current278-map review, actual guards/configuration/release and
subsequent evidence remain separate gates.


## Bounded synchronous RPC reply source repair

Actual pure process-I/O calibration in spawn-io-calibration-r1/evidence.json
(5153 bytes, SHA256 c41f9cafe9233361d29792275159b887c96f00cc10f429176107aeba61661fae)
recorded the parent receiving the17-byte synchronous marker on each stream.
Independent child markers recorded successful asynchronous callbacks for19-byte
writes on each stream, while the parent received neither asynchronous marker.
This narrowly supports using synchronous output for this helper invocation; it
does not establish the original empty-reply mechanism or a general Node defect.
The calibration is diagnostic evidence only, not fixture or HTTPS qualification.

Only the RPC helper output is changed: serialize its existing JSON-plus-LF reply
once into a Buffer, refuse more than16777216 bytes, and call builtin writeSync on
fd1 exactly once. The returned count must equal the full Buffer length; short or
zero counts throw RPC_WRITE_COMPLETE. Native exceptions, including EAGAIN and
EWOULDBLOCK, propagate unchanged to the existing caught stack/exit1 path. There is
no retry, spin, asynchronous fallback or second write. Main-mode stdout is unchanged.

The existing top-level await and referenced14-second RPC watchdog remain unchanged.
A synchronous write can block the JavaScript thread, so that watchdog cannot
interrupt it. The separate parent15-second deadline is an external cooperative
guard with event-loop/OS scheduling limits, not a hard realtime guarantee; forced
or incomplete replies remain unqualified. A successful write count is not durable
storage or recipient acknowledgement. The previous callback repair remains in
source history; it did not resolve the observed empty replies in the full invocation.

All constructor/API calls, stdin, sixteen-RPC plan, ONE_REPLY/lifecycle checks,
whole oracles, recipes, ciphertext/blob commitments, profiles and contracts remain
unchanged. Source-only checks comprise pinned Node --check and finite inert checks
of this extracted write fragment with a mocked writeSync: full/short/zero counts,
EAGAIN/EWOULDBLOCK/other native errors and exact/oversized byte limits. These checks
do not execute the helper, project imports or APIs and do not establish runtime
interoperability. Current278/source review, fresh actual guards/qualification,
configuration/admission and a separately released PREPARE remain future gates.
No automatic rerun, new accepted fixture, configuration or admission follows.


## ACQUIRE-only cumulative phase-budget source amendment

Actual primary51061 ended FAILED/UNQUALIFIED after301.7930540810339s under the
former300s cumulative phase budget. H01-H08 matched their exact whole expectations;
H09 exhausted the remaining phase allowance and was forced, and H10-H14 were not
executed. Aggregate counters remain null and finalIntegrity false. The retained
negative evidence, including147 durable mirrors, is acquisition-primary-negative-r1/
evidence.json (89305 bytes, SHA256
90a9871a695cb6e942a556e9e9fcbfcc7df3dfdc52d9a637fa1deacff1acba4a).
The failed capture is unchanged; partial matches are not whole HTTPS qualification.

Independent QA/security identified an insufficient cumulative phase budget. Their
approximately482s fourteen-case timing projection supports a900s ACQUIRE allowance
with margin, not a completion guarantee. One source-owned phase_budget_seconds
selects900 only for ACQUIRE and300 otherwise; both prelaunch remaining-time checks
and the final elapsed-time check use that same value. Profile timersMs.phase and
contract boundInterpretation.phaseMs now describe ACQUIRE900000ms. PREPARE remains
300s, with its existing295s child cap; acquisition children remain capped at150s
or the actual remaining phase time, whichever is smaller.

Consumer120s, browser30s startup/100s operation/15s close/5s server close and every
network1s/3s/10s timer are unchanged. Certificate validity still requires at least
300000ms remaining; that independent threshold is not the phase budget. Metadata,
whole fourteen-case observations/counts, sixteen preparation RPCs, APIs, recipes,
D/blob commitments, synchronous RPC reply fix and all lifecycle/failure checks are
unchanged. Forced or unknown execution remains unqualified.

This is source-only remediation: compile(source,...) without import or .pyc and
finite inert extracted phase-selection/remaining/cap/final checks are permitted;
no controls, admission or target execution occurs. Fresh current source review,
actual guards, configuration/admission and external releases are still required.
Accepted F/TLS artifacts may be carried forward only after independent current pin
and certificate-validity checks. A fresh full primary and separate independent QA
run remain future work; no automatic retry or whole E06 PASS follows.
