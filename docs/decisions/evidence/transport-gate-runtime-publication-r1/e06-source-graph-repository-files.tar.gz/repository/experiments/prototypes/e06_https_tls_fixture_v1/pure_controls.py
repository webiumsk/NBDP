"""Fixed inert regression source, NOT_EXECUTED. No real process or certificates.

Later separately released controls may import module definitions only. Text below
is synthetic native-format extension evidence, not generated X509/crypto output.
All process handles, wait observations and group signals are explicit fakes.
"""
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).absolute().parent
KID = '11:' * 19 + '11'


def load_helpers():
    spec = importlib.util.spec_from_file_location('e06_tls_pure_prepare', HERE / 'prepare.py')
    module = importlib.util.module_from_spec(spec)
    exec(compile((HERE / 'prepare.py').read_bytes(), str(HERE / 'prepare.py'), 'exec'), module.__dict__)
    return module


def fixture(san):
    entries = [('Basic Constraints', 'critical', 'CA:TRUE, pathlen:0' if san is None else 'CA:FALSE'),
               ('Key Usage', 'critical', 'Certificate Sign, CRL Sign' if san is None else 'Digital Signature, Key Encipherment'),
               ('Subject Key Identifier', '', KID)]
    if san is not None:
        entries += [('Extended Key Usage', '', 'TLS Web Server Authentication'),
                    ('Authority Key Identifier', '', KID), ('Subject Alternative Name', '', 'DNS:' + san)]
    blocks = [f'            X509v3 {name}: {critical}\n                {value}\n'
              for name, critical, value in entries]
    return 'Certificate:\n    Data:\n        X509v3 extensions:\n', blocks, '    Signature Algorithm: sha256WithRSAEncryption\n'


class FakeChild:
    def __init__(self, events, reaped=False):
        self.pid, self.returncode, self.events = 4242, (0 if reaped else None), events

    def wait(self, timeout):
        if self.returncode is not None or timeout != 0:
            raise AssertionError('FAKE_REAP_ORDER')
        self.events.append('REAP')
        self.returncode = 0
        return 0


class FakeExit:
    def __init__(self, pid):
        self.si_pid = pid


def main():
    if len(sys.argv) != 1 or not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode):
        raise ValueError('FIXED_ISOLATED_PURE_CONTROLS_ONLY')
    helper = load_helpers()
    rows = []
    def reject(identifier, text, san, reason):
        try:
            helper.validated_extensions(text, san)
        except ValueError as error:
            helper.need(str(error) == reason, 'WRONG_REFUSAL_' + identifier)
            rows.append({'id': identifier, 'observation': 'REFUSED', 'reason': str(error)})
        else:
            raise AssertionError('UNEXPECTED_ACCEPT_' + identifier)
    for profile, san in [('ROOT', None), ('SERVER', 'files.invalid'), ('WRONG', 'wrong.files.invalid')]:
        start, blocks, end = fixture(san)
        text = start + ''.join(blocks) + end
        value = helper.validated_extensions(text, san)
        helper.need(value == {'subjectKeyIdentifier': KID, 'authorityKeyIdentifier': None if san is None else KID}, 'POSITIVE_TEXT_' + profile)
        rows.append({'id': profile + '_VALID', 'observation': 'ACCEPTED', 'value': value})
        reject(profile + '_MISSING', start + ''.join(blocks[:1] + blocks[2:]) + end, san, 'EXACT_X509_EXTENSION_SET')
        unknown = '            X509v3 Unknown Extension:\n                unknown\n'
        reject(profile + '_EXTRA', start + ''.join(blocks) + unknown + end, san, 'EXACT_X509_EXTENSION_SET')
        reject(profile + '_DUPLICATE', start + ''.join(blocks) + blocks[2] + end, san, 'DUPLICATE_OR_EMPTY_X509_EXTENSION')
        reject(profile + '_CRITICAL', text.replace('Basic Constraints: critical', 'Basic Constraints: '), san, 'EXACT_X509_EXTENSION_VALUE')
        reject(profile + '_VALUE', text.replace('CA:TRUE, pathlen:0' if san is None else 'CA:FALSE', 'CA:TRUE, pathlen:1'), san, 'EXACT_X509_EXTENSION_VALUE')
    start, blocks, end = fixture(None)
    reject('NO_CONTAINER', ''.join(blocks) + end, None, 'ONE_X509_EXTENSION_SECTION')
    reject('NO_TERMINATOR', start + ''.join(blocks), None, 'UNTERMINATED_EXTENSION_SECTION')

    def guard_case(identifier, reaped=False, confirmed=True, event=None, error=None, expected_signal=False):
        events, ownership = [], {'confirmed': confirmed}
        child = FakeChild(events, reaped)
        def waitid(*args):
            events.append('OBSERVE')
            if error is not None:
                raise error
            return event
        def signal_group(pid, sig):
            helper.need(child.returncode is None and ownership['confirmed'] and pid == 4242, 'UNOWNED_FAKE_SIGNAL')
            events.append('SIGNAL')
        state = helper.signal_owned(child, ownership, signal_group=signal_group, waitid=waitid)
        helper.need(('SIGNAL' in events) == expected_signal and state['terminationAttempted'] == expected_signal, 'OWNERSHIP_GUARD_' + identifier)
        if reaped or not confirmed:
            helper.need(events == [], 'ACTION_AFTER_OWNERSHIP_RELEASE')
        if error is not None or (event is not None and getattr(event, 'si_pid', None) != 4242):
            helper.need(not ownership['confirmed'] and state['cleanupErrors'], 'UNKNOWN_OWNERSHIP_NOT_RETAINED')
        rows.append({'id': identifier, 'observation': state, 'events': events, 'ownershipConfirmed': ownership['confirmed']})

    guard_case('OWNED_ALIVE', expected_signal=True)
    guard_case('OWNED_EXIT_UNREAPED', event=FakeExit(4242), expected_signal=True)
    guard_case('REAPED_NO_GROUP_ACTION', reaped=True)
    guard_case('UNKNOWN_NO_GROUP_ACTION', confirmed=False)
    guard_case('ECHILD_NO_GROUP_ACTION', error=ChildProcessError('SYNTHETIC_ECHILD'))
    guard_case('WRONG_ID_NO_GROUP_ACTION', event=FakeExit(4243))
    guard_case('MISSING_ID_NO_GROUP_ACTION', event=object())
    events, ownership = [], {'confirmed': True}
    child = FakeChild(events)
    life = {'leaderExitObserved': helper.observe_owned_exit(child, ownership, waitid=lambda *args: FakeExit(4242))}
    helper.reap_observed(child, ownership, life)
    state = helper.signal_owned(child, ownership,
        signal_group=lambda *args: (_ for _ in ()).throw(AssertionError('POST_REAP_SIGNAL')),
        waitid=lambda *args: (_ for _ in ()).throw(AssertionError('POST_REAP_PROBE')))
    helper.need(events == ['REAP'] and life['reaped'] and not state['terminationAttempted'], 'SINGLE_FINAL_REAP')
    rows.append({'id': 'SINGLE_REAP_THEN_NO_ACTION', 'observation': state, 'events': events})
    helper.need(len(rows) == 28, 'FIXED_CONTROL_COUNT')
    # Literal rows retained from actual TLS06 r1; these tests are inert text,
    # not a rerun or a generated certificate/validity override.
    retained = ('            Not Before: Oct 19 22:26:41 2026 GMT\n'
                '            Not After : Oct 20 22:26:41 2026 GMT\n')
    date_cases = [
        ('DATE_RETAINED_ROWS', retained, {'notBefore': 1792448801000, 'notAfter': 1792535201000}),
        ('DATE_SINGLE_DAY', retained.replace('Oct 19', 'Oct  9').replace('Oct 20', 'Oct 10'),
            {'notBefore': 1791584801000, 'notAfter': 1791671201000}),
        ('DATE_LEAP', '            Not Before: Feb 29 00:00:00 2024 GMT\n            Not After : Mar  1 00:00:00 2024 GMT\n',
            {'notBefore': 1709164800000, 'notAfter': 1709251200000}),
        ('DATE_MONTH_UNKNOWN', retained.replace('Oct 19', 'Foo 19'), 'NATIVE_GMT_DATE_FORMAT'),
        ('DATE_IMPOSSIBLE_DAY', retained.replace('Oct 19', 'Apr 31'), 'NATIVE_GMT_CALENDAR'),
        ('DATE_NONLEAP', retained.replace('Oct 19 22:26:41 2026', 'Feb 29 22:26:41 2025'), 'NATIVE_GMT_CALENDAR'),
        ('DATE_HOUR24', retained.replace('22:26:41', '24:26:41', 1), 'NATIVE_GMT_CALENDAR'),
        ('DATE_UNKNOWN_ZONE', retained.replace('GMT', 'UTC', 1), 'NATIVE_GMT_DATE_FORMAT'),
        ('DATE_YEAR_OVERFLOW', retained.replace('2026', '10000', 1), 'NATIVE_GMT_DATE_FORMAT'),
        ('DATE_TEXT_OVERFLOW', retained + 'X' * 65536, 'NATIVE_VALIDITY_BOUND'),
        ('DATE_LABEL_UNKNOWN', retained.replace('Not Before', 'Not Befor'), 'NATIVE_VALIDITY_LABEL'),
        ('DATE_LABEL_DUPLICATE_BEFORE', retained + retained.splitlines(True)[0], 'NATIVE_VALIDITY_UNIQUE_LABELS'),
        ('DATE_LABEL_DUPLICATE_AFTER', retained + retained.splitlines(True)[1], 'NATIVE_VALIDITY_UNIQUE_LABELS'),
        ('DATE_LABEL_EXCESS_PADDING', retained.replace('Not After :', 'Not After  :'), 'NATIVE_VALIDITY_LABEL'),
        ('DATE_LABEL_MISSING_AFTER', retained.splitlines(True)[0], 'NATIVE_VALIDITY_UNIQUE_LABELS'),
        ('DATE_SECOND60', retained.replace('22:26:41', '22:26:60', 1), 'NATIVE_GMT_CALENDAR'),
        ('DATE_LABEL_TABS', retained.replace('Not After :', 'Not After\t:'), 'NATIVE_VALIDITY_LABEL'),
        ('DATE_YEAR_ZERO', retained.replace('2026', '0000', 1), 'NATIVE_GMT_CALENDAR'),
        ('DATE_NONNATIVE_ISO', retained.replace('Oct 19 22:26:41 2026 GMT', '2026-10-19T22:26:41Z'), 'NATIVE_GMT_DATE_FORMAT'),
        ('DATE_LABEL_EXTRA', retained + '            Not Something: Oct 20 22:26:41 2026 GMT\n', 'NATIVE_VALIDITY_LABEL'),
    ]
    for identifier, text, expected in date_cases:
        try:
            observed = helper.certificate_validity(text)
        except ValueError as error:
            helper.need(type(expected) is str and str(error) == expected, 'DATE_WRONG_REFUSAL_' + identifier)
            rows.append({'id': identifier, 'observation': 'REFUSED', 'reason': str(error)})
        else:
            helper.need(type(expected) is dict and observed == expected, 'DATE_WRONG_VALUE_' + identifier)
            rows.append({'id': identifier, 'observation': 'ACCEPTED', 'value': observed})
    helper.need(len(rows) == 48, 'FIXED_R2_CONTROL_COUNT')
    print(json.dumps({'schema': 'e06-isolated-tls-pure-controls-v1', 'observations': rows,
                      'limitations': 'SYNTHETIC_TEXT_AND_FAKE_HANDLES_ONLY_NO_RUNTIME_INTEROPERABILITY'}, separators=(',', ':')))


if __name__ == '__main__':
    main()
