// SOURCE IMPLEMENTATION ONLY; fixed LAB-I4 JS one-request persistent native window.
// No expected reply, original oracle, socket, spawn, protocol handle or release authority.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL,fileURLToPath} from 'node:url';
import path from 'node:path';
import {parseStrict,typedEqual,validateShape,verifyClosure,readBinding,selectedWindow,checkDescriptor} from './wire.mjs';
const ROOT='/home/peterhorvath/apps/bitcoin/NBDP';
const HERE=ROOT+'/experiments/prototypes/e06_relay_https_composition_v1';
const ENTRY=ROOT+'/experiments/prototypes/e06_invoice_file_v1/js/metadata.mjs';
const ENTRY_PIN={bytes:16205,sha256:'c9f0cd7055a98e2edcfcc32efc9be99e499077dc6d131472cb4c179b8c4c348c'};
const need=(ok,reason)=>{if(!ok)throw Error(reason);};
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const secret='0'.repeat(63)+'2'; // Existing isolated synthetic recipient; never accepts a production key.

// Validate actual wire bytes against fixed typed fixtures without replacing/reserializing them.
export function validateInput(line,binding,selection,definitions,index) {
  need(index===0,'EXTRA_REQUEST');need(Buffer.isBuffer(line)&&line.length<=131072,'REQUEST_BOUND');
  const req=parseStrict(line,131072).value;validateShape(req,'@nativeRequest',definitions);
  const window=selectedWindow(selection,binding.caseId),family=selection.families[window.family];
  need(req.secretHex===secret&&typedEqual(req.config,binding.scope)&&typedEqual(req.config,family.scope),'FIXED_SCOPE_SECRET');
  for(const slot of ['D','F']) {
    const desc=slot==='D'?binding.dFixture:binding.fFixture;
    const job=window.jobs.find(j=>j.slot===slot);need(job&&typedEqual(desc,job.wire),'FIXED_FIXTURE');
    checkDescriptor(desc);const fixture=parseStrict(fs.readFileSync(desc.path)).value;
    const received=parseStrict(Buffer.from(req[slot.toLowerCase()+'WireHex'],'hex')).value;
    need(typedEqual(received,fixture),'WHOLE_EVENT');
  }
  return req;
}
async function main() {
  need(process.argv.length===4,'CLI node metadata_loader.mjs ABS_BINDING SHA');
  const [bindingPath,sha]=process.argv.slice(2);
  const {binding:b,selection,definitions}=readBinding(bindingPath,sha,'nativeBinding');
  const window=selectedWindow(selection,b.caseId),family=selection.families[window.family];
  need(window.metadataBackend==='JS'&&b.backend==='JS'&&b.windowId===window.windowId&&b.maxRequests===1,'I4_JS_WINDOW');
  need(typedEqual(b.scope,family.scope),'BOUND_SCOPE');
  need(b.metadataEntry.path===ENTRY&&b.metadataEntry.bytes===ENTRY_PIN.bytes&&b.metadataEntry.sha256===ENTRY_PIN.sha256,'FIXED_METADATA_ENTRY');
  for(const slot of ['D','F'])need(typedEqual(slot==='D'?b.dFixture:b.fFixture,window.jobs.find(j=>j.slot===slot).wire),'FIXED_RAW_FIXTURES');
  const verify=()=>{
    need(hash(fs.readFileSync(bindingPath))===sha,'BINDING_CHANGED');
    const map=verifyClosure(b.closure,[fileURLToPath(import.meta.url),HERE+'/wire.mjs',ENTRY,b.dFixture.path,b.fFixture.path]);
    need(typedEqual(map.get(ENTRY),b.metadataEntry)&&typedEqual(map.get(b.dFixture.path),b.dFixture)&&typedEqual(map.get(b.fFixture.path),b.fFixture),'NATIVE_CLOSURE_JOIN');
  };
  // Entire admitted closure and all fixed bindings are checked before native dependencies load.
  verify();const metadata=await import(pathToFileURL(ENTRY).href);verify();
  need(typeof metadata._handleLine==='function','METADATA_EXPORT');
  let pending=Buffer.alloc(0),count=0,total=0;
  for await(const chunk of process.stdin) {
    total+=chunk.length;need(total<=131073,'TOTAL_STDIN_BOUND');pending=Buffer.concat([pending,chunk]);
    let lf;
    while((lf=pending.indexOf(10))!==-1) {
      const line=pending.subarray(0,lf);pending=pending.subarray(lf+1);
      validateInput(line,b,selection,definitions,count);verify();
      const reply=await metadata._handleLine(new TextDecoder('utf-8',{fatal:true}).decode(line));
      // Fixed exclusive retention is evidence only, never an authentication input.
      // Preserve the actual complete JSONL before shape/post-integrity checks can reject it.
      const serialized=JSON.stringify(reply);need(typeof serialized==='string','NATIVE_REPLY_JSON');
      const replyBytes=Buffer.from(serialized+'\n');need(replyBytes.length<=16777216,'NATIVE_REPLY_BOUND');
      const replyPath=path.join(path.dirname(bindingPath),'native-reply.jsonl');
      const replyFd=fs.openSync(replyPath,'wx',0o600);
      try {fs.writeFileSync(replyFd,replyBytes);fs.fsyncSync(replyFd);}finally {fs.closeSync(replyFd);}
      const dirFd=fs.openSync(path.dirname(bindingPath),fs.constants.O_RDONLY|fs.constants.O_DIRECTORY);
      try {fs.fsyncSync(dirFd);}finally {fs.closeSync(dirFd);}
      count++;
      // No successful-channel output until validation finishes; parent retains failure artifact+stderr.
      // Shape grammar contains type/key/arity only. Scalars are native facts, not an expected oracle.
      validateShape(reply,'@nativeReply',definitions);verify();
      need(fs.writeSync(1,replyBytes,0,replyBytes.length)===replyBytes.length,'NATIVE_REPLY_COMPLETE_WRITE');
    }
    need(pending.length<=131072,'LINE_BOUND');
    // stdin deliberately remains open/quiescent after the sole reply through S06.
  }
  need(pending.length===0&&count===1,'EOF_REQUEST_COUNT');verify();
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  main().catch(error=>{process.stderr.write((error.name+': '+error.message).slice(0,16000)+'\n');process.exitCode=1;});
}
