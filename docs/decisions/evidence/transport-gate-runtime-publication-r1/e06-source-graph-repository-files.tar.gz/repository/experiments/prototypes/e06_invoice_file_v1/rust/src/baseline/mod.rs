//! Disposable experiment adapter. Not an SDK. No cryptographic algorithms implemented here.
use std::io::{self, BufRead, Write};
use std::fmt;
use base64::{Engine, engine::general_purpose::STANDARD};
use nostr::prelude::*;
use nostr::nips::{nip44::v2, nip59::GiftWrapBuilder};
use serde::de::{self, Visitor, MapAccess, SeqAccess};
use serde::{Deserialize, Deserializer};
use serde_json::{Value, json, Map};

// Independent duplicate-key rejecting parser; serde_json normally retains the last key.
struct Unique(Value);
impl<'de> Deserialize<'de> for Unique {
 fn deserialize<D: Deserializer<'de>>(d:D)->Result<Self,D::Error>{
  struct V;
  impl<'de> Visitor<'de> for V {
   type Value=Unique;
   fn expecting(&self,f:&mut fmt::Formatter)->fmt::Result{write!(f,"unambiguous JSON")}
   fn visit_bool<E:de::Error>(self,v:bool)->Result<Unique,E>{Ok(Unique(json!(v)))}
   fn visit_i64<E:de::Error>(self,v:i64)->Result<Unique,E>{Ok(Unique(json!(v)))}
   fn visit_u64<E:de::Error>(self,v:u64)->Result<Unique,E>{Ok(Unique(json!(v)))}
   fn visit_f64<E:de::Error>(self,_v:f64)->Result<Unique,E>{Err(de::Error::custom("integer tokens required"))}
   fn visit_str<E:de::Error>(self,v:&str)->Result<Unique,E>{Ok(Unique(json!(v)))}
   fn visit_unit<E:de::Error>(self)->Result<Unique,E>{Ok(Unique(Value::Null))}
   fn visit_seq<A:SeqAccess<'de>>(self,mut a:A)->Result<Unique,A::Error>{let mut v=vec![];while let Some(Unique(x))=a.next_element()?{v.push(x)}Ok(Unique(Value::Array(v)))}
   fn visit_map<A:MapAccess<'de>>(self,mut a:A)->Result<Unique,A::Error>{let mut m=Map::new();while let Some(k)=a.next_key::<String>()?{if m.contains_key(&k){return Err(de::Error::custom("duplicate key"))}let Unique(v)=a.next_value()?;m.insert(k,v);}Ok(Unique(Value::Object(m)))}
  }
  d.deserialize_any(V)
 }
}
fn depth(v:&Value)->usize{match v{Value::Array(a)=>1+a.iter().map(depth).max().unwrap_or(0),Value::Object(m)=>1+m.values().map(depth).max().unwrap_or(0),_=>0}}
fn parse(s:&str)->Result<Value,String>{if s.len()>2_000_000{return Err("resource".into())}let Unique(v)=serde_json::from_str(s).map_err(|_|"json")?;if depth(&v)>32{return Err("json".into())}Ok(v)}
fn st<'a>(v:&'a Value,k:&str)->Result<&'a str,String>{v[k].as_str().ok_or("schema".into())}
fn hexlen(s:&str,n:usize)->bool{s.len()==n&&s.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))}
fn guard(c:bool,e:&str)->Result<(),String>{if c{Ok(())}else{Err(e.into())}}
fn shape(v:&Value,signed:bool)->Result<(),String>{
 let keys=if signed{vec!["id","pubkey","created_at","kind","tags","content","sig"]}else{vec!["id","pubkey","created_at","kind","tags","content"]};
 let m=v.as_object().ok_or("structure")?;
 guard(m.len()==keys.len()&&keys.iter().all(|k|m.contains_key(*k)),"structure")?;
 guard(hexlen(st(v,"id")?,64)&&hexlen(st(v,"pubkey")?,64),"structure")?;
 if signed{guard(hexlen(st(v,"sig")?,128),"structure")?;}
 guard(v["kind"].as_u64().is_some_and(|x|x<=65535)&&v["created_at"].as_u64().is_some_and(|x|x<=9_007_199_254_740_991),"structure")?;
 st(v,"content")?;
 let tags=v["tags"].as_array().ok_or("structure")?;
 guard(tags.len()<=64&&tags.iter().all(|t|t.as_array().is_some_and(|a|a.len()<=8&&a.iter().all(|x|x.is_string()))),"structure")
}
fn named_p_count(v:&Value)->usize{v["tags"].as_array().unwrap().iter().filter(|t|t[0]=="p").count()}
fn peers(v:&Value)->Vec<String>{v["tags"].as_array().unwrap().iter().filter(|t|t[0]=="p").filter_map(|t|t[1].as_str().map(String::from)).collect()}
fn schema(e:&Value,r:&Value)->Result<(),String>{
 guard(e["version"]==1,"version")?;
 guard(e["required"]==json!([]),"extension")?;
 guard(e["type"]=="document"&&e["context"]=="synthetic","schema")?;
 guard(hexlen(st(e,"id")?,64)&&e["from"]==r["pubkey"]&&Some(st(e,"to")?.to_owned())==peers(r).first().cloned(),"binding")?;
 let allowed=["protocol","version","type","id","from","to","context","required","document","files","note"];
 guard(e.as_object().is_some_and(|m|m.keys().all(|k|allowed.contains(&k.as_str()))),"schema")?;
 let d=&e["document"];
 guard(d.as_object().is_some_and(|m|m.len()==5)&&hexlen(st(d,"id")?,64)&&hexlen(st(d,"sha256")?,64)&&d["bytes"].as_u64().is_some_and(|x|x<=1_048_576)&&d["revision"].as_u64().is_some_and(|x|x>0&&x<=9_007_199_254_740_991)&&!st(d,"media")?.is_empty(),"schema")?;
 if let Some(f)=e.get("files"){
  let a=f.as_array().ok_or("schema")?;guard(a.len()<=16,"schema")?;
  for x in a{let size=x["size"].as_str().ok_or("schema")?;let n=size.parse::<u64>().map_err(|_|"schema")?;guard(x.as_object().is_some_and(|m|m.len()==3)&&hexlen(st(x,"x")?,64)&&hexlen(st(x,"ox")?,64)&&n>=16&&n<=1_048_592&&n.to_string()==size,"schema")?;}
 }
 if let Some(n)=e.get("note"){guard(n.is_string(),"schema")?;}
 Ok(())
}
fn validate(q:&Value,trace:&mut [usize;2])->Result<Value,String>{
 let role=q.get("role").and_then(Value::as_str).ok_or("local-role")?;guard(role=="incoming"||role=="archive","local-role")?;
 let pin=match q.get("expectedSender"){None=>None,Some(v)=>{let peer=v.as_str().ok_or("local-pin")?;guard(hexlen(peer,64),"local-pin")?;Some(peer)}};
 let remote=match q.get("expectedRemoteRecipient"){None=>None,Some(v)=>{let peer=v.as_str().ok_or("local-remote")?;guard(hexlen(peer,64),"local-remote")?;Some(peer)}};
 let context=match q.get("expectedContext"){None=>None,Some(v)=>{let text=v.as_str().ok_or("local-context")?;guard(!text.is_empty(),"local-context")?;Some(text)}};
 let cap=q["cap"].as_u64().unwrap_or(16384) as usize;
 let acquired;
 let wire=if q["op"]=="validate-bytes"{
  let text=q.get("wireHex").and_then(Value::as_str).ok_or("local-wire-bytes")?;
  guard(text.len()%2==0&&text.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b)),"local-wire-bytes")?;
  guard(text.len()/2+10<=cap,"resource")?;
  acquired=String::from_utf8(hex::decode(text).map_err(|_|"local-wire-bytes")?).map_err(|_|"wire-utf8")?;
  acquired.as_str()
 }else{st(q,"wire")?};
 guard(wire.len()+10<=cap,"resource")?;
 let w=parse(wire)?;shape(&w,true)?;guard(w["kind"]==1059,"outer-kind")?;
 let keys=Keys::parse(st(q,"secret")?).map_err(|_|"key")?;let local=keys.public_key().to_hex();
 guard(w["tags"]==json!([["p",local]]),"recipient")?;
 let event=Event::from_json(w.to_string()).map_err(|_|"structure")?;event.verify().map_err(|_|"outer-auth")?;
 trace[0]+=1;
 let raw=keys.nip44_decrypt(&event.pubkey,&event.content).map_err(|_|"outer-crypto")?;
 let s=parse(&raw)?;shape(&s,true)?;guard(s["kind"]==13,"seal-kind")?;guard(s["tags"]==json!([]),"seal-tags")?;
 let seal=Event::from_json(s.to_string()).map_err(|_|"structure")?;seal.verify().map_err(|_|"seal-auth")?;
 trace[1]+=1;
 let raw=keys.nip44_decrypt(&seal.pubkey,&seal.content).map_err(|_|"seal-crypto")?;
 let r=parse(&raw)?;shape(&r,false)?;guard(r["kind"]==14||r["kind"]==15,"rumor-kind")?;
 let rumor=UnsignedEvent::from_json(r.to_string()).map_err(|_|"structure")?;rumor.verify_id().map_err(|_|"rumor-id")?;
 guard(r["pubkey"]==s["pubkey"],"author")?;guard(named_p_count(&r)==1,"recipient")?;guard(r["tags"].as_array().unwrap().iter().find(|t|t[0]=="p").unwrap().as_array().unwrap().len()==2,"recipient")?;let p=peers(&r);guard(p.len()==1&&hexlen(&p[0],64),"recipient")?;
 let archive=role=="archive";
 guard(if archive{r["pubkey"]==local}else{p[0]==local},"recipient")?;
 if let Some(peer)=pin{guard(r["pubkey"]==peer,"authorization")?;}
 if r["kind"]==15{return Ok(json!({"rumor":r,"dispatch":false,"role":if archive{"archive"}else{"file"}}))}
 let content=st(&r,"content")?;
 let e=if content.starts_with('{'){parse(content)?}else{Value::Null};
 if e["protocol"]!="NBDP/experiment"{return Ok(json!({"rumor":r,"dispatch":false,"role":"chat"}))}
 schema(&e,&r)?;
 let matched=remote.is_some_and(|peer|p[0]==peer&&e["to"]==peer)&&context.is_some_and(|text|e["context"]==text);
 let mut value=json!({"rumor":r,"envelope":e,"dispatch":!archive,"role":if archive{"archive"}else{"incoming"}});
 if archive{value["archiveConversationMatched"]=json!(matched);}
 Ok(value)
}
fn run(q:Value)->Result<Value,String>{
 match st(&q,"op")?{
 "carrier-produce"|"carrier-consume"|"carrier-match-receipt"=>Ok(carrier_entry(&q)),
 "source"=>Ok(json!(include_str!("main.rs"))),
 "pubkey"=>Ok(json!(Keys::parse(st(&q,"secret")?).map_err(|e|e.to_string())?.public_key().to_hex())),
 "wrap"=>{let keys=Keys::parse(st(&q,"secret")?).map_err(|e|e.to_string())?;let p=PublicKey::from_hex(st(&q,"to")?).map_err(|e|e.to_string())?;let r=UnsignedEvent::from_json(q["rumor"].to_string()).map_err(|e|e.to_string())?;let w=GiftWrapBuilder::new(p,r).finalize(&keys).map_err(|e|e.to_string())?;Ok(serde_json::from_str(&w.as_json()).unwrap())},
 "encrypt"=>{let k=Keys::parse(st(&q,"secret")?).map_err(|e|e.to_string())?;let p=PublicKey::from_hex(st(&q,"to")?).map_err(|e|e.to_string())?;Ok(json!(k.nip44_encrypt(&p,st(&q,"plaintext")?).map_err(|e|e.to_string())?))},
 "decrypt"=>{let k=Keys::parse(st(&q,"secret")?).map_err(|e|e.to_string())?;let p=PublicKey::from_hex(st(&q,"from")?).map_err(|e|e.to_string())?;Ok(json!(k.nip44_decrypt(&p,st(&q,"payload")?).map_err(|e|e.to_string())?))},
 "conversation"=>{let k=Keys::parse(st(&q,"secret")?).map_err(|e|e.to_string())?;let p=PublicKey::from_hex(st(&q,"to")?).map_err(|e|e.to_string())?;Ok(json!(hex::encode(v2::ConversationKey::derive(k.secret_key(),&p).map_err(|e|e.to_string())?.as_bytes())))},
 "vector-encrypt"=>{let c=v2::ConversationKey::from_slice(&hex::decode(st(&q,"key")?).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;let n:[u8;32]=hex::decode(st(&q,"nonce")?).map_err(|e|e.to_string())?.try_into().map_err(|_|"nonce")?;Ok(json!(STANDARD.encode(v2::encrypt_to_bytes_with_nonce(&c,st(&q,"plaintext")?.as_bytes(),n).map_err(|e|e.to_string())?)))},
 "vector-decrypt"=>{let c=v2::ConversationKey::from_slice(&hex::decode(st(&q,"key")?).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;let bytes=STANDARD.decode(st(&q,"payload")?).map_err(|e|e.to_string())?;guard(bytes.first()==Some(&2),"version")?;Ok(json!(String::from_utf8(v2::decrypt_to_bytes(&c,&bytes).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?))},
 "validate"|"validate-bytes"=>{let mut trace=[0,0];let result=validate(&q,&mut trace);Ok(match result{Ok(v)=>json!({"ok":true,"value":v,"decrypts":trace}),Err(e)=>json!({"ok":false,"error":e,"decrypts":trace})})},
 "discover"=>discover(&q),
 "correlate"=>correlate(&q),
 "file-rumor"=>{
  let from=st(&q,"from")?;let to=st(&q,"to")?;let f=&q["file"];
  let mut r=json!({"pubkey":from,"created_at":q["timestamp"],"kind":15,"tags":[["p",to],["e",q["parent"],"","reply"],["file-type",q["media"]],["encryption-algorithm","aes-gcm"],["decryption-key",f["key"]],["decryption-nonce",f["nonce"]],["x",f["ciphertext_sha256"]],["ox",f["plaintext_sha256"]],["size",f["blob_bytes"].as_u64().unwrap().to_string()]],"content":q["url"]});
  let mut u=UnsignedEvent::from_json(r.to_string()).map_err(|e|e.to_string())?;u.ensure_id();r["id"]=json!(u.id.unwrap().to_hex());Ok(r)
 },
 _=>Err("unsupported operation".into())
 }
}
fn discover(q:&Value)->Result<Value,String>{
 let peer=st(q,"peer")?;let now=q["now"].as_u64().ok_or("clock")?;let seen=q["seen"].as_u64().unwrap_or(0);
 let mut valid=vec![];
 for v in q["candidates"].as_array().ok_or("candidates")?{
  if shape(v,true).is_err()||v["kind"]!=10050||v["pubkey"]!=peer{continue}
  if Event::from_json(v.to_string()).and_then(|e|e.verify()).is_ok(){valid.push(v)}
 }
 if valid.is_empty(){return Ok(json!({"state":"inbox-unavailable","destinations":[]}))}
 valid.sort_by_key(|v|v["created_at"].as_u64().unwrap());let best=valid.last().unwrap();let timestamp=best["created_at"].as_u64().unwrap();
 let same:Vec<_>=valid.iter().filter(|v|v["created_at"].as_u64()==Some(timestamp)).collect();
 if same.iter().any(|v|v["id"]!=best["id"]){return Ok(json!({"state":"discovery-conflict","destinations":[]}))}
 if timestamp<seen||timestamp>now+300||now.saturating_sub(timestamp)>864000{return Ok(json!({"state":"stale-or-rollback","destinations":[]}))}
 let tags=best["tags"].as_array().unwrap();let mut urls=vec![];
 for tag in tags{if tag[0]!="relay"||tag.as_array().unwrap().len()!=2{return Ok(json!({"state":"malformed-inbox","destinations":[]}))}let u=tag[1].as_str().unwrap();
  let parsed=nostr::types::Url::parse(u);match parsed{Ok(p) if p.scheme()=="ws"&&matches!(p.host_str(),Some("127.0.0.1")|Some("localhost"))&&p.username().is_empty()&&p.password().is_none()=>urls.push(u.to_owned()),_=>return Ok(json!({"state":"unsafe-lab-route","destinations":[]}))}
 }
 urls.sort();urls.dedup();if urls.is_empty(){return Ok(json!({"state":"inbox-empty","destinations":[]}))}
 Ok(json!({"state":"ready","destinations":urls,"list_id":best["id"]}))
}
fn correlate(q:&Value)->Result<Value,String>{
 let events=q["events"].as_array().ok_or("events")?;
 let envs:Vec<_>=events.iter().filter(|e|e["kind"]==14).collect();
 if envs.is_empty(){return Ok(json!({"state":"PENDING","operations":0,"effects":0}))}
 let base=envs[0];let e=parse(st(base,"content")?)?;let d=&e["document"];
 if envs.iter().any(|r|r["id"]!=base["id"]){return Ok(json!({"state":"CONFLICT","operations":0,"effects":0}))}
 let file= &e["files"][0];let mut matching=false;
 for r in events.iter().filter(|r|r["kind"]==15){
  let get=|name:&str|->Option<&Value>{let tags=r["tags"].as_array()?;let values:Vec<_>=tags.iter().filter(|t|t[0]==name).collect();if values.len()!=1{return None}values[0].get(1)};
  if r["pubkey"]!=base["pubkey"]||peers(r)!=peers(base){return Ok(json!({"state":"CONFLICT","operations":0,"effects":0}))}
  if get("encryption-algorithm")!=Some(&json!("aes-gcm")){return Ok(json!({"state":"UNSUPPORTED","operations":0,"effects":0}))}
  if get("e")!=base.get("id"){continue}
  let key=get("decryption-key").and_then(Value::as_str).unwrap_or("");let nonce=get("decryption-nonce").and_then(Value::as_str).unwrap_or("");
  if !hexlen(key,64)||!hexlen(nonce,24)||get("x")!=file.get("x")||get("ox")!=d.get("sha256")||get("file-type")!=d.get("media")||get("size").and_then(Value::as_str)!=file["size"].as_str(){return Ok(json!({"state":"CONFLICT","operations":0,"effects":0}))}
  matching=true;
 }
 Ok(json!({"state":if matching{"READY"}else{"INCOMPLETE"},"operations":if matching{1}else{0},"effects":0}))
}
fn main(){for line in io::stdin().lock().lines(){let line=line.unwrap();let mut carrier=false;let result=if line.len()>5_000_000{Err("request cap".into())}else{serde_json::from_str::<Value>(&line).map_err(|e|e.to_string()).and_then(|q|{carrier=is_carrier_entry(&q);run(q)})};let output=match result{Ok(v) if carrier=>v,Ok(v)=>json!({"ok":true,"value":v}),Err(e)=>json!({"ok":false,"error":e})};println!("{}",output);io::stdout().flush().unwrap();}}

// New explicit experimental entries. Legacy operations above are preserved;
// their envelope parser is never used to interpret the new application body.
#[allow(dead_code)]
mod codec;

struct CarrierFailure {
    stage: &'static str,
    reason: &'static str,
}

impl CarrierFailure {
    fn new(stage: &'static str, reason: &'static str) -> Self { Self { stage, reason } }
}

fn carrier_guard(ok: bool, stage: &'static str, reason: &'static str) -> Result<(), CarrierFailure> {
    if ok { Ok(()) } else { Err(CarrierFailure::new(stage, reason)) }
}

fn is_carrier_entry(q: &Value) -> bool {
    matches!(q.get("op").and_then(Value::as_str),
        Some("carrier-produce" | "carrier-consume" | "carrier-match-receipt"))
}

fn carrier_exact_keys(value: &Value, keys: &[&str]) -> bool {
    value.as_object().is_some_and(|object| object.len() == keys.len()
        && keys.iter().all(|key| object.contains_key(*key)))
}

fn carrier_h64(value: &Value) -> bool {
    value.as_str().is_some_and(|s| hexlen(s, 64))
}

fn carrier_hex(value: &Value) -> Option<&str> {
    value.as_str().filter(|s| s.len() % 2 == 0
        && s.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)))
}

fn carrier_keys(value: &Value, reason: &'static str) -> Result<Keys, CarrierFailure> {
    carrier_guard(carrier_h64(value), "S0", reason)?;
    Keys::parse(value.as_str().expect("H64 checked"))
        .map_err(|_| CarrierFailure::new("S0", reason))
}

fn carrier_entry(q: &Value) -> Value {
    let producer = q["op"] == "carrier-produce";
    let mut decrypts = [0, 0];
    let result = if producer { carrier_produce(q) } else { carrier_consume(q, &mut decrypts) };
    match result {
        Ok(value) => value,
        Err(failure) => json!({
            "status": "REFUSED", "stage": failure.stage, "reason": failure.reason,
            "transportVerification": if producer { "NOT_EVALUATED" } else { "INCOMPLETE" },
            "decrypts": decrypts, "codecInvocations": 0,
        }),
    }
}

fn carrier_produce(q: &Value) -> Result<Value, CarrierFailure> {
    carrier_guard(carrier_exact_keys(q, &["op", "secretHex", "from", "to", "createdAt", "contentHex"]),
        "P0", "RPC")?;
    carrier_guard(carrier_h64(&q["secretHex"]), "P0", "PRODUCER_KEY")?;
    let keys = Keys::parse(q["secretHex"].as_str().expect("H64 checked"))
        .map_err(|_| CarrierFailure::new("P0", "PRODUCER_KEY"))?;
    let from = keys.public_key();
    carrier_guard(carrier_h64(&q["from"]) && q["from"] == from.to_hex(), "P0", "PRODUCER_FROM")?;
    carrier_guard(carrier_h64(&q["to"]), "P0", "PRODUCER_TO")?;
    let to = PublicKey::from_hex(q["to"].as_str().expect("H64 checked"))
        .map_err(|_| CarrierFailure::new("P0", "PRODUCER_TO"))?;
    to.xonly().map_err(|_| CarrierFailure::new("P0", "PRODUCER_TO"))?;
    carrier_guard(q["createdAt"].as_u64().is_some_and(|n| n <= 9_007_199_254_740_991),
        "P0", "PRODUCER_TIME")?;
    let content_hex = carrier_hex(&q["contentHex"])
        .ok_or_else(|| CarrierFailure::new("P0", "PRODUCER_CONTENT"))?;
    carrier_guard(content_hex.len() / 2 <= 8192, "P0", "PRODUCER_CONTENT")?;
    let bytes = hex::decode(content_hex).map_err(|_| CarrierFailure::new("P0", "PRODUCER_CONTENT"))?;
    let content = String::from_utf8(bytes).map_err(|_| CarrierFailure::new("P0", "PRODUCER_CONTENT"))?;

    // This Rust producer builds its own full rumor fields from its own request.
    // The pinned library alone supplies NIP01 ID calculation and NIP44/59 crypto.
    let fields = json!({"pubkey": from.to_hex(), "created_at": q["createdAt"], "kind": 14,
                        "tags": [["p", to.to_hex()]], "content": content});
    let mut rumor = UnsignedEvent::from_json(fields.to_string())
        .map_err(|_| CarrierFailure::new("P1", "PRODUCER_LIBRARY"))?;
    rumor.ensure_id();
    let rumor_value = serde_json::to_value(&rumor)
        .map_err(|_| CarrierFailure::new("P1", "PRODUCER_LIBRARY"))?;
    let peer = GiftWrapBuilder::new(to, rumor.clone()).finalize(&keys)
        .map_err(|_| CarrierFailure::new("P2", "PRODUCER_LIBRARY"))?;
    let archive = GiftWrapBuilder::new(from, rumor).finalize(&keys)
        .map_err(|_| CarrierFailure::new("P2", "PRODUCER_LIBRARY"))?;
    let peer_value = serde_json::to_value(&peer)
        .map_err(|_| CarrierFailure::new("P2", "PRODUCER_LIBRARY"))?;
    let archive_value = serde_json::to_value(&archive)
        .map_err(|_| CarrierFailure::new("P2", "PRODUCER_LIBRARY"))?;
    Ok(json!({"status": "PRODUCED", "stage": "P_DONE", "transportVerification": "NOT_EVALUATED",
              "decrypts": [0, 0], "codecInvocations": 0, "rumor": rumor_value,
              "wraps": {"peer": peer_value, "archive": archive_value}}))
}

fn carrier_parse(text: &str, stage: &'static str) -> Result<Value, CarrierFailure> {
    parse(text).map_err(|_| CarrierFailure::new(stage, "JSON"))
}

fn carrier_shape(value: &Value, signed: bool, stage: &'static str) -> Result<(), CarrierFailure> {
    // Reuse D08 shape with an additional NEW-entry-only minimum tag item length.
    shape(value, signed).map_err(|_| CarrierFailure::new(stage, "STRUCTURE"))?;
    carrier_guard(value["tags"].as_array().expect("shape checked").iter()
        .all(|tag| !tag.as_array().expect("shape checked").is_empty()), stage, "STRUCTURE")
}

fn carrier_consume(q: &Value, decrypts: &mut [usize; 2]) -> Result<Value, CarrierFailure> {
    let match_receipt = q["op"] == "carrier-match-receipt";
    let request_keys: &[&str] = if match_receipt {
        &["op", "secretHex", "config", "wireHex", "originalDeliveryHex", "deliveryRumorId", "fileRumorId"]
    } else { &["op", "secretHex", "config", "wireHex"] };
    carrier_guard(carrier_exact_keys(q, request_keys) && q["config"].is_object(), "S0", "RPC")?;
    let config = &q["config"];
    let role = config["role"].as_str();
    carrier_guard(matches!(role, Some("incoming" | "archive")), "S0", "LOCAL_ROLE")?;
    carrier_guard(carrier_h64(&config["expectedLocal"]), "S0", "LOCAL_PIN")?;
    let keys = carrier_keys(&q["secretHex"], "LOCAL_KEY")?;
    let local = keys.public_key().to_hex();
    carrier_guard(config["expectedLocal"] == local, "S0", "LOCAL_PIN_BINDING")?;
    carrier_guard(carrier_h64(&config["expectedPeer"]), "S0", "LOCAL_PEER")?;
    carrier_guard(carrier_h64(&config["expectedContext"]), "S0", "LOCAL_CONTEXT")?;
    if let Some(domain) = config.get("expectedReceiptDomain") {
        carrier_guard(carrier_h64(domain), "S0", "LOCAL_DOMAIN")?;
    }
    let enabled = config["enabled"].as_bool().ok_or_else(|| CarrierFailure::new("S0", "LOCAL_ENABLED"))?;
    let mut config_keys = vec!["enabled", "role", "expectedLocal", "expectedPeer", "expectedContext"];
    if config.get("expectedReceiptDomain").is_some() { config_keys.push("expectedReceiptDomain"); }
    carrier_guard(carrier_exact_keys(config, &config_keys), "S0", "LOCAL_CONFIG")?;
    if match_receipt {
        for key in ["deliveryRumorId", "fileRumorId"] {
            carrier_guard(carrier_h64(&q[key]), "S0", "LOCAL_ORIGINAL_IDS")?;
        }
    }
    if !enabled {
        return Ok(json!({"status": "NO_DISPATCH", "stage": "S0", "reason": "DISABLED",
            "transportVerification": "NOT_EVALUATED", "decrypts": [0, 0], "codecInvocations": 0}));
    }

    // S1-S4 reuse the same ordered D08 primitives, without its legacy body tail.
    let wire_hex = carrier_hex(&q["wireHex"]).ok_or_else(|| CarrierFailure::new("S1", "WIRE_HEX"))?;
    carrier_guard(wire_hex.len() / 2 + 10 <= 16384, "S1", "RESOURCE")?;
    let wire_bytes = hex::decode(wire_hex).map_err(|_| CarrierFailure::new("S1", "WIRE_HEX"))?;
    let wire = String::from_utf8(wire_bytes).map_err(|_| CarrierFailure::new("S1", "WIRE_UTF8"))?;
    let w = carrier_parse(&wire, "S1")?;
    carrier_shape(&w, true, "S1")?;
    carrier_guard(w["kind"] == 1059, "S1", "OUTER_KIND")?;
    carrier_guard(w["tags"] == json!([["p", local]]), "S1", "OUTER_RECIPIENT")?;
    let event = Event::from_json(w.to_string()).map_err(|_| CarrierFailure::new("S1", "OUTER_AUTH"))?;
    event.verify().map_err(|_| CarrierFailure::new("S1", "OUTER_AUTH"))?;

    decrypts[0] += 1;
    let seal_text = keys.nip44_decrypt(&event.pubkey, &event.content)
        .map_err(|_| CarrierFailure::new("S2", "OUTER_CRYPTO"))?;
    let s = carrier_parse(&seal_text, "S2")?;
    carrier_shape(&s, true, "S2")?;
    carrier_guard(s["kind"] == 13, "S2", "SEAL_KIND")?;
    carrier_guard(s["tags"] == json!([]), "S2", "SEAL_TAGS")?;
    let seal = Event::from_json(s.to_string()).map_err(|_| CarrierFailure::new("S2", "SEAL_AUTH"))?;
    seal.verify().map_err(|_| CarrierFailure::new("S2", "SEAL_AUTH"))?;

    decrypts[1] += 1;
    let rumor_text = keys.nip44_decrypt(&seal.pubkey, &seal.content)
        .map_err(|_| CarrierFailure::new("S3", "SEAL_CRYPTO"))?;
    let r = carrier_parse(&rumor_text, "S3")?;
    carrier_shape(&r, false, "S3")?;
    carrier_guard(r["kind"] == 14 || r["kind"] == 15, "S3", "RUMOR_KIND")?;
    let rumor = UnsignedEvent::from_json(r.to_string()).map_err(|_| CarrierFailure::new("S3", "RUMOR_ID"))?;
    rumor.verify_id().map_err(|_| CarrierFailure::new("S3", "RUMOR_ID"))?;
    carrier_guard(r["pubkey"] == s["pubkey"], "S3", "AUTHOR")?;

    carrier_guard(named_p_count(&r) == 1, "S4", "INNER_RECIPIENT")?;
    let tags = r["tags"].as_array().expect("shape checked");
    let p_tag = tags.iter().find(|tag| tag[0] == "p").expect("named count checked");
    carrier_guard(p_tag.as_array().expect("shape checked").len() == 2,
        "S4", "INNER_RECIPIENT")?;
    let recipient = p_tag[1].as_str().expect("shape checked");
    carrier_guard(hexlen(recipient, 64), "S4", "INNER_RECIPIENT")?;
    let archive = role == Some("archive");
    carrier_guard(if archive { r["pubkey"] == local } else { recipient == local },
        "S4", "INNER_RECIPIENT")?;
    carrier_guard(if archive { p_tag[1] == config["expectedPeer"] }
        else { r["pubkey"] == config["expectedPeer"] }, "S4", "PEER_BINDING")?;
    carrier_guard(r["kind"] == 14, "S4", "INVOICE_KIND")?;
    carrier_guard(r["tags"] == json!([["p", recipient]]), "S4", "INVOICE_TAGS")?;

    // Exactly one codec call, using actual authenticated rumor content octets.
    let raw_body_hex = hex::encode(r["content"].as_str().expect("shape checked").as_bytes());
    let mut codec_request = json!({
        "method": if match_receipt { "matchReceipt" } else { "validate" },
        "config": config, "bodyHex": raw_body_hex,
    });
    if match_receipt {
        for key in ["originalDeliveryHex", "deliveryRumorId", "fileRumorId"] {
            codec_request[key] = q[key].clone();
        }
    }
    let codec_result = codec::carrier_handle(&codec_request);
    Ok(json!({"status": "CARRIER_RESULT", "stage": "S5",
        "transportVerification": "CHAIN_AND_ENDPOINT_VALIDATED", "decrypts": decrypts,
        "codecInvocations": 1, "rumor": r, "rawBodyHex": raw_body_hex, "codec": codec_result}))
}

// E06 visibility-only adapters; all preceding original bytes are unchanged.
pub(super) fn metadata_parse(raw: &[u8]) -> Result<Value, ()> {
    super::metadata_json::parse(raw)
}

pub(super) fn metadata_local_pubkey(secret: &str) -> Option<String> {
    Keys::parse(secret).ok().map(|keys| keys.public_key().to_hex())
}

pub(super) fn metadata_rpc(q: Value) -> Value {
    // Exactly the successful/failed envelope selected by the original main RPC,
    // including the extra outer envelope for legacy validate-bytes.
    let carrier = is_carrier_entry(&q);
    match run(q) {
        Ok(v) if carrier => v,
        Ok(v) => json!({"ok": true, "value": v}),
        Err(e) => json!({"ok": false, "error": e}),
    }
}
