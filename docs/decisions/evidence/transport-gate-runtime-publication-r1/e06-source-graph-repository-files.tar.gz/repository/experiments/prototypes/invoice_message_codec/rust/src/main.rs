//! Experimental structural codec only. Authentication is never evaluated.
//! No event, file, cryptographic, persistence or authority operation is performed.

use serde_json::{Map, Value, json, value::RawValue};
use std::collections::BTreeSet;
use std::io::{self, BufRead, Write};

const PROTOCOL: &str = "NBDP/invoice-delivery-draft";
const MAX_SAFE: u64 = 9_007_199_254_740_991;
const DELIVERY_KEYS: &[&str] = &[
    "protocol", "version", "type", "id", "from", "to", "context", "required",
    "document", "file",
];
const RECEIPT_KEYS: &[&str] = &[
    "protocol", "version", "type", "id", "from", "to", "context", "required",
    "subject", "stage", "persistence",
];

struct Issue {
    reason: &'static str,
    path: String,
}

impl Issue {
    fn new(reason: &'static str, path: &str) -> Self {
        Self { reason, path: path.to_owned() }
    }

    fn response(&self) -> Value {
        json!({"status": "REFUSED", "authentication": "NOT_EVALUATED",
               "reason": self.reason, "path": self.path})
    }
}

fn refused(reason: &'static str, path: &str) -> Value {
    Issue::new(reason, path).response()
}

fn no_dispatch(reason: &str) -> Value {
    json!({"status": "NO_DISPATCH", "authentication": "NOT_EVALUATED",
           "reason": reason})
}

fn exact_keys(object: &Map<String, Value>, keys: &[&str]) -> bool {
    object.len() == keys.len() && keys.iter().all(|key| object.contains_key(*key))
}

fn lower_hex(text: &str) -> bool {
    text.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

fn h(value: &Value, size: usize) -> bool {
    value.as_str().is_some_and(|s| s.len() == size && lower_hex(s))
}

fn integer_range(value: &Value, low: u64, high: u64) -> bool {
    value.as_u64().is_some_and(|n| n >= low && n <= high)
}

fn nibble(byte: u8) -> u8 {
    if byte.is_ascii_digit() { byte - b'0' } else { byte - b'a' + 10 }
}

// All these flags are collected only AFTER standard JSON syntax succeeds.
// UTF16 units retain escaped lone surrogates long enough to honor duplicate-key
// precedence; the resulting Rust strings are created only after scalar checks.
#[derive(Default)]
struct TextFlags {
    depth: bool,
    duplicate: bool,
    scalar: bool,
    number: bool,
}

enum Frame {
    Object { keys: BTreeSet<Vec<u16>>, expecting_key: bool },
    Array,
}

fn hex_unit(bytes: &[u8]) -> u16 {
    bytes.iter().fold(0, |acc, byte| {
        let digit = match byte {
            b'0'..=b'9' => byte - b'0',
            b'a'..=b'f' => byte - b'a' + 10,
            b'A'..=b'F' => byte - b'A' + 10,
            _ => unreachable!("standard JSON syntax already checked"),
        };
        acc * 16 + u16::from(digit)
    })
}

fn string_units(text: &str, mut offset: usize) -> (Vec<u16>, usize) {
    let bytes = text.as_bytes();
    let mut units = Vec::new();
    offset += 1; // opening quote
    while bytes[offset] != b'"' {
        if bytes[offset] == b'\\' {
            offset += 1;
            if bytes[offset] == b'u' {
                units.push(hex_unit(&bytes[offset + 1..offset + 5]));
                offset += 5;
                continue;
            }
            units.push(match bytes[offset] {
                b'"' => 0x22,
                b'\\' => 0x5c,
                b'/' => 0x2f,
                b'b' => 8,
                b'f' => 12,
                b'n' => 10,
                b'r' => 13,
                b't' => 9,
                _ => unreachable!("standard JSON syntax already checked"),
            });
            offset += 1;
        } else {
            let ch = text[offset..].chars().next().expect("validated JSON string");
            let mut pair = [0; 2];
            units.extend_from_slice(ch.encode_utf16(&mut pair));
            offset += ch.len_utf8();
        }
    }
    (units, offset + 1)
}

fn text_flags(text: &str) -> TextFlags {
    let mut flags = TextFlags::default();
    let mut stack = Vec::new();
    let bytes = text.as_bytes();
    let mut offset = 0;
    while offset < bytes.len() {
        match bytes[offset] {
            b'{' => {
                stack.push(Frame::Object { keys: BTreeSet::new(), expecting_key: true });
                flags.depth |= stack.len() > 32;
                offset += 1;
            }
            b'[' => {
                stack.push(Frame::Array);
                flags.depth |= stack.len() > 32;
                offset += 1;
            }
            b'}' | b']' => { stack.pop(); offset += 1; }
            b',' => {
                if let Some(Frame::Object { expecting_key, .. }) = stack.last_mut() {
                    *expecting_key = true;
                }
                offset += 1;
            }
            b'"' => {
                let (units, end) = string_units(text, offset);
                flags.scalar |= char::decode_utf16(units.iter().copied()).any(|u| u.is_err());
                if let Some(Frame::Object { keys, expecting_key }) = stack.last_mut() {
                    if *expecting_key {
                        flags.duplicate |= !keys.insert(units);
                        *expecting_key = false;
                    }
                }
                offset = end;
            }
            b'-' | b'0'..=b'9' => {
                let start = offset;
                while offset < bytes.len()
                    && matches!(bytes[offset], b'0'..=b'9' | b'-' | b'+' | b'.' | b'e' | b'E') {
                    offset += 1;
                }
                let token = &text[start..offset];
                let digits_only = token.bytes().all(|b| b.is_ascii_digit());
                flags.number |= !digits_only || token.len() > 16
                    || (token.len() == 16 && token > "9007199254740991");
            }
            _ => offset += 1,
        }
    }
    flags
}

fn root_shape(message: &Value, path: &str, receipt: bool, nested: bool) -> Result<(), Issue> {
    let bad = || Issue::new("SCHEMA", path);
    let object = message.as_object().ok_or_else(bad)?;
    if !exact_keys(object, if receipt { RECEIPT_KEYS } else { DELIVERY_KEYS })
        || message["protocol"].as_str() != Some(PROTOCOL)
        || message["version"].as_u64() != Some(1)
        || message["type"].as_str() != Some(if receipt { "receipt" } else { "delivery" })
        || !["id", "from", "to", "context"].iter().all(|key| message[*key].is_string())
        || !message["required"].is_array()
        || (receipt && (!message["subject"].is_object()
            || !message["stage"].is_string()
            || !message["persistence"].is_object()))
        || (!receipt && (!message["document"].is_object() || !message["file"].is_object())) {
        return Err(bad());
    }
    if !message["required"].as_array().expect("array checked").is_empty() {
        if nested { return Err(bad()); }
        return Err(Issue::new("UNSUPPORTED_REQUIRED", "$.required"));
    }
    if !["id", "from", "to", "context"].iter().all(|key| h(&message[*key], 64))
        || (receipt && message["stage"].as_str() != Some("verified-durable")) {
        return Err(bad());
    }
    Ok(())
}

fn delivery_children(message: &Value, path: &str) -> Result<(), Issue> {
    let document = &message["document"];
    let document_path = format!("{path}.document");
    let doc_keys = ["id", "kind", "revision", "sha256", "bytes", "media"];
    if !document.as_object().is_some_and(|o| exact_keys(o, &doc_keys))
        || !h(&document["id"], 64)
        || !matches!(document["kind"].as_str(), Some("invoice" | "credit-note"))
        || !integer_range(&document["revision"], 1, MAX_SAFE)
        || !h(&document["sha256"], 64)
        || !integer_range(&document["bytes"], 0, 1_048_576)
        || document["media"].as_str() != Some("application/octet-stream") {
        return Err(Issue::new("SCHEMA", &document_path));
    }
    let file = &message["file"];
    let file_path = format!("{path}.file");
    let file_keys = ["profile", "x", "ox", "bytes", "key", "nonce"];
    if !file.as_object().is_some_and(|o| exact_keys(o, &file_keys))
        || file["profile"].as_str() != Some("aes256gcm-12-empty-v1")
        || !h(&file["x"], 64) || !h(&file["ox"], 64) || !h(&file["key"], 64)
        || !h(&file["nonce"], 24)
        || !integer_range(&file["bytes"], 16, 1_048_592)
        || file["ox"] != document["sha256"]
        || file["bytes"].as_u64() != document["bytes"].as_u64().map(|n| n + 16) {
        return Err(Issue::new("SCHEMA", &file_path));
    }
    Ok(())
}

fn schema(message: &Value) -> Result<(), Issue> {
    // Both discriminator native types precede unsupported-value checks.
    if !message["version"].is_u64() || !message["type"].is_string() {
        return Err(Issue::new("SCHEMA", "$"));
    }
    if message["version"].as_u64() != Some(1) {
        return Err(Issue::new("UNSUPPORTED_VERSION", "$.version"));
    }
    let receipt = match message["type"].as_str() {
        Some("delivery") => false,
        Some("receipt") => true,
        _ => return Err(Issue::new("UNSUPPORTED_TYPE", "$.type")),
    };
    root_shape(message, "$", receipt, false)?;
    if !receipt { return delivery_children(message, "$"); }
    let subject = &message["subject"];
    let subject_keys = ["delivery_rumor", "file_rumor", "delivery"];
    if !subject.as_object().is_some_and(|o| exact_keys(o, &subject_keys))
        || !h(&subject["delivery_rumor"], 64) || !h(&subject["file_rumor"], 64)
        || !subject["delivery"].is_object() {
        return Err(Issue::new("SCHEMA", "$.subject"));
    }
    root_shape(&subject["delivery"], "$.subject.delivery", false, true)?;
    delivery_children(&subject["delivery"], "$.subject.delivery")?;
    let persistence = &message["persistence"];
    if !persistence.as_object().is_some_and(|o| exact_keys(o, &["domain"]))
        || !h(&persistence["domain"], 64) {
        return Err(Issue::new("SCHEMA", "$.persistence"));
    }
    Ok(())
}

fn parse_body(input: &Value) -> Result<Value, Value> {
    let hex = input.as_str().ok_or_else(|| refused("INPUT_HEX", "$"))?;
    if hex.len() % 2 != 0 || !lower_hex(hex) { return Err(refused("INPUT_HEX", "$")); }
    if hex.len() / 2 > 8192 { return Err(refused("BYTES", "$")); }
    let bytes: Vec<u8> = hex.as_bytes().chunks_exact(2)
        .map(|pair| nibble(pair[0]) * 16 + nibble(pair[1])).collect();
    let text = std::str::from_utf8(&bytes).map_err(|_| refused("UTF8", "$"))?;
    if !text.starts_with('{') { return Err(no_dispatch("NON_CANDIDATE")); }
    if !text.ends_with('}') { return Err(refused("JSON_FRAMING", "$")); }

    // RawValue checks complete standard syntax without decoding Unicode strings
    // or rounding/range-converting numbers; its cached parser uses an iterative
    // container stack. This permits the required later error precedence.
    serde_json::from_str::<&RawValue>(text).map_err(|_| refused("JSON", "$"))?;
    let flags = text_flags(text);
    for (failed, reason) in [
        (flags.depth, "DEPTH"), (flags.duplicate, "DUPLICATE_KEY"),
        (flags.scalar, "UNICODE_SCALAR"), (flags.number, "NUMBER"),
    ] {
        if failed { return Err(refused(reason, "$")); }
    }
    // Only scalar-valid strings, bounded depth and exact safe unsigned integer
    // lexemes reach the ordinary semantic-value parser.
    let message: Value = serde_json::from_str(text).map_err(|_| refused("JSON", "$"))?;
    if message["protocol"].as_str() != Some(PROTOCOL) {
        return Err(no_dispatch("FOREIGN_PROTOCOL"));
    }
    schema(&message).map_err(|issue| issue.response())?;
    Ok(message)
}

struct Config<'a> {
    enabled: bool,
    incoming: bool,
    local: &'a Value,
    peer: &'a Value,
    context: &'a Value,
    domain: Option<&'a Value>,
}

fn config(value: &Value) -> Result<Config<'_>, Value> {
    let role = value["role"].as_str();
    if !matches!(role, Some("incoming" | "archive")) {
        return Err(refused("LOCAL_ROLE", "$.config.role"));
    }
    for (key, reason) in [
        ("expectedLocal", "LOCAL_PIN"), ("expectedPeer", "LOCAL_PEER"),
        ("expectedContext", "LOCAL_CONTEXT"),
    ] {
        if !h(&value[key], 64) {
            return Err(refused(reason, &format!("$.config.{key}")));
        }
    }
    let domain = value.get("expectedReceiptDomain");
    if domain.is_some_and(|v| !h(v, 64)) {
        return Err(refused("LOCAL_DOMAIN", "$.config.expectedReceiptDomain"));
    }
    let enabled = value["enabled"].as_bool()
        .ok_or_else(|| refused("LOCAL_ENABLED", "$.config.enabled"))?;
    let mut keys = vec!["enabled", "role", "expectedLocal", "expectedPeer", "expectedContext"];
    if domain.is_some() { keys.push("expectedReceiptDomain"); }
    if !value.as_object().is_some_and(|o| exact_keys(o, &keys)) {
        return Err(refused("LOCAL_CONFIG", "$.config"));
    }
    Ok(Config { enabled, incoming: role == Some("incoming"),
        local: &value["expectedLocal"], peer: &value["expectedPeer"],
        context: &value["expectedContext"], domain })
}

fn binding(message: &Value, cfg: &Config<'_>, reversed: bool) -> Option<Issue> {
    let (mut from, mut to) = if cfg.incoming { (cfg.peer, cfg.local) } else { (cfg.local, cfg.peer) };
    if reversed { std::mem::swap(&mut from, &mut to); }
    for (key, expected) in [("from", from), ("to", to), ("context", cfg.context)] {
        if &message[key] != expected {
            return Some(Issue::new("BINDING", &format!("$.{key}")));
        }
    }
    if message["type"].as_str() == Some("receipt") {
        if let Some(domain) = cfg.domain {
            if &message["persistence"]["domain"] != domain {
                return Some(Issue::new("BINDING", "$.persistence.domain"));
            }
        }
    }
    None
}

fn receipt_relation(message: &Value) -> Option<Issue> {
    if message["type"].as_str() != Some("receipt") { return None; }
    let delivery = &message["subject"]["delivery"];
    for (nested, root) in [("from", "to"), ("to", "from"), ("context", "context")] {
        if delivery[nested] != message[root] {
            return Some(Issue::new("RECEIPT_RELATION", &format!("$.subject.delivery.{nested}")));
        }
    }
    None
}

fn handle(request: &Value) -> Value {
    let Some(object) = request.as_object() else { return refused("RPC", "$"); };
    let is_match = match request["method"].as_str() {
        Some("validate") => false,
        Some("matchReceipt") => true,
        _ => return refused("RPC", "$"),
    };
    let keys: &[&str] = if is_match {
        &["method", "config", "bodyHex", "originalDeliveryHex", "deliveryRumorId", "fileRumorId"]
    } else { &["method", "config", "bodyHex"] };
    if !exact_keys(object, keys) || !request["config"].is_object() {
        return refused("RPC", "$");
    }
    let cfg = match config(&request["config"]) { Ok(cfg) => cfg, Err(error) => return error };
    if is_match {
        for key in ["deliveryRumorId", "fileRumorId"] {
            if !h(&request[key], 64) {
                return refused("ORIGINAL_IDENTIFIERS", &format!("$.{key}"));
            }
        }
    }
    if !cfg.enabled { return no_dispatch("DISABLED"); }
    let original = if is_match {
        match parse_body(&request["originalDeliveryHex"]) {
            Ok(value) if value["type"].as_str() == Some("delivery")
                && binding(&value, &cfg, true).is_none() => Some(value),
            _ => return refused("ORIGINAL_DELIVERY", "$original"),
        }
    } else { None };
    let message = match parse_body(&request["bodyHex"]) { Ok(v) => v, Err(error) => return error };
    if !is_match {
        if let Some(issue) = binding(&message, &cfg, false).or_else(|| receipt_relation(&message)) {
            return issue.response();
        }
        return json!({"status": "STRUCTURALLY_VALID", "authentication": "NOT_EVALUATED",
                      "rawBodyHex": request["bodyHex"], "message": message});
    }
    if message["type"].as_str() != Some("receipt") {
        return refused("MATCH_RECEIPT_REQUIRED", "$.type");
    }
    let original = original.expect("match method parsed its original first");
    let mismatch = binding(&message, &cfg, false)
        .or_else(|| receipt_relation(&message))
        .or_else(|| {
            if message["subject"]["delivery_rumor"] != request["deliveryRumorId"] {
                Some(Issue::new("SUBJECT_ID", "$.subject.delivery_rumor"))
            } else if message["subject"]["file_rumor"] != request["fileRumorId"] {
                Some(Issue::new("SUBJECT_ID", "$.subject.file_rumor"))
            } else if message["subject"]["delivery"] != original {
                Some(Issue::new("SUBJECT_VALUE", "$.subject.delivery"))
            } else { None }
        });
    let mut result = json!({
        "status": if mismatch.is_some() { "STRUCTURAL_SUBJECT_MISMATCH" } else { "STRUCTURAL_SUBJECT_MATCH" },
        "authentication": "NOT_EVALUATED", "rawBodyHex": request["bodyHex"],
        "message": message, "originalDeliveryRawHex": request["originalDeliveryHex"],
        "originalDelivery": original, "deliveryRumorId": request["deliveryRumorId"],
        "fileRumorId": request["fileRumorId"],
    });
    if let Some(issue) = mismatch {
        result["reason"] = json!(issue.reason);
        result["path"] = json!(issue.path);
    }
    result
}

// JSONL is solely the local harness transport, never the application wire.
// Invalid RPC JSON is outside COMMON_JSON; respond with the generic RPC refusal.
fn main() -> io::Result<()> {
    let stdin = io::stdin();
    let mut stdout = io::BufWriter::new(io::stdout().lock());
    for line in stdin.lock().lines() {
        let line = line?;
        let result = match serde_json::from_str::<Value>(&line) {
            Ok(request) => handle(&request),
            Err(_) => refused("RPC", "$"),
        };
        serde_json::to_writer(&mut stdout, &result)?;
        stdout.write_all(b"\n")?;
        stdout.flush()?;
    }
    Ok(())
}
