// Experimental JavaScript adapter over the TypeScript-authored nostr-tools package.
// No crypto primitive is implemented here. Never use public fixtures for real data.
import { getPublicKey, getEventHash, finalizeEvent, verifyEvent } from 'nostr-tools/pure';
import { createSeal, createWrap, unwrapEvent } from 'nostr-tools/nip59';
import { v2 } from './nip44-strict.mjs';
export { getPublicKey, getEventHash, finalizeEvent, createSeal, createWrap, unwrapEvent, v2 };
export const secret = n => Uint8Array.from(Buffer.from(n.toString(16).padStart(64, '0'), 'hex'));
export const hex = x => Buffer.from(x).toString('hex');
const assert = (ok, reason) => { if (!ok) throw Error(reason); };
const ishex = (s,n) => typeof s==='string' && s.length===n && /^[0-9a-f]+$/.test(s);
const isSenderPin = s => typeof s==='string' && s.length===64 && [...s].every(c=>'0123456789abcdef'.includes(c));

const isContext = s => {
  if(typeof s!=='string'||s.length===0)return false;
  for(const c of s){const cp=c.codePointAt(0);if(cp>=0xd800&&cp<=0xdfff)return false;}
  return true;
};

function scalarJSON(value) {
  if(typeof value==='string') {
    for(const c of value){const cp=c.codePointAt(0);assert(cp<0xd800||cp>0xdfff,'json');}
  } else if(Array.isArray(value)) {
    for(const child of value)scalarJSON(child);
  } else if(value!==null&&typeof value==='object') {
    for(const [key,child] of Object.entries(value)){scalarJSON(key);scalarJSON(child);}
  }
  return value;
}

export function strictJSON(text) {
  assert(Buffer.byteLength(text)<=2_000_000, 'resource');
  const stack=[];
  // Scan raw JSON strings and container boundaries before parsing; escaped keys compare decoded.
  for(let i=0;i<text.length;i++) {
    const c=text[i];
    if(c==='"') {
      const start=i++;
      while(i<text.length) { if(text[i]==='\\') {i+=2;continue;} if(text[i]==='"')break;i++; }
      let next=i+1; while(/\s/.test(text[next]??'X')) next++;
      if(text[next]===':') { const frame=stack.at(-1);assert(frame?.type==='{','json');const key=JSON.parse(text.slice(start,i+1));assert(!frame.keys.has(key),'json');frame.keys.add(key); }
    } else if(/[-0-9]/.test(c)){let end=i+1;while(end<text.length&&!/[\s,}\]]/.test(text[end]))end++;assert(/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(text.slice(i,end)),'json');i=end-1;}
    else if(c==='{'||c==='[') { stack.push({type:c,keys:new Set()});assert(stack.length<=32,'json'); }
    else if(c==='}'||c===']') { const f=stack.pop();assert(f?.type===(c==='}'?'{':'['),'json'); }
  }
  assert(stack.length===0,'json');
  try{return scalarJSON(JSON.parse(text));}catch{throw Error('json');}
}
function shape(e,signed) {
  const fields=['id','pubkey','created_at','kind','tags','content',...(signed?['sig']:[])];
  assert(e&&typeof e==='object'&&!Array.isArray(e)&&Object.keys(e).length===fields.length&&fields.every(k=>Object.hasOwn(e,k)),'structure');
  assert(ishex(e.id,64)&&ishex(e.pubkey,64)&&(!signed||ishex(e.sig,128)),'structure');
  assert(Number.isSafeInteger(e.kind)&&e.kind>=0&&e.kind<=65535&&Number.isSafeInteger(e.created_at)&&e.created_at>=0&&typeof e.content==='string','structure');
  assert(Array.isArray(e.tags)&&e.tags.length<=64&&e.tags.every(t=>Array.isArray(t)&&t.length>=1&&t.length<=8&&t.every(x=>typeof x==='string')),'structure');
}
const ps=r=>r.tags.filter(t=>t[0]==='p').map(t=>t[1]);
function schema(e,r) {
  assert(e.version===1,'version');assert(JSON.stringify(e.required)==='[]','extension');
  assert(e.type==='document'&&e.context==='synthetic','schema');
  assert(ishex(e.id,64)&&e.from===r.pubkey&&e.to===ps(r)[0],'binding');
  const allowed=['protocol','version','type','id','from','to','context','required','document','files','note'];
  assert(Object.keys(e).every(k=>allowed.includes(k)),'schema');
  const d=e.document;
  assert(d&&Object.keys(d).length===5&&ishex(d.id,64)&&ishex(d.sha256,64)&&Number.isSafeInteger(d.bytes)&&d.bytes>=0&&d.bytes<=1_048_576&&Number.isSafeInteger(d.revision)&&d.revision>0&&typeof d.media==='string'&&d.media.length>0,'schema');
  if(Object.hasOwn(e,'files')) assert(Array.isArray(e.files)&&e.files.length<=16&&e.files.every(f=>f&&typeof f==='object'&&!Array.isArray(f)&&Object.keys(f).length===3&&ishex(f.x,64)&&ishex(f.ox,64)&&typeof f.size==='string'&&/^[1-9][0-9]*$/.test(f.size)&&Number(f.size)>=16&&Number(f.size)<=1_048_592),'schema');
  if(Object.hasOwn(e,'note')) assert(typeof e.note==='string','schema');
}
function validateInput(wire,key,options,byteRequest) {
  const decrypts=[0,0];
  try {
    assert(options!==null&&typeof options==='object'&&!Array.isArray(options)&&Object.hasOwn(options,'role')&&(options.role==='incoming'||options.role==='archive'),'local-role');
    const hasPin=Object.hasOwn(options,'expectedSender');
    assert(!hasPin||isSenderPin(options.expectedSender),'local-pin');
    const hasRemote=Object.hasOwn(options,'expectedRemoteRecipient');
    assert(!hasRemote||isSenderPin(options.expectedRemoteRecipient),'local-remote');
    const hasContext=Object.hasOwn(options,'expectedContext');
    assert(!hasContext||isContext(options.expectedContext),'local-context');
    const {role,cap=16384,expectedSender,expectedRemoteRecipient,expectedContext}=options;
    if(byteRequest!==undefined) {
      assert(Object.hasOwn(byteRequest,'wireHex')&&typeof byteRequest.wireHex==='string'&&byteRequest.wireHex.length%2===0&&!/[^0-9a-f]/.test(byteRequest.wireHex),'local-wire-bytes');
      assert(byteRequest.wireHex.length/2+10<=cap,'resource');
      try{wire=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(Buffer.from(byteRequest.wireHex,'hex'));}catch{throw Error('wire-utf8');}
    }
    assert(Buffer.byteLength(wire)+10<=cap,'resource');
    const w=strictJSON(wire);shape(w,true);assert(w.kind===1059,'outer-kind');const local=getPublicKey(key);
    assert(JSON.stringify(w.tags)===JSON.stringify([['p',local]]),'recipient');
    // Parse into a fresh object. finalizeEvent/verifyEvent cache state must never be trusted after mutation.
    assert(verifyEvent(w),'outer-auth');decrypts[0]++;
    let sealText;try{sealText=v2.decrypt(w.content,v2.utils.getConversationKey(key,w.pubkey));}catch{throw Error('outer-crypto');}
    const s=strictJSON(sealText);
    shape(s,true);assert(s.kind===13,'seal-kind');assert(s.tags.length===0,'seal-tags');assert(verifyEvent(s),'seal-auth');decrypts[1]++;
    let rumorText;try{rumorText=v2.decrypt(s.content,v2.utils.getConversationKey(key,s.pubkey));}catch{throw Error('seal-crypto');}
    const r=strictJSON(rumorText);
    shape(r,false);assert([14,15].includes(r.kind),'rumor-kind');assert(getEventHash(r)===r.id,'rumor-id');assert(r.pubkey===s.pubkey,'author');
    const namedP=r.tags.filter(t=>t[0]==='p');assert(namedP.length===1,'recipient');assert(namedP[0].length===2,'recipient');
    const recipients=ps(r);assert(recipients.length===1&&ishex(recipients[0],64),'recipient');
    assert(role==='archive'?r.pubkey===local:recipients[0]===local,'recipient');
    if(hasPin)assert(r.pubkey===expectedSender,'authorization');
    if(r.kind===15)return {ok:true,value:{rumor:r,dispatch:false,role:role==='archive'?'archive':'file'},decrypts};
    const e=r.content.startsWith('{')?strictJSON(r.content):null;
    if(e?.protocol!=='NBDP/experiment')return {ok:true,value:{rumor:r,dispatch:false,role:'chat'},decrypts};
    schema(e,r);
    const value={rumor:r,envelope:e,dispatch:role!=='archive',role:role==='archive'?'archive':'incoming'};
    if(role==='archive')value.archiveConversationMatched=hasRemote&&hasContext&&expectedRemoteRecipient===recipients[0]&&expectedRemoteRecipient===e.to&&expectedContext===e.context;
    return {ok:true,value,decrypts};
  }catch(e){return {ok:false,error:e.message,decrypts};}
}
export function validate(wire,key,options){return validateInput(wire,key,options,undefined);}
export function validateBytes(request,key,options){return validateInput(undefined,key,options,request);}
export function rumor(envelope,from,to,{kind=14,tags=[['p',to]],timestamp=Math.floor(Date.now()/1000)}={}) {
  const r={pubkey:from,created_at:timestamp,kind,tags,content:typeof envelope==='string'?envelope:JSON.stringify(envelope)};
  return {...r,id:getEventHash(r)};
}
export function wrap(r,key,to){return createWrap(createSeal(r,key,to),to);}
export function sealRaw(raw,key,to,patch={}) {
  return finalizeEvent({kind:13,created_at:Math.floor(Date.now()/1000)-60,tags:[],content:v2.encrypt(raw,v2.utils.getConversationKey(key,to)),...patch},key);
}
export function envelope(from,to,n=1) {
  return {protocol:'NBDP/experiment',version:1,type:'document',id:n.toString(16).padStart(64,'0'),from,to,context:'synthetic',required:[],document:{id:'d'.repeat(64),revision:1,sha256:'a'.repeat(64),bytes:7,media:'application/octet-stream'}};
}


// Explicit invoice carrier entry only. All preceding D08 bytes/exports are intact.
// SOURCE_PREPARED_NOT_EXECUTED; contract ed5f57df25c67efccb2e3ac9cc6171883a675a7ab18df3673b131ac5ca4104f8.
import { handle as invoiceCodecHandle } from '../../invoice_message_codec/js/codec.mjs';

const carrierObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const carrierOwn = (value, key) => Object.hasOwn(value, key);
const carrierKeys = (value, fields) => carrierObject(value) && Object.keys(value).length === fields.length
  && fields.every(field => carrierOwn(value, field));
const carrierH64 = value => typeof value === 'string' && value.length === 64 && !/[^0-9a-f]/.test(value);
const carrierHexBytes = value => typeof value === 'string' && value.length % 2 === 0 && !/[^0-9a-f]/.test(value);
const carrierConfigFields = ['enabled', 'role', 'expectedLocal', 'expectedPeer', 'expectedContext'];

class CarrierFailure extends Error {
  constructor(stage, reason) { super(reason); this.stage = stage; this.reason = reason; }
}
function carrierEnsure(condition, stage, reason) {
  if (!condition) throw new CarrierFailure(stage, reason);
}
function carrierScalarText(value) {
  for (const character of value) {
    const point = character.codePointAt(0);
    if (point >= 0xd800 && point <= 0xdfff) return false;
  }
  return true;
}
function carrierKey(value, stage, reason) {
  carrierEnsure(carrierH64(value), stage, reason);
  const key = Uint8Array.from(Buffer.from(value, 'hex'));
  let publicKey;
  try { publicKey = getPublicKey(key); }
  catch { throw new CarrierFailure(stage, reason); }
  return { key, publicKey };
}
function carrierParse(text, stage) {
  try { return strictJSON(text); }
  catch { throw new CarrierFailure(stage, 'JSON'); }
}
function carrierShape(event, signed, stage) {
  try { shape(event, signed); }
  catch { throw new CarrierFailure(stage, 'STRUCTURE'); }
}
function carrierAuthenticated(event) {
  // Event objects are fresh from strictJSON, never caller/library cache objects.
  try { return verifyEvent(event) === true; }
  catch { return false; }
}
const carrierSingleP = (tags, recipient) => tags.length === 1 && tags[0].length === 2
  && tags[0][0] === 'p' && tags[0][1] === recipient;
const carrierProducerRefusal = (stage, reason) => ({ status: 'REFUSED', stage, reason,
  transportVerification: 'NOT_EVALUATED', decrypts: [0, 0], codecInvocations: 0 });
const carrierConsumerRefusal = (stage, reason, decrypts) => ({ status: 'REFUSED', stage, reason,
  transportVerification: 'INCOMPLETE', decrypts: [...decrypts], codecInvocations: 0 });

function carrierProduce(request) {
  let stage = 'P0';
  try {
    carrierEnsure(carrierKeys(request, ['op', 'secretHex', 'from', 'to', 'createdAt', 'contentHex']), 'P0', 'RPC');
    const { key, publicKey } = carrierKey(request.secretHex, 'P0', 'PRODUCER_KEY');
    carrierEnsure(carrierH64(request.from) && request.from === publicKey, 'P0', 'PRODUCER_FROM');
    carrierEnsure(carrierH64(request.to), 'P0', 'PRODUCER_TO');
    // Existing library conversion validates the recipient point in preflight.
    try { v2.utils.getConversationKey(key, request.to); }
    catch { throw new CarrierFailure('P0', 'PRODUCER_TO'); }
    carrierEnsure(Number.isSafeInteger(request.createdAt) && request.createdAt >= 0, 'P0', 'PRODUCER_TIME');
    carrierEnsure(carrierHexBytes(request.contentHex) && request.contentHex.length / 2 <= 8192, 'P0', 'PRODUCER_CONTENT');
    let content;
    try { content = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(Buffer.from(request.contentHex, 'hex')); }
    catch { throw new CarrierFailure('P0', 'PRODUCER_CONTENT'); }
    carrierEnsure(carrierScalarText(content), 'P0', 'PRODUCER_CONTENT');
    stage = 'P1';
    const unsigned = { pubkey: request.from, created_at: request.createdAt, kind: 14,
      tags: [['p', request.to]], content };
    const r = { ...unsigned, id: getEventHash(unsigned) };
    stage = 'P2';
    // Both library wraps encrypt THIS exact canonical rumor without rebuilding it.
    const peer = wrap(r, key, request.to);
    const archive = wrap(r, key, request.from);
    return { status: 'PRODUCED', stage: 'P_DONE', transportVerification: 'NOT_EVALUATED',
      decrypts: [0, 0], codecInvocations: 0, rumor: r, wraps: { peer, archive } };
  } catch (error) {
    if (error instanceof CarrierFailure) return carrierProducerRefusal(error.stage, error.reason);
    if (stage === 'P1' || stage === 'P2') return carrierProducerRefusal(stage, 'PRODUCER_LIBRARY');
    throw error;
  }
}

// New COMMON_JSON carrier RPC. Legacy validate/validateBytes never call this path.
export function carrierHandle(request) {
  if (carrierObject(request) && request.op === 'carrier-produce') return carrierProduce(request);
  const decrypts = [0, 0];
  try {
    carrierEnsure(carrierObject(request) && ['carrier-consume', 'carrier-match-receipt'].includes(request.op), 'S0', 'RPC');
    const matching = request.op === 'carrier-match-receipt';
    const fields = matching ? ['op', 'secretHex', 'config', 'wireHex', 'originalDeliveryHex', 'deliveryRumorId', 'fileRumorId']
      : ['op', 'secretHex', 'config', 'wireHex'];
    carrierEnsure(carrierKeys(request, fields) && carrierObject(request.config), 'S0', 'RPC');
    const config = request.config;
    carrierEnsure(carrierOwn(config, 'role') && ['incoming', 'archive'].includes(config.role), 'S0', 'LOCAL_ROLE');
    carrierEnsure(carrierOwn(config, 'expectedLocal') && carrierH64(config.expectedLocal), 'S0', 'LOCAL_PIN');
    const { key, publicKey: local } = carrierKey(request.secretHex, 'S0', 'LOCAL_KEY');
    carrierEnsure(config.expectedLocal === local, 'S0', 'LOCAL_PIN_BINDING');
    carrierEnsure(carrierOwn(config, 'expectedPeer') && carrierH64(config.expectedPeer), 'S0', 'LOCAL_PEER');
    carrierEnsure(carrierOwn(config, 'expectedContext') && carrierH64(config.expectedContext), 'S0', 'LOCAL_CONTEXT');
    const hasDomain = carrierOwn(config, 'expectedReceiptDomain');
    carrierEnsure(!hasDomain || carrierH64(config.expectedReceiptDomain), 'S0', 'LOCAL_DOMAIN');
    carrierEnsure(carrierOwn(config, 'enabled') && typeof config.enabled === 'boolean', 'S0', 'LOCAL_ENABLED');
    carrierEnsure(carrierKeys(config, hasDomain ? [...carrierConfigFields, 'expectedReceiptDomain'] : carrierConfigFields), 'S0', 'LOCAL_CONFIG');
    if (matching) carrierEnsure(carrierH64(request.deliveryRumorId) && carrierH64(request.fileRumorId), 'S0', 'LOCAL_ORIGINAL_IDS');
    if (!config.enabled) return { status: 'NO_DISPATCH', stage: 'S0', reason: 'DISABLED',
      transportVerification: 'NOT_EVALUATED', decrypts, codecInvocations: 0 };

    carrierEnsure(carrierHexBytes(request.wireHex), 'S1', 'WIRE_HEX');
    carrierEnsure(request.wireHex.length / 2 + 10 <= 16384, 'S1', 'RESOURCE');
    let wire;
    try { wire = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(Buffer.from(request.wireHex, 'hex')); }
    catch { throw new CarrierFailure('S1', 'WIRE_UTF8'); }
    const w = carrierParse(wire, 'S1');
    carrierShape(w, true, 'S1');
    carrierEnsure(w.kind === 1059, 'S1', 'OUTER_KIND');
    carrierEnsure(carrierSingleP(w.tags, local), 'S1', 'OUTER_RECIPIENT');
    carrierEnsure(carrierAuthenticated(w), 'S1', 'OUTER_AUTH');

    decrypts[0]++;
    let sealText;
    try { sealText = v2.decrypt(w.content, v2.utils.getConversationKey(key, w.pubkey)); }
    catch { throw new CarrierFailure('S2', 'OUTER_CRYPTO'); }
    const s = carrierParse(sealText, 'S2');
    carrierShape(s, true, 'S2');
    carrierEnsure(s.kind === 13, 'S2', 'SEAL_KIND');
    carrierEnsure(s.tags.length === 0, 'S2', 'SEAL_TAGS');
    carrierEnsure(carrierAuthenticated(s), 'S2', 'SEAL_AUTH');

    decrypts[1]++;
    let rumorText;
    try { rumorText = v2.decrypt(s.content, v2.utils.getConversationKey(key, s.pubkey)); }
    catch { throw new CarrierFailure('S3', 'SEAL_CRYPTO'); }
    const r = carrierParse(rumorText, 'S3');
    carrierShape(r, false, 'S3');
    carrierEnsure(r.kind === 14 || r.kind === 15, 'S3', 'RUMOR_KIND');
    let hash;
    try { hash = getEventHash(r); }
    catch { throw new CarrierFailure('S3', 'RUMOR_ID'); }
    carrierEnsure(hash === r.id, 'S3', 'RUMOR_ID');
    carrierEnsure(r.pubkey === s.pubkey, 'S3', 'AUTHOR');

    const named = r.tags.filter(tag => tag[0] === 'p');
    carrierEnsure(named.length === 1 && named[0].length === 2 && carrierH64(named[0][1]), 'S4', 'INNER_RECIPIENT');
    const recipient = named[0][1];
    carrierEnsure(config.role === 'archive' ? r.pubkey === local : recipient === local, 'S4', 'INNER_RECIPIENT');
    carrierEnsure(config.role === 'archive' ? recipient === config.expectedPeer : r.pubkey === config.expectedPeer, 'S4', 'PEER_BINDING');
    carrierEnsure(r.kind === 14, 'S4', 'INVOICE_KIND');
    carrierEnsure(carrierSingleP(r.tags, recipient), 'S4', 'INVOICE_TAGS');

    const rawBodyHex = Buffer.from(r.content, 'utf8').toString('hex');
    const codecRequest = matching ? { method: 'matchReceipt', config, bodyHex: rawBodyHex,
      originalDeliveryHex: request.originalDeliveryHex, deliveryRumorId: request.deliveryRumorId, fileRumorId: request.fileRumorId }
      : { method: 'validate', config, bodyHex: rawBodyHex };
    // Exactly one frozen codec invocation, after the complete chain/endpoint proof.
    const codec = invoiceCodecHandle(codecRequest);
    return { status: 'CARRIER_RESULT', stage: 'S5', transportVerification: 'CHAIN_AND_ENDPOINT_VALIDATED',
      decrypts, codecInvocations: 1, rumor: r, rawBodyHex, codec };
  } catch (error) {
    if (error instanceof CarrierFailure) return carrierConsumerRefusal(error.stage, error.reason, decrypts);
    throw error;
  }
}
