//! Source-only E06 metadata/authentication component; no acquisition/AES/effects.
use std::collections::{BTreeMap, BTreeSet};
use std::io::{self, BufRead, Write};
use serde_json::{Value, json};

#[allow(dead_code)]
mod baseline;
mod metadata_json;

const LIMITATIONS: &str = "NO_ACQUISITION_NO_ORIGINAL_VERIFICATION_NO_DURABILITY_NO_RECEIPT_NO_BUSINESS_AUTHORITY";
const REQUEST_BOUND: usize = 131072;
const WIRE_HEX_BOUND: usize = 32748;

#[derive(Clone, PartialEq, Eq)]
struct Scope {
    role: String,
    local: String,
    peer: String,
    context: String,
    origin: String,
}

#[derive(Clone)]
struct Delivery {
    raw: String,
    proof: Value,
    rumor: Value,
    message: Value,
    scope: Scope,
}

#[derive(Clone)]
struct FileEvidence {
    raw: String,
    proof: Value,
    rumor: Value,
    scope: Scope,
}

#[derive(Clone, Default)]
struct Window {
    scope: Option<Scope>,
    deliveries: BTreeMap<String, Delivery>,
    files: BTreeMap<String, FileEvidence>,
    conflicts: BTreeSet<String>,
    capacity_held: bool,
}

struct Observation {
    d_source: &'static str,
    d_id: Option<String>,
    f_id: Option<String>,
    d_reply: Option<Value>,
    f_reply: Option<Value>,
    d_calls: u8,
    f_calls: u8,
}

impl Observation {
    fn empty() -> Self {
        Self { d_source: "ABSENT", d_id: None, f_id: None,
               d_reply: None, f_reply: None, d_calls: 0, f_calls: 0 }
    }

    fn finish(&self, window: &Window, status: &str, stage: &str, reason: &str, association: &str) -> Value {
        let record = |entry: &str, reply: &Option<Value>| match reply {
            Some(raw) => json!({"backend":"RUST", "entry":entry, "rawReply":raw}),
            None => Value::Null,
        };
        json!({"schema":"e06-file-metadata-result-v1", "component":"METADATA_AUTHENTICATION_ONLY",
            "status":status, "stage":stage, "reason":reason, "dSource":self.d_source,
            "dRumorId":self.d_id, "fRumorId":self.f_id, "association":association,
            "validation":{"D":record("carrier-consume", &self.d_reply),
                          "F":record("validate-bytes", &self.f_reply)},
            "validationCallCounts":{"D":self.d_calls,"F":self.f_calls},
            "window":{"dEntries":window.deliveries.len(),"fEntries":window.files.len(),
                       "capacityHeld":window.capacity_held}, "limitations":LIMITATIONS})
    }

    fn refusal(&self, window: &Window, stage: &str, reason: &str) -> Value {
        self.finish(window, "REFUSED", stage, reason, "UNCHANGED")
    }
}

fn exact(value: &Value, keys: &[&str]) -> bool {
    value.as_object().is_some_and(|map| map.len() == keys.len() && keys.iter().all(|key| map.contains_key(*key)))
}

fn lower_hex(text: &str) -> bool {
    text.bytes().all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}

fn h(value: &Value, length: usize) -> bool {
    value.as_str().is_some_and(|text| text.len() == length && lower_hex(text))
}

fn wire_repr(value: &Value) -> bool {
    value.as_str().is_some_and(|text| text.len() % 2 == 0 && lower_hex(text))
}

fn origin(text: &str) -> bool {
    if text.len() > 447 || !text.is_ascii() { return false; }
    let Some(authority) = text.strip_prefix("https://") else { return false; };
    let (host, port) = match authority.split_once(':') {
        Some((host, port)) => (host, Some(port)),
        None => (authority, None),
    };
    if host.is_empty() || host.len() > 253 { return false; }
    if !host.split('.').all(|label| {
        let bytes = label.as_bytes();
        !bytes.is_empty() && bytes.len() <= 63
            && bytes[0].is_ascii_alphanumeric() && bytes[bytes.len()-1].is_ascii_alphanumeric()
            && bytes.iter().all(|b| b.is_ascii_digit() || (b'a'..=b'z').contains(b) || *b == b'-')
    }) { return false; }
    if let Some(port) = port {
        if port.is_empty() || !port.bytes().all(|b| b.is_ascii_digit()) { return false; }
        let mut number = 0u32;
        for digit in port.bytes() {
            number = number * 10 + u32::from(digit - b'0');
            if number > 65535 { return false; }
        }
        if number == 0 { return false; }
    }
    true
}

fn local(request: &Value) -> Result<(Scope, bool), &'static str> {
    if !exact(request, &["op","secretHex","config","dWireHex","fWireHex"])
        || request["op"] != "correlate-file-metadata"
        || !exact(&request["config"], &["enabled","role","expectedLocal","expectedPeer","expectedContext","allowedOrigin"])
        || !(request["dWireHex"].is_null() || request["dWireHex"].is_string())
        || !request["fWireHex"].is_string() { return Err("REQUEST_SHAPE"); }
    let config = &request["config"];
    let role = config["role"].as_str().filter(|r| *r == "incoming" || *r == "archive").ok_or("LOCAL_ROLE")?;
    if !h(&config["expectedLocal"],64) { return Err("LOCAL_PIN"); }
    if !h(&request["secretHex"],64) { return Err("LOCAL_KEY"); }
    let actual = baseline::metadata_local_pubkey(request["secretHex"].as_str().expect("H64 checked")).ok_or("LOCAL_KEY")?;
    if config["expectedLocal"] != actual { return Err("LOCAL_PIN_BINDING"); }
    if !h(&config["expectedPeer"],64) { return Err("LOCAL_PEER"); }
    if !h(&config["expectedContext"],64) { return Err("LOCAL_CONTEXT"); }
    let allowed = config["allowedOrigin"].as_str().filter(|s| origin(s)).ok_or("LOCAL_ORIGIN")?;
    let enabled = config["enabled"].as_bool().ok_or("LOCAL_ENABLED")?;
    Ok((Scope { role:role.to_owned(), local:actual, peer:config["expectedPeer"].as_str().unwrap().to_owned(),
                context:config["expectedContext"].as_str().unwrap().to_owned(), origin:allowed.to_owned() }, enabled))
}

fn validate_d(raw: &str, secret: &str, scope: &Scope, obs: &mut Observation) -> Result<Delivery, (&'static str, &'static str)> {
    if raw.encode_utf16().count() > WIRE_HEX_BOUND { return Err(("D_AUTH","PROFILE_OUTER_BOUND")); }
    obs.d_calls += 1;
    let reply = baseline::metadata_rpc(json!({"op":"carrier-consume", "secretHex":secret,
        "config":{"enabled":true,"role":scope.role,"expectedLocal":scope.local,
                  "expectedPeer":scope.peer,"expectedContext":scope.context}, "wireHex":raw}));
    obs.d_reply = Some(reply.clone());
    if reply["status"] != "CARRIER_RESULT" || reply["stage"] != "S5"
        || reply["transportVerification"] != "CHAIN_AND_ENDPOINT_VALIDATED" {
        return Err(("D_AUTH","D_VALIDATION"));
    }
    if reply["rumor"]["kind"] != 14 || reply["codec"]["status"] != "STRUCTURALLY_VALID"
        || reply["codec"]["message"]["type"] != "delivery" {
        return Err(("D_SCHEMA","D_NOT_QUALIFIED_DELIVERY"));
    }
    let delivery = Delivery { raw:raw.to_owned(), proof:reply.clone(), rumor:reply["rumor"].clone(),
                              message:reply["codec"]["message"].clone(), scope:scope.clone() };
    obs.d_id = delivery.rumor["id"].as_str().map(String::from);
    Ok(delivery)
}

fn validate_f(raw: &str, secret: &str, scope: &Scope, obs: &mut Observation) -> Result<FileEvidence, (&'static str, &'static str)> {
    if raw.encode_utf16().count() > WIRE_HEX_BOUND { return Err(("F_AUTH","PROFILE_OUTER_BOUND")); }
    obs.f_calls += 1;
    let sender = if scope.role == "archive" { &scope.local } else { &scope.peer };
    let reply = baseline::metadata_rpc(json!({"op":"validate-bytes", "wireHex":raw, "secret":secret,
        "role":scope.role,"expectedSender":sender,"cap":16384}));
    obs.f_reply = Some(reply.clone());
    // Preserve, and only internally inspect, both legacy RPC envelope layers.
    if reply["ok"] != true || reply["value"]["ok"] != true { return Err(("F_AUTH","F_VALIDATION")); }
    let rumor = &reply["value"]["value"]["rumor"];
    if rumor["kind"] != 15 { return Err(("F_AUTH","F_KIND")); }
    let expected_author = if scope.role == "archive" { &scope.local } else { &scope.peer };
    let expected_recipient = if scope.role == "archive" { &scope.peer } else { &scope.local };
    let recipients: Vec<&Value> = rumor["tags"].as_array().map(|tags| tags.iter().filter(|tag| tag[0] == "p").collect()).unwrap_or_default();
    if rumor["pubkey"].as_str() != Some(expected_author.as_str()) || recipients.len() != 1
        || recipients[0] != &json!(["p",expected_recipient]) { return Err(("F_AUTH","F_SCOPE")); }
    obs.f_id = rumor["id"].as_str().map(String::from);
    let admitted_rumor = rumor.clone();
    Ok(FileEvidence { raw:raw.to_owned(), proof:reply, rumor:admitted_rumor, scope:scope.clone() })
}

fn file_shape(file: &FileEvidence) -> Result<(), &'static str> {
    let names = ["p","e","file-type","encryption-algorithm","decryption-key","decryption-nonce","x","ox","size"];
    let Some(tags) = file.rumor["tags"].as_array() else { return Err("EXACT_NINE_TAGS"); };
    if tags.len() != 9 { return Err("EXACT_NINE_TAGS"); }
    for (index,name) in names.iter().enumerate() {
        let Some(cells) = tags[index].as_array() else { return Err("EXACT_NINE_TAGS"); };
        if cells.len() != (if index == 1 {4} else {2}) || cells[0] != *name
            || !cells.iter().all(Value::is_string) { return Err("EXACT_NINE_TAGS"); }
    }
    if !h(&tags[4][1],64) || !h(&tags[5][1],24) || !h(&tags[6][1],64) || !h(&tags[7][1],64) {
        return Err("F_ENCODING");
    }
    let decimal = tags[8][1].as_str().unwrap();
    let size = decimal.parse::<u64>().ok().filter(|n| (16..=1_048_592).contains(n));
    if !decimal.bytes().all(|b| b.is_ascii_digit()) || size.is_none()
        || size.unwrap().to_string() != decimal { return Err("F_ENCODING"); }
    let expected = format!("{}/{}",file.scope.origin,tags[6][1].as_str().unwrap());
    if file.rumor["content"].as_str() != Some(expected.as_str()) || expected.len() > 512 {
        return Err("F_URL");
    }
    Ok(())
}

fn correlate(file: &FileEvidence, delivery: Option<&Delivery>) -> Result<(), &'static str> {
    let tags = file.rumor["tags"].as_array().expect("file shape qualified");
    if !h(&tags[1][1],64) || tags[1][2] != "" || tags[1][3] != "reply" { return Err("EXACT_D_PARENT"); }
    if tags[2][1] != "application/octet-stream" || tags[3][1] != "aes-gcm" { return Err("F_PROFILE_CONSTANTS"); }
    if let Some(delivery) = delivery {
        if tags[1][1] != delivery.rumor["id"] { return Err("EXACT_D_PARENT"); }
        let message = &delivery.message;
        if file.scope != delivery.scope || file.rumor["pubkey"] != message["from"] || tags[0][1] != message["to"]
            || tags[2][1] != message["document"]["media"] || tags[4][1] != message["file"]["key"]
            || tags[5][1] != message["file"]["nonce"] || tags[6][1] != message["file"]["x"]
            || tags[7][1] != message["file"]["ox"]
            || tags[8][1].as_str() != message["file"]["bytes"].as_u64().map(|n| n.to_string()).as_deref()
            || file.rumor["content"].as_str() != Some(format!("{}/{}",file.scope.origin,
                message["file"]["x"].as_str().expect("D codec H64")).as_str()) {
            return Err("EXACT_D_FILE_EQUALITY");
        }
    }
    Ok(())
}

impl Window {
    fn apply(&mut self, request: &Value) -> Value {
        let mut obs = Observation::empty();
        let (scope,enabled) = match local(request) {
            Ok(value) => value,
            Err(reason) => return obs.refusal(self,"LOCAL",reason),
        };
        if self.scope.as_ref().is_some_and(|old| old != &scope) { return obs.refusal(self,"LOCAL","SCOPE_CHANGED"); }
        if !enabled { return obs.finish(self,"NO_DISPATCH","LOCAL","DISABLED","UNCHANGED"); }
        if self.capacity_held { return obs.finish(self,"WINDOW_FULL","ASSOCIATION","WINDOW_CAPACITY","CAPACITY_HOLD"); }
        let secret = request["secretHex"].as_str().expect("local secret checked");
        let mut delivery = None;
        if !request["dWireHex"].is_null() {
            obs.d_source = "SUPPLIED_RAW";
            if request["dWireHex"].as_str().unwrap().encode_utf16().count() > WIRE_HEX_BOUND {
                return obs.refusal(self,"D_AUTH","PROFILE_OUTER_BOUND");
            }
            if !wire_repr(&request["dWireHex"]) { return obs.refusal(self,"LOCAL","WIRE_REPRESENTATION"); }
            match validate_d(request["dWireHex"].as_str().unwrap(),secret,&scope,&mut obs) {
                Ok(d) => delivery = Some(d),
                Err((stage,reason)) => return obs.refusal(self,stage,reason),
            }
        }
        if request["fWireHex"].as_str().unwrap().encode_utf16().count() > WIRE_HEX_BOUND {
            return obs.refusal(self,"F_AUTH","PROFILE_OUTER_BOUND");
        }
        if !wire_repr(&request["fWireHex"]) { return obs.refusal(self,"LOCAL","WIRE_REPRESENTATION"); }
        let file = match validate_f(request["fWireHex"].as_str().unwrap(),secret,&scope,&mut obs) {
            Ok(value) => value,
            Err((stage,reason)) => return obs.refusal(self,stage,reason),
        };
        if let Err(reason) = file_shape(&file) { return obs.refusal(self,"F_SHAPE",reason); }
        if let Err(reason) = correlate(&file,None) { return obs.refusal(self,"CORRELATION",reason); }
        let parent = file.rumor["tags"][1][1].as_str().unwrap();
        if delivery.is_none() {
            if let Some(retained) = self.deliveries.get(parent) {
                obs.d_source = "RETAINED_RAW_REVALIDATED";
                match validate_d(&retained.raw,secret,&scope,&mut obs) {
                    Ok(value) => delivery = Some(value),
                    Err((stage,reason)) => return obs.refusal(self,stage,reason),
                }
            }
        }
        if let Err(reason) = correlate(&file,delivery.as_ref()) { return obs.refusal(self,"CORRELATION",reason); }
        let fid = obs.f_id.as_ref().expect("F authentication qualifies ID").clone();
        let mut qualified_ids = BTreeSet::new();
        if let Some(d) = &delivery {
            qualified_ids.insert(fid.clone());
            // Original private raw/proof/scope provenance is retained in each
            // record. Projection checks every comparand, not only parent hints.
            for (id,old) in &self.files {
                if old.scope == scope && correlate(old,Some(d)).is_ok() { qualified_ids.insert(id.clone()); }
            }
        }
        let new_d = obs.d_id.as_ref().is_some_and(|id| !self.deliveries.contains_key(id));
        let new_f = !self.files.contains_key(&fid);
        if self.deliveries.len() + usize::from(new_d) > 16 || self.files.len() + usize::from(new_f) > 32
            || qualified_ids.len() > 2 {
            self.capacity_held = true;
            return obs.finish(self,"WINDOW_FULL","ASSOCIATION","WINDOW_CAPACITY","CAPACITY_HOLD");
        }
        let mut candidate = self.clone();
        candidate.scope = Some(scope.clone());
        candidate.files.entry(fid.clone()).or_insert(file);
        let mut duplicate = false;
        let mut conflict = false;
        if let Some(d) = delivery {
            let did = obs.d_id.as_ref().expect("D validator qualified ID").clone();
            duplicate = self.files.contains_key(&fid) && self.deliveries.contains_key(&did);
            candidate.deliveries.entry(did.clone()).or_insert(d);
            if qualified_ids.len() >= 2 { candidate.conflicts.insert(did.clone()); }
            conflict = candidate.conflicts.contains(&did);
        }
        *self = candidate;
        if conflict { return obs.finish(self,"CONFLICT","ASSOCIATION","MULTIPLE_CANONICAL_F_IDS","CONFLICT_RETAIN_BOTH"); }
        if obs.d_id.is_none() { return obs.finish(self,"ORPHAN_PENDING","ASSOCIATION","ORPHAN_F","PENDING_NO_D"); }
        let association = if duplicate {"UNCHANGED_ONE_F"} else {"ONE_CANONICAL_F"};
        if scope.role == "archive" { return obs.finish(self,"ARCHIVE_ONLY","ASSOCIATION","ARCHIVE_NO_ACQUISITION",association); }
        obs.finish(self,if duplicate {"DUPLICATE"} else {"CORRELATED"},"ASSOCIATION",
                   if duplicate {"SAME_CANONICAL_F"} else {"EXACT_D_F_METADATA"},association)
    }
}

fn next_line<R: BufRead>(reader: &mut R) -> io::Result<Option<Result<Vec<u8>, ()>>> {
    let mut raw = Vec::new();
    let mut overflow = false;
    let mut seen = false;
    loop {
        let chunk = reader.fill_buf()?;
        if chunk.is_empty() {
            return Ok(if !seen {None} else if overflow {Some(Err(()))} else {Some(Ok(raw))});
        }
        seen = true;
        let newline = chunk.iter().position(|b| *b == b'\n');
        let used = newline.map_or(chunk.len(), |index| index + 1);
        let body = if newline.is_some() {used-1} else {used};
        if !overflow {
            if raw.len() + body > REQUEST_BOUND { overflow = true; raw.clear(); }
            else { raw.extend_from_slice(&chunk[..body]); }
        }
        reader.consume(used);
        if newline.is_some() { return Ok(Some(if overflow {Err(())} else {Ok(raw)})); }
    }
}

fn main() -> io::Result<()> {
    let mut window = Window::default();
    let stdin = io::stdin();
    let mut input = stdin.lock();
    let stdout = io::stdout();
    let mut output = io::BufWriter::new(stdout.lock());
    while let Some(raw) = next_line(&mut input)? {
        let parsed = raw.and_then(|bytes| baseline::metadata_parse(&bytes));
        let result = match parsed {
            Ok(request) => window.apply(&request),
            Err(()) => Observation::empty().refusal(&window,"LOCAL","REQUEST_SHAPE"),
        };
        serde_json::to_writer(&mut output,&result)?;
        output.write_all(b"\n")?;
        output.flush()?;
    }
    Ok(())
}
