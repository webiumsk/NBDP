# Finite laboratory composition: non-executable interface plan

State: **SOURCE_PLAN_NOT_EXECUTABLE / NOT_RUNTIME_READY**. No implementation,
fixture generation, source import, control or experiment is released. Signatures
below describe future private interfaces, not an SDK or executable source.
`contract.json` and `profile.json` have the same approval boundary. The coordinator
authorized only these six planning files after accepted HTTPS primary76355/QA14337.

## Process and ownership boundary

One serial controller owns each window's schedule, raw relay transcripts and
counter ledger. One new composition case process owns the derivative protocol's
private context/generation/authentication/snapshot/result WeakMaps. It launches or
owns one admitted persistent native metadata child per window, with a fixed
backend and scope. JS metadata uses the unchanged admitted `_handleLine` entry;
Rust uses the unchanged admitted persistent RPC entry. All multi-step requests
remain in that same metadata child; restarting it does not reset a window safely.

If controller and composition case are different processes, only bounded private
framed descriptors cross the pipe. The case must independently bind each claimed
wire job to its frozen job, actual raw receive frame, EVENT object span, complete
transcript/lifecycle and current release. A controller JSON `verified:true`, native
PASS string or fixture equality cannot mint an authenticated capability. No
capability crosses processes, and no caller-supplied module/command is permitted.
Before implementation, freeze the exact private frame and reply schemas in the
new contract; they are currently NOT_FROZEN and admission must refuse them.

## Relay worker interfaces

Future files owned exclusively by relay worker: `wire.mjs`,
`metadata_loader.mjs`, `wire_controls.mjs`. This worker is not alone; preserve all
other edits and accepted originals. No Git mutations or publication.

- `receiveFixedEvent(jobBinding, externalBindingSHA) -> OwnedReceiveRecord`:
  private fixed-job CLI. New selection binds exact accepted D/new-F wires, relay,
  outer ID, role, tool/ws closure, fresh output and finite frame/stream limits.
  Retain ACK, EVENT, EOSE, CLOSE and actual Close1000; extra/unknown transitions
  refuse. No crypto, metadata import, URL rewrite, signing or new wrapping here.
- `validateEventFrame(rawFrameBytes, subscription, expectedEvent) ->
  {event, wireHex}`: preserve the existing raw-span algorithm. `wireHex` is the
  original third-element EVENT object byte span, never `JSON.stringify(event)`.
  Typed whole-event equality and exact span/frame binding are separate checks.
- `startMetadataWindow(admittedBinding) -> OwnedMetadataChannel`: one fixed
  existing backend, fresh window, fixed role/local/peer/context/origin and maximum
  request count. JS loader import occurs only after full derivative admission.
- `sendMetadata(channel, rawJSONLRequest) -> NativeReplyRecord`: request has the
  unchanged exact keys `op,secretHex,config,dWireHex,fWireHex`; replace wire fields
  only with actual received spans. Preserve raw bytes, full backend-native reply,
  request/reply count/order and native lifecycle. No expected reply in worker input.
- `closeMetadata(channel) -> LifecycleRecord`: require exact declared request
  cardinality, no extra output, natural exit/reap/both EOF/no forced/timeout for a
  qualified path. A failure preserves partial records and uncertainty.

These are proposals for derivative adapters around the existing private APIs.
The accepted relay executables are pinned to the old selection and cannot simply
be invoked with new HTTPS fixtures. EOSE/Close1000 is a laboratory cut only.

## Protocol/controller worker interfaces

Future files owned exclusively by protocol/controller worker: `protocol.mjs`,
`runner.py`, `admission.py`, `controls.py`. Preserve all accepted sources and the
other workers' files. The coordinator owns manifests/releases and shared state.

- `loadWindowContext(framePath, externalSHA) -> WindowContext`: validate the exact
  derivative source/tool/binary/image/input/control/config/release closure and
  selected supported lane/window before dependent work. Only LAB-I4's C01-C04 may
  be selected by an eventual I4 release. Reject LAB-N, mixed cases, unknown cases,
  missing/unprepared oracles and unresolved NOT_FROZEN markers. No fallback to a
  positive profile when a negative profile is unavailable.
- `bindReceivedEvent(ctx, ownedReceiveRecord) -> ReceivedEventHandle`: mint a
  private handle only after actual transcript/span/lifecycle binding above. Raw
  fixture equality is a guard, not received-byte provenance or authentication.
- `authenticateReceived(ctx, dHandleOrNull, fHandle) -> AuthenticatedStepHandle`:
  invoke the same persistent metadata child with actual spans, retain full native
  13-key reply and actual validation counts, and derive subject from native
  authenticated D/F facts. Never invoke old HTTPS `authenticateFixture()` or use
  a supplied prepared expected object as authentication. Retained D is raw and
  must follow the existing native revalidation path. Exact native stage precedence
  is preserved. Missing F has no fictitious metadata reply.
- `sealWindow(ctx, completedFrontier) -> GenerationHandle`: serial local action,
  allowed once, only after all declared pre-seal work is complete and exactly one
  incoming eligible association exists with local permission/current pins and no
  sticky conflict/capacity/lifecycle uncertainty. Immutable record binds canonical
  D/F IDs, actual receive/authentication provenance, scope, origin/URL, byte
  commitments, engine route and single allowance. It is not a wire object or
  cryptographic attestation. Initial I4 has no post-seal input jobs.
- `reserveAcquisition(ctx, generation) -> AttemptHandle`: recheck eligibility and
  latch the sole attempt BEFORE server/listener/client/connection side effects.
  Write retained reservation evidence before invoking transport. A failed/unknown
  acquisition or launch consumes allowance. No second reservation, retry or
  fallback, even after first-attempt failure or duplicate arrival.
- `getAuthenticated(generation, ctx) -> FrozenAuthenticatedSubject`: only private
  same-context/window/generation handles qualify. Subject is derived internally
  from actual fresh native authentication, never caller IDs/JSON permission.
- `invalidateGeneration(ctx, authenticatedStep) -> InvalidationRecord`: qualifying
  distinct F appends invalidation without changing sealed identity or allowance.
  Reauthenticate duplicate/fresh wrap; retain provenance but create no generation
  or acquisition/consumer/release allowance. Invalid/wrong-origin traffic is not
  a qualifying comparand. Source/lifecycle uncertainty independently holds work.
- `checkpointEligible(ctx, generation, checkpoint) -> EligibilityFact`: serial
  checks before connection, consumer, and final public release. Late conflict
  stops further work at the next enforceable checkpoint and attempts owned
  cleanup; callbacks already in flight may complete. Preserve actual prior GET,
  bytes, consumer and disclosure facts; never replace them with zero.
- `createSnapshot(generation, actualReceivedBuffer, acquisitionRecord, ctx) ->
  SnapshotHandle`: complete entity ended/EOF evidence, exact authenticated count
  and x, immutable copy and same generation; one assignment only.
- `readSnapshot(generation, snapshot, ctx) -> PrivateSnapshotView`: same private
  registry/context/generation, one consumer use, count/x/D agreement again. No
  reopening URL, fixture-buffer substitution or foreign context handle.
- `retainPrivateConsumer(ctx, generation, nativeFact) -> PrivateResultHandle`:
  bind actual native attempt journal, snapshot, engine result/bytes and cleanup.
  Private verified bytes do not populate shareable `originalHex` yet.
- `closeoutAndPublish(ctx, generation, privateResult, closeoutRecord) ->
  CompositionObservation`: process every declared post-seal step/checkpoint,
  close owned relay/metadata/transport/browser resources, verify current inputs
  and source integrity, then one serial final eligibility check/publication with
  no intervening awaited work. This final source-local publication is not a disk
  durability/transaction guarantee. Before success and on HOLD/UNQUALIFIED publish
  `originalHex:null, originalReleased:false`. All results retain
  `receiptsEmitted:false, businessEffects:0`.

WeakMaps in this **same new protocol module instance** own every private handle.
Do not import the old protocol alongside the new consumer or use import-query
tricks to reset state. A fresh admitted process isolates each new window.

## Acquisition/consumer worker interfaces

Future exclusive files: `acquisition.mjs`, `consumer.mjs`. Rebind both to the new
protocol module after its interface is frozen; an external wrapper cannot mint
the old private WeakMap handles. Preserve all other workers' files.

- `acquireSnapshot(ctx, generation, attempt) -> AcquisitionFact`: acquire only
  under an already retained reservation; retain fixed destination/peer/TLS/HTTP,
  parser/header/stream/body/time bounds and owned cleanup. No direct caller URL,
  environment proxy, alternate origin, redirect/reacquisition or prepared buffer.
  The resulting snapshot contains only the actual complete received entity.
- `consumeOriginal(generation, snapshot, ctx) -> PrivateNativeConsumerFact`:
  preserve the existing NodeEVP or ChromeWebCrypto mapping, private snapshot use,
  journal-before-native-call, raw native errors, exact original count/ox/hash and
  owned browser/server cleanup. Recheck eligibility before the native API and
  retain actual attempts even when later invalidated. Consumer output is private
  evidence, not public composition success.

## Protected derivative boundaries

Accepted N12 is immutable. Reference pins are in `contract.json.sourceLineage`.
The shared `experiments/shared/attachment-crypto.mjs` stays byte-identical.
The exact 2937-byte classifier SHA256
`c6a5135c877f2cb041b4c7ac515795826097f6ba520e00e89bffa2ca3a5b5840`
stays byte-identical, with both auth-null branches and unknown native rethrow.
Do not change native AES/GCM/profile construction or add a Rust AES dependency.

For acquisition, preserve the algorithms/limits in `Refusal`, `errorFact`,
`rememberError`, `parsedHeaders`, `ownedTransport` and its transport/cleanup
callbacks. `initialRecord`, `enforceProfile`, `responseFor`, `expectedRefusal` and
`main` require explicitly reviewed derivative rebinding: new case/profile IDs,
new schedule/record grammar, received metadata handles, reservation/checkpoints,
and final public withholding. Do not copy H01-H14 dispatch into I4 accidentally.
Transport protection does not mean every case-dispatch byte stays unchanged;
freeze exact permitted deltas and mechanically review the remaining functions.

For consumer, preserve `pinnedCrypto`, `startBrowser`, `closeOwnedBrowser`,
native engine calls, classifier and raw error handling. `AttemptJournal` and its
counter validation need only reviewed case/component/private-public binding
changes; preserve bounded durable attempt-before-call capture semantics. The
`consumeOriginal` wrapper/imports need the same new protocol instance and private
fact publication. Any broader change triggers fresh independent source review.

For relay, preserve strict parsing/span extraction, whole EVENT comparison,
ACK/EVENT/EOSE/close state transitions and finite limits; rebind selection/job
closure explicitly. Keep unchanged existing metadata JS/Rust implementations.

## Dependency order and gates

1. Independently review these six planning files. Inventory complete inputs and
   unresolved full oracles; no worker receives implementation permission here.
2. Coordinator separately assigns bounded source work. Freeze private frame,
   receive/native/protocol/result schemas and protected-delta map first.
3. Relay and acquisition/consumer work may proceed on their disjoint files only
   against frozen interfaces; protocol/controller integrates sequentially. No
   worker edits another owner's files, shared state, accepted sources or Git.
4. Independent QA/security review complete derivative closure and protected
   deltas. All RC01-RC14 controls need meaningful qualified evidence before any
   runtime, even for I4. Missing genuine F2/auth fixture cannot be turned into a
   claimed target regression; distinguish pure policy controls from actual native
   cryptographic/relay composition traces and retain LAB-N gates.
5. Separately prepare/qualify any missing fixtures/oracles; freeze a chosen lane,
   exact step denominator and current config/closure/certificates/output lifecycle.
   Obtain fresh control acceptance, positive admission and separate primary then
   independent QA releases. HTTPS/component/design releases do not release this.

I4 could establish only four positive composed traces. It does not establish
negative target guarantees, unseen-conflict freedom, persistent/global replay,
full E06, ordinary-client compatibility, business authority or SDK readiness.
