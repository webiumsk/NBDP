"""Pure, finite admission for the non-normative NETWORK_METADATA_ONLY harness."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
COMPONENT = 'NETWORK_METADATA_ONLY'
SELECTION_SHA = '8e67ab182f155a853a1a9c3f3149a0e31a5e582d018d7976777c786d7fe93c1f'
DATA_SHA = 'c38b885805d68b0679ab0f3c875108fd6b28b57ee5e7a92bbc837a6b47146508'

class Refusal(ValueError):
    pass

def need(condition, reason):
    if not condition:
        raise Refusal(reason)

def closed(value, keys, reason='CLOSED_KEYS'):
    need(type(value) is dict and set(value) == set(keys), reason)
    return value

def pairs(items):
    result = {}
    for key, value in items:
        need(key not in result, 'DUPLICATE_JSON_KEY')
        result[key] = value
    return result

def loads(raw):
    need(type(raw) is bytes and len(raw) <= 16777216, 'JSON_BOUND')
    value = json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(Refusal('NONFINITE')))
    pending = [value]
    while pending:
        child = pending.pop()
        if type(child) is str:
            need(not any(0xD800 <= ord(c) <= 0xDFFF for c in child), 'UNICODE_SCALAR')
        elif type(child) in (int, float):
            need(type(child) is int and abs(child) <= 9007199254740991, 'SAFE_INTEGER')
        elif type(child) is dict:
            pending.extend(child.keys()); pending.extend(child.values())
        elif type(child) is list:
            pending.extend(child)
    return value

def typed_equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return set(a) == set(b) and all(typed_equal(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(typed_equal(x, y) for x, y in zip(a, b))
    return a == b

def descriptor(path):
    p = Path(path)
    need(p.is_absolute() and p.resolve(strict=True) == p and p.is_file(), 'RESOLVED_REGULAR_FILE')
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def checked(d):
    closed(d, ('path', 'bytes', 'sha256'))
    need(type(d['bytes']) is int and d['bytes'] >= 0 and type(d['sha256']) is str
         and re.fullmatch('[0-9a-f]{64}', d['sha256']), 'DESCRIPTOR')
    need(descriptor(d['path']) == d, 'PIN_MISMATCH:' + str(d['path']))
    return Path(d['path']).read_bytes()

def document(d):
    return loads(checked(d))

def check_map(pins):
    need(type(pins) is dict and pins, 'PIN_MAP')
    for path, value in pins.items():
        closed(value, ('bytes', 'sha256'))
        checked({'path': path, **value})

def merge(*maps):
    result = {}
    for pins in maps:
        for path, value in pins.items():
            need(path not in result or result[path] == value, 'PIN_CONFLICT')
            result[path] = value
    return result

def as_map(descriptors):
    return {d['path']: {k: d[k] for k in ('bytes', 'sha256')} for d in descriptors}

def current_sources(contract):
    return as_map([descriptor(HERE / name) for name in contract['sources']] + [descriptor(HERE / 'source-contract.json')])

def review(d, subjects, role, decision):
    value = document(d)
    closed(value, ('schema', 'session', 'role', 'decision', 'subjects', 'findings'))
    need(value['schema'] == 'e06-relay-metadata-source-review-v1' and value['role'] == role
         and value['decision'] == decision and value['findings'] == []
         and typed_equal(value['subjects'], subjects) and type(value['session']) is str
         and value['session'].startswith('/root/') and value['session'] != '/root/recovery_fixture_parent', 'INDEPENDENT_REVIEW')
    return value['session']

def validate_selection(s):
    need(s['schema'] == 'e06-relay-metadata-selection-v1' and s['component'] == COMPONENT
         and s['state'] == 'NOT_EXECUTED' and s['executionReleased'] is False, 'DATA_SCOPE')
    expected_routes = [('S1','strfry','JS','RUST','incoming',2), ('S2','strfry','JS','RUST','archive',1),
                       ('S3','strfry','RUST','JS','incoming',1), ('S4','strfry','RUST','JS','archive',1),
                       ('R1','rs-relay','RUST','JS','incoming',2), ('R2','rs-relay','RUST','JS','archive',1),
                       ('R3','rs-relay','JS','RUST','incoming',1), ('R4','rs-relay','JS','RUST','archive',1)]
    need(len(s['routes']) == 8 and len(s['historicalProofs']) == 32, 'DATA_COUNTS')
    proof_ids = {p['id'] for p in s['historicalProofs']}
    need(len(proof_ids) == 32, 'DUPLICATE_PROOF')
    for r, expected in zip(s['routes'], expected_routes):
        need((r['id'],r['relay'],r['producer'],r['consumer'],r['role'],len(r['steps'])) == expected, 'ROUTE_ROLE')
        stdin = checked(r['sourceStdin']).splitlines(keepends=True)
        original_expected = document(r['sourceExpected'])
        for st in r['steps']:
            raw = bytes.fromhex(st['rawLine']['hex'])
            need(len(raw) == st['rawLine']['bytes'] and hashlib.sha256(raw).hexdigest() == st['rawLine']['sha256']
                 and raw.endswith(b'\n') and raw == stdin[st['sourceLineIndex']], 'SOURCE_LINE')
            req = loads(raw)
            need(set(req) == {'op','secretHex','config','dWireHex','fWireHex'}
                 and req['secretHex'] == r['scope']['publicSyntheticSecretHex']
                 and typed_equal(req['config'], r['scope']['config']), 'TEMPLATE_SCOPE')
            expected_value = document(st['expected'])
            need(len(expected_value) == 13 and typed_equal(expected_value, original_expected[st['sourceExpectedArrayIndex']]), 'WHOLE_PROJECTION')
            for slot, pid in st['validationProofIds'].items():
                need(pid is None or pid in proof_ids, 'PROOF_ID')
    full_proofs=document(s['anchors']['proofs'])['proofs']
    for p in s['historicalProofs']:
        v = p['value']
        need(typed_equal(v,full_proofs[p['sourceProofIndex']]),'WHOLE_HISTORICAL_PROOF')
        need(v['matched'] is True and v['authenticatedPrefix'] == 'FULL' and v['fullChainSuccess'] is True, 'PROOF_PREFIX')
        need(typed_equal(document(v['rawReply']), document(p['sourceCall']['reply'])), 'RAW_PROOF_REPLY')

def external_document(path, sha):
    d=descriptor(path)
    need(d['sha256']==sha,'EXTERNAL_SHA')
    return d,document(d)

def verify(manifest_path, manifest_sha, release_path, release_sha):
    """Read-only; no imports, process creation, sockets, or output creation."""
    md,m = external_document(manifest_path,manifest_sha)
    rd,_ = external_document(release_path,release_sha)
    closed(m, ('schema','component','contract','selection','dataAcceptance','tools','imports','sourceReviews','output','runId'))
    need(m['schema'] == 'e06-relay-metadata-manifest-v1' and m['component'] == COMPONENT, 'MANIFEST_SCOPE')
    need(m['contract']['path'] == str(HERE/'source-contract.json'), 'CONTRACT_PATH')
    c = document(m['contract'])
    need(c['schema'] == 'e06-relay-metadata-source-contract-v1' and c['component'] == COMPONENT, 'CONTRACT_SCOPE')
    need(m['selection'] == c['selection'] and m['selection']['sha256'] == SELECTION_SHA, 'SELECTION_PIN')
    need(m['dataAcceptance'] == c['dataAcceptance'] and m['dataAcceptance']['sha256'] == DATA_SHA, 'DATA_ACCEPTANCE_PIN')
    s = document(m['selection']); a = document(m['dataAcceptance'])
    need(a['decision'] == 'ACCEPT_RELAY_METADATA_DATA_ONLY' and a['state'] == 'DATA_ACCEPTED_NOT_EXECUTED'
         and a['selection'] == m['selection'], 'ACCEPTED_DATA')
    for role in ('qa','security'):
        dr = document(a['reviews'][role]['report'])
        need(dr['decision'] == 'ACCEPT_RELAY_METADATA_DATA_ONLY' and dr['findings'] == []
             and dr['subjects']['selection'] == m['selection'] and dr['subjects']['readme'] == a['readme'], 'DATA_REVIEW')
    need(typed_equal(m['tools'], c['tools']) and typed_equal(m['imports'], c['imports']), 'FIXED_TOOLS_IMPORTS')
    need(m['tools']['python']['path'] == str(Path(sys.executable).resolve()), 'INTERPRETER')
    sources = current_sources(c)
    closed(m['sourceReviews'], ('qa','security'))
    sessions = [review(m['sourceReviews'][role], sources, role, 'ACCEPT_RELAY_METADATA_SOURCE_ONLY') for role in ('qa','security')]
    need(len(set(sessions)) == 2, 'SEPARATE_REVIEW_SESSIONS')
    pins = merge(c['inputPins'], c['imports'], as_map(c['tools'].values()), sources,
                 as_map([md,rd,*m['sourceReviews'].values()]))
    check_map(pins); validate_selection(s)
    for experiment, expected_status in (('E01','PASS'),('E02','PARTIAL'),('E05','PASS')):
        evidence=json.loads(checked(c['prerequisites'][experiment]),object_pairs_hook=pairs)
        need(evidence['experiment']==experiment and evidence['status']==expected_status
             and evidence['exit_status']==0,'CANONICAL_PREREQUISITE_STATUS')
    r = document(rd)
    closed(r, ('schema','component','decision','manifest','sourceReviews','controls','rootSession'))
    need(r['schema'] == 'e06-relay-metadata-release-v1' and r['component'] == COMPONENT
         and r['decision'] == 'RELEASE_NETWORK_METADATA_ONLY' and r['manifest'] == md
         and r['sourceReviews'] == m['sourceReviews'] and r['rootSession'] == '/root', 'ROOT_RELEASE')
    q = document(r['controls'])
    closed(q, ('schema','component','decision','subjects','controls','runs','reviews'))
    need(q['schema'] == 'e06-relay-metadata-control-qualification-v1' and q['component'] == COMPONENT
         and q['decision'] == 'ACCEPT_PURE_CONTROLS_ONLY' and q['subjects'] == sources
         and set(q['controls']) == set(c['guardIds']) and all(x is True for x in q['controls'].values()), 'PURE_CONTROL_QUALIFICATION')
    closed(q['reviews'], ('qa','security'))
    closed(q['runs'],('python','node'))
    control_pins={}
    for backend in ('python','node'):
        call=document(q['runs'][backend])
        closed(call,('argv','environment','exit','reaped','forced','stdoutEOF','stderrEOF','stdout','stderr'))
        expected_argv=([c['tools']['python']['path'],'-I','-B',str(HERE/'controls.py')] if backend=='python' else [c['tools']['node']['path'],str(HERE/'wire_controls.mjs')])
        need(call['argv']==expected_argv and call['environment']==c['environment']
             and call['exit']==0 and call['reaped'] is True and call['forced'] is False
             and call['stdoutEOF'] is True and call['stderrEOF'] is True and checked(call['stderr'])==b'','ACTUAL_CONTROL_CALL')
        raw=checked(call['stdout']);need(raw.endswith(b'\n') and raw.count(b'\n')==1,'CONTROL_JSONL')
        result=loads(raw)
        need(result['qualified'] is True and result['scope']=='PURE_HELPER_ONLY'
             and all(row['qualified'] is True for row in result['rows']),'ACTUAL_CONTROL_RESULT')
        if backend=='python':need(result['subjects']==sources and set(c['guardIds'])<=set(row['id'] for row in result['rows']),'PARENT_CONTROL_IDS')
        else:need(len(result['rows'])==35 and len({row['id'] for row in result['rows']})==35,'WIRE_CONTROL_IDS')
        control_pins=merge(control_pins,as_map([q['runs'][backend],call['stdout'],call['stderr']]))
    control_subjects={'sources':sources,'runs':q['runs']}
    sessions2 = [review(q['reviews'][role], control_subjects, role, 'ACCEPT_RELAY_METADATA_CONTROLS_ONLY') for role in ('qa','security')]
    need(len(set(sessions2)) == 2, 'SEPARATE_CONTROL_REVIEW')
    pins = merge(pins,control_pins,as_map([r['controls'], *q['reviews'].values()]))
    check_map(pins)
    need(type(m['runId']) is str and re.fullmatch('[a-z0-9-]{1,32}',m['runId']), 'RUN_ID')
    output = Path(m['output'])
    need(output.is_absolute() and output.parent.resolve(strict=True) == output.parent
         and not output.exists() and not output.is_symlink() and ',' not in str(output), 'FRESH_OUTPUT')
    return {'manifest':m,'contract':c,'selection':s,'pins':pins,'manifestDescriptor':md,'releaseDescriptor':rd}

if __name__ == '__main__':
    try:
        need(len(sys.argv)==5,'CLI: admission.py MANIFEST SHA RELEASE SHA')
        result=verify(*sys.argv[1:])
        print(json.dumps({'component':COMPONENT,'admitted':True,'workloadStarted':False,'inputPins':len(result['pins'])}))
    except BaseException as exc:
        sys.stderr.write(type(exc).__name__+': '+str(exc)+'\n');sys.exit(1)
