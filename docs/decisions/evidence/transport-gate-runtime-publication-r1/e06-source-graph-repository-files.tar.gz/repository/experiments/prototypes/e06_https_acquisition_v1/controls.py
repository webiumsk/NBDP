"""Focused pure guards. Execution requires a later concrete control release."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
HERE=Path(__file__).resolve().parent

def put(path,value):
    raw=value if type(value) is bytes else (json.dumps(value,separators=(',',':'))+'\n').encode()
    with path.open('xb') as handle:handle.write(raw)

def main(argv):
    if len(argv)!=3:raise ValueError('CLI: controls.py MANIFEST SHA FRESH_OUTPUT')
    raw=Path(argv[0]).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=argv[1]:raise ValueError('MANIFEST_SHA')
    m=json.loads(raw);p=HERE/'admission.py';b=p.read_bytes()
    if m.get('sourcePins',{}).get(str(p))!={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}:raise ValueError('GATE_PIN')
    spec=importlib.util.spec_from_file_location('_https_controls_gate',p);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
    ctx=a.verify_common(argv[0],argv[1]);c=ctx['contract'];rows=[];native_controls=[]
    a.need(re.fullmatch(c['controlEvidence']['controlOutputPattern'],argv[2]),'CONTROL_OWNED_OUTPUT')
    out=Path(argv[2]);out.mkdir(mode=0o700,exist_ok=False)
    def control(ident,callback,refuse=True):
        try:callback();rejected=False
        except (a.Refusal,ValueError,UnicodeError):rejected=True
        if rejected is not refuse:raise ValueError('CONTROL_FAILED:'+ident)
        rows.append({'id':ident,'matched':True,'kind':'PURE_PREDICATE_NO_WORKLOAD'})
    def refusal(callback):
        try:callback()
        except (a.Refusal,ValueError,UnicodeError):return
        raise RuntimeError('EXPECTED_PURE_REFUSAL')
    def altered(key,value):
        changed=copy.deepcopy(m);changed[key]=value;a.validate_manifest(changed,c)
    control('HG01',lambda:a.validate_manifest(m,c),False)
    control('HG02',lambda:altered('sourcePins',{}))
    badtools=copy.deepcopy(m['tools']);badtools['node']['sha256']='0'*64
    control('HG03',lambda:altered('tools',badtools))
    control('HG04',lambda:altered('phase','UNREVIEWED'))
    control('HG05',lambda:altered('output','/tmp/outside-fixed-namespace'))
    def prerequisites():
        refusal(lambda:altered('prerequisites',{}))
        wrong_pins=copy.deepcopy(m['prerequisites']);wrong_pins['relayMetadata']['sha256']='0'*64
        refusal(lambda:altered('prerequisites',wrong_pins))
        for name,binding in c['prerequisites'].items():
            value=a.loads(a.checked(binding['descriptor']),historical_native=True)
            a.prerequisite_native(name,value,c)
            for field in binding['nativeFields']:
                wrong=copy.deepcopy(value);wrong[field]=None
                refusal(lambda:a.prerequisite_native(name,wrong,c))
        a.need(a.loads(b'{"elapsed":1.25}',historical_native=True)['elapsed']==1.25,'HISTORICAL_FRACTION')
        for raw in [b'{"x":NaN}',b'{"x":1,"\\u0078":2}',b'{"x":9007199254740992}']:
            refusal(lambda:a.loads(raw,historical_native=True))
    control('HG06',prerequisites,False)
    control('HG07',lambda:a.loads(b'{"x":1,"\\u0078":2}'))
    control('HG08',lambda:a.loads(b'{"x":9007199254740992}'))
    control('HG09',lambda:a.loads(b'{"x":"\\ud800"}'))
    def certificate_bindings():
        a.need(not a.equal({'count':True},{'count':1}),'TYPE_IS_NOT_INTEGER')
        spec=c['tlsFixtureBinding'];root=spec['root']
        calls=[{'ordinal':i,'argv':op['argv'],'cwd':root,
                'stdin':{'path':root+'/stdin.bin','bytes':0,'sha256':hashlib.sha256(b'').hexdigest()},
                'stdout':{'path':root+'/'+op['id']+'.stdout'},'stderr':{'path':root+'/'+op['id']+'.stderr'},
                'lifecycle':{}} for i,op in enumerate(spec['operations'])]
        outputs={'ca':{'path':spec['outputPaths']['ca']},'server':{k:{'path':v} for k,v in spec['outputPaths']['server'].items()},
                 'wrongSan':{k:{'path':v} for k,v in spec['outputPaths']['wrongSan'].items()}}
        structural={'sourcePins':spec['sourcePins'],'toolClosure':spec['toolClosure'],'authors':spec['authors'],'calls':calls,'outputs':outputs}
        a.certificate_stage_binding(structural,c)
        variants=[]
        wrong=copy.deepcopy(structural);wrong['calls'][0]['argv'][0]='/wrong/openssl';variants.append(wrong)
        wrong=copy.deepcopy(structural);wrong['calls'][9]['argv']=wrong['calls'][8]['argv'];variants.append(wrong)
        wrong=copy.deepcopy(structural);wrong['calls'][9]['cwd']='/tmp/wrong';variants.append(wrong)
        wrong=copy.deepcopy(structural);wrong['outputs']['wrongSan']['cert']['path']=wrong['outputs']['server']['cert']['path'];variants.append(wrong)
        wrong=copy.deepcopy(structural);wrong['toolClosure']={};variants.append(wrong)
        wrong=copy.deepcopy(structural);wrong['calls'].pop();variants.append(wrong)
        for wrong in variants:refusal(lambda:a.certificate_stage_binding(wrong,c))
        a.certificate_native_output(9,(root+'/wrong-host.cert.pem: OK\n').encode(),b'',c)
        refusal(lambda:a.certificate_native_output(9,(root+'/server.cert.pem: OK\n').encode(),b'',c))
        mismatch=('CN = wrong.files.invalid\nerror 62 at 0 depth lookup: hostname mismatch\nerror '+root+'/wrong-host.cert.pem: verification failed\n').encode()
        a.certificate_native_output(10,b'',mismatch,c)
        refusal(lambda:a.certificate_native_output(10,b'',b'unrelated hostname mismatch\n',c))
    control('HG10',certificate_bindings,False)
    def author_exclusion():
        for session in c['excludedAuthors']:a.need(not a.non_author(session,c),'AUTHOR_ALLOWED')
        a.need(a.non_author('/root/independent_https_qa',c),'INDEPENDENT_REVIEWER_REJECTED')
    control('HG11',author_exclusion,False)
    def source_subject_drift():
        pack=a.document(m['sourceReviews']);pack['subjects']={};a.reviews(pack,m['sourcePins'],c,'ACCEPT_CURRENT_SOURCES_ONLY')
    control('HG12',source_subject_drift)
    def qualification_boundaries():
        source=a.document(m['sourceReviews'])
        replay={'schema':c['qualificationSchema']['schema'],'decision':'ACCEPT_PURE_GUARDS_ONLY',
                'subjects':{'sourcePins':m['sourcePins'],'actualControlEvidence':ctx['manifestDescriptor']},
                'guards':c['guardIds'],'reviews':source['reviews']}
        refusal(lambda:a.qualification(replay,m['sourcePins'],c))
        cap={'schema':c['controlEvidence']['captureSchema'],'subjects':m['sourcePins'],
             'rows':[{'id':ident,'matched':True,'kind':'PURE_PREDICATE_NO_WORKLOAD'} for ident in c['guardIds']],
             'nativeControls':[ctx['manifestDescriptor']],'qualified':True,'limitations':['PURE_MEMORY_CALIBRATION_ONLY']}
        a.control_capture_shape(cap,m['sourcePins'],c)
        for key,value in [('rows',cap['rows'][:-1]),('nativeControls',[]),('subjects',{})]:
            wrong=copy.deepcopy(cap);wrong[key]=value;refusal(lambda:a.control_capture_shape(wrong,m['sourcePins'],c))
        wrong=copy.deepcopy(cap);wrong['rows'][0]['matched']=False
        refusal(lambda:a.control_capture_shape(wrong,m['sourcePins'],c))
        wrong_pin=dict(ctx['manifestDescriptor'],sha256='0'*64);refusal(lambda:a.document(wrong_pin))
        refusal(lambda:a.control_evidence({'schema':c['controlEvidence']['schema']},m['sourcePins'],c))
    control('HG13',qualification_boundaries,False)
    def node_private_boundaries():
        tool=c['tools']['node'];a.need(a.equal(a.descriptor(tool['path']),tool),'CONTROL_NODE_PIN')
        stdin=out/'HG14.stdin.bin';stdout=out/'HG14.stdout.bin';stderr=out/'HG14.stderr.bin';put(stdin,b'')
        command=[tool['path'],'--input-type=module','--eval',c['nodeControlCode']]
        life={'launchAttempt':True,'acquisition':'UNKNOWN','pid':None,'exitCode':None,'signal':None,
              'reaped':False,'stdoutEOF':False,'stderrEOF':False,'forced':False,'timedOut':False,'error':None}
        child=None;raw_out=b'';raw_err=b''
        try:
            child=subprocess.Popen(command,cwd=out,env=c['profileEnvironment'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            life['acquisition']='ACQUIRED';life['pid']=child.pid
            try:raw_out,raw_err=child.communicate(timeout=15)
            except subprocess.TimeoutExpired:
                life['timedOut']=True;life['forced']=True;child.kill();raw_out,raw_err=child.communicate(timeout=5)
            life['exitCode']=child.returncode if child.returncode>=0 else None
            life['signal']=-child.returncode if child.returncode<0 else None
            life['reaped']=True;life['stdoutEOF']=True;life['stderrEOF']=True
        except BaseException as exc:
            life['error']={'name':type(exc).__name__,'message':str(exc)}
            if child is not None and child.poll() is None:
                life['forced']=True
                try:child.kill();raw_out,raw_err=child.communicate(timeout=5);life['reaped']=True
                except BaseException:pass
        put(stdout,raw_out[:65536]);put(stderr,raw_err[:65536])
        receipt={'schema':c['controlEvidence']['nodeReceiptSchema'],'tool':tool,'argv':command,'cwd':str(out),
                 'environment':c['profileEnvironment'],'stdin':a.descriptor(stdin),'stdout':a.descriptor(stdout),
                 'stderr':a.descriptor(stderr),'lifecycle':life}
        rd=out/'HG14.receipt.json';put(rd,receipt);native_controls.append(a.descriptor(rd))
        a.natural_zero(life)
        for field in ('stdoutEOF','stderrEOF','reaped'):
            wrong=copy.deepcopy(life);wrong[field]=False;refusal(lambda:a.natural_zero(wrong))
        wrong=copy.deepcopy(life);wrong['forced']=True;refusal(lambda:a.natural_zero(wrong))
        a.need(raw_out.hex()==c['controlEvidence']['nodeStdoutHex'] and raw_err==b'','NODE_PRIVATE_BOUNDARIES')
    control('HG14',node_private_boundaries,False)
    a.need([r['id'] for r in rows]==c['guardIds'],'FIXED_GUARD_SET');a.check_map(m['sourcePins'])
    result={'schema':c['controlEvidence']['captureSchema'],'subjects':m['sourcePins'],'rows':rows,
            'nativeControls':native_controls,'qualified':True,
            'limitations':['Pure in-memory predicate calibrations plus one fixed Node interpreter; no target/API/socket/browser or OS fault evidence.',
                           'Not runtime authority. Separate actual outer receipt/raw streams and CONTROL-only independent reviews required.']}
    put(out/'capture.json',result);print(json.dumps(a.descriptor(out/'capture.json')))
    return 0

if __name__=='__main__':
    try:result=main(sys.argv[1:])
    except BaseException as exc:print(type(exc).__name__+': '+str(exc),file=sys.stderr);result=1
    raise SystemExit(result)
