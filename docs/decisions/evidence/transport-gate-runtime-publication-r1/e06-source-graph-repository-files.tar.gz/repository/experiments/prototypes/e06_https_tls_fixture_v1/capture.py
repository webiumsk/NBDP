"""Fixed195s TLS preparation outer capture. SOURCE ONLY / NOT_EXECUTED.

Owned-leader guard derives from accepted B/capture_execution.py cleanup_owned
(6557B/d03bed5fdd1496cbdbde4deb9605768af1bb5cddd6e7d8cea86a657bfe90eeac).
WNOWAIT keeps the leader owned until all possible group cleanup has finished.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import selectors
import subprocess
import sys
import time

HERE = Path(__file__).absolute().parent
OUTER = Path('/tmp/nbdp-e06-https-tls-outer-r2')
MAX = 65536


def load_helpers(release_path, release_sha):
    # Pin the inert helper source before executing its module definitions. The
    # helper then verifies the complete release/reviews/current tool/source map.
    if not Path(release_path).is_absolute() or len(release_sha) != 64:
        raise ValueError('ABSOLUTE_EXTERNAL_RELEASE_REQUIRED')
    raw = Path(release_path).read_bytes()
    if len(raw) > MAX or hashlib.sha256(raw).hexdigest() != release_sha:
        raise ValueError('EXTERNAL_RELEASE_PIN')
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError('DUPLICATE_JSON_KEY')
            value[key] = item
        return value
    release = json.loads(raw, object_pairs_hook=pairs)
    helper = HERE / 'prepare.py'
    pin = release['sourcePins'][str(helper)]
    source = helper.read_bytes()
    if helper.resolve() != helper or pin != {'bytes': len(source), 'sha256': hashlib.sha256(source).hexdigest()}:
        raise ValueError('INERT_HELPER_PIN')
    spec = importlib.util.spec_from_file_location('e06_tls_private_prepare', helper)
    module = importlib.util.module_from_spec(spec)
    # Execute precisely the pinned source bytes, never an ambient .pyc cache.
    exec(compile(source, str(helper), 'exec'), module.__dict__)
    return module


def main():
    if len(sys.argv) != 3:
        raise ValueError('CLI_ABSOLUTE_RELEASE_AND_SHA')
    started = time.monotonic()
    helper = load_helpers(*sys.argv[1:])
    release, release_d, recipe = helper.admit(*sys.argv[1:])
    helper.need(not os.path.lexists(helper.ROOT), 'FRESH_TLS_OUTPUT_REQUIRED')
    helper.need(recipe['outer'] == {'output': str(OUTER), 'wholeSeconds': 195, 'workSeconds': 190,
        'cleanupSeconds': 5, 'stdoutBytes': MAX, 'stderrBytes': MAX, 'fileBytes': MAX,
        'packBytes': 196608}, 'FIXED_OUTER_CONFIGURATION')
    os.umask(0o077)
    OUTER.mkdir(mode=0o700)  # Atomic fresh ownership; no reuse/overwrite.
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX, MAX))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    stdin_d = helper.write_new(OUTER / 'stdin.bin', b'')
    argv = [recipe['python']['path'], '-I', '-S', '-B', str(HERE / 'prepare.py'), *sys.argv[1:]]
    life = {'launchAttempted': False, 'acquisition': 'NOT_ATTEMPTED', 'pid': None,
        'exitCode': None, 'signal': None, 'reaped': False, 'stdoutEOF': False, 'stderrEOF': False,
        'leaderExitObserved': False, 'ownershipRetainedUntilReap': False,
        'forced': False, 'forceAttempted': False, 'timedOut': False, 'streamOverflow': False,
        'stdoutObservedBytes': 0, 'stderrObservedBytes': 0, 'cleanupErrors': []}
    receipt = {'schema': 'e06-isolated-tls-outer-capture-v1', 'qualified': False,
        'release': release_d, 'argv': argv, 'cwd': str(OUTER), 'environment': recipe['environment'],
        'stdin': stdin_d, 'stdout': None, 'stderr': None, 'lifecycle': life,
        'startedUTC': helper.utc_now(), 'finishedUTC': None, 'elapsedSeconds': None,
        'error': None, 'finalPinsUnchanged': False, 'outerTerminationUncertain': True,
        'limitations': 'DIRECT_CHILD_OBSERVATION_ONLY_NO_DESCENDANT_CONTAINMENT_CLAIM'}
    child, selector, handles = None, selectors.DefaultSelector(), {}
    ownership, forced_at = {'confirmed': False}, None
    retained = {'stdout': 0, 'stderr': 0}
    work_deadline, absolute_deadline = started + 190, started + 195

    def force_once():
        nonlocal forced_at
        if forced_at is None:
            forced_at = time.monotonic()
            state = helper.signal_owned(child, ownership)
            life['forced'], life['forceAttempted'] = state['forced'], state['terminationAttempted']
            life['cleanupErrors'].extend(state['cleanupErrors'])

    def drain_once():
        for key, _ in selector.select(0.025):
            name = key.data
            try:
                chunk = os.read(key.fileobj.fileno(), MAX)
            except BlockingIOError:
                continue
            if not chunk:
                life[name + 'EOF'] = True
                selector.unregister(key.fileobj)
                key.fileobj.close()
                continue
            life[name + 'ObservedBytes'] += len(chunk)
            view = memoryview(chunk[:max(0, MAX - retained[name])])
            while view:
                count = os.write(handles[name], view)
                helper.need(count > 0, 'OUTER_STREAM_SHORT_WRITE')
                view = view[count:]
                retained[name] += count
            if life[name + 'ObservedBytes'] > MAX:
                life['streamOverflow'] = True

    def observe():
        life['leaderExitObserved'] = helper.observe_owned_exit(child, ownership)

    try:
        for name in retained:
            handles[name] = os.open(OUTER / (name + '.bin'), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        helper.need(time.monotonic() < work_deadline, 'OUTER_DEADLINE_BEFORE_LAUNCH')
        with open(OUTER / 'stdin.bin', 'rb', buffering=0) as stdin:
            life['launchAttempted'], life['acquisition'] = True, 'UNKNOWN'
            child = subprocess.Popen(argv, env=recipe['environment'], cwd=OUTER, stdin=stdin,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                close_fds=True, shell=False, bufsize=0)
        life['pid'], life['acquisition'], ownership['confirmed'] = child.pid, 'ACQUIRED', True
        for name in retained:
            pipe = getattr(child, name)
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, name)
        while True:
            observe()  # Exit observation cannot reap/release PID ownership.
            if life['leaderExitObserved'] and not selector.get_map():
                break
            if time.monotonic() >= work_deadline:
                life['timedOut'] = True
            if life['timedOut'] or life['streamOverflow']:
                force_once()
            if forced_at is not None and time.monotonic() >= min(forced_at + 5, absolute_deadline):
                raise TimeoutError('OUTER_EOF_OR_EXIT_UNCERTAIN')
            drain_once()
    except BaseException as error:
        receipt['error'] = {'name': type(error).__name__, 'message': str(error), 'errno': getattr(error, 'errno', None)}
    finally:
        if child is not None and child.returncode is None:
            try:
                if not (life['leaderExitObserved'] and not selector.get_map()):
                    force_once()
                    until = min(forced_at + 5, absolute_deadline)
                    while time.monotonic() < until:
                        observe()
                        if life['leaderExitObserved'] and not selector.get_map():
                            break
                        drain_once()
                if ownership['confirmed'] and life['leaderExitObserved']:
                    helper.reap_observed(child, ownership, life)
            except BaseException as error:
                life['cleanupErrors'].append(type(error).__name__ + ': ' + str(error))
        # Single final reap has ended all group operations. No numeric PGID probe.
        for key in list(selector.get_map().values()):
            key.fileobj.close()
        selector.close()
        for fd in handles.values():
            os.fsync(fd); os.close(fd)
        for name in retained:
            target = OUTER / (name + '.bin')
            if target.exists():
                receipt[name] = helper.descriptor(target)
        try:
            helper.verify_map(release['sourcePins']); helper.verify_map(release['toolClosure'])
            helper.checked(release_d, MAX); helper.checked(release['sourceReviews'], MAX)
            helper.checked(recipe['research'], MAX)
            receipt['finalPinsUnchanged'] = True
        except BaseException as error:
            life['cleanupErrors'].append('FINAL_PIN: ' + type(error).__name__ + ': ' + str(error))
        receipt['finishedUTC'], receipt['elapsedSeconds'] = helper.utc_now(), time.monotonic() - started
        clean = bool(life['acquisition'] == 'ACQUIRED' and life['leaderExitObserved'] and life['reaped'] and
            life['ownershipRetainedUntilReap'] and life['exitCode'] == 0 and life['signal'] is None and
            life['stdoutEOF'] and life['stderrEOF'] and not life['forceAttempted'] and not life['forced'] and
            not life['timedOut'] and not life['streamOverflow'] and not life['cleanupErrors'] and receipt['error'] is None)
        receipt['outerTerminationUncertain'] = not clean
        receipt['qualified'] = clean and receipt['finalPinsUnchanged'] and time.monotonic() <= absolute_deadline
        receipt_d = helper.write_new(OUTER / 'receipt.json', helper.encode(receipt))
        helper.need(sum(p.stat().st_size for p in OUTER.iterdir()) <= 196608, 'OUTER_PACK_BOUND')
        print(json.dumps({'qualified': receipt['qualified'], 'receipt': receipt_d}, separators=(',', ':')))
    return 0 if receipt['qualified'] else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except BaseException as error:
        if isinstance(error, SystemExit):
            raise
        sys.stderr.write(json.dumps({'name': type(error).__name__, 'message': str(error),
                                     'errno': getattr(error, 'errno', None)}) + '\n')
        sys.exit(1)
