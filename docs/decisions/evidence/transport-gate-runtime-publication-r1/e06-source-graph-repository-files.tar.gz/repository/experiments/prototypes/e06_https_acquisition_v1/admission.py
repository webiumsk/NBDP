"""Finite, pure admission. Import is inert; no target/process/network API here."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import math

HERE = Path(__file__).resolve().parent
COMPONENT = 'HTTPS_ACQUISITION_AND_ORIGINAL_RECOVERY_ONLY'

class Refusal(ValueError):
    pass

def need(ok, reason):
    if not ok:
        raise Refusal(reason)

def closed(value, keys):
    need(type(value) is dict and set(value) == set(keys), 'CLOSED_KEYS')
    return value

def pairs(items):
    out = {}
    for key, value in items:
        need(key not in out, 'DUPLICATE_KEY')
        out[key] = value
    return out

def loads(raw, historical_native=False):
    need(type(raw) is bytes and len(raw) <= 33554432, 'JSON_BOUND')
    value = json.loads(raw.decode('utf-8', 'strict'), object_pairs_hook=pairs,
                       parse_constant=lambda _: need(False, 'NONFINITE'))
    pending = [value]
    while pending:
        v = pending.pop()
        if type(v) is str:
            need(not any(0xD800 <= ord(c) <= 0xDFFF for c in v), 'UNICODE_SCALAR')
        elif type(v) in (float, int):
            need((type(v) is int and abs(v) <= 9007199254740991) or (historical_native and type(v) is float and math.isfinite(v) and (not v.is_integer() or abs(v)<=9007199254740991)), 'SAFE_INTEGER')
        elif type(v) is dict:
            pending.extend(v); pending.extend(v.values())
        elif type(v) is list:
            pending.extend(v)
    return value

def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return set(a) == set(b) and all(equal(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b

def descriptor(path):
    p = Path(path)
    need(p.is_absolute() and p.resolve(strict=True) == p and p.is_file(), 'CANONICAL_FILE')
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        while block:=f.read(1048576):h.update(block);size+=len(block)
    return dict(path=str(p), bytes=size, sha256=h.hexdigest())

def checked(d):
    closed(d, ('path', 'bytes', 'sha256'))
    need(type(d['bytes']) is int and d['bytes'] >= 0 and type(d['sha256']) is str
         and re.fullmatch('[0-9a-f]{64}', d['sha256']), 'DESCRIPTOR')
    need(equal(descriptor(d['path']), d), 'PIN_MISMATCH:' + str(d['path']))
    return Path(d['path']).read_bytes()

def document(d):
    return loads(checked(d))

def check_map(pins):
    need(type(pins) is dict and pins, 'SOURCE_MAP')
    for path, pin in pins.items():
        closed(pin, ('bytes', 'sha256')); need(equal(descriptor(path),dict(path=path,**pin)),'PIN_MISMATCH')

def non_author(session, contract):
    return type(session) is str and session not in contract['excludedAuthors']

def reviews(pack, subjects, contract, decision):
    closed(pack, ('schema', 'decision', 'subjects', 'reviews'))
    need(pack['schema'] == contract['sourceReviewSchema']['schema']
         and pack['decision'] == decision and equal(pack['subjects'], subjects), 'REVIEW_SUBJECT')
    rows = pack['reviews']
    need(type(rows) is list and len(rows) == 2, 'TWO_REVIEWS')
    need({r.get('role') for r in rows} == {'qa', 'security'}, 'REVIEW_ROLES')
    need(len({r.get('session') for r in rows}) == 2, 'INDEPENDENT_SESSIONS')
    for r in rows:
        closed(r, ('role', 'session', 'decision', 'subjects'))
        need(non_author(r['session'], contract) and r['decision'] == 'ACCEPT_SOURCE_ONLY'
             and equal(r['subjects'], subjects), 'AUTHOR_OR_REVIEW_SUBJECT')

def required_map(contract):
    pins = dict(contract['currentDependencies'])
    for d in [*contract['tools'].values(), contract['browserProfile'],
              *[r['descriptor'] for r in contract['prerequisites'].values()]]:
        pin = {k: d[k] for k in ('bytes', 'sha256')}
        need(d['path'] not in pins or equal(pins[d['path']], pin), 'CONFLICT_PIN')
        pins[d['path']] = pin
    for name in contract['plannedFiles']:
        d = descriptor(HERE / name); pins[d['path']] = {k:d[k] for k in ('bytes','sha256')}
    return pins

def validate_manifest(m, c):
    closed(m, c['runtimeManifestKeys'])
    need(m['schema'] == c['runtimeManifestSchema'] and m['component'] == COMPONENT,
         'MANIFEST_COMPONENT')
    need(m['phase'] in ('PREPARE', 'ACQUIRE') and m['label'] in ('primary', 'qa'), 'PHASE_LABEL')
    need(type(m['output']) is str and re.fullmatch('/tmp/e6https-(prepare|primary|qa)-[a-z0-9]{6,12}', m['output']), 'OWNED_OUTPUT')
    need(equal(m['tools'], c['tools']) and equal(m['sourcePins'], required_map(c)), 'CURRENT_MAP')
    need(equal(m['contract'], descriptor(HERE/'contract.json'))
         and equal(m['profile'], descriptor(HERE/'profile.json')), 'CONTRACT_PROFILE')
    need(equal(m['prerequisites'], {k:v['descriptor'] for k,v in c['prerequisites'].items()}), 'PREREQUISITES')
    closed(m['inputs'], c['privateFrame']['inputsByPhase'][m['phase']])
    need(m['controls'] == c['guardIds'], 'GUARD_SET')
    # Expected outputs are observer-only and never propagated to private child frames.
    if m['phase'] == 'ACQUIRE':
        expected = document(m['expected'])
        need(equal(expected, c['caseExpectations']), 'FROZEN_EXPECTATIONS')
    else:
        need(m['expected'] is None and equal(m['inputs']['recipes'], descriptor(HERE/'fixture-recipes.json')), 'PREPARE_INPUT')

def certificate_stage_binding(native,c):
    spec=c['tlsFixtureBinding'];root=spec['root']
    need(spec['sourcePins'] is not None and equal(native['sourcePins'],spec['sourcePins'])
         and equal(native['toolClosure'],spec['toolClosure']) and equal(native['authors'],spec['authors']),
         'EXACT_TLS_SOURCE_TOOL_BINDING')
    need(type(native['calls']) is list and len(native['calls'])==11,'CERT_ELEVEN_STAGES')
    empty=hashlib.sha256(b'').hexdigest()
    for i,(call,op) in enumerate(zip(native['calls'],spec['operations'])):
        closed(call,c['futureCertificateAcceptanceSchema']['callKeys'])
        need(type(call['ordinal']) is int and call['ordinal']==i and call['argv']==op['argv']
             and call['cwd']==root and call['stdin']=={'path':root+'/stdin.bin','bytes':0,'sha256':empty}
             and call['stdout']['path']==root+'/'+op['id']+'.stdout'
             and call['stderr']['path']==root+'/'+op['id']+'.stderr','EXACT_TLS_STAGE_ARGV_CWD_OPERANDS')
    outputs=native['outputs'];closed(outputs,('ca','server','wrongSan'))
    need(outputs['ca']['path']==spec['outputPaths']['ca'],'CA_OUTPUT_BINDING')
    for role in ('server','wrongSan'):
        closed(outputs[role],('key','cert'))
        need(all(outputs[role][k]['path']==spec['outputPaths'][role][k] for k in ('key','cert')),'LEAF_OUTPUT_BINDING')

def certificate_native_output(i,stdout,stderr,c):
    root=c['tlsFixtureBinding']['root']
    need(type(stdout) is bytes and type(stderr) is bytes and len(stdout)<=65536 and len(stderr)<=65536,'CERT_RAW_BOUND')
    if i in (8,9):
        target='server.cert.pem' if i==8 else 'wrong-host.cert.pem'
        need(stdout==(root+'/'+target+': OK\n').encode() and stderr==b'','EXACT_POSITIVE_HOST_VERIFY')
    if i in (5,6,7):need(stderr==b'','CERT_INSPECTION_STDERR')
    if i==10:
        lines=stderr.splitlines()
        need(stdout==b'' and len(lines)==3 and re.fullmatch(rb'CN\s*=\s*wrong\.files\.invalid',lines[0]) is not None
             and lines[1]==b'error 62 at 0 depth lookup: hostname mismatch'
             and lines[2]==('error '+root+'/wrong-host.cert.pem: verification failed').encode(),
             'SPECIFIC_NATIVE_HOSTNAME_REFUSAL')

def acquisition_inputs(m,c):
    fa=document(m['inputs']['fixtureAcceptance']);ca=document(m['inputs']['certificateAcceptance'])
    closed(fa,c['futureFixtureAcceptanceSchema']['keys']);closed(ca,c['futureCertificateAcceptanceSchema']['keys'])
    need(fa['schema']==c['futureFixtureAcceptanceSchema']['schema'] and fa['decision']=='ACCEPT_NEW_HTTPS_FIXTURES_ONLY'
         and ca['schema']==c['futureCertificateAcceptanceSchema']['schema'] and ca['decision']=='ACCEPT_ISOLATED_TEST_CERTIFICATES_ONLY','CURRENT_INPUT_ACCEPTANCE')
    need(equal(fa['recipes'],descriptor(HERE/'fixture-recipes.json')),'CURRENT_RECIPES')
    reviews(fa['reviews'],{'recipes':fa['recipes'],'catalogue':fa['catalogue']},c,'ACCEPT_CURRENT_SOURCES_ONLY')
    catalogue=document(fa['catalogue']);closed(catalogue,('schema','recipes','blob','families','calls','proofs','expected'))
    need(catalogue['schema']=='e06-https-fixture-catalogue-v1' and equal(catalogue['recipes'],fa['recipes'])
         and len(catalogue['families'])==2 and {r['id'] for r in catalogue['families']}=={'invoice','credit-note'},'FIXTURE_CATALOGUE')
    for d in [catalogue['blob'],catalogue['calls'],catalogue['proofs'],*catalogue['expected']]:checked(d)
    spec=c['futureCertificateAcceptanceSchema'];ev=ca['reviews'];closed(ev,spec['reviewsEnvelope']['keys'])
    need(ev['schema']==spec['reviewsEnvelope']['schema'],'CERT_EVIDENCE')
    native=document(ev['materialization']);closed(native,spec['materializationKeys'])
    need(native['schema']==spec['materializationSchema'] and native['qualified'] is True
         and equal(native['sourceReviews'],ev['sourceReviews'])
         and equal(native['outputs'],{k:ca[k] for k in ('ca','server','wrongSan')}),'CERT_MATERIALIZATION')
    need(type(native['authors']) is list and native['authors'] and all(type(x) is str for x in native['authors']) and len(set(native['authors']))==len(native['authors']),'CERT_AUTHORS')
    cert_review_contract=dict(c,excludedAuthors=c['excludedAuthors']+native['authors'])
    certificate_stage_binding(native,c)
    check_map(native['sourcePins']);check_map(native['toolClosure']);subjects=dict(native['sourcePins'])
    for p,pin in native['toolClosure'].items():
        need(p not in subjects or equal(subjects[p],pin),'CERT_CLOSURE_CONFLICT');subjects[p]=pin
    reviews(document(ev['sourceReviews']),subjects,cert_review_contract,'ACCEPT_CURRENT_SOURCES_ONLY')
    reviews(ev['acceptance'],{k:ca[k] for k in ('ca','server','wrongSan')}|{'materialization':ev['materialization'],'sourceReviews':ev['sourceReviews']},cert_review_contract,'ACCEPT_CURRENT_SOURCES_ONLY')
    need(type(native['calls']) is list and len(native['calls'])==11,'CERT_ELEVEN_STAGES')
    for i,call in enumerate(native['calls']):
        closed(call,spec['callKeys']);life=call['lifecycle']
        need(call['ordinal']==i and life['reaped'] is True and life['stdoutEOF'] is True
             and life['stderrEOF'] is True and life['forced'] is False and life['signal'] is None
             and type(life['exitCode']) is int and (life['exitCode']==0 if i<10 else life['exitCode']>0),'CERT_NATIVE_LIFECYCLE')
        for k in ('stdin','stdout','stderr'):
            if call[k] is not None:checked(call[k])
        certificate_native_output(i,checked(call['stdout']),checked(call['stderr']),c)
        need(life.get('acquisition')=='ACQUIRED' and life.get('ownershipRetainedUntilReap') is True and life.get('ownedCleanupQualified') is True and life.get('streamOverflow') is False and life.get('timedOut') is False and life.get('error') is None,'CERT_ACTUAL_OWNED_LIFECYCLE')
    for name,pin in c['tlsFixtureBinding']['configs'].items():checked(dict(path=c['tlsFixtureBinding']['root']+'/'+name,**pin))
    for name in ('providers-empty','engines-empty'):
        directory=Path(c['tlsFixtureBinding']['root'])/name
        need(directory.is_dir() and not directory.is_symlink() and not list(directory.iterdir()),'EXACT_EMPTY_PROVIDER_DIR')
    checked(ca['ca'])
    for k in ('server','wrongSan'):
        closed(ca[k],('key','cert'));checked(ca[k]['key']);checked(ca[k]['cert'])
    validity=native['validity'];closed(validity,spec['validityKeys']);now=int(time.time()*1000)
    closed(validity['notBefore'],('ca','server','wrongSan'));closed(validity['notAfter'],('ca','server','wrongSan'))
    need(all(type(n) is int and n<=now for n in validity['notBefore'].values())
         and all(type(n) is int for n in validity['notAfter'].values())
         and validity['earliestExpiry']==min(validity['notAfter'].values())
         and validity['earliestExpiry']-now>=300000,'CERT_CURRENT_VALIDITY')
    # Actual X509-byte dates/SAN/keypairs/CA signatures are independently checked
    # by the fixed child before its metadata or acquisition API is attempted.

def prerequisite_native(name,native,c):
    need(name in c['prerequisites'] and type(native) is dict,'PREREQUISITE_NAME')
    spec=c['prerequisites'][name]
    for key,value in spec['nativeFields'].items():
        need(key in native and equal(native[key],value),'PREREQUISITE_NATIVE:'+name+':'+key)
    for key in spec['absentNativeFields']:need(key not in native,'PREREQUISITE_UNDECLARED_FIELD:'+name)

def verify_common(path, sha):
    need(type(sha) is str and re.fullmatch('[0-9a-f]{64}', sha), 'EXTERNAL_SHA')
    md = descriptor(path); need(md['sha256'] == sha, 'EXTERNAL_SHA')
    c = loads((HERE/'contract.json').read_bytes()); m = document(md)
    validate_manifest(m, c); check_map(m['sourcePins'])
    pack = document(m['sourceReviews']); reviews(pack, m['sourcePins'], c, 'ACCEPT_CURRENT_SOURCES_ONLY')
    for name, binding in c['prerequisites'].items():
        native = loads(checked(binding['descriptor']),historical_native=True)
        prerequisite_native(name,native,c)
    if m['phase']=='ACQUIRE':acquisition_inputs(m,c)
    # Current fixed E01/E02/E05 bytes are pinned exactly; E02 PARTIAL is permitted by adopted policy.
    return dict(manifest=m, manifestDescriptor=md, contract=c, sourcePins=m['sourcePins'], output=m['output'])

def natural_zero(life):
    need(type(life) is dict and life.get('acquisition')=='ACQUIRED' and type(life.get('pid')) is int and life['pid']>0
         and life.get('launchAttempt') is True and life.get('exitCode')==0 and type(life.get('exitCode')) is int
         and life.get('signal') is None and life.get('reaped') is True
         and life.get('stdoutEOF') is True and life.get('stderrEOF') is True
         and life.get('forced') is False and life.get('timedOut') is False and life.get('error') is None,
         'ACTUAL_NATURAL_CONTROL_LIFECYCLE')

def control_review_rows(rows,subjects,c):
    need(type(rows) is list and len(rows)==2 and {r.get('role') for r in rows}=={'qa','security'}
         and len({r.get('session') for r in rows})==2,'TWO_CONTROL_REVIEWS')
    for row in rows:
        closed(row,c['qualificationSchema']['reviewKeys'])
        need(non_author(row['session'],c) and row['decision']==c['qualificationSchema']['reviewDecision']
             and row['scope']==c['qualificationSchema']['reviewScope'] and equal(row['subjects'],subjects),
             'CONTROL_REVIEW_SCOPE_OR_SUBJECT')

def control_capture_shape(capture,pins,c):
    spec=c['controlEvidence'];closed(capture,spec['captureKeys'])
    need(capture['schema']==spec['captureSchema'] and capture['qualified'] is True
         and equal(capture['subjects'],pins) and type(capture['rows']) is list
         and len(capture['rows'])==14,'ACTUAL_CONTROL_CAPTURE')
    for ident,row in zip(c['guardIds'],capture['rows']):
        closed(row,('id','matched','kind'))
        need(row['id']==ident and row['matched'] is True and row['kind']=='PURE_PREDICATE_NO_WORKLOAD','FOURTEEN_MATCHED_ROWS')
    need(type(capture['nativeControls']) is list and len(capture['nativeControls'])==1,'ONE_ACTUAL_HG14_RECEIPT')

def control_evidence(evidence,pins,c):
    spec=c['controlEvidence'];closed(evidence,spec['keys']);need(evidence['schema']==spec['schema'],'ACTUAL_CONTROL_EVIDENCE')
    capture=document(evidence['capture']);control_capture_shape(capture,pins,c)
    out=str(Path(evidence['capture']['path']).parent)
    need(re.fullmatch(spec['controlOutputPattern'],out) and Path(evidence['capture']['path']).name=='capture.json','CONTROL_OUTPUT')
    receipt=document(evidence['receipt']);closed(receipt,spec['outerReceiptKeys'])
    need(receipt['schema']==spec['outerReceiptSchema'] and equal(receipt['tool'],c['tools']['python'])
         and receipt['cwd']==spec['cwd'] and equal(receipt['environment'],c['profileEnvironment'])
         and receipt['output']==out and equal(receipt['sourcePins'],pins),'CONTROL_TOOL_RECEIPT')
    md=receipt['manifest'];checked(md)
    need(receipt['argv']==[c['tools']['python']['path'],'-I','-B',str(HERE/'controls.py'),md['path'],md['sha256'],out],
         'ACTUAL_CONTROL_ARGV')
    base=document(md);need(equal(base['sourcePins'],pins) and equal(base['controls'],c['guardIds']),'CONTROL_BASE_SOURCE_SUBJECT')
    natural_zero(receipt['lifecycle']);need(checked(evidence['stdin'])==b'' and checked(evidence['stderr'])==b'','CONTROL_RAW_STREAMS')
    stdout=checked(evidence['stdout']);need(stdout.endswith(b'\n') and stdout.count(b'\n')==1
         and equal(loads(stdout[:-1]),evidence['capture']),'CONTROL_RAW_STDOUT_CAPTURE_BINDING')
    nd=capture['nativeControls'][0];need(nd['path']==out+'/HG14.receipt.json','HG14_OWNED_RECEIPT')
    node=document(nd);closed(node,spec['nodeReceiptKeys'])
    need(node['schema']==spec['nodeReceiptSchema'] and equal(node['tool'],c['tools']['node'])
         and node['argv']==[c['tools']['node']['path'],'--input-type=module','--eval',c['nodeControlCode']]
         and node['cwd']==out and equal(node['environment'],c['profileEnvironment']),'HG14_NATIVE_COMMAND')
    natural_zero(node['lifecycle'])
    for key,name in [('stdin','HG14.stdin.bin'),('stdout','HG14.stdout.bin'),('stderr','HG14.stderr.bin')]:
        need(node[key]['path']==out+'/'+name,'HG14_OWNED_STREAM')
    need(checked(node['stdin'])==b'' and checked(node['stdout']).hex()==spec['nodeStdoutHex']
         and checked(node['stderr']).hex()==spec['nodeStderrHex'],'HG14_ACTUAL_RAW_STREAMS')

def qualification(q,pins,c):
    closed(q,('schema','decision','subjects','guards','reviews'))
    need(q['schema']==c['qualificationSchema']['schema'] and q['decision']=='ACCEPT_PURE_GUARDS_ONLY'
         and q['guards']==c['guardIds'],'QUALIFICATION')
    closed(q['subjects'],c['qualificationSchema']['subjectKeys'])
    need(equal(q['subjects']['sourcePins'],pins),'QUALIFICATION_CURRENT_SOURCES')
    control_review_rows(q['reviews'],q['subjects'],c)
    control_evidence(document(q['subjects']['actualControlEvidence']),pins,c)

def verify(path, sha, release_path, release_sha):
    ctx = verify_common(path, sha); m=ctx['manifest']; c=ctx['contract']
    q = document(m['qualification']); qualification(q, m['sourcePins'], c)
    rd=descriptor(release_path); need(rd['sha256'] == release_sha, 'RELEASE_EXTERNAL_SHA')
    r=document(rd); closed(r, c['releaseSchema']['keys'])
    need(r['schema'] == c['releaseSchema']['schema'] and r['decision'] == 'RELEASE_EXACT_PHASE_ONLY'
         and r['rootSession'] == '/root' and r['phase'] == m['phase']
         and equal(r['manifest'],ctx['manifestDescriptor']) and equal(r['sourceReviews'],m['sourceReviews'])
         and equal(r['qualification'],m['qualification']), 'EXACT_ROOT_RELEASE')
    ctx['releaseDescriptor']=rd
    return ctx

if __name__ == '__main__':
    try:
        need(len(sys.argv) == 5, 'CLI: admission.py MANIFEST SHA RELEASE SHA')
        result=verify(*sys.argv[1:]); print(json.dumps({'admitted':True,'manifest':result['manifestDescriptor']}))
    except Exception as exc:
        print(type(exc).__name__ + ': ' + str(exc),file=sys.stderr); raise SystemExit(1)
