// SOURCE_PREPARED_NOT_EXECUTED. Private metadata component, not an E06 release.
// Interface SHA256 e87f56f9482f8621597371532d34ff5bd213ead3a82dd3b3dc1a4ab2af8e1174.
import { pathToFileURL } from 'node:url';

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  throw Error('E06_METADATA_MODULE_ONLY_REQUIRES_ADMITTED_PARENT');
}

const LIMITATION = 'NO_ACQUISITION_NO_ORIGINAL_VERIFICATION_NO_DURABILITY_NO_RECEIPT_NO_BUSINESS_AUTHORITY';
const ROOT_KEYS = ['op', 'secretHex', 'config', 'dWireHex', 'fWireHex'];
const CONFIG_KEYS = ['enabled', 'role', 'expectedLocal', 'expectedPeer', 'expectedContext', 'allowedOrigin'];
const TAG_NAMES = ['p', 'e', 'file-type', 'encryption-algorithm', 'decryption-key', 'decryption-nonce', 'x', 'ox', 'size'];
const windowState = { scope: null, deliveries: new Map(), files: new Map(), conflicts: new Set(), capacityHeld: false };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const exactKeys = (value, names) => object(value) && Object.keys(value).length === names.length
  && names.every(name => Object.hasOwn(value, name));
const hex = (value, length) => typeof value === 'string' && value.length === length && !/[^0-9a-f]/.test(value);
const h64 = value => hex(value, 64);
const evenHex = value => value.length % 2 === 0 && !/[^0-9a-f]/.test(value);

function clone(value) {
  if (Array.isArray(value)) return value.map(clone);
  if (object(value)) return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, clone(child)]));
  return value;
}

function freeze(value) {
  if (value !== null && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}

function sameScope(left, right) {
  return left !== null && Object.keys(left).length === Object.keys(right).length
    && Object.keys(left).every(key => left[key] === right[key]);
}

function originValid(origin) {
  if (typeof origin !== 'string' || origin.length > 447) return false;
  const match = /^https:\/\/([a-z0-9.-]+)(?::([0-9]+))?$/.exec(origin);
  if (!match || match[1].length > 253) return false;
  if (!match[1].split('.').every(label => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))) return false;
  return match[2] === undefined || (Number(match[2]) >= 1 && Number(match[2]) <= 65535);
}

function parseLine(line) {
  // No target import is needed to enforce the closed JSONL/duplicate-key boundary.
  if (typeof line !== 'string' || Buffer.byteLength(line, 'utf8') > 131072 || !line.isWellFormed()) throw Error('REQUEST_SHAPE');
  const stack = [];
  for (let index = 0; index < line.length; index++) {
    const character = line[index];
    if (character === '"') {
      const start = index++;
      while (index < line.length && line[index] !== '"') {
        if (line[index] === '\\') index++;
        index++;
      }
      if (index >= line.length) throw Error('REQUEST_SHAPE');
      let next = index + 1;
      while ([' ', '\t', '\r', '\n'].includes(line[next])) next++;
      if (line[next] === ':') {
        const frame = stack.at(-1);
        if (!frame || frame.kind !== '{') throw Error('REQUEST_SHAPE');
        const key = JSON.parse(line.slice(start, index + 1));
        if (frame.keys.has(key)) throw Error('REQUEST_SHAPE');
        frame.keys.add(key);
      }
    } else if (character === '{' || character === '[') {
      stack.push({ kind: character, keys: new Set() });
      if (stack.length > 32) throw Error('REQUEST_SHAPE');
    } else if (character === '}' || character === ']') {
      const frame = stack.pop();
      if (!frame || frame.kind !== (character === '}' ? '{' : '[')) throw Error('REQUEST_SHAPE');
    }
  }
  if (stack.length) throw Error('REQUEST_SHAPE');
  const parsed = JSON.parse(line);
  const pending = [parsed];
  while (pending.length) {
    const value = pending.pop();
    if (typeof value === 'string' && !value.isWellFormed()) throw Error('REQUEST_SHAPE');
    if (typeof value === 'number' && !Number.isFinite(value)) throw Error('REQUEST_SHAPE');
    if (value !== null && typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) {
        if (!key.isWellFormed()) throw Error('REQUEST_SHAPE');
        pending.push(child);
      }
    }
  }
  return parsed;
}

function context() {
  return { dSource: 'ABSENT', dRumorId: null, fRumorId: null,
    validation: { D: null, F: null }, validationCallCounts: { D: 0, F: 0 } };
}

function reply(call, status, stage, reason, association = 'UNCHANGED') {
  // Raw replies are complete and backend-specific. Never return retained references.
  return { schema: 'e06-file-metadata-result-v1', component: 'METADATA_AUTHENTICATION_ONLY',
    status, stage, reason, dSource: call.dSource, dRumorId: call.dRumorId, fRumorId: call.fRumorId,
    association, validation: clone(call.validation), validationCallCounts: { ...call.validationCallCounts },
    window: { dEntries: windowState.deliveries.size, fEntries: windowState.files.size,
      capacityHeld: windowState.capacityHeld }, limitations: LIMITATION };
}

const refused = (call, stage, reason) => reply(call, 'REFUSED', stage, reason);

function carrierConfig(config) {
  return { enabled: config.enabled, role: config.role, expectedLocal: config.expectedLocal,
    expectedPeer: config.expectedPeer, expectedContext: config.expectedContext };
}

function checkWire(wire, which, call) {
  if (wire.length > 32748) return refused(call, which + '_AUTH', 'PROFILE_OUTER_BOUND');
  if (!evenHex(wire)) return refused(call, 'LOCAL', 'WIRE_REPRESENTATION');
  return null;
}

function validateD(wireHex, source, request, transport, scope, call) {
  call.dSource = source;
  const wireFailure = checkWire(wireHex, 'D', call);
  if (wireFailure) return { failure: wireFailure };
  const input = { op: 'carrier-consume', secretHex: request.secretHex, config: carrierConfig(request.config), wireHex };
  call.validationCallCounts.D++;
  const rawReply = transport.carrierHandle(input);
  call.validation.D = { backend: 'JS', entry: 'carrier-consume', rawReply };
  if (rawReply.status !== 'CARRIER_RESULT' || rawReply.stage !== 'S5'
      || rawReply.transportVerification !== 'CHAIN_AND_ENDPOINT_VALIDATED' || rawReply.rumor?.kind !== 14) {
    return { failure: refused(call, 'D_AUTH', 'D_VALIDATION') };
  }
  if (rawReply.codec?.status !== 'STRUCTURALLY_VALID' || rawReply.codec.message?.type !== 'delivery') {
    return { failure: refused(call, 'D_SCHEMA', 'D_NOT_QUALIFIED_DELIVERY') };
  }
  const delivery = { id: rawReply.rumor.id, rumor: rawReply.rumor, message: rawReply.codec.message,
    rawBodyHex: rawReply.rawBodyHex, rawInput: input, scope, provenance: call.validation.D };
  call.dRumorId = delivery.id;
  return { delivery };
}

function validateF(request, transport, key, scope, call) {
  const wireFailure = checkWire(request.fWireHex, 'F', call);
  if (wireFailure) return { failure: wireFailure };
  const options = { role: request.config.role,
    expectedSender: request.config.role === 'incoming' ? request.config.expectedPeer : scope.local };
  call.validationCallCounts.F++;
  const rawReply = transport.validateBytes({ wireHex: request.fWireHex }, key, options);
  call.validation.F = { backend: 'JS', entry: 'validate-bytes', rawReply };
  if (rawReply.ok !== true) return { failure: refused(call, 'F_AUTH', 'F_VALIDATION') };
  const rumor = rawReply.value?.rumor;
  if (rumor?.kind !== 15) return { failure: refused(call, 'F_AUTH', 'F_KIND') };
  const ps = rumor.tags.filter(tag => tag[0] === 'p');
  if (ps.length !== 1 || ps[0].length !== 2 || !h64(ps[0][1])
      || (scope.role === 'incoming' ? rumor.pubkey !== scope.peer || ps[0][1] !== scope.local
        : rumor.pubkey !== scope.local || ps[0][1] !== scope.peer)) {
    return { failure: refused(call, 'F_AUTH', 'F_SCOPE') };
  }
  call.fRumorId = rumor.id;
  return { file: { id: rumor.id, rumor, scope, provenance: call.validation.F,
    rawInput: { wireHex: request.fWireHex, secretHex: request.secretHex, options } } };
}

function fileShape(file, origin, call) {
  const tags = file.rumor.tags;
  if (tags.length !== 9 || !tags.every((tag, index) => tag[0] === TAG_NAMES[index]
      && tag.length === (index === 1 ? 4 : 2) && tag.every(cell => typeof cell === 'string'))) {
    return refused(call, 'F_SHAPE', 'EXACT_NINE_TAGS');
  }
  const values = { parent: tags[1][1], markerHint: tags[1][2], marker: tags[1][3], media: tags[2][1],
    algorithm: tags[3][1], key: tags[4][1], nonce: tags[5][1], x: tags[6][1], ox: tags[7][1], size: tags[8][1] };
  if (!h64(values.key) || !hex(values.nonce, 24) || !h64(values.x) || !h64(values.ox)
      || !/^(?:0|[1-9][0-9]*)$/.test(values.size) || values.size.length > 7
      || Number(values.size) < 16 || Number(values.size) > 1048592) {
    return refused(call, 'F_SHAPE', 'F_ENCODING');
  }
  if (typeof file.rumor.content !== 'string' || Buffer.byteLength(file.rumor.content, 'utf8') > 512
      || /[^\x00-\x7f]/.test(file.rumor.content) || file.rumor.content !== origin + '/' + values.x) {
    return refused(call, 'F_SHAPE', 'F_URL');
  }
  file.values = values;
  return null;
}

function constantsFailure(file) {
  if (!h64(file.values.parent) || file.values.markerHint !== '' || file.values.marker !== 'reply') return 'EXACT_D_PARENT';
  if (file.values.media !== 'application/octet-stream' || file.values.algorithm !== 'aes-gcm') return 'F_PROFILE_CONSTANTS';
  return null;
}

function correspondenceFailure(file, delivery) {
  const constants = constantsFailure(file);
  if (constants) return constants;
  if (file.values.parent !== delivery.id) return 'EXACT_D_PARENT';
  const message = delivery.message;
  if (file.rumor.pubkey !== message.from || file.rumor.tags[0][1] !== message.to
      || file.values.media !== message.document.media || file.values.key !== message.file.key
      || file.values.nonce !== message.file.nonce || file.values.x !== message.file.x
      || file.values.ox !== message.file.ox || file.values.size !== String(message.file.bytes)) {
    return 'EXACT_D_FILE_EQUALITY';
  }
  return null;
}

function capacity(call) {
  // Terminal hold retains every old comparand and sticky conflict; never evict.
  windowState.capacityHeld = true;
  return reply(call, 'WINDOW_FULL', 'ASSOCIATION', 'WINDOW_CAPACITY', 'CAPACITY_HOLD');
}

function retain(file, delivery, scope, call) {
  const nextFiles = new Map(windowState.files);
  if (!nextFiles.has(file.id)) nextFiles.set(file.id, freeze(clone(file)));
  if (!delivery) {
    if (nextFiles.size > 32) return capacity(call);
    windowState.files = nextFiles;
    if (windowState.scope === null) windowState.scope = freeze(clone(scope));
    return reply(call, 'ORPHAN_PENDING', 'ASSOCIATION', 'ORPHAN_F', 'PENDING_NO_D');
  }

  // Original authenticated orphan provenance is internal and immutable. Recheck
  // every D/endpoint/descriptor/URL equality, not merely a parent lookup hint.
  const qualifying = new Set([file.id]);
  for (const previous of windowState.files.values()) {
    if (sameScope(previous.scope, scope) && previous.rumor.content === scope.origin + '/' + previous.values.x
        && correspondenceFailure(previous, delivery) === null) qualifying.add(previous.id);
  }
  const wasDuplicate = windowState.deliveries.has(delivery.id) && windowState.files.has(file.id)
    && correspondenceFailure(windowState.files.get(file.id), delivery) === null;
  const nextDeliveries = new Map(windowState.deliveries);
  if (!nextDeliveries.has(delivery.id)) nextDeliveries.set(delivery.id, freeze(clone(delivery)));
  if (nextDeliveries.size > 16 || nextFiles.size > 32 || qualifying.size > 2) return capacity(call);
  const nextConflicts = new Set(windowState.conflicts);
  if (qualifying.size >= 2) nextConflicts.add(delivery.id);

  // Atomic process-local publication: no awaited operations occur in this block.
  windowState.deliveries = nextDeliveries;
  windowState.files = nextFiles;
  windowState.conflicts = nextConflicts;
  if (windowState.scope === null) windowState.scope = freeze(clone(scope));
  if (nextConflicts.has(delivery.id)) {
    return reply(call, 'CONFLICT', 'ASSOCIATION', 'MULTIPLE_CANONICAL_F_IDS', 'CONFLICT_RETAIN_BOTH');
  }
  const association = wasDuplicate ? 'UNCHANGED_ONE_F' : 'ONE_CANONICAL_F';
  if (scope.role === 'archive') return reply(call, 'ARCHIVE_ONLY', 'ASSOCIATION', 'ARCHIVE_NO_ACQUISITION', association);
  return wasDuplicate ? reply(call, 'DUPLICATE', 'ASSOCIATION', 'SAME_CANONICAL_F', association)
    : reply(call, 'CORRELATED', 'ASSOCIATION', 'EXACT_D_F_METADATA', association);
}

async function handleRequest(request, call) {
  if (!exactKeys(request, ROOT_KEYS) || request.op !== 'correlate-file-metadata'
      || !exactKeys(request.config, CONFIG_KEYS) || (request.dWireHex !== null && typeof request.dWireHex !== 'string')
      || typeof request.fWireHex !== 'string') return refused(call, 'LOCAL', 'REQUEST_SHAPE');
  const config = request.config;
  if (!['incoming', 'archive'].includes(config.role)) return refused(call, 'LOCAL', 'LOCAL_ROLE');
  if (!h64(config.expectedLocal)) return refused(call, 'LOCAL', 'LOCAL_PIN');
  if (!h64(request.secretHex)) return refused(call, 'LOCAL', 'LOCAL_KEY');

  // Fixed project-private target import only. An external reviewed E06 admission
  // must complete before its pinned parent loader may invoke this private entry.
  // No caller module path, command, verified JSON or release token is accepted.
  const transport = await import('../../invoice_authenticated_carrier/js/transport.mjs');
  const key = Uint8Array.from(Buffer.from(request.secretHex, 'hex'));
  let local;
  try { local = transport.getPublicKey(key); }
  catch { return refused(call, 'LOCAL', 'LOCAL_KEY'); }
  if (local !== config.expectedLocal) return refused(call, 'LOCAL', 'LOCAL_PIN_BINDING');
  if (!h64(config.expectedPeer)) return refused(call, 'LOCAL', 'LOCAL_PEER');
  if (!h64(config.expectedContext)) return refused(call, 'LOCAL', 'LOCAL_CONTEXT');
  if (!originValid(config.allowedOrigin)) return refused(call, 'LOCAL', 'LOCAL_ORIGIN');
  if (typeof config.enabled !== 'boolean') return refused(call, 'LOCAL', 'LOCAL_ENABLED');
  const scope = { role: config.role, local, peer: config.expectedPeer,
    context: config.expectedContext, origin: config.allowedOrigin };
  if (windowState.scope !== null && !sameScope(windowState.scope, scope)) return refused(call, 'LOCAL', 'SCOPE_CHANGED');
  if (!config.enabled) return reply(call, 'NO_DISPATCH', 'LOCAL', 'DISABLED');
  if (windowState.capacityHeld) return reply(call, 'WINDOW_FULL', 'ASSOCIATION', 'WINDOW_CAPACITY', 'CAPACITY_HOLD');

  let delivery = null;
  if (request.dWireHex !== null) {
    const result = validateD(request.dWireHex, 'SUPPLIED_RAW', request, transport, scope, call);
    if (result.failure) return result.failure;
    delivery = result.delivery;
  }
  const result = validateF(request, transport, key, scope, call);
  if (result.failure) return result.failure;
  const file = result.file;
  const shapeFailure = fileShape(file, scope.origin, call);
  if (shapeFailure) return shapeFailure;
  const knownFailure = constantsFailure(file);
  if (knownFailure) return refused(call, 'CORRELATION', knownFailure);
  if (delivery === null && windowState.deliveries.has(file.values.parent)) {
    const retained = windowState.deliveries.get(file.values.parent);
    const checked = validateD(retained.rawInput.wireHex, 'RETAINED_RAW_REVALIDATED', request, transport, scope, call);
    if (checked.failure) return checked.failure;
    delivery = checked.delivery;
  }
  if (delivery) {
    const mismatch = correspondenceFailure(file, delivery);
    if (mismatch) return refused(call, 'CORRELATION', mismatch);
  }
  return retain(file, delivery, scope, call);
}

// The only supported module entry consumes the original bounded JSONL text.
// It exposes neither mutable window state nor a parsed-object/token shortcut.
export async function _handleLine(line) {
  const call = context();
  let request;
  try { request = parseLine(line); }
  catch { return refused(call, 'LOCAL', 'REQUEST_SHAPE'); }
  return handleRequest(request, call);
}
