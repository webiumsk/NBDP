// SOURCE IMPLEMENTATION ONLY. No control/configuration/runtime release is supplied here.
// Fixed LAB-I4 helper. JSON evidence never authenticates a protocol capability.
import {readFileSync, writeFileSync, statSync, realpathSync, lstatSync, readdirSync, writeSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';
import path from 'node:path';
const ROOT = '/home/peterhorvath/apps/bitcoin/NBDP';
const HERE = ROOT+'/experiments/prototypes/e06_relay_https_composition_v1';
const WS_ENTRY = ROOT+'/experiments/node_modules/ws/wrapper.mjs';
const NODE = '/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node';
const NODE_PIN = {bytes:121613584,sha256:'ccacb2d6d87ba6d118b2bffc1ae33747a05cc5fc6b1f1ec4fc1d420b687e952d'};
const ENDPOINTS = Object.freeze({strfry:'ws://127.0.0.1:17777','rs-relay':'ws://127.0.0.1:18081'});
const ENV = Object.freeze({PATH:'/usr/bin:/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',TZ:'UTC',WS_NO_BUFFER_UTIL:'1',WS_NO_UTF_8_VALIDATE:'1'});
const MAX_FRAME = 262144, MAX_FRAMES = 16, MAX_RAW = 2097152;
const assert = (ok, message) => {if (!ok) throw Error(message);};
const keys = (value, names) => value!==null && typeof value==='object' && !Array.isArray(value)
  && Object.keys(value).length===names.length && names.every(k=>Object.hasOwn(value,k));
const hash = b => createHash('sha256').update(b).digest('hex');
const pin = file => {const b=readFileSync(file);return {bytes:b.length,sha256:hash(b)};};
const samePin = (a,b) => keys(a,['bytes','sha256']) && keys(b,['bytes','sha256'])
  && a.bytes===b.bytes && a.sha256===b.sha256;

export function typedEqual(a,b) {
  if (typeof a!==typeof b || (a===null)!==(b===null) || Array.isArray(a)!==Array.isArray(b)) return false;
  if (a===null || typeof a!=='object') return Object.is(a,b);
  if (Array.isArray(a)) return a.length===b.length && a.every((v,i)=>typedEqual(v,b[i]));
  return Object.keys(a).length===Object.keys(b).length
    && Object.keys(a).every(k=>Object.hasOwn(b,k)&&typedEqual(a[k],b[k]));
}

function scalar(s) {
  for(let i=0;i<s.length;i++) {
    const c=s.charCodeAt(i);
    if(c>=0xd800&&c<=0xdbff) {const d=s.charCodeAt(++i);assert(d>=0xdc00&&d<=0xdfff,'Unpaired high surrogate');}
    else assert(!(c>=0xdc00&&c<=0xdfff),'Unpaired low surrogate');
  }
  return s;
}

// Inert strict JSON parser. Spans are UTF-8 byte offsets, including nested objects.
// Numeric grammar intentionally admits decimal safe integers only, without -0.
export function parseStrict(raw, limit=MAX_RAW) {
  assert(Buffer.isBuffer(raw)||raw instanceof Uint8Array,'Raw bytes required');
  const bytes=Buffer.from(raw);assert(bytes.length<=limit,'JSON byte bound');
  const text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);
  let i=0,nodes=0;
  const white=()=>{while(i<text.length&&/[\x20\x09\x0a\x0d]/.test(text[i]))i++;};
  const offsets=new Uint32Array(text.length+1);let byteOffset=0;
  for(let j=0;j<text.length;j++){offsets[j]=byteOffset;const c=text.codePointAt(j);if(c>0xffff){offsets[++j]=byteOffset;byteOffset+=4;}else byteOffset+=c<0x80?1:c<0x800?2:3;}
  offsets[text.length]=byteOffset;const position=x=>offsets[x];
  function string() {
    const start=i;assert(text[i++]==='"','Expected string');
    while(i<text.length) {
      const c=text.charCodeAt(i++);
      if(c===34)return scalar(JSON.parse(text.slice(start,i)));
      assert(c>=32,'Control in string');
      if(c===92) {
        assert(i<text.length,'Incomplete escape');const e=text[i++];
        if(e==='u') {assert(/^[0-9a-fA-F]{4}$/.test(text.slice(i,i+4)),'Invalid Unicode escape');i+=4;}
        else assert('"\\/bfnrt'.includes(e),'Invalid escape');
      }
    }
    throw Error('Unterminated string');
  }
  function value(depth=0) {
    assert(depth<=64&&++nodes<=100000,'JSON structural bound');white();const start=i;let result,children=null;
    const c=text[i];
    if(c==='"')result=string();
    else if(c==='[') {
      i++;result=[];children=[];white();
      if(text[i]!==']')while(true) {
        const child=value(depth+1);result.push(child.value);children.push(child);white();
        if(text[i]!==',')break;i++;
      }
      assert(text[i++ ]===']','Invalid array');
    } else if(c==='{') {
      i++;result=Object.create(null);children=Object.create(null);white();
      if(text[i]!=='}')while(true) {
        white();const key=string();assert(!Object.hasOwn(result,key),'Duplicate object key');white();
        assert(text[i++]===':','Missing colon');const child=value(depth+1);result[key]=child.value;children[key]=child;white();
        if(text[i]!==',')break;i++;
      }
      assert(text[i++]==='}','Invalid object');
    } else if(text.startsWith('true',i)){result=true;i+=4;}
    else if(text.startsWith('false',i)){result=false;i+=5;}
    else if(text.startsWith('null',i)){result=null;i+=4;}
    else {
      const match=/^-?(?:0|[1-9][0-9]*)/.exec(text.slice(i));assert(match,'Invalid JSON value');
      i+=match[0].length;result=Number(match[0]);
      assert(match[0]!=='-0'&&Number.isSafeInteger(result),'Unsupported integer');
    }
    return {value:result,start:position(start),end:position(i),children};
  }
  const root=value();white();assert(i===text.length,'Trailing JSON content');
  return {value:root.value,spans:root,raw:bytes};
}

export function validateAck(raw,id) {
  const a=parseStrict(raw,MAX_FRAME).value;
  assert(Array.isArray(a)&&a.length===4&&a[0]==='OK'&&a[1]===id&&a[2]===true&&typeof a[3]==='string','Exact OK true required');return a;
}
export function validateEose(raw,sub) {
  const a=parseStrict(raw,MAX_FRAME).value;
  assert(Array.isArray(a)&&a.length===2&&a[0]==='EOSE'&&a[1]===sub,'Exact EOSE required');return a;
}
export function validateEventFrame(raw,sub,fixture) {
  const parsed=parseStrict(raw,MAX_FRAME),a=parsed.value;
  assert(Array.isArray(a)&&a.length===3&&a[0]==='EVENT'&&a[1]===sub,'Exact EVENT frame required');
  assert(typedEqual(a[2],fixture),'Whole EVENT mismatch');
  const span=parsed.spans.children[2];
  assert(span.value!==null&&typeof span.value==='object'&&!Array.isArray(span.value),'EVENT object required');
  return {event:a[2],wireHex:parsed.raw.subarray(span.start,span.end).toString('hex')};
}
export function validateClose(code,reason) {
  assert(code===1000,'Strict Close1000 required');
  assert(Buffer.isBuffer(reason)||reason instanceof Uint8Array,'Raw close reason required');
  return {code,reason:scalar(new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(reason))};
}

// The same pure state machine is used by callbacks and refusal controls.
export function createProtocolState(id,sub,fixture) {
  let phase='OPEN',wireHex=null,eventCount=0,publicationCount=0,queryCount=0;
  return {
    sent(kind) {
      if(kind==='EVENT'){assert(phase==='OPEN','Premature EVENT publication');phase='ACK';publicationCount++;}
      else if(kind==='REQ'){assert(phase==='ACK_RETAINED','REQ before ACK');phase='EVENT';queryCount++;}
      else if(kind==='CLOSE'){assert(phase==='EOSE_RETAINED','CLOSE before EOSE');phase='CLOSING';}
      else throw Error('Unknown send kind');
    },
    received(raw,binary=false) {
      assert(!binary,'Binary payload refused');
      if(phase==='ACK'){validateAck(raw,id);phase='ACK_RETAINED';return 'OK';}
      if(phase==='EVENT'){const event=validateEventFrame(raw,sub,fixture);wireHex=event.wireHex;eventCount++;phase='EOSE';return 'EVENT';}
      if(phase==='EOSE'){validateEose(raw,sub);phase='EOSE_RETAINED';return 'EOSE';}
      throw Error('Unexpected or premature relay payload in '+phase);
    },
    closed(code,reason) {assert(phase==='CLOSING','Premature socket close');const close=validateClose(code,reason);phase='CLOSED';return close;},
    snapshot() {return {phase,wireHex,eventCount,publicationCount,queryCount};}
  };
}

// All exports below are inert on import. Only fixed builtins are loaded before admission.
export function absoluteFile(file) {
  assert(typeof file==='string'&&path.isAbsolute(file)&&realpathSync(file)===file&&!lstatSync(file).isSymbolicLink()&&statSync(file).isFile(),'Resolved regular absolute file required');
}
export function privateDir(dir) {
  assert(path.isAbsolute(dir)&&realpathSync(dir)===dir,'Resolved absolute directory required');
  const s=statSync(dir);assert(s.isDirectory()&&(s.mode&0o777)===0o700&&s.uid===process.getuid(),'Owned mode0700 directory required');
}
export function checkDescriptor(d) {
  assert(keys(d,['path','bytes','sha256'])&&Number.isSafeInteger(d.bytes)&&d.bytes>=0&&/^[a-f0-9]{64}$/.test(d.sha256),'Closed descriptor required');
  absoluteFile(d.path);assert(samePin(pin(d.path),{bytes:d.bytes,sha256:d.sha256}),'Descriptor bytes changed');return d;
}
export function validateShape(value, shape, definitions, depth=0) {
  assert(depth<=128,'Schema recursion bound');
  const next=(v,s)=>validateShape(v,s,definitions,depth+1);
  if(typeof shape==='string') {
    if(shape.startsWith('@')) {assert(Object.hasOwn(definitions,shape.slice(1)),'Unknown schema reference');return next(value,definitions[shape.slice(1)]);}
    assert(shape==='null'?value===null:shape==='boolean'?typeof value==='boolean':false,'Unsupported primitive or wrong type');return true;
  }
  if(Object.hasOwn(shape,'union')) {for(const s of shape.union)try{next(value,s);return true;}catch{}throw Error('No schema union arm');}
  if(Object.hasOwn(shape,'literal'))assert(typedEqual(value,shape.literal),'Literal mismatch');
  else if(Object.hasOwn(shape,'enum'))assert(shape.enum.some(v=>typedEqual(value,v)),'Enum mismatch');
  else if(Object.hasOwn(shape,'record')) {assert(keys(value,Object.keys(shape.record)),'Closed record keys');for(const [k,s]of Object.entries(shape.record))next(value[k],s);}
  else if(Object.hasOwn(shape,'array')) {assert(Array.isArray(value)&&value.length>=shape.length[0]&&value.length<=shape.length[1],'Bounded array');for(const v of value)next(v,shape.array);}
  else if(Object.hasOwn(shape,'tuple')) {assert(Array.isArray(value)&&value.length===shape.tuple.length,'Tuple arity');shape.tuple.forEach((s,i)=>next(value[i],s));}
  else if(Object.hasOwn(shape,'integer'))assert(Number.isSafeInteger(value)&&!Object.is(value,-0)&&value>=shape.integer[0]&&value<=shape.integer[1],'Safe integer range');
  else if(Object.hasOwn(shape,'stringMax')||Object.hasOwn(shape,'pattern')) {
    assert(typeof value==='string','String required');scalar(value);
    if(Object.hasOwn(shape,'stringMax'))assert(Buffer.byteLength(value,'utf8')<=shape.stringMax,'String byte bound');
    if(Object.hasOwn(shape,'pattern'))assert(new RegExp(shape.pattern,'u').test(value),'String pattern');
  } else throw Error('Unsupported schema grammar');
  return true;
}
const FROZEN_DATA = Object.freeze(Object.fromEntries(Object.entries({"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/BRIDGE.md":{"bytes":10113,"sha256":"03df5e47ba6a1acf9d47444b61999c6d854005dce92852dc72d2d984e939eac6"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/SOURCE.md":{"bytes":9366,"sha256":"fc2c8a6fecf374094c970088213765873f1f511804d812f86f8fb3266ffcaab5"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/bridge-schemas.json":{"bytes":25275,"sha256":"927c4536b32efaba37908a31f7e428a84fe333994ce84052610806322aaeb8c1"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/contract.json":{"bytes":21113,"sha256":"c15e87802d199e049eb535b130b0db420cc869982deeb51911239ab803924bc3"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/i4-oracle-rules.json":{"bytes":9017,"sha256":"1b410aae0f1d8457c18dfeaf2a2f05b01d956ee28ad82c548f1d16bacbd4a0d3"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/interfaces.md":{"bytes":13134,"sha256":"a4025f32f0f1c42280edc83a7efbcd0ed82f6592ffc95203ced07d204f2fcff9"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/oracles.json":{"bytes":94166,"sha256":"c8c2830334342c771e959d94fc3b8e6e2d91d8139679a85c63819ce92df618e0"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/profile.json":{"bytes":5749,"sha256":"0b1f2ef54e2dc89c3555c30b48b815d999b84958877a5603d9cd27a52533346c"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/protected-deltas.json":{"bytes":7387,"sha256":"c299b3b4078dd0c75a428d34c82ae92ca69903be67c98f0db563d9cb99adb2e9"},"/home/peterhorvath/apps/bitcoin/NBDP/experiments/prototypes/e06_relay_https_composition_v1/selection-map.json":{"bytes":35919,"sha256":"f523aee4be1e4b5fa5adc51723c414f859465517bf99f79f0e91d1e13a26c1d2"}}).map(([file,descriptor])=>[file,Object.freeze(descriptor)])));
export function verifyClosure(closure, required=[]) {
  assert(Array.isArray(closure)&&closure.length>=1&&closure.length<=1024,'Finite closure required');const map=new Map();
  for(const d of closure){checkDescriptor(d);assert(!map.has(d.path),'Duplicate/aliased closure path');map.set(d.path,d);}
  for(const [p,d] of Object.entries(FROZEN_DATA))assert(map.has(p)&&samePin(pin(p),d)&&samePin({bytes:map.get(p).bytes,sha256:map.get(p).sha256},d),'Frozen planning input absent/changed');
  assert(typedEqual(process.env,ENV),'Closed six-variable environment required');
  assert(realpathSync(process.execPath)===NODE&&samePin(pin(NODE),NODE_PIN),'Fixed Node binary required');
  for(const p of [NODE,...required])assert(map.has(p),'Required current runtime absent from closure');
  assert(samePin({bytes:map.get(NODE).bytes,sha256:map.get(NODE).sha256},NODE_PIN),'Fixed Node closure pin');
  return map;
}
export function fixedData() {
  for(const [p,d]of Object.entries(FROZEN_DATA)){absoluteFile(p);assert(samePin(pin(p),d),'Frozen data changed');}
  const selection=parseStrict(readFileSync(HERE+'/selection-map.json')).value;
  const schemas=parseStrict(readFileSync(HERE+'/bridge-schemas.json')).value;
  return {selection,definitions:schemas.definitions};
}
export function selectedWindow(selection,caseId) {
  const w=selection.initialWindows.filter(x=>x.caseId===caseId);assert(w.length===1&&['C01','C02','C03','C04'].includes(caseId),'Unsupported lane/case');return w[0];
}
export function readBinding(bindingPath,sha,kind) {
  absoluteFile(bindingPath);privateDir(path.dirname(bindingPath));
  const s=statSync(bindingPath);assert(s.uid===process.getuid()&&(s.mode&0o777)===0o600,'Owned mode0600 binding required');
  assert(/^[a-f0-9]{64}$/.test(sha)&&s.size<=1048576&&pin(bindingPath).sha256===sha,'External bounded binding SHA');
  const raw=readFileSync(bindingPath),binding=parseStrict(raw,1048576).value;
  const {selection,definitions}=fixedData();validateShape(binding,'@'+kind,definitions);
  return {binding,selection,definitions};
}
export function writeOneLine(value) {
  const b=Buffer.from(JSON.stringify(value)+'\n');assert(b.length<=16777216,'Reply byte bound');
  assert(writeSync(1,b,0,b.length)===b.length,'Complete synchronous reply required');
}
function validateBinding(binding,selection) {
  const w=selectedWindow(selection,binding.caseId),job=w.jobs.find(j=>j.slot===binding.slot);
  assert(binding.relay===w.relay&&job&&typedEqual(binding.wire,job.wire),'Exact I4 slot/relay/fixture required');
  checkDescriptor(binding.wire);const fixture=parseStrict(readFileSync(binding.wire.path),MAX_FRAME).value;
  assert(fixture.id===binding.outerId&&fixture.kind===1059,'Fixed signed outer ID/kind');
  const map=verifyClosure(binding.closure,[fileURLToPath(import.meta.url),WS_ENTRY,binding.wire.path]);
  assert(typedEqual(map.get(binding.wire.path),binding.wire),'Wire descriptor absent from closure');
  privateDir(binding.output);assert(readdirSync(binding.output).length===0,'Fresh empty owned output required');return fixture;
}
async function main() {
  assert(process.argv.length===4,'CLI: node wire.mjs ABS_BINDING SHA256');
  const [bindingPath,sha]=process.argv.slice(2);
  const {binding,selection,definitions}=readBinding(bindingPath,sha,'wireBinding');
  // Parent owns release admission and complete exact closure. This child rechecks all supplied bytes before dependent import.
  const fixture=validateBinding(binding,selection),self=fileURLToPath(import.meta.url);
  const verify=()=>{
    assert(pin(bindingPath).sha256===sha,'Binding changed');
    verifyClosure(binding.closure,[self,WS_ENTRY,binding.wire.path]);privateDir(binding.output);
  };
  const report={schema:'i4-wire-report-v1',caseId:binding.caseId,slot:binding.slot,qualified:false,publicationCount:0,queryCount:0,eventCount:0,wireHex:null,close:null,frames:[],error:null};
  let ws=null,terminal=null,wake=null,totalBytes=0,closed=false;
  const sub='nbdp-'+binding.caseId+'-'+binding.slot;
  const state=createProtocolState(binding.outerId,sub,fixture);
  const signal=()=>{if(wake){const fn=wake;wake=null;fn();}};
  const fail=error=>{terminal??=error;signal();if(ws&&!closed)ws.terminate();};
  const capture=(direction,raw,kind)=>{
    const remaining=Math.max(0,MAX_RAW-totalBytes);
    if(report.frames.length>=MAX_FRAMES)throw Error('Frame count bound');
    report.frames.push({direction,kind:raw.length>remaining?'BOUND_EXCEEDED_PREFIX':kind,rawHex:raw.subarray(0,remaining).toString('hex')});
    totalBytes+=Math.min(raw.length,remaining);
    assert(raw.length<=MAX_FRAME&&raw.length<=remaining,'Raw stream bound');
  };
  const waitFor=async(predicate,ms,label)=>{
    const deadline=Date.now()+ms;
    while(!predicate()) {
      if(terminal)throw terminal;const remaining=deadline-Date.now();assert(remaining>0,label+' deadline');
      await new Promise(resolve=>{const timer=setTimeout(()=>{wake=null;resolve();},remaining);wake=()=>{clearTimeout(timer);resolve();};});
    }
    if(terminal)throw terminal;
  };
  const send=(kind,raw)=>{
    assert(!terminal&&ws.readyState===1,'Socket not available');state.sent(kind);capture('SEND',raw,kind);ws.send(raw,{binary:false});
  };
  try {
    verify();const {default:WebSocket}=await import(pathToFileURL(WS_ENTRY).href);verify();
    ws=new WebSocket(ENDPOINTS[binding.relay],{handshakeTimeout:3000,maxPayload:MAX_FRAME,followRedirects:false,perMessageDeflate:false});
    ws.on('message',(data,binary)=>{
      const raw=Buffer.from(data);
      try {
        capture('RECEIVE',raw,binary?'BINARY':'UNVALIDATED');
        const kind=state.received(raw,binary);report.frames[report.frames.length-1].kind=kind==='OK'?'ACK':kind;signal();
      } catch(error){fail(error);}
    });
    ws.on('error',fail);
    ws.on('close',(code,reason)=>{
      closed=true;
      try {state.closed(code,Buffer.from(reason));report.close={code,reasonHex:Buffer.from(reason).toString('hex')};assert(reason.length===0,'I4 empty Close1000 reason required');}
      catch(error){terminal??=error;}
      signal();
    });
    ws.on('open',signal);
    await waitFor(()=>ws.readyState===1,3000,'Open');
    // Publication keeps original signed object bytes; no fixture reserialization.
    verify();checkDescriptor(binding.wire);const signed=readFileSync(binding.wire.path);
    send('EVENT',Buffer.concat([Buffer.from('["EVENT",'),signed,Buffer.from(']')]));
    await waitFor(()=>state.snapshot().phase==='ACK_RETAINED',3000,'ACK');
    send('REQ',Buffer.from(JSON.stringify(['REQ',sub,{ids:[binding.outerId],limit:1}])));
    // EVENT and EOSE may arrive back-to-back; state retains both without discarding.
    await waitFor(()=>state.snapshot().eventCount===1,3000,'EVENT');
    await waitFor(()=>state.snapshot().phase==='EOSE_RETAINED',3000,'EOSE');
    send('CLOSE',Buffer.from(JSON.stringify(['CLOSE',sub])));ws.close(1000);
    await waitFor(()=>closed,1000,'Close');
    assert(state.snapshot().phase==='CLOSED','Incomplete wire sequence');verify();report.qualified=true;
  } catch(error){report.error=(error.name+': '+error.message).slice(0,16000);}
  finally {
    if(ws&&!closed)ws.terminate();
    const s=state.snapshot();for(const k of ['publicationCount','queryCount','eventCount','wireHex'])report[k]=s[k];
    try{verify();}catch(error){report.qualified=false;report.error??=error.name+': '+error.message;}
    assert(report.publicationCount===1||!report.qualified,'Incomplete publication count');
    assert(report.queryCount===1&&report.eventCount===1||!report.qualified,'Incomplete retrieval count');
    validateShape(report,'@wireReport',definitions);
    writeFileSync(path.join(binding.output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
  }
  const reportPath=path.join(binding.output,'report.json');
  const reply={schema:'i4-wire-cli-reply-v1',caseId:binding.caseId,slot:binding.slot,qualified:report.qualified,report:{path:reportPath,...pin(reportPath)}};
  validateShape(reply,'@wireCLIReply',definitions);writeOneLine(reply);return report.qualified?0:1;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  main().then(code=>{process.exitCode=code;}).catch(error=>{process.stderr.write(error.name+': '+error.message+'\n');process.exitCode=1;});
}
