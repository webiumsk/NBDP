"""SOURCE ONLY: fixed, separately released four-case relay/HTTPS composition.

Importing this runner is inert. A later externally approved bootstrap must pin this
file itself. The fixed admission below is pinned BEFORE import; no JSON can grant
an SDK, architecture decision or a new target profile. Checker oracles stay here,
never in workerData, frames, native requests or child environments.
"""
import hashlib
import errno
import importlib.util
import json
import os
from pathlib import Path
import selectors
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ADMISSION = {'path':str(HERE/'admission.py'),'bytes':26884,
             'sha256':'1242661a310cc4e54f21846dbe19f5fdc556d9ff8c2c057942850fc152c966ab'}
ENV = {'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
       'WS_NO_BUFFER_UTIL':'1','WS_NO_UTF_8_VALIDATE':'1'}
A = None


def bootstrap():
    """No project import until the fixed source bytes and interpreter are checked."""
    global A
    source=Path(ADMISSION['path'])
    if source.stat().st_size!=ADMISSION['bytes']:raise ValueError('FIXED_ADMISSION_SIZE')
    raw=source.read_bytes()
    if source.resolve(strict=True)!=source or source.is_symlink() or len(raw)!=ADMISSION['bytes'] or hashlib.sha256(raw).hexdigest()!=ADMISSION['sha256']:
        raise ValueError('FIXED_ADMISSION_PIN')
    if dict(os.environ)!=ENV:raise ValueError('EXACT_OUTER_ENVIRONMENT')
    python=Path('/home/peterhorvath/.miniforge3/bin/python3.13')
    if Path(sys.executable).resolve(strict=True)!=python:raise ValueError('FIXED_OUTER_PYTHON')
    spec=importlib.util.spec_from_file_location('_i4_fixed_runner_admission',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);A=module
    A.need(A.equal(A.descriptor(python),A.PYTHON),'FIXED_OUTER_PYTHON_PIN')
    return A


def error_fact(exc):
    return {'name':type(exc).__name__[:1024],'message':str(exc)[:16384],
            'code':None,'stack':None}


def put_bytes(p,raw):
    A.need(type(raw) is bytes and len(raw)<=33554432,'EVIDENCE_WRITE_BOUND')
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        with os.fdopen(fd,'wb',closefd=False) as handle:handle.write(raw);handle.flush();os.fsync(fd)
    finally:os.close(fd)
    parent=os.open(Path(p).parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(parent)
    finally:os.close(parent)
    return A.descriptor(p)


def put_json(p,value):
    return put_bytes(p,(json.dumps(value,ensure_ascii=True,separators=(',',':'))+'\n').encode())


def one_line(raw):
    A.need(type(raw) is bytes and len(raw)<=16777216 and raw.endswith(b'\n') and raw.count(b'\n')==1,'EXACT_ONE_JSONL')
    return A.loads(raw[:-1])


def pure_group_signal_allowed(ownership,observation,returncode):
    """Actual signal gate: a fresh WNOWAIT child observation, before any reap."""
    return ownership=='HELD' and observation in ('RUNNING','EXITED') and returncode is None


def pure_phase_timeout(now_ns,window_deadline_ns,anchors):
    """Non-rebased monotonic policy; completion cannot erase an overdue interval."""
    if now_ns>=window_deadline_ns:return 'CASE_OUTER_DEADLINE'
    for name,seconds in (('acquisition',150),('consumer',120)):
        v=anchors[name]
        if v['startedNs'] is not None:
            end=v['completedNs'] if v['completedNs'] is not None else now_ns
            if end-v['startedNs']>=seconds*1000000000:return 'CASE_'+name.upper()+'_DEADLINE'
    return None


class OwnedCase:
    """Owned Popen, WNOWAIT observations, no post-reap numeric group operations.

    Only HELD permits signals, each preceded by fresh waitid(WNOWAIT). REAPING
    is latched BEFORE the sole consuming waitid. ECHILD/ambiguous observation
    loses ownership: never guess a process/group from its numeric identifier.
    Cleanup keeps the leader unreaped until every possible group signal ends.
    The six optional I/O seams serve inert controls, never frame/CLI input.
    """
    def __init__(self,argv,directory,env,deadline,current,phase_progress=None,io=None):
        self.argv=list(argv);self.directory=directory;self.env=dict(env);self.deadline=deadline;self.current=current
        self.process=None;self.selector=None;self.streams={k:None for k in ('stdin','stdout','stderr')}
        self.total={'stdout':0,'stderr':0};self.out={k:bytearray() for k in self.total}
        self.limits={'stdout':16777216,'stderr':65536};self.ownership='NOT_ACQUIRED';self.observation=None
        self.primary=None;self.secondary=[];self.secondary_bytes=0;self.secondary_overflow=False
        self.receipt=None;self.capture_complete=False;self.phase_progress=phase_progress
        self.phase={'windowDeadlineNs':int(deadline*1000000000),'lastObservationNs':None,'maxObservationGapNs':0,
                    'timeoutCause':None,'anchors':{n:{'startedNs':None,'completedNs':None,'startSource':None,'completionSource':None}
                    for n in ('acquisition','consumer')},'observations':[],
                    'meaning':'Parent first-observed fixed source-owned pathname creation; internal entry/durability times UNKNOWN. No hard realtime/host-stall or escaped-descendant guarantee.'}
        self.io={'waitid':os.waitid,'killpg':os.killpg,'clockNs':time.monotonic_ns,
                 'writeBytes':put_bytes,'writeJSON':put_json,'stderr':lambda b:os.write(2,b)}
        if io is not None:
            if set(io)!=set(self.io) or not all(callable(v) for v in io.values()):raise ValueError('CLOSED_INERT_IO_SEAMS')
            self.io=dict(io)
        self.life={'launchAttempt':False,'acquisition':'NOT_ATTEMPTED','pid':None,'exitCode':None,'signal':None,
                   'reaped':False,'stdoutEOF':False,'stderrEOF':False,'timedOut':False,'forced':False,'error':None}
    def primary_error(self,exc):
        if self.primary is None:self.primary=error_fact(exc);self.life['error']=dict(self.primary)
    def secondary_error(self,owner,exc):
        row={'owner':str(owner)[:256],'error':error_fact(exc)};size=len(json.dumps(row).encode())
        if len(self.secondary)<16 and self.secondary_bytes+size<=131072:self.secondary.append(row);self.secondary_bytes+=size
        else:self.secondary_overflow=True
    def attempt(self,owner,fn):
        try:return True,fn()
        except BaseException as exc:self.secondary_error(owner,exc);return False,None
    def observe_owned(self):
        if self.ownership!='HELD':return 'UNKNOWN'
        if self.process is None or self.process.returncode is not None:
            self.ownership='UNKNOWN';raise ValueError('OWNERSHIP_ENDED_OUTSIDE_SUPERVISOR')
        try:r=self.io['waitid'](os.P_PID,self.process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
        except BaseException as exc:
            self.ownership='UNKNOWN'
            # ECHILD is loss of ownership, never proof of cleanup/reap by this owner.
            if isinstance(exc,ChildProcessError) or isinstance(exc,OSError) and exc.errno==errno.ECHILD:
                raise ValueError('CHILD_OWNERSHIP_UNKNOWN_ECHILD') from exc
            raise
        if r is not None and r.si_pid!=self.process.pid:
            self.ownership='UNKNOWN';raise ValueError('CHILD_OBSERVATION_IDENTITY')
        self.observation=r;return 'EXITED' if r is not None else 'RUNNING'
    def signal_owned_group(self,number):
        observation=self.observe_owned()
        if not pure_group_signal_allowed(self.ownership,observation,self.process.returncode if self.process else None):
            raise ValueError('NO_RETAINED_GROUP_SIGNAL_AUTHORITY')
        self.life['forced']=True
        # The exact child remains unreaped during every allowed group operation.
        self.io['killpg'](self.process.pid,number)
    def reap_exited(self):
        if self.observe_owned()!='EXITED':return False
        self.ownership='REAPING'  # BEFORE the consuming syscall, including interruption/error paths.
        try:r=self.io['waitid'](os.P_PID,self.process.pid,os.WEXITED|os.WNOHANG)
        except BaseException:
            self.ownership='UNKNOWN';raise
        if r is None or r.si_pid!=self.process.pid:
            self.ownership='UNKNOWN';raise ValueError('REAP_OUTCOME_UNKNOWN')
        if r.si_code==os.CLD_EXITED:code=r.si_status;sig=None;returncode=code
        elif r.si_code in (os.CLD_KILLED,os.CLD_DUMPED):code=None;sig=signal.Signals(r.si_status).name;returncode=-r.si_status
        else:self.ownership='UNKNOWN';raise ValueError('REAP_STATUS_UNKNOWN')
        self.process.returncode=returncode
        self.life.update(reaped=True,exitCode=code,signal=sig);self.ownership='REAPED';return True
    def watch_phases(self):
        now=self.io['clockNs']();previous=self.phase['lastObservationNs']
        if previous is not None:self.phase['maxObservationGapNs']=max(self.phase['maxObservationGapNs'],now-previous)
        self.phase['lastObservationNs']=now
        cause=pure_phase_timeout(now,self.phase['windowDeadlineNs'],self.phase['anchors'])
        if cause:self.phase['timeoutCause']=cause;self.life['timedOut']=True;raise TimeoutError(cause)
        if self.phase_progress is not None:
            case,ident=self.phase_progress
            # S04 pathname creation conservatively includes reservation, imports and acquisition.
            # S05 starts the consumer interval; S06 completion includes its owned cleanup.
            for suffix in ('S04','S05','S06'):
                file=case/(ident+'-'+suffix+'.json')
                if not file.exists():continue
                st=file.lstat()
                if file.is_symlink() or not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or stat.S_IMODE(st.st_mode)!=0o600:
                    raise ValueError('SOURCE_OWNED_PHASE_PATH')
                if any(row['source']==str(file) for row in self.phase['observations']):continue
                self.phase['observations'].append({'source':str(file),'firstObservedNs':now,'sizeAtObservation':st.st_size})
                acquisition=self.phase['anchors']['acquisition'];consumer=self.phase['anchors']['consumer']
                if suffix=='S04':acquisition.update(startedNs=now,startSource=str(file))
                elif suffix=='S05':
                    if acquisition['startedNs'] is None:raise ValueError('ACQUISITION_PHASE_ORIGIN_MISSING')
                    acquisition.update(completedNs=now,completionSource=str(file));consumer.update(startedNs=now,startSource=str(file))
                else:
                    if consumer['startedNs'] is None:raise ValueError('CONSUMER_PHASE_ORIGIN_MISSING')
                    consumer.update(completedNs=now,completionSource=str(file))
            cause=pure_phase_timeout(now,self.phase['windowDeadlineNs'],self.phase['anchors'])
            if cause:self.phase['timeoutCause']=cause;self.life['timedOut']=True;raise TimeoutError(cause)
    def read_key(self,key):
        name=key.data
        try:raw=os.read(key.fileobj.fileno(),65536)
        except BaseException:
            self.total[name]=None  # Interrupted/error read cannot certify its byte accounting.
            raise
        if not raw:
            self.life[name+'EOF']=True;self.selector.unregister(key.fileobj);return
        if self.total[name] is not None:self.total[name]+=len(raw)
        remaining=max(0,self.limits[name]-len(self.out[name]));self.out[name].extend(raw[:remaining])
        if self.total[name] is None or self.total[name]>self.limits[name]:raise ValueError('CASE_OUTER_STREAM_BOUND')
    def pump(self,seconds,cleanup=False):
        if self.selector is None:return
        if cleanup:
            ok,events=self.attempt('cleanup:selector-select',lambda:self.selector.select(seconds))
            if not ok:return
            for key,_ in events:self.attempt('cleanup:pipe-read:'+key.data,lambda key=key:self.read_key(key))
        else:
            for key,_ in self.selector.select(seconds):self.read_key(key)
    def all_eof(self):return self.life['stdoutEOF'] and self.life['stderrEOF']
    def cleanup(self):
        if self.ownership=='REAPING':self.ownership='UNKNOWN'  # Consuming syscall may already have completed.
        if self.process is not None and self.ownership=='HELD':
            ok,observation=self.attempt('cleanup:initial-WNOWAIT',self.observe_owned)
            if ok and not (observation=='EXITED' and self.all_eof()):
                self.attempt('cleanup:owned-SIGTERM',lambda:self.signal_owned_group(signal.SIGTERM))
                self.cleanup_until(2)
                if self.ownership=='HELD':
                    ok,observation=self.attempt('cleanup:post-TERM-WNOWAIT',self.observe_owned)
                    if ok and not (observation=='EXITED' and self.all_eof()):
                        self.attempt('cleanup:owned-SIGKILL',lambda:self.signal_owned_group(signal.SIGKILL));self.cleanup_until(5)
            if self.ownership=='HELD':
                ok,reaped=self.attempt('cleanup:final-reap',self.reap_exited)
                if ok and not reaped:self.secondary_error('cleanup:unreaped-child',ValueError('OWNED_CHILD_STILL_UNREAPED'))
        # No signal path exists below this point; bounded drain and all closes are independent.
        until=self.io['clockNs']()+2000000000;turns=0
        while self.selector is not None and not self.all_eof() and self.io['clockNs']()<until and turns<4096:
            turns+=1;self.pump(0.05,True)
        if self.process is not None:
            for name in ('stdin','stdout','stderr'):
                self.attempt('cleanup:pipe-close:'+name,lambda name=name:self.close_pipe(name))
        if self.selector is not None:self.attempt('cleanup:selector-close',self.selector.close)
        if self.process is not None and (self.ownership!='REAPED' or not self.all_eof()):
            self.secondary_error('cleanup:ownership-or-EOF',ValueError('OWNED_CLEANUP_NOT_CONFIRMED'))
    def cleanup_until(self,seconds):
        until=self.io['clockNs']()+seconds*1000000000;turns=0
        while self.ownership=='HELD' and self.io['clockNs']()<until and turns<4096:
            turns+=1;self.pump(0.05,True)
            ok,observation=self.attempt('cleanup:WNOWAIT',self.observe_owned)
            if not ok or observation=='EXITED' and self.all_eof():break
    def close_pipe(self,name):
        pipe=getattr(self.process,name,None)
        if pipe is not None and not pipe.closed:pipe.close()
    def capture(self):
        # Attempt every raw stream even after earlier storage/capture failures.
        for name,raw in [('stdin',b''),*[(k,bytes(v)) for k,v in self.out.items()]]:
            ok,d=self.attempt('capture:raw:'+name,lambda name=name,raw=raw:self.io['writeBytes'](self.directory/(name+'.bin'),raw))
            if ok:self.streams[name]=d
        self.capture_complete=all(self.streams.values())
        if (self.secondary or self.secondary_overflow or not self.capture_complete) and self.life['error'] is None:
            self.life['error']=error_fact(ValueError('OUTER_CLEANUP_OR_CAPTURE_UNQUALIFIED'))
        self.record={'schema':'i4-python-owned-case-v2','argv':self.argv,'cwd':str(self.directory),'environment':self.env,
                     'lifecycle':dict(self.life),'ownership':self.ownership,'primaryError':self.primary,
                     'secondaryErrors':list(self.secondary),'secondaryOverflow':self.secondary_overflow,'captureComplete':self.capture_complete,
                     'streams':dict(self.streams),'observedBytes':dict(self.total),'retainedBytes':{k:len(v) for k,v in self.out.items()},'phaseMonitor':self.phase}
        ok,d=self.attempt('capture:receipt',lambda:self.io['writeJSON'](self.directory/'receipt.json',self.record))
        if ok:self.receipt=d
        else:
            self.capture_complete=False
            if self.life['error'] is None:self.life['error']=error_fact(ValueError('OUTER_RECEIPT_CAPTURE_UNQUALIFIED'))
            # Fixed fallback is bounded diagnostic evidence, not a substituted receipt.
            b=(json.dumps({'schema':'i4-outer-receipt-capture-failure-v1','primary':self.primary,'ownership':self.ownership,
                           'secondary':self.secondary,'overflow':self.secondary_overflow,'qualified':False})+'\n').encode()
            self.attempt('capture:bounded-stderr-fallback',lambda:self.io['stderr'](b[:8192]))
    def run(self):
        try:
            self.current();self.life.update(launchAttempt=True,acquisition='UNKNOWN')
            self.process=subprocess.Popen(self.argv,cwd=self.directory,env=self.env,stdin=subprocess.PIPE,
                                          stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,bufsize=0)
            self.ownership='HELD';self.life.update(acquisition='ACQUIRED',pid=self.process.pid)
            self.process.stdin.close();self.selector=selectors.DefaultSelector()
            for name in self.out:
                pipe=getattr(self.process,name);os.set_blocking(pipe.fileno(),False);self.selector.register(pipe,selectors.EVENT_READ,name)
            while True:
                self.watch_phases();observation=self.observe_owned()
                if observation=='EXITED' and self.all_eof():break
                self.pump(0.1)
            self.reap_exited()
        except BaseException as exc:self.primary_error(exc)
        finally:
            # Even unexpected cleanup failures cannot bypass all raw receipt writes.
            self.attempt('cleanup:outer-guard',self.cleanup)
            ok,_=self.attempt('capture:outer-guard',self.capture)
            if not ok:
                self.capture_complete=False
                if self.life['error'] is None:self.life['error']=error_fact(ValueError('OUTER_CAPTURE_UNQUALIFIED'))
                self.attempt('capture:last-bounded-diagnostic',lambda:self.io['stderr'](b'I4_OUTER_CAPTURE_UNQUALIFIED\n'))
        return bytes(self.out['stdout'])


class Checker:
    """Strict whole records plus independently joined current raw evidence.

    This is a checker, not a metadata implementation or a source of capabilities.
    It cannot independently attest inner OS PIDs; it revalidates source-owned
    receipts and exact captured bytes, while Python owns the case process above.
    """
    def __init__(self,ctx,cell,case,outer):
        self.ctx=ctx;self.cell=cell;self.case=case;self.outer=outer
        self.defs=A.document(A.DATA['bridge-schemas.json'])['definitions']
        self.rules=A.document(A.DATA['i4-oracle-rules.json']);self.worker=ctx['workers'][cell['caseId']]
        self.verified={};self.receives={};self.steps=[];self.native=None;self.generation=None;self.snapshot=None;self.consumer=None
    def raw(self,d):
        A.validate(d,'@descriptor',self.defs);p=Path(d['path'])
        A.need(p.is_relative_to(self.case) and p!=self.case,'OWNED_CASE_EVIDENCE_PATH')
        st=p.lstat();A.need(stat.S_IMODE(st.st_mode)==0o600 and st.st_uid==os.getuid(),'OWNED_0600_EVIDENCE')
        raw=A.checked(d);previous=self.verified.get(d['path']);A.need(previous is None or A.equal(previous,d),'IMMUTABLE_EVIDENCE_DESCRIPTOR')
        self.verified[d['path']]=d;return raw
    def doc(self,d,shape=None):
        value=A.loads(self.raw(d))
        if shape:A.validate(value,'@'+shape,self.defs)
        return value
    def common_spawn(self,d,kind,terminal):
        r=self.doc(d,'spawnReceipt');A.need(r['caseId']==self.cell['caseId'] and r['kind']==kind,'SAME_CASE_CHILD_KIND')
        A.need(A.equal(r['environment'],ENV),'EXACT_NATIVE_CHILD_ENV');life=r['lifecycle']
        if terminal:A.natural(life)
        else:
            A.need(life['launchAttempt'] is True and life['acquisition']=='ACQUIRED' and type(life['pid']) is int and life['pid']>0
                and life['exitCode'] is None and life['signal'] is None and life['reaped'] is False and life['stdoutEOF'] is False
                and life['stderrEOF'] is False and life['forced'] is False and life['timedOut'] is False and life['error'] is None,'LIVE_QUIESCENT_NATIVE_RECEIPT')
        A.need(self.raw(r['streams']['stderr'])==b'','EMPTY_NATIVE_STDERR')
        return r
    def receive(self,d,slot):
        r=self.doc(d,'receiveRecord');worker=self.worker;fixture_d=worker['dWire' if slot=='D' else 'fWire'];fixture=A.loads(A.checked(fixture_d))
        A.need(r['caseId']==self.cell['caseId'] and r['windowId']==self.cell['windowId'] and r['slot']==slot
            and r['subscription']=='nbdp-'+self.cell['caseId']+'-'+slot and r['outerId']==fixture['id'],'RECEIVE_ID_JOIN')
        spawn=self.common_spawn(r['spawn'],'WIRE_'+slot,True)
        A.need(A.equal(spawn['tool'],A.NODE) and spawn['cwd']==str(self.case/('wire-'+slot)),'WIRE_TOOL_CWD')
        binding_d=A.descriptor(self.case/('wire-'+slot)/'binding.json');binding=self.doc(binding_d,'wireBinding')
        A.need(A.equal(spawn['argv'],[A.NODE['path'],str(HERE/'wire.mjs'),binding_d['path'],binding_d['sha256']]),'FIXED_WIRE_COMMAND')
        A.need(binding['caseId']==self.cell['caseId'] and binding['slot']==slot and binding['relay']==self.cell['relay']
            and binding['outerId']==fixture['id'] and A.equal(binding['wire'],fixture_d)
            and A.equal(binding['closure'],self.ctx['sourceClosure']) and binding['output']==str(self.case/('wire-'+slot)/'output'),'WIRE_BINDING_JOIN')
        cli=one_line(self.raw(spawn['streams']['stdout']));A.validate(cli,'@wireCLIReply',self.defs)
        A.need(cli['qualified'] is True and cli['caseId']==r['caseId'] and cli['slot']==slot and A.equal(cli['report'],r['report']),'WIRE_CLI_JOIN')
        report=self.doc(r['report'],'wireReport');A.need(report['qualified'] is True and report['caseId']==r['caseId'] and report['slot']==slot
            and report['error'] is None and report['publicationCount']==report['queryCount']==report['eventCount']==1
            and A.equal(report['close'],{'code':1000,'reasonHex':''}),'WHOLE_WIRE_REPORT')
        sequence=[('SEND','EVENT'),('RECEIVE','ACK'),('SEND','REQ'),('RECEIVE','EVENT'),('RECEIVE','EOSE'),('SEND','CLOSE')]
        A.need(len(report['frames'])==6,'SIX_WIRE_FRAMES');raw_total=0;span=None
        for i,(direction,kind) in enumerate(sequence):
            frame=report['frames'][i];A.need(frame['direction']==direction and frame['kind']==kind,'WIRE_FRAME_ORDER')
            raw=bytes.fromhex(frame['rawHex']);raw_total+=len(raw);A.need(len(raw)<=262144 and raw_total<=2097152,'WIRE_RAW_BOUND');value=A.loads(raw)
            if i==0:A.need(raw==b'["EVENT",'+A.checked(fixture_d)+b']','EXACT_SIGNED_PUBLICATION_BYTES')
            elif i==1:A.need(type(value) is list and len(value)==4 and value[:3]==['OK',fixture['id'],True] and value[2] is True and type(value[3]) is str,'EXACT_TRUE_ACK')
            elif i==2:A.need(A.equal(value,['REQ',r['subscription'],{'ids':[fixture['id']],'limit':1}]),'EXACT_ID_QUERY')
            elif i==3:
                A.need(type(value) is list and len(value)==3 and value[:2]==['EVENT',r['subscription']] and A.equal(value[2],fixture),'EXACT_RECEIVED_TYPED_EVENT')
                text=raw.decode('utf-8');decoder=json.JSONDecoder();offset=1
                for _ in range(2):
                    while text[offset] in ' \t\r\n':offset+=1
                    _,offset=decoder.raw_decode(text,offset)
                    while text[offset] in ' \t\r\n':offset+=1
                    A.need(text[offset]==',','RAW_EVENT_SEPARATOR');offset+=1
                while text[offset] in ' \t\r\n':offset+=1
                _,end=decoder.raw_decode(text,offset);start_byte=len(text[:offset].encode());end_byte=len(text[:end].encode());span=raw[start_byte:end_byte]
                A.need(r['eventFrameIndex']==3 and r['spanStart']==start_byte and r['spanEnd']==end_byte
                    and self.raw(r['eventSpan'])==span and report['wireHex']==span.hex(),'ACTUAL_EVENT_RAW_SPAN')
            elif i==4:A.need(A.equal(value,['EOSE',r['subscription']]),'EXACT_EOSE')
            else:A.need(A.equal(value,['CLOSE',r['subscription']]),'EXACT_CLOSE_REQUEST')
        A.need(span is not None and self.raw(spawn['streams']['stdin'])==b'','WIRE_RAW_CUSTODY')
        self.receives[slot]=(d,r,span,spawn);return r
    def metadata(self,d):
        n=self.doc(d,'nativeCallRecord');A.need(n['caseId']==self.cell['caseId'] and n['windowId']==self.cell['windowId'] and n['backend']==self.cell['metadataBackend']
            and n['ordinal']==0 and n['replyObserved'] is True and n['channelAlive'] is True and n['pendingOutputBytes']==0 and n['terminalLifecycle'] is None,'WHOLE_NATIVE_CALL_RECORD')
        A.need(A.equal(n['dReceive'],self.receives['D'][0]) and A.equal(n['fReceive'],self.receives['F'][0]),'NATIVE_RECEIVE_BINDINGS')
        request_raw=self.raw(n['request']);request=one_line(request_raw);A.validate(request,'@nativeRequest',self.defs)
        wanted={'op':'correlate-file-metadata','secretHex':self.worker['secretHex'],'config':self.worker['scope'],
                'dWireHex':self.receives['D'][2].hex(),'fWireHex':self.receives['F'][2].hex()}
        A.need(A.equal(request,wanted),'ACTUAL_REQUEST_SPAN_JOIN')
        reply_raw=self.raw(n['reply']);reply=one_line(reply_raw);A.validate(reply,'@nativeReply',self.defs)
        expected=A.document(self.cell['metadataExpected']);A.need(A.equal(reply,expected),'WHOLE_NATIVE_EXPECTED_REPLY')
        live=self.common_spawn(n['channelReceipt'],'METADATA',False)
        A.need(self.raw(live['streams']['stdin'])==request_raw and self.raw(live['streams']['stdout'])==reply_raw,'LIVE_NATIVE_PIPE_CAPTURE')
        if self.cell['metadataBackend']=='JS':
            A.need(A.equal(live['tool'],A.NODE),'JS_TOOL');bd=A.descriptor(self.case/'metadata'/'binding.json');binding=self.doc(bd,'nativeBinding')
            A.need(A.equal(live['argv'],[A.NODE['path'],str(HERE/'metadata_loader.mjs'),bd['path'],bd['sha256']]) and binding['caseId']==self.cell['caseId']
                and binding['windowId']==self.cell['windowId'] and A.equal(binding['scope'],self.worker['scope']) and A.equal(binding['closure'],self.ctx['sourceClosure'])
                and A.equal(binding['dFixture'],self.worker['dWire']) and A.equal(binding['fFixture'],self.worker['fWire']),'JS_NATIVE_BINDING_JOIN')
            A.need(self.raw(A.descriptor(self.case/'metadata'/'native-reply.jsonl'))==reply_raw,'JS_RETAINED_REPLY_CUSTODY')
        else:A.need(A.equal(live['tool'],A.RUST) and A.equal(live['argv'],[A.RUST['path']]),'RUST_TOOL_COMMAND')
        A.need(live['cwd']==str(self.case/'metadata'),'NATIVE_CWD');self.native=(d,n,live,reply)
    def generation_record(self,d):
        g=self.doc(d,'generation');native=self.native[3];body=native['validation']['D']['rawReply']['codec']['message'];file=body['file'];document=body['document']
        subject={'dRumorId':native['dRumorId'],'fRumorId':native['fRumorId'],'peer':body['from'],'local':body['to'],'context':body['context'],
                 'url':self.worker['scope']['allowedOrigin']+'/'+file['x'],'media':document['media'],'key':file['key'],'nonce':file['nonce'],
                 'x':file['x'],'ox':file['ox'],'bytes':document['bytes'],'blobBytes':file['bytes']}
        expected={'schema':'i4-immutable-generation-v1','caseId':self.cell['caseId'],'windowId':self.cell['windowId'],'label':'G-'+self.cell['caseId'],
                  'role':'incoming','subject':subject,'engine':self.cell['engine'],'dReceive':self.receives['D'][0],'fReceive':self.receives['F'][0],
                  'nativeCall':self.native[0],'sealedAfter':self.cell['caseId']+'-S03','allowance':1}
        A.need(A.equal(g,expected),'WHOLE_IMMUTABLE_GENERATION_JOIN');self.generation=(d,g)
    def snapshot_record(self,d):
        s=self.doc(d,'snapshot');A.need(s['caseId']==self.cell['caseId'] and A.equal(s['generation'],self.generation[0]) and s['actualBytes']==20
            and s['actualSHA256']==self.rules['snapshotFacts']['x'] and s['ended'] is True and s['responseComplete'] is True and s['useCount']==0,'WHOLE_SNAPSHOT_FACTS')
        blob=self.raw(s['blob']);A.need(len(blob)==20 and hashlib.sha256(blob).hexdigest()==self.rules['snapshotFacts']['x'],'ACTUAL_RECEIVED_BLOB_HASH')
        reservation=self.doc(s['reservation'],'reservation');A.need(A.equal(reservation,{'schema':'i4-attempt-reservation-v1','caseId':self.cell['caseId'],
            'generation':self.generation[0],'ordinal':1,'consumed':True,'effectState':'NOT_STARTED','recordedBeforeSideEffect':True}),'WHOLE_RESERVED_ALLOWANCE')
        transport=self.doc(s['acquisition']);A.need(transport['schema']=='e06-https-acquisition-record-v1' and transport['id']==self.cell['caseId']
            and transport['completeSnapshot'] is True and transport['bodyObservedBytes']==transport['bodyRetainedBytes']==20 and transport['bodySha256']==s['actualSHA256']
            and transport['acquisitionConnections']==transport['httpGets']==1 and transport['responseComplete'] is True and transport['ended'] is True
            and transport['harnessCleanupQualified'] is True and transport['cleanupProblems']==[] and transport['errors']==[] and transport['componentFault'] is False
            and transport['errorEvidenceOverflow'] is False and transport['client']['retainedBodyHex']==blob.hex()
            and transport['client']['authorized'] is True and transport['client']['responseComplete'] is True and transport['client']['responseEnd'] is True
            and transport['client']['statusCode']==200 and transport['server']['socketEvidenceComplete'] is True,'ACTUAL_TRANSPORT_RESULT_JOIN')
        self.snapshot=(d,s)
    def consumer_record(self,d):
        c=self.doc(d,'privateConsumer');A.need(c['caseId']==self.cell['caseId'] and A.equal(c['generation'],self.generation[0]) and A.equal(c['snapshot'],self.snapshot[0])
            and c['engine']==self.cell['engine'] and c['status']=='PRIVATE_VERIFIED' and c['stage']=='ORIGINAL_COMMITMENT' and c['reason']=='PRIVATE_ORIGINAL_VERIFIED'
            and c['originalHex']==self.rules['snapshotFacts']['originalHex'] and c['consumerCalls']==1 and c['attachmentEncryptions']==0 and c['cleanupQualified'] is True,'WHOLE_PRIVATE_CONSUMER')
        journal=self.doc(c['journal'],'engineJournal');A.need(journal['id']==self.cell['caseId'] and journal['route']==self.cell['engine'] and A.equal(journal['subject'],self.generation[1]['subject'])
            and A.equal(journal['snapshot'],{'bytes':20,'sha256':self.rules['snapshotFacts']['x']}) and journal['fileConsumerCalls']==1 and journal['attachmentEncryptions']==0
            and journal['outcome']=='RETURNED' and journal['nativeError'] is None and journal['componentError'] is None and journal['captureErrors']==[] and journal['finalized'] is True,'FINAL_ACTUAL_ENGINE_JOURNAL')
        fact=self.doc(c['nativeFact']);A.closed(fact,('schema','route','status','stage','reason','originalHex','fileConsumerCalls','attachmentEncryptions','journal','browser','cleanupQualified','record'))
        A.need(fact['schema']=='e06-https-native-consumer-fact-v1' and fact['route']==self.cell['engine'] and fact['status']=='VERIFIED_BYTES'
            and fact['originalHex']==c['originalHex'] and fact['fileConsumerCalls']==1 and fact['attachmentEncryptions']==0 and fact['cleanupQualified'] is True
            and fact['record'] is None and A.equal(fact['journal'],journal) and A.equal(fact['browser'],c['browser']),'WHOLE_PRIVATE_NATIVE_FACT_JOIN')
        browser=c['browser'];A.need(browser['cleanupUncertain'] is False and browser['startError'] is None,'BROWSER_CERTAIN')
        if self.cell['engine']=='ChromeWebCrypto':A.need(browser['started'] is True and browser['browserCloseAttempted'] is True and browser['browserCloseSucceeded'] is True
            and browser['browserCloseError'] is None and browser['serverCloseAttempted'] is True and browser['serverCloseSucceeded'] is True and browser['serverCloseError'] is None,'OWNED_CHROME_CLOSE')
        else:A.need(browser['started'] is False and browser['browserCloseAttempted'] is False and browser['serverCloseAttempted'] is False,'NODE_NO_BROWSER')
        self.consumer=(d,c)
    def check(self,cli):
        A.natural(self.outer.life);A.need(self.outer.total['stderr']==0,'CASE_OUTER_STDERR');A.validate(cli,'@caseCLIReply',self.defs)
        A.need(cli['caseId']==self.cell['caseId'] and cli['windowId']==self.cell['windowId'] and cli['qualified'] is True and len(cli['stepRecords'])==7
            and cli['notExecuted']==[] and cli['caseCleanupQualified'] is True and cli['finalIntegrity'] is True and cli['error'] is None,'WHOLE_CASE_REPLY')
        for i,d in enumerate(cli['stepRecords']):
            step=self.doc(d,'step');rule=self.rules['steps'][i];index=i+1
            A.need(step['stepId']==self.cell['caseId']+'-'+rule['suffix'] and all(step[k]==rule[k] for k in ('phase','decision','status','stage','reason')),'EXACT_SUCCESS_STEP')
            A.need(A.equal(step['counts'],dict(zip(self.rules['counterOrder'],self.rules['successCountersByStep'][i])))
                and step['receiptsEmitted'] is False and step['businessEffects']==0 and step['invalidation'] is None,'WHOLE_STEP_COUNTERS_AND_EFFECTS')
            for slot in ('D','F'):
                required=slot=='D' or index>=2;value=step['eventProvenance'][slot]
                if required:
                    if slot not in self.receives:self.receive(value,slot)
                    A.need(A.equal(value,self.receives[slot][0]),'IMMUTABLE_RECEIVE_REFERENCE')
                else:A.need(value is None,'NO_PREMATURE_F')
            if index>=3:
                if self.native is None:self.metadata(step['metadataRecord'])
                A.need(A.equal(step['metadataRecord'],self.native[0]) and step['associationState']=='ONE_CANONICAL_F','IMMUTABLE_NATIVE_REFERENCE')
            else:A.need(step['metadataRecord'] is None and step['associationState']=='NONE','NO_PREMATURE_NATIVE')
            if index>=4:
                if self.generation is None:self.generation_record(step['generation'])
                A.need(A.equal(step['generation'],self.generation[0]) and step['eligibility']=='ELIGIBLE','IMMUTABLE_GENERATION_REFERENCE')
            else:A.need(step['generation'] is None and step['eligibility']=='NOT_ELIGIBLE','NO_PREMATURE_GENERATION')
            if index>=5:
                if self.snapshot is None:self.snapshot_record(step['snapshot'])
                A.need(A.equal(step['snapshot'],self.snapshot[0]),'IMMUTABLE_SNAPSHOT_REFERENCE')
            else:A.need(step['snapshot'] is None,'NO_PREMATURE_SNAPSHOT')
            if index>=6:
                if self.consumer is None:self.consumer_record(step['nativeConsumerRecord'])
                A.need(A.equal(step['nativeConsumerRecord'],self.consumer[0]),'IMMUTABLE_CONSUMER_REFERENCE')
            else:A.need(step['nativeConsumerRecord'] is None,'NO_PREMATURE_CONSUMER')
            A.need(step['originalHex']==(self.rules['snapshotFacts']['originalHex'] if index==7 else None) and step['originalReleased'] is (index==7),'PUBLIC_DISCLOSURE_ORDER')
            life=step['lifecycle'];A.need(life['caseHostPID']==self.outer.life['pid'] and life['caseOuterReap'] is None,'ACTUAL_CASE_PID_JOIN')
            A.need(A.equal(life['wireD'],self.receives['D'][1]['spawn']) and A.equal(life['wireF'],self.receives['F'][1]['spawn'] if index>=2 else None),'WHOLE_WIRE_LIFECYCLE_REFERENCES')
            wanted_state='TERMINAL_QUALIFIED' if index==7 else 'ALIVE_QUIESCENT' if index>=3 else 'NOT_STARTED'
            A.need(life['metadataChannel']==wanted_state and A.equal(life['metadataTerminal'],cli['metadataTerminal'] if index==7 else None),'NATIVE_TERMINAL_FRONTIER')
            A.need(A.equal(step['cleanup'],{'relayWireChildren':'QUALIFIED','https':'QUALIFIED' if index>=5 else 'NOT_STARTED','consumer':'QUALIFIED' if index>=6 else 'NOT_STARTED',
                'metadata':'QUALIFIED' if index==7 else 'ALIVE_QUIESCENT' if index>=3 else 'NOT_STARTED','problems':[]})
                and A.equal(step['integrity'],{'sourceCurrent':True,'inputsCurrent':True,'evidenceComplete':True}),'WHOLE_CLEANUP_INTEGRITY_SHAPE')
            self.steps.append(d)
        terminal=self.common_spawn(cli['metadataTerminal'],'METADATA',True);live=self.native[2]
        for key in ('tool','argv','cwd','environment'):A.need(A.equal(terminal[key],live[key]),'SAME_TERMINAL_NATIVE_CHILD')
        A.need(terminal['lifecycle']['pid']==live['lifecycle']['pid'] and self.raw(terminal['streams']['stdin'])==self.raw(self.native[1]['request'])
            and self.raw(terminal['streams']['stdout'])==self.raw(self.native[1]['reply']),'TERMINAL_EXACT_ONE_REQUEST_REPLY')
        A.need(A.equal(cli['finalObservation'],self.steps[-1]),'FINAL_OBSERVATION_EQUALS_S07')
        for desc in self.verified.values():A.checked(desc)
        return {'matched':True,'scope':'FOUR_POSITIVE_I4_TRACES_ONLY','stepRecords':self.steps,'verifiedEvidence':list(self.verified.values())}


def run(ctx):
    m=ctx['manifest'];out=Path(ctx['output']);out.mkdir(mode=0o700);started=time.monotonic();deadline=started+1500
    capture={'schema':'i4-python-composition-capture-v1','qualified':False,'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],
             'cases':[],'notExecuted':[],'labCleanup':None,'finalIntegrity':False,'errors':[],
             'limits':['SHARED_HOST_HARNESS_INPUTS','FOUR_POSITIVE_I4_TRACES_ONLY','NO_LAB_N_RUNTIME_EVIDENCE','NO_RECEIPT_BUSINESS_EFFECT_DURABILITY_GLOBAL_FINALITY_FS_OR_WHOLE_E06']}
    lab=None;entered=False;failure=None;all_evidence={};inputs=[ctx['manifestDescriptor'],ctx['releaseDescriptor'],*m['workerInputs'].values()]
    def current():
        A.need(time.monotonic()<deadline,'PHASE_DEADLINE');A.closure(ctx['sourceClosure'])
        for d in inputs:A.need(A.equal(A.descriptor(d['path']),d),'ORIGINAL_RUNNER_INPUT_DRIFT')
        for d in all_evidence.values():A.checked(d)
    try:
        current();put_json(out/'admission.json',{'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],'sourceClosure':ctx['sourceClosure']})
        contract=A.document(A.DATA['contract.json']);old_d=contract['sourceLineage']['experiments/prototypes/e06_relay_metadata_v1/selection.json']
        mapping=A.closure(ctx['sourceClosure']);A.member(mapping,old_d);old=A.document(old_d);provenance=old['relayProvenance'];assets=provenance['assets']
        required=[assets['supervisor'],assets['strfryConfig'],assets['rsRelayConfig'],provenance['dockerToolReference'],A.PYTHON]
        for d in required:A.member(mapping,d);A.need(A.equal(A.descriptor(d['path']),d),'CURRENT_LAB_INPUT');inputs.append(d)
        inputs.append(old_d);current()
        spec=importlib.util.spec_from_file_location('_i4_exact_isolated_relay_lab',assets['supervisor']['path']);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
        A.need(A.equal(helper.IMAGES,provenance['imageIds']) and A.equal(helper.PORTS,{'strfry':(17777,7777),'rs-relay':(18081,8080)}),'FIXED_LAB_IMAGES_ENDPOINTS')
        config={'scope':'CURRENT_CARRIER_TWO_RELAY_LAB_ONLY','execution_allowed':True,'run_id':m['runId'],
                'files':{'supervisor':assets['supervisor'],'python':A.PYTHON,'docker':provenance['dockerToolReference'],
                         'strfry_config':assets['strfryConfig'],'rs_relay_config':assets['rsRelayConfig']}}
        lab=helper.RelayLab(config,out/'lab');tick=time.monotonic();lab.__enter__();entered=True
        capture['labStartupMilliseconds']=round((time.monotonic()-tick)*1000);A.need(capture['labStartupMilliseconds']<=360000,'LAB_STARTUP_BOUND')
        selection=A.document(A.DATA['selection-map.json'])
        for cell in selection['initialWindows']:
            current();lab.assert_healthy();case=out/cell['caseId'];case.mkdir(mode=0o700);monitor=case/'outer-monitor';monitor.mkdir(mode=0o700)
            frame={'schema':'i4-case-private-frame-v1','lane':'LAB-I4','caseId':cell['caseId'],'windowId':cell['windowId'],
                   'manifest':ctx['manifestDescriptor'],'release':ctx['releaseDescriptor'],'workerData':m['workerInputs'][cell['caseId']],'output':str(case)}
            defs=A.document(A.DATA['bridge-schemas.json'])['definitions'];A.validate(frame,'@frame',defs);fd=put_json(case/'frame.json',frame)
            env=dict(ENV,NBDP_CHROME='/opt/google/chrome/chrome');argv=[A.NODE['path'],str(HERE/'acquisition.mjs'),fd['path'],fd['sha256']]
            child=OwnedCase(argv,monitor,env,min(deadline,time.monotonic()+240),current,phase_progress=(case,cell['caseId']))
            row={'caseId':cell['caseId'],'frame':fd,'qualified':False,'outer':None,'reply':None,'comparison':None,'error':None};capture['cases'].append(row)
            try:
                raw=child.run();row['outer']=child.receipt
                if raw:
                    value=one_line(raw);row['reply']=value
                    A.validate(value,'@caseCLIReply',defs)
                else:raise ValueError('NO_CASE_CLI_REPLY')
                checker=Checker(ctx,cell,case,child);result=checker.check(value)
                comparison=put_json(case/'outer-comparison.json',result);row['comparison']=comparison;row['qualified']=True
                all_evidence.update(checker.verified);all_evidence[comparison['path']]=comparison
                for d in child.streams.values():all_evidence[d['path']]=d
                all_evidence[child.receipt['path']]=child.receipt;all_evidence[fd['path']]=fd;current();lab.assert_healthy()
            except BaseException as exc:row['error']=error_fact(exc);raise
        A.need([r['caseId'] for r in capture['cases']]==['C01','C02','C03','C04'] and all(r['qualified'] for r in capture['cases']),'FOUR_CASE_WHOLE_COMPARISONS')
    except BaseException as exc:failure=exc;capture['errors'].append(error_fact(exc))
    finally:
        if entered:
            tick=time.monotonic()
            try:lab.__exit__(type(failure) if failure else None,failure,None)
            except BaseException as exc:capture['errors'].append(error_fact(exc))
            capture['labCleanupMilliseconds']=round((time.monotonic()-tick)*1000)
            if capture['labCleanupMilliseconds']>60000:capture['errors'].append(error_fact(ValueError('FINAL_LAB_CLEANUP_BOUND')))
        cleanup=out/'lab'/'cleanup.json'
        try:
            d=A.descriptor(cleanup);v=A.document(d);capture['labCleanup']=d
            A.need(v['qualified'] is True and v['problems']==[] and v['uncertain_creates']==[],'ACTUAL_OWNED_LAB_CLEANUP')
        except BaseException as exc:capture['errors'].append(error_fact(exc))
        try:
            ctx['recheckAuthorityEvidence']()  # Original admission referents, after actual lab cleanup.
            current();capture['finalIntegrity']=True
        except BaseException as exc:capture['errors'].append(error_fact(exc))
        done={r['caseId'] for r in capture['cases']}
        capture['notExecuted']=[{'caseId':c,'reason':'EARLIER_FAILURE'} for c in ['C01','C02','C03','C04'] if c not in done]
        capture['elapsedMilliseconds']=round((time.monotonic()-started)*1000)
        capture['qualified']=not capture['errors'] and not capture['notExecuted'] and len(capture['cases'])==4 and all(r['qualified'] for r in capture['cases']) and capture['finalIntegrity']
        # Bounded inventory also retains rejected/partial native replies and raw stdout/stderr.
        # No accepted historical tree is walked. No failure record is replaced by a success oracle.
        try:
            files=[];total=0
            for p in sorted(out.rglob('*')):
                A.need(not p.is_symlink(),'OWNED_OUTPUT_NO_SYMLINK')
                if p.is_file():
                    d=A.descriptor(p);total+=d['bytes'];A.need(len(files)<2048 and total<=33554432,'OWNED_EVIDENCE_PACK_BOUND');files.append(d)
            capture['artifactManifest']=put_json(out/'artifact-manifest.json',{'schema':'i4-owned-output-inventory-v1','files':files,'bytes':total,
                'excludes':['artifact-manifest.json','capture.json'],'meaning':'Current pre-finalization owned files; outer assembly must pin inventory and final capture separately.'})
        except BaseException as exc:capture['errors'].append(error_fact(exc));capture['qualified']=False
        put_json(out/'capture.json',capture)
    return 0 if capture['qualified'] else 1


def main(argv):
    if len(argv)!=7:raise ValueError('CLI runner.py MANIFEST SHA RELEASE SHA EXECUTION_SESSION primary|qa')
    a=bootstrap();ctx=a.verify(argv[1],argv[2],argv[3],argv[4],argv[5],argv[6])
    # The pure verifier completes before importing lab helpers or starting any process.
    return run(ctx)


if __name__=='__main__':
    try:code=main(sys.argv)
    except BaseException as exc:sys.stderr.write(type(exc).__name__+': '+str(exc)[:16384]+'\n');code=2
    raise SystemExit(code)
