# Experimental invoice message codec component

**SOURCE PREPARATION ONLY — NO CODEC BUILD OR RUNTIME RELEASE AT THIS CHECKPOINT.**

This isolated component implements the reviewed invoice delivery/receipt proposal
sections 1–2 as pure structural parsing and comparison. The frozen
`contract.json` defines the exact local harness RPC and refusal precedence.
`cases.json` contains 93 groups / 283 explicit input-oracle variants, all
NOT_EXECUTED with null actual results. Two separately reviewed compound-precedence
regressions in `source-review-controls.json` supplement that unchanged corpus:
95 groups / 285 variants are scheduled in total. Existing schemas, sources and the symbolic
invoice conformance descriptions remain unchanged.

Separate actual authors prepare `js/codec.mjs` and `rust/src/main.rs` from the
same independently reviewed contract/oracles, without reading or copying each
other's implementation. JavaScript uses Node standard facilities; Rust uses
pinned serde 1.0.228 and serde_json 1.0.145 with `raw_value`. Existing Node 22.18.0
and Rust/Cargo 1.90.0 are available. The separately authorized offline metadata-only
lockfile preparation is distinct from compilation or codec evaluation.

The component checks raw UTF8 and scalar strings, decoded duplicate keys, lexical
unsigned safe integers, closed declaration schemas and exact local expectations.
Receipt comparison independently validates the retained original declaration,
keeps its A→B direction, and compares every nested value plus supplied D/F IDs,
receipt B→A direction, context and optional persistence-domain expectation.
Parsed whole objects and exact original bytes remain separate; there is no JSON
canonicalizer, rumor-ID computation, signature or document transformation.

Every response has `authentication: NOT_EVALUATED`. H64/H24 keys, commitments,
rumor IDs and domains are format-only declarations. Parsing `verified-durable`
verifies no bytes, durability, authority or issuer. Even a structural subject match
does not prove supplied IDs correspond to the retained bytes. No result invokes
L1 admission, storage, fetching, signing, a technical receipt or business action.

Future evaluation requires independent source/dependency/harness review and a
separate frozen build/runtime release. The coordinator-owned evidence runner
then builds a fresh private Rust working copy **offline with the reviewed lock**,
runs identical JSON-lines requests through both implementations and compares
complete typed results against all 283 original outcomes plus the two source-review
controls. It preserves raw
streams, actual commands/exits, binary/source/tool pins and all failures. An actual
independent QA session must rebuild/rerun separately; authors approve no findings.

The proposed command, **not a release**, is:

```sh
python3 -I -B docs/decisions/evidence/invoice-message-codec/run_codec.py primary
```

The runner uses pinned GNU timeout supervision for the non-detaching build and
two processes. Each build is bounded at 120 seconds plus a 2-second kill interval;
each codec process at 30 seconds plus 2 seconds. Nonzero, timeout or signal is
unqualified. It retains a newly owned `/tmp/nbdp-invoice-codec-*` workspace and
raw phase receipts. This is no general guarantee after external supervisor kill,
and no forced deadline test is claimed. Build paths/debug binary hashes may differ
between independent runs. Output equality is complete typed value equality, not
serialized object-member order. The corpus is never rewritten with actual results.

These are component-level parser checks, not Nostr client interoperability,
cryptographic or acquired-original verification, hostile resource measurement,
E04/E06/full IC execution, business approval or SDK readiness. No network,
cryptographic material generation, real data, deployments, commits or publication
belong here. Canonical E02 remains PARTIAL; required E04/E06 and E08/E09/E12 gates,
all five blockers, conditional Option B, no baseline FS, parallel-device and
Satflux-independence boundaries remain unchanged.

Later actual results belong in
`docs/decisions/evidence/invoice-message-codec/`; this source README preserves its
preparation checkpoint and does not assert a test result.
