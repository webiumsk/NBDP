/** Fixed isolated E06 acquisition component. SOURCE ONLY / NOT_EXECUTED.
 * Not a library or public fetch API. Requires a separately released private frame.
 * Parser/retention bounds below do not claim raw-wire, TLS-buffer or RSS bounds.
 */
import https from 'node:https';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {
  loadCaseContext, runOwnedWire, startNative, authenticateReceived, sealWindow,
  reserveAcquisition, getAuthenticated, createSnapshot, checkpointEligible,
  assertCurrent, writeRecord, getConsumerFact, closeMetadata, closeoutAndPublish,
} from './protocol.mjs';

const COMPONENT = 'RELAY_TO_HTTPS_COMPOSITION_I4_ONLY';
const LIMITATIONS = 'NO_DURABILITY_NO_RECEIPT_NO_BUSINESS_EFFECTS_NO_GLOBAL_E06_CLAIM';
const CERTIFICATE_CODES = new Set([
  'ERR_TLS_CERT_ALTNAME_INVALID', 'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'UNABLE_TO_GET_ISSUER_CERT', 'UNABLE_TO_GET_ISSUER_CERT_LOCALLY',
  'DEPTH_ZERO_SELF_SIGNED_CERT', 'SELF_SIGNED_CERT_IN_CHAIN',
  'CERT_HAS_EXPIRED', 'CERT_NOT_YET_VALID', 'CERT_SIGNATURE_FAILURE',
]);
class Refusal extends Error {
  constructor(code, stage) { super(code); this.name = 'AcquisitionRefusal'; this.code = code; this.stage = stage; }
}
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

// Error fields are native when present, including the original stack. If a native
// error is too large, retain an explicitly incomplete prefix and fail qualification.
function errorFact(error, evidence) {
  const fact = error === null || error === undefined || typeof error !== 'object'
    ? {name: typeof error, message: String(error), code: null, stack: null}
    : {name: String(error.name ?? 'Error'), message: String(error.message ?? ''),
      code: error.code === undefined ? null : String(error.code),
      stack: error.stack === undefined ? null : String(error.stack)};
  const text = JSON.stringify(fact);
  if (Buffer.byteLength(text) <= 65536) return fact;
  evidence.errorEvidenceOverflow = true;
  return {complete: false, utf8PrefixHex: Buffer.from(text).subarray(0, 65536).toString('hex')};
}
function rememberError(record, owner, error) {
  if (record.errors.length === 16) { record.errorEvidenceOverflow = true; return; }
  record.errors.push({owner, error: errorFact(error, record)});
}

// Build the exact JSON representation incrementally into a fixed16KiB buffer.
// Individual escaped code points are bounded; an overflow is never a complete
// transcript. rawHeaders contains parsed duplicate-preserving strings, not wire.
function parsedHeaders(statusCode, rawHeaders, limit) {
  const storage = Buffer.alloc(limit);
  let retained = 0, encodedBytes = 0;
  const append = fragment => {
    const bytes = Buffer.from(fragment, 'utf8');
    encodedBytes += bytes.length;
    const copied = Math.min(bytes.length, limit - retained);
    if (copied > 0) { bytes.copy(storage, retained, 0, copied); retained += copied; }
  };
  append(`{"kind":"PARSED_DUPLICATE_PRESERVING_HEADERS_JSON_UTF8","complete":true,"statusCode":${statusCode},"rawHeaders":[`);
  for (let i = 0; i < rawHeaders.length; i++) {
    if (i) append(',');
    append('"');
    for (const codePoint of rawHeaders[i]) append(JSON.stringify(codePoint).slice(1, -1));
    append('"');
  }
  append(']}');
  if (encodedBytes <= limit) return JSON.parse(storage.subarray(0, retained).toString('utf8'));
  // Retaining a hex-encoded16KiB prefix would itself exceed16KiB. On overflow,
  // retain only this small incomplete fact, never a larger escaped transcript.
  return {kind: 'PARSED_DUPLICATE_PRESERVING_HEADERS_JSON_UTF8',
    complete: false, refusedEncodedBytes: encodedBytes, retainedHeaderValues: false};
}

function initialRecord(ctx) {
  return {
    schema: 'e06-https-acquisition-record-v1', id: ctx.id,
    component: COMPONENT, parserAccounting: 'NODE_MAX_HEADER_SIZE_NOT_RAW_WIRE_BYTES',
    limits: {parserMaxHeaderSize: 16384, maxHeaderPairs: 64,
      parsedHeaderEvidenceBytes: 16384, retainedBodyBytes: 21},
    policy: {authenticated: false, permissionChecked: false, permitted: false,
      subjectPeerMatched: null, subjectURLMatched: null},
    server: {listenAttempted: false, listening: false, address: null,
      acceptedConnections: 0, droppedConnections: 0, requests: 0, gets: 0, sockets: [], socketEvidenceComplete: true,
      closeAttempted: false, closeCallback: false, closeError: null},
    client: {constructed: false, requestEndAttempted: false, finish: false,
      requestClose: false, socketAssigned: false, connectObserved: false,
      secureConnectObserved: false, authorized: null, authorizationError: null,
      peer: null, tlsProtocol: null, socketEnd: false, socketClose: false,
      socketCloseHadError: null, localRequestDestroy: false, localSocketDestroy: false,
      responseSeen: false, responseEnd: false, responseClose: false,
      responseAborted: false, responseComplete: null, statusCode: null,
      headerPairs: null, headers: null, headerEvidenceBytes: null, observedChunks: 0, observedBodyBytes: 0,
      retainedBodyBytes: 0, retainedBodyHex: '', observedBodySha256: null,
      timeoutStage: null, requestQueued: false, nativeErrorCount: 0},
    acquisitionConnections: 0, httpGets: 0, completeSnapshot: false,
    errors: [], errorEvidenceOverflow: false, harnessCleanupQualified: false,
    cleanupProblems: [], componentFault: false,
  };
}

function enforceProfile(ctx) {
  const p = ctx.profile;
  if (p.origin.scheme !== 'https:' || p.origin.hostname !== 'files.invalid' ||
      p.origin.port !== 18443 || p.origin.address !== '127.0.0.1' ||
      p.origin.family !== 4 || p.origin.servername !== 'files.invalid' ||
      p.origin.hostHeader !== 'files.invalid:18443' ||
      p.origin.path !== '/aba67e462b0ef41729c3bb31f1f50b98c4ae2245f20e9f1adb312174d18952c5' ||
      p.commitments.blobBytes !== 20 || p.http.bodyRetentionBytes !== 21 ||
      p.http.maxHeaderSize !== 16384 || p.http.maxHeadersCount !== 0 ||
      p.http.maxHeaderPairs !== 64 || p.http.parsedHeaderEvidenceBytes !== 16384 ||
      p.timersMs.serverStartup !== 5000 || p.timersMs.connect !== 3000 ||
      p.timersMs.tls !== 3000 || p.timersMs.headers !== 3000 ||
      p.timersMs.bodyIdle !== 1000 || p.timersMs.whole !== 10000 ||
      p.timersMs.ownedCleanup !== 5000) throw new Error('FIXED_PROFILE_DRIFT');
}

// The source-bound case table is closed. No frame flag chooses a response behavior.
function responseFor(ctx, res, record, timers) {
  res.on('error', error => rememberError(record, 'server-response', error));
  const headers = {'Content-Length': '20', 'Connection': 'close',
    'Content-Type': 'application/octet-stream'};
  const body = Buffer.from(ctx.blob);
  if (body.length !== 20 || sha256(body) !== ctx.profile.commitments.x) throw new Error('SERVER_FIXTURE_DRIFT');
  if (ctx.id === 'H06') {
    res.writeHead(302, {'Content-Length': '0', 'Connection': 'close',
      'Location': 'https://files.invalid:18443/never-follow'}); res.end();
  } else if (ctx.id === 'H07') {
    res.writeHead(404, {'Content-Length': '0', 'Connection': 'close'}); res.end();
  } else if (ctx.id === 'H09') {
    const over = Buffer.alloc(21); body.copy(over); over[20] = 1;
    res.writeHead(200, {...headers, 'Content-Length': '21'}); res.end(over);
  } else if (ctx.id === 'H08') {
    res.writeHead(200, headers); res.end(body.subarray(0, 10));
  } else if (ctx.id === 'H11') {
    res.writeHead(200, headers); res.flushHeaders();
    res.write(body.subarray(0, 5), () => {
      const timer = setTimeout(() => {
        timers.delete(timer); res.destroy();
      }, 20);
      timers.add(timer);
    });
  } else if (ctx.id === 'H12') {
    res.writeHead(200, headers); res.flushHeaders(); res.write(body.subarray(0, 1));
    // Deliberately no completion: the fixed client idle guard must abort it.
  } else {
    if (ctx.id === 'H10') body[0] ^= 1;
    res.writeHead(200, headers); res.end(body);
  }
}

function ownedTransport(ctx, record) {
  const p = ctx.profile;
  let server = null, request = null, response = null, clientSocket = null;
  let serverStarted = false, requestConstructing = false;
  let bodyStorage = null, bodyHash = null, bodyRetained = 0;
  const serverSockets = new Map(), behaviorTimers = new Set();
  const activeTimers = new Set();
  const clear = timer => { if (timer) { clearTimeout(timer); activeTimers.delete(timer); } };
  const timer = (ms, callback) => {
    const handle = setTimeout(() => { activeTimers.delete(handle); callback(); }, ms);
    activeTimers.add(handle); return handle;
  };
  const resources = {
    async start() {
      record.server.listenAttempted = true;
      // Binding the single exact port itself is the busy-port test. EADDRINUSE
      // fails without scanning, terminating a listener or selecting a fallback.
      server = https.createServer({key: ctx.tls.key, cert: ctx.tls.cert,
        minVersion: 'TLSv1.2', maxHeaderSize: 16384, insecureHTTPParser: false,
        handshakeTimeout: 3000, requestTimeout: 10000, headersTimeout: 3000}, (req, res) => {
        record.server.requests++;
        if (req.method === 'GET') record.server.gets++;
        if (record.server.requests !== 1 || req.method !== 'GET' ||
            req.url !== p.origin.path || req.headers.host !== p.origin.hostHeader) {
          if (!record.cleanupProblems.includes('UNEXPECTED_OWNED_SERVER_REQUEST')) record.cleanupProblems.push('UNEXPECTED_OWNED_SERVER_REQUEST');
          req.socket.destroy(); return;
        }
        try { responseFor(ctx, res, record, behaviorTimers); }
        catch (error) { rememberError(record, 'server-handler', error); res.destroy(); }
      });
      server.maxConnections = 1;
      server.on('drop', () => {
        record.server.droppedConnections++;
        if (!record.cleanupProblems.includes('DROPPED_EXCESS_CONNECTION')) record.cleanupProblems.push('DROPPED_EXCESS_CONNECTION');
      });
      server.on('connection', socket => {
        const fact = {index: record.server.acceptedConnections, end: false, close: false,
          closeHadError: null, localDestroy: false};
        if (record.server.sockets.length < 2) record.server.sockets.push(fact);
        else record.server.socketEvidenceComplete = false;
        serverSockets.set(socket, fact);
        record.server.acceptedConnections++;
        socket.on('end', () => { fact.end = true; });
        socket.on('close', hadError => { fact.close = true; fact.closeHadError = hadError; serverSockets.delete(socket); });
        socket.on('error', error => rememberError(record, 'server-socket', error));
        if (record.server.acceptedConnections > 1) {
          if (!record.cleanupProblems.includes('EXCESS_OWNED_SERVER_CONNECTION')) record.cleanupProblems.push('EXCESS_OWNED_SERVER_CONNECTION');
          fact.localDestroy = true; socket.destroy();
        }
      });
      server.on('tlsClientError', error => rememberError(record, 'server-tls', error));
      // Always retain asynchronous errors, including those after initial startup.
      server.on('error', error => rememberError(record, 'server', error));
      await new Promise((resolve, reject) => {
        const startup = timer(p.timersMs.serverStartup, () => {
          server.removeListener('listening', ready); server.removeListener('error', failed);
          reject(new Refusal('SERVER_STARTUP_TIMEOUT', 'server'));
        });
        const failed = error => { clear(startup); server.removeListener('listening', ready); reject(error); };
        const ready = () => {
          clear(startup); server.removeListener('error', failed); serverStarted = true;
          record.server.listening = true; record.server.address = server.address(); resolve();
        };
        server.once('error', failed); server.once('listening', ready);
        server.listen({host: '127.0.0.1', port: 18443, exclusive: true});
      });
    },
    async receive() {
      const storage = Buffer.alloc(21);
      const hash = createHash('sha256');
      bodyStorage = storage; bodyHash = hash;
      let stageTimer = null, idleTimer = null, wholeTimer = null;
      let settled = false;
      return await new Promise((resolve, reject) => {
        const complete = (error = null) => {
          if (settled) return; settled = true;
          clear(stageTimer); clear(idleTimer); clear(wholeTimer);
          if (error) reject(error);
          else resolve(Buffer.from(storage.subarray(0, bodyRetained)));
        };
        const abort = error => {
          if (request && !request.destroyed) { record.client.localRequestDestroy = true; request.destroy(); }
          complete(error);
        };
        const stage = (name, milliseconds, reason) => {
          clear(stageTimer);
          stageTimer = timer(milliseconds, () => {
            record.client.timeoutStage = name; abort(new Refusal(reason, name));
          });
        };
        const idle = () => {
          clear(idleTimer);
          idleTimer = timer(p.timersMs.bodyIdle, () => {
            record.client.timeoutStage = 'body'; abort(new Refusal('BODY_IDLE_TIMEOUT', 'body'));
          });
        };
        wholeTimer = timer(p.timersMs.whole, () => {
          record.client.timeoutStage = 'whole'; abort(new Refusal('WHOLE_ACQUISITION_TIMEOUT', 'transport'));
        });
        stage('connect', p.timersMs.connect, 'CONNECT_TIMEOUT');
        // Fallible construction can have effects before returning. Do not restore
        // a guessed zero if socket dispatch/cleanup cannot be established.
        requestConstructing = true; record.acquisitionConnections = null; record.httpGets = null;
        try {
          request = https.request({protocol: 'https:', hostname: 'files.invalid',
            port: 18443, path: p.origin.path, method: 'GET',
            family: 4, autoSelectFamily: false, servername: 'files.invalid',
            lookup(hostname, options, callback) {
              if (hostname !== 'files.invalid') { callback(new Error('UNEXPECTED_LOOKUP_HOST')); return; }
              record.acquisitionConnections = 1;
              callback(null, '127.0.0.1', 4);
            },
            ca: ctx.tls.ca, rejectUnauthorized: true, minVersion: 'TLSv1.2',
            agent: false, maxHeaderSize: 16384, insecureHTTPParser: false,
            headers: {Host: 'files.invalid:18443', 'Accept-Encoding': 'identity', Connection: 'close'},
          });
          // Must occur synchronously, before asynchronous dispatch. Unlimited
          // parsed visibility is followed by our explicit64-pair refusal.
          request.maxHeadersCount = 0;
          record.client.constructed = true; requestConstructing = false;
          request.on('finish', () => { record.client.finish = true; record.client.requestQueued = true; });
          request.on('close', () => { record.client.requestClose = true; });
          request.on('error', error => {
            record.client.nativeErrorCount++;
            rememberError(record, 'client-request', error);
            if (ctx.id === 'H05' && CERTIFICATE_CODES.has(error.code)) complete(new Refusal('TLS_CERTIFICATE_REFUSED', 'tls'));
            else if (record.client.responseAborted) complete(new Refusal(ctx.id === 'H11' ? 'TRANSFER_INTERRUPTED' : 'INCOMPLETE_ENTITY', 'body'));
            else complete(error);
          });
          request.on('socket', socket => {
            clientSocket = socket; record.client.socketAssigned = true;
            socket.on('connect', () => {
              record.client.connectObserved = true;
              record.client.peer = {address: socket.remoteAddress, port: socket.remotePort, family: socket.remoteFamily};
              if (socket.remoteAddress !== '127.0.0.1' || socket.remotePort !== 18443) {
                abort(new Refusal('ACTUAL_PEER_POLICY', 'connect')); return;
              }
              if (!settled) stage('tls', p.timersMs.tls, 'TLS_TIMEOUT');
            });
            socket.on('secureConnect', () => {
              record.client.secureConnectObserved = true; record.client.authorized = socket.authorized;
              record.client.authorizationError = socket.authorizationError === undefined ? null : String(socket.authorizationError);
              record.client.tlsProtocol = socket.getProtocol();
              if (socket.authorized !== true) { abort(new Refusal('TLS_NOT_AUTHORIZED', 'tls')); return; }
              if (!settled) stage('headers', p.timersMs.headers, 'HEADERS_TIMEOUT');
            });
            socket.on('end', () => { record.client.socketEnd = true; });
            socket.on('close', hadError => { record.client.socketClose = true; record.client.socketCloseHadError = hadError; });
            socket.on('error', error => { record.client.nativeErrorCount++; rememberError(record, 'client-socket', error); });
          });
          request.on('information', information => {
            rememberError(record, 'client-information', new Refusal(`UNEXPECTED_INFORMATION_${information.statusCode}`, 'headers'));
            abort(new Refusal('UNEXPECTED_INFORMATION', 'headers'));
          });
          request.on('upgrade', (res, socket) => {
            response = res; clientSocket = socket; abort(new Refusal('UNEXPECTED_UPGRADE', 'headers'));
          });
          request.on('response', res => {
            response = res; record.client.responseSeen = true;
            record.client.statusCode = res.statusCode; clear(stageTimer);
            // Install raw lifecycle/error listeners before any framing refusal.
            res.on('aborted', () => {
              record.client.responseAborted = true;
              complete(new Refusal(ctx.id === 'H11' ? 'TRANSFER_INTERRUPTED' : 'INCOMPLETE_ENTITY', 'body'));
            });
            res.on('error', error => { record.client.nativeErrorCount++; rememberError(record, 'client-response', error); if (!settled) complete(error); });
            res.on('close', () => {
              record.client.responseClose = true; record.client.responseComplete = res.complete;
              if (!settled && !record.client.responseEnd) complete(new Refusal('INCOMPLETE_ENTITY', 'body'));
            });
            res.on('end', () => {
              record.client.responseEnd = true; record.client.responseComplete = res.complete;
              if (settled) return;
              if (res.complete !== true || record.client.observedBodyBytes !== 20) { complete(new Refusal('INCOMPLETE_ENTITY', 'body')); return; }
              complete();
            });
            res.on('data', chunk => {
              // Even chunks racing with a refusal are counted and hashed in
              // full. Finalize the hash only after actual owned resource closure.
              if (!Buffer.isBuffer(chunk)) { abort(new Error('NON_BINARY_ENTITY')); return; }
              record.client.observedChunks++; record.client.observedBodyBytes += chunk.length;
              if (bodyHash) bodyHash.update(chunk);
              else {
                record.client.observedBodySha256 = null;
                if (!record.cleanupProblems.includes('DATA_AFTER_CLEANUP_BOUND')) record.cleanupProblems.push('DATA_AFTER_CLEANUP_BOUND');
              }
              const copied = Math.min(chunk.length, 21 - bodyRetained);
              if (copied > 0) { chunk.copy(storage, bodyRetained, 0, copied); bodyRetained += copied; }
              if (settled) {
                // A framing refusal can still have queued body events. Preserve
                // them without substituting a new reason or resetting timers.
                return;
              }
              if (record.client.observedBodyBytes > 20) { abort(new Refusal('ENTITY_OVERFLOW', 'body')); return; }
              idle();
            });
            const raw = res.rawHeaders;
            record.client.headerPairs = raw.length / 2;
            record.client.headers = parsedHeaders(res.statusCode, raw, 16384);
            record.client.headerEvidenceBytes = Buffer.byteLength(JSON.stringify(record.client.headers));
            if (record.client.headerEvidenceBytes > 16384) { abort(new Error('HEADER_EVIDENCE_IMPLEMENTATION_BOUND')); return; }
            if (raw.length % 2 || raw.length / 2 > 64) { abort(new Refusal('HEADER_PAIR_LIMIT', 'headers')); return; }
            if (!record.client.headers.complete) { abort(new Refusal('PARSED_HEADER_EVIDENCE_LIMIT', 'headers')); return; }
            const framing = new Map();
            for (let i = 0; i < raw.length; i += 2) {
              const name = raw[i].toLowerCase();
              if (['content-length', 'transfer-encoding', 'content-encoding'].includes(name)) {
                if (framing.has(name)) { abort(new Refusal('DUPLICATE_FRAMING_HEADER', 'headers')); return; }
                framing.set(name, raw[i + 1]);
              }
            }
            if (res.statusCode !== 200) { abort(new Refusal(`HTTP_STATUS_${res.statusCode}`, 'headers')); return; }
            if (framing.get('content-length') !== '20') { abort(new Refusal('CONTENT_LENGTH_POLICY', 'headers')); return; }
            if (framing.has('transfer-encoding') || framing.has('content-encoding')) { abort(new Refusal('ENCODING_POLICY', 'headers')); return; }
            idle();
          });
          record.client.requestEndAttempted = true; request.end();
        } catch (error) { rememberError(record, 'client-construction', error); complete(error); }
      });
    },
    async cleanup() {
      for (const t of activeTimers) clearTimeout(t); activeTimers.clear();
      for (const t of behaviorTimers) clearTimeout(t); behaviorTimers.clear();
      await new Promise(resolve => {
        let done = false;
        const end = () => { if (!done) { done = true; clearTimeout(deadline); resolve(); } };
        const deadline = setTimeout(() => { record.cleanupProblems.push('HTTPS_CLEANUP_TIMEOUT'); end(); }, p.timersMs.ownedCleanup);
        const check = () => {
          const serverClosed = server === null || record.server.closeCallback;
          const clientClosed = clientSocket === null || record.client.socketClose;
          const requestClosed = request === null || record.client.requestClose;
          const responseClosed = response === null || record.client.responseClose;
          const allServerClosed = [...serverSockets.values()].every(fact => fact.close);
          if (serverClosed && clientClosed && requestClosed && responseClosed && allServerClosed) end();
        };
        if (request) request.once('close', check);
        if (response) response.once('close', check);
        if (clientSocket) clientSocket.once('close', check);
        for (const socket of serverSockets.keys()) socket.once('close', check);
        if (server) {
          record.server.closeAttempted = true;
          try {
            server.close(error => {
              if (error && !(error.code === 'ERR_SERVER_NOT_RUNNING' && !serverStarted)) {
                record.server.closeError = errorFact(error, record); record.cleanupProblems.push('SERVER_CLOSE_ERROR');
              }
              record.server.closeCallback = true; check();
            });
          } catch (error) {
            record.server.closeError = errorFact(error, record); record.cleanupProblems.push('SERVER_CLOSE_THROW');
          }
        }
        if (request && !request.destroyed) { record.client.localRequestDestroy = true; request.destroy(); }
        if (clientSocket && !clientSocket.destroyed) { record.client.localSocketDestroy = true; clientSocket.destroy(); }
        for (const [socket, fact] of serverSockets) {
          if (!socket.destroyed) { fact.localDestroy = true; socket.destroy(); }
        }
        check();
      });
      if (requestConstructing) record.cleanupProblems.push('REQUEST_CONSTRUCTION_EFFECT_UNKNOWN');
      record.harnessCleanupQualified = record.cleanupProblems.length === 0 && !record.errorEvidenceOverflow;
      if (bodyHash && record.harnessCleanupQualified) {
        record.client.observedBodySha256 = bodyHash.digest('hex'); bodyHash = null;
        record.client.retainedBodyBytes = bodyRetained;
        record.client.retainedBodyHex = bodyStorage.subarray(0, bodyRetained).toString('hex');
      } else if (bodyStorage) {
        record.client.retainedBodyBytes = bodyRetained;
        record.client.retainedBodyHex = bodyStorage.subarray(0, bodyRetained).toString('hex');
      }
      // A quiesced owned server provides the actual received GET count. It is
      // not a guessed request counter and says nothing about TLS record bytes.
      if (record.harnessCleanupQualified) record.httpGets = record.server.gets;
      if (record.acquisitionConnections === null && !requestConstructing && !record.client.socketAssigned && request === null) {
        // Constructor failure may have side effects; deliberately remain null.
        record.harnessCleanupQualified = false; record.cleanupProblems.push('ACQUISITION_ATTEMPTS_UNKNOWN');
      }
    },
  };
  return resources;
}


// I4 orchestration only. The protected transport above still owns every actual
// HTTPS callback/chunk/timer/socket and uses only the admitted fixed origin.
// No fixture plaintext or prepared metadata reply enters this bridge.
function boundedDiagnostic(owner, error) {
  // Secondary capture diagnostics are never a successful case observation.
  try {
    const evidence = {errorEvidenceOverflow: false};
    const raw = Buffer.from(JSON.stringify({owner, error: errorFact(error, evidence),
      errorEvidenceOverflow: evidence.errorEvidenceOverflow}));
    const value = raw.length <= 32768 ? raw : Buffer.from(JSON.stringify({
      owner, complete: false, utf8PrefixHex: raw.subarray(0, 8192).toString('hex')}));
    fs.writeSync(2, Buffer.concat([value, Buffer.from('\n')]));
  } catch { /* Capture sink failure cannot qualify work or replace its primary. */ }
}

function closedPrimaryFact(error) {
  const evidence = {errorEvidenceOverflow: false};
  const fact = errorFact(error, evidence);
  const limits = {name: 1024, message: 16384, code: 1024, stack: 65536};
  const valid = !evidence.errorEvidenceOverflow && fact !== null
    && Object.keys(fact).length === 4 && Object.keys(limits).every(key => Object.hasOwn(fact, key))
    && typeof fact.name === 'string' && typeof fact.message === 'string'
    && ['code', 'stack'].every(key => fact[key] === null || typeof fact[key] === 'string')
    && Object.entries(limits).every(([key, limit]) => fact[key] === null
      || (fact[key].isWellFormed() && Buffer.byteLength(fact[key]) <= limit));
  if (valid) return fact; // Keep actual bounded native name/code/message/stack unchanged.
  boundedDiagnostic('primary-error-capture-bound', error);
  // The original bounded raw prefix remains diagnostic evidence. This is an
  // explicit capture failure, never an invented native/AEAD/transport cause.
  return {name: 'UnqualifiedPrimaryCapture',
    message: 'Primary error exceeds closed capture bounds; bounded raw prefix retained in stderr.',
    code: 'OUTPUT_BOUND', stack: null};
}

export async function acquireSnapshot(ctx, generation, attempt) {
  const record = initialRecord(ctx);
  let transport = null, received = null, primaryPresent = false, primary;
  let cleanupAttempted = false;
  try {
    // Internal generation capability is the only authentication authority.
    const authenticated = getAuthenticated(generation, ctx);
    await assertCurrent(ctx);
    record.policy.authenticated = true;
    record.policy.permissionChecked = true;
    if (ctx.permission !== true) throw new Refusal('LOCAL_ACQUISITION_DISABLED', 'policy');
    record.policy.subjectPeerMatched = authenticated.subject.peer === ctx.expectedPeer;
    if (!record.policy.subjectPeerMatched) throw new Refusal('AUTHENTICATED_PEER_POLICY', 'policy');
    record.policy.subjectURLMatched = authenticated.subject.url ===
      'https://files.invalid:18443' + ctx.profile.origin.path;
    if (!record.policy.subjectURLMatched) throw new Refusal('AUTHENTICATED_URL_POLICY', 'policy');
    if (authenticated.subject.blobBytes !== 20 || authenticated.subject.bytes !== 4
        || authenticated.subject.x !== ctx.profile.commitments.x
        || authenticated.subject.ox !== ctx.profile.commitments.ox)
      throw new Refusal('AUTHENTICATED_COMMITMENT_POLICY', 'policy');
    record.policy.permitted = true;
    checkpointEligible(ctx, generation);
    // Same-case private token check AND one-way entry latch precede even the
    // ownedTransport constructor. Failure/UNKNOWN consumes the saved allowance.
    ctx.checkAcquisitionAttempt(generation, attempt);
    transport = ownedTransport(ctx, record);
    await transport.start();
    received = await transport.receive();
  } catch (error) {
    primaryPresent = true; primary = error;
    rememberError(record, 'component', error);
  } finally {
    if (transport !== null && !cleanupAttempted) {
      cleanupAttempted = true; // A failed cleanup is not retried or assumed complete.
      try { await transport.cleanup(); }
      catch (error) {
        record.harnessCleanupQualified = false;
        record.cleanupProblems.push('HTTPS_CLEANUP_THROW');
        rememberError(record, 'cleanup', error);
        if (!primaryPresent) { primaryPresent = true; primary = error; }
      }
    } else if (transport === null && !record.server.listenAttempted && !record.client.constructed) {
      // There were no owned transport resources: this is source-observed zero
      // work before construction, not an acquisition-success/cleanup claim.
      record.harnessCleanupQualified = true;
    }
  }
  // Normalize only facts actually observed by the unchanged transport. These
  // remain null/partial on failed or unknown work; no planned vector fills them.
  record.bodyObservedBytes = record.client.observedBodyBytes;
  record.bodyRetainedBytes = record.client.retainedBodyBytes;
  record.responseComplete = record.client.responseComplete;
  record.ended = record.client.responseEnd;
  record.bodySha256 = record.client.observedBodySha256;
  if (!primaryPresent) {
    try {
      if (!record.harnessCleanupQualified) throw new Error('HTTPS_HARNESS_CLEANUP_UNQUALIFIED');
      if (!Buffer.isBuffer(received) || received.length !== 20
          || record.client.observedBodyBytes !== 20 || record.client.retainedBodyBytes !== 20
          || !record.client.responseEnd || record.client.responseComplete !== true)
        throw new Refusal('INCOMPLETE_ENTITY', 'body');
      if (record.client.nativeErrorCount !== 0 || record.errors.length !== 0)
        throw new Error('NATIVE_TRANSPORT_ERRORS_BEFORE_SNAPSHOT');
      if (sha256(received) !== getAuthenticated(generation, ctx).subject.x)
        throw new Refusal('SNAPSHOT_HASH', 'snapshot');
      record.completeSnapshot = true; // Actual completed entity; no original released.
      await assertCurrent(ctx);
    } catch (error) {
      primaryPresent = true; primary = error;
      rememberError(record, 'component', error);
    }
  }
  let descriptor;
  try { descriptor = await writeRecord(ctx, 'acquisition', record); }
  catch (error) {
    boundedDiagnostic('acquisition-record-capture', error);
    if (!primaryPresent) { primaryPresent = true; primary = error; }
  }
  if (primaryPresent) throw primary; // Preserve null/undefined/unknown native throws too.
  // ONLY the actual received Buffer and our retained source-owned descriptor.
  // The protocol independently checks count/x/full transport/cleanup/ownership,
  // copies these SAME bytes and records S05. No reopening/reacquisition/fixture read.
  return createSnapshot(generation, received, descriptor, ctx);
}

async function main(args) {
  let ctx = null, generation = null, primaryPresent = false, primary;
  let metadataCloseAttempted = false, consumer = null;
  try {
    if (args.length !== 2 || !path.isAbsolute(args[0]) || !/^[0-9a-f]{64}$/.test(args[1]))
      throw new Error('PRIVATE_CLI_REQUIRES_ABSOLUTE_FRAME_AND_EXTERNAL_SHA256');
    ctx = await loadCaseContext(args[0], args[1]);
    // S01-S04: each operation owns actual work and writes its own immutable step.
    const d = await runOwnedWire(ctx, 'D');
    const f = await runOwnedWire(ctx, 'F');
    await startNative(ctx);
    const authenticated = await authenticateReceived(ctx, d, f);
    generation = await sealWindow(ctx, authenticated);
    // S05: reserve is fsynced before acquireSnapshot can enter transport.
    const attempt = await reserveAcquisition(ctx, generation);
    const snapshot = await acquireSnapshot(ctx, generation, attempt);
    // The derivative consumer is import-inert, fixed and current. Import ONLY
    // after independent case admission; no alternate protocol instance/query.
    await assertCurrent(ctx);
    const {consumeOriginal} = await import('./consumer.mjs');
    await assertCurrent(ctx);
    consumer = await consumeOriginal(generation, snapshot, ctx); // S06 remains PRIVATE.
    if (consumer !== getConsumerFact(ctx)) throw new Error('PRIVATE_RESULT_IDENTITY');
  } catch (error) {
    primaryPresent = true; primary = error;
  } finally {
    // Caller-owned terminal close before successful S07, also after early failure.
    // Local latch is independent of the core's latch; no close/cleanup retry.
    if (ctx !== null && ctx.progress.metadataStarted && !metadataCloseAttempted
        && ctx.progress.metadataTerminal === null) {
      metadataCloseAttempted = true;
      try { await closeMetadata(ctx); }
      catch (error) {
        // The core separately retains its cleanup guard/errors. Never replace
        // an earlier transport/native/consumer failure with a cleanup refusal.
        if (!primaryPresent) { primaryPresent = true; primary = error; }
      }
    }
  }
  if (ctx === null) {
    boundedDiagnostic('pre-admission', primary);
    return 2; // No fabricated case observation and no dependent work.
  }
  try {
    // Exactly ONE finalizer call. It prints the sole caseCLIReply itself.
    const step = await closeoutAndPublish(ctx, generation,
      primaryPresent ? {error: closedPrimaryFact(primary)} : getConsumerFact(ctx));
    return step === null ? 1 : 0;
  } catch (error) {
    // A final capture/sink failure may follow an already persisted release:
    // preserve prior evidence; do not invoke closeout again or claim withholding.
    boundedDiagnostic('case-final-capture', error);
    return 1;
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { process.exitCode = await main(process.argv.slice(2)); }
  catch (error) { boundedDiagnostic('case-entry', error); process.exitCode = 1; }
}
