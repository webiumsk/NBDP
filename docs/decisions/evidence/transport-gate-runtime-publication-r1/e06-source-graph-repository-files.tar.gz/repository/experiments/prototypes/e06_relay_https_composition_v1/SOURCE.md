# Relay to HTTPS composition source/data plan

State: **SOURCE_PLAN_NOT_EXECUTABLE / NOT_RUNTIME_READY**.
No executable source, request/result fixture or experiment release is included.

This six-file plan follows the exact independently accepted HTTPS component pair
primary76355/QA14337, not the earlier partial primary51061. The accepted pair's
14 cases/14 metadata calls/3 consumers/12 connections/11 GETs/0 attachment
encryptions per run remain component facts. Relay metadata8/10/16 and selected
local snapshot recovery48/52 remain separately accepted components. Their sum is
not relay-to-HTTPS evidence, whole E06 PASS or a delivery/receipt guarantee.

## Files and evidence

- `contract.json`: scope, policy, preserved evidence/source descriptors, RC refusal
  obligations and later gates. Descriptors are read-only source-data inventories,
  not a complete runnable current closure or a grant of authority.
- `profile.json`: proposed finite LAB-I4 resources/28-step positive denominator,
  inherited payload/TLS/HTTP limits and explicit no-retry policy.
- `selection-map.json`: exact accepted R5 families/IDs/wires/expected objects;
  four proposed incoming cells and nineteen visible deferred LAB-N obligations.
- `oracles.json`: closed whole-step shape, accepted native metadata descriptors,
  source-derived positive policy/count expectations and explicit NOT_FROZEN
  fields. These are deliberately unusable as runtime expected fixtures.
- `interfaces.md`: disjoint future ownership, private interfaces, source seams,
  immutable generations, attempt reservation and protected derivative boundaries.
- `SOURCE.md`: this explanatory source plan.

The `contract.json.evidence` records include runtime acceptance, R5 fixture
materialization, TLS acceptance, design r3 independent QA/security, the initial
MEDIUM security finding and code-seam notes. Historical documents' contemporaneous
"QA pending" language remains historical; current exact pair acceptance satisfies
that prerequisite only. The initial security finding is preserved, remediated at
DESIGN level only by independently reviewed v3; this author approves no security
finding, derivative source, control or runtime outcome.

Accepted saved IDs are copied from existing JSON. Byte counts/hashes are inert
standard-library file/data inventory only. No project module, Nostr producer,
crypto helper or source function ran. No candidate rumor/ID/signature/wrap/key/
nonce/blob was generated; no fixture or expected native reply was invented.

## Minimum useful lane and retained gaps

LAB-I4 fixes C01-C04/W-C01-W-C04: Rust-produced invoice to JS metadata/NodeEVP,
and JS-produced credit note to Rust metadata/ChromeWebCrypto, each through strfry
and rs-relay. Existing R5 incoming D/F/raw wraps, native expected pair objects,
20-byte blob and original `00ff8001` fact are available. They are reusable only
after current descriptor/acceptance/closure checks, fresh authentication of actual
received EVENT spans and qualification of the derivative paths. Temporary `/tmp`
operands must still exist/currently match, or a separately reviewed byte-exact
durable-mirror mapping must replace them. No rematerialization is authorized here.

Each I4 window has exactly seven planned steps, D-before-F and an empty post-seal
event schedule. Its four positives do not exercise orphan completion, target
duplicates, late conflicting arrivals, archive or auth-negative composition.
They may not be reported as those negative guarantees. Source refusal controls
remain mandatory before even this narrower lane could run; no selection may
silently fall back from unsupported/unprepared LAB-N to I4.

LAB-N names candidate finite obligation windows N01-N19. Their sequences are
planning labels only; complete input, per-step whole oracles and resource/step
denominators are NOT_FROZEN. No aggregate LAB-N suite is selected or released.
In particular:

- Genuine F2 and fresh outer wraps of the saved new `:18443` F are not identified
  as qualified fixtures in the bounded inputs. F2 needs a distinct canonical F
  ID with identical accepted origin/parent/descriptor/author/recipient/scope and
  future independent native proofs from both backends. Merely changing wrapping
  is a duplicate; a distinct inner timestamp is only a future preparation idea.
- Archive D/F wraps/native inspect proofs exist, but new-origin full archive
  `correlate-file-metadata` step oracles remain NOT_FROZEN.
- Orphan and exact-wire duplicate steps can use existing raw bytes, but their new
  persistent-window full native replies/counter and state traces need independent
  oracle derivation/qualification. D-only cannot invent an API response requiring F.
- Old relay F uses `https://files.invalid/<x>` and refuses `F_SHAPE/F_URL` under
  `https://files.invalid:18443` after a valid earlier prefix. It is not a second
  qualifying F. Exact old paired inputs and full backend-native oracles are still
  unselected in this plan; static D1/F1 expectation is not new runtime evidence.
- Auth-negative, revised-parent and genuine revision fixtures are unselected or
  unqualified for this new scope. Deferred recovery B08-B11 auth8/full56/60 remains
  unqualified. Do not mutate a source/wire and call it independently proved.
- H07/H10/H13/H14 supply accepted isolated failure facts only. Relay-fed network,
  snapshot, cleanup/source and late-event target traces require new explicit
  derivative mapping, checkpoint controls and whole oracles. H14 is no OS-fault test.

Missing fixtures never become a positive assumption. Minimum source work may
prepare I4 interfaces while leaving LAB-N visibly blocked; qualifying I4 later
would not close LAB-N, full E06 or SDK/normative gates. No expansion, historical
matrix replay, compatibility-control execution or new crypto is authorized.

## Local policy and public result boundary

COLLECT authenticates actual spans in one persistent metadata window. Explicit
SEAL requires complete declared lab frontier, one incoming unambiguous qualified
pair, local permission/current pins and no capacity/conflict/uncertainty. EOSE
proves neither global history completeness nor absence of later F.

One immutable private WeakMap generation binds the exact received/authenticated
subject. Reserve the only acquisition allowance before listener/server/client/
connection side effects; failure or UNKNOWN consumes it. No retry/alternate F,
URL, mirror, ciphertext, key or nonce is selected. Duplicate/fresh wrap adds
provenance without another allowance or release, including after first failure.

Verify actual complete encrypted count/x before passing the SAME immutable
snapshot to the existing native consumer; journal the consumer attempt before
the actual native API. Private engine bytes remain restricted evidence until
all declared late steps/checkpoints, owned cleanup and current integrity succeed,
then a serial final eligibility/publication check. Held/unqualified output has
`originalHex:null`; receipts=false/businessEffects=0 always.

Genuine late conflict appends invalidation without changing the sealed subject.
Stop further work at the next enforceable check and clean up, preserving actual
earlier connections/GETs/bytes/consumer calls; already queued callbacks may finish.
Never report zero egress retroactively. If public release already happened,
retain that historical disclosure and prevent another release; it cannot be undone.
Invalid/wrong-origin traffic does not become a qualifying conflict. Independent
source/lifecycle uncertainty still withholds public success and keeps unknown
counters null. No persistent/global exactly-once or business-state guarantee follows.

## Implementation and approval boundary

Accepted N12, metadata implementations, shared attachment crypto and the exact
2937-byte native classifier remain immutable. New protocol/acquisition/consumer
must share the SAME derivative WeakMap module; an external wrapper cannot mint
old handles. Interface/lineage/case-ID/journal changes require explicit bounded
source assignments and independent protected-diff review before controls/config/
fixture/admission and separately released primary/QA runtime evidence.

No new Product Owner decision is identified for this reversible lab planning.
Conditional vendor-independent Option B, parallel-device authority, no baseline
FS/PCS and canonical Q/E IDs remain. E06 retains E01/E02/E05 and the adopted exact
candidate-specific E02 transport-sub-evidence substitution; E04 PASS is not its
dependency. Canonical E06 stays NOT EXECUTED and overlay PARTIAL.

Normative G1 identity/correlation/revision/equivalence and attachment tuple/profile
adoption, Q08/Q27 producer compatibility/ambiguity, Q01 threat/privacy/sensitivity,
Q13 retention/recovery and Q15 parallel authority remain open. Applicable later
E07-E15, full independent evidence and explicit G3 Product Owner authorization
are still required before SDK work. No new NIP/kind, custom crypto, Satflux
dependency, production/real data/keys, deployment or publication follows.

Only static JSON/schema/cross-reference/source-data descriptor checks are suitable
for this assignment. No executable implementation, target import, producer,
fixture/control/admission/experiment, network, container, Git mutation, commit,
PR or publication has been authorized or performed by these planning changes.
