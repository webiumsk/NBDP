"""SOURCE_PREPARED_NOT_EXECUTED: exact release/evidence gate, inert sentinel only.

No E04 target exists here. JSON is data, never code or a verified capability.
Every public admission path reloads the externally hash-bound release.
"""

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / "experiments/prototypes/e04_prerequisite_gate_v1"
EVIDENCE = ROOT / "docs/decisions/evidence/invoice-authenticated-carrier"
PYTHON = Path("/home/peterhorvath/.miniforge3/bin/python3.13")
POLICY = "transport-sub-evidence-v1"
TARGET = "E04/invoice-carrier-frame-v1"
SOURCE_NAMES = {"prerequisite_gate.py", "gate_sentinel.py", "gate-cases.json",
                "test_prerequisite_gate.py", "README.md"}
POLICY_FILES = {"adoption": ROOT / "docs/decisions/transport-sub-evidence-prerequisite-v1.md",
                "proposal": ROOT / "docs/decisions/proposals/transport-sub-evidence-prerequisite.md",
                "reviews": ROOT / "docs/decisions/evidence/transport-sub-evidence-policy/proposal-reviews.json"}
ACCEPTANCE = EVIDENCE / "relay-close-v1-completion-and-next-action.json"
ARCHIVES = {"e01-qa/artifact-manifest.json", "fixture-r2-qa/artifact-manifest.json",
            "consumer-qa/artifact-manifest.json", "handler-r2-qa/artifact-manifest.json",
            "relay-close-v1-primary/artifact-manifest.json", "relay-close-v1-qa/artifact-manifest.json",
            "relay-close-remediation/guarded-build-v1/build-primary-r1/artifact-manifest.json",
            "close-v1-primary/artifact-manifest.json", "relay-primary/artifact-manifest.json",
            "close-diagnostic-primary/artifact-manifest.json"}
LINEAGE_SCOPES = ["E01_LEGACY140", "FIXTURE_PRODUCERS", "CONSUMER124_S0_S5", "HANDLER56_AND_TWO_RELAY40"]
IMAGES = {"strfry": "sha256:d72c7eb4e19562e22c24924ea51bc345ea5d22d03ada1429a46e0bb90ea97d40",
          "rs-relay": "sha256:d3e7c3f67e513687616f9cddc7b71caa3f5980c798fe6f9a41b7b9534a8a19de"}
OLD_IMAGES = dict(IMAGES, **{"rs-relay": "sha256:fe586a0bc68edefb553a62d21983de469128f7cb785bfcc2ef7c82dbf1cded82"})
RELEASE_KEYS = {"schema", "purpose", "policy", "target", "targetState", "targetModule",
                "e04ExecutionReleased", "gateSources", "sentinel", "policyEvidence",
                "transportAcceptance", "tools", "output", "controls"}
NETWORK_KEYS = {"schema", "decision", "recorded_at_utc", "qualified", "scope", "candidate_sources",
                "dependency_files_sha256", "accepted_inputs", "selected_matrix", "selected_proof_bundle",
                "plan", "source_reviews", "image_ids", "historical_image_ids", "historical_failure_preserved",
                "runs", "reviews", "mandatory_transport_paths_complete", "unresolved_relevant_findings",
                "coverage_lineage", "limitations", "next_action"}


class Refusal(Exception):
    def __init__(self, reason, sentinel_invocations=0):
        super().__init__(reason)
        self.reason = reason
        self.sentinel_invocations = sentinel_invocations


def require(condition, reason):
    if not condition:
        raise Refusal(reason)


def exact_keys(value, keys):
    require(type(value) is dict and set(value) == set(keys), "SCHEMA")


def same(actual, expected, reason):
    def typed(a, b):
        if type(a) is not type(b):
            return False
        if type(a) is dict:
            return set(a) == set(b) and all(typed(a[key], b[key]) for key in a)
        if type(a) in (list, tuple):
            return len(a) == len(b) and all(typed(x, y) for x, y in zip(a, b))
        return a == b
    require(typed(actual, expected), reason)


def _object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def decode(raw):
    require(len(raw) <= 32 * 1024 * 1024, "JSON_BOUND")
    try:
        return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=_object,
                          parse_constant=lambda _: (_ for _ in ()).throw(Refusal("JSON_CONSTANT")))
    except (UnicodeError, ValueError, RecursionError) as error:
        raise Refusal("MALFORMED_JSON") from error


def absolute(value):
    require(type(value) is str and "\x00" not in value, "UNSAFE_PATH")
    path = Path(value)
    require(path.is_absolute() and ".." not in path.parts and str(path) == value, "UNSAFE_PATH")
    return path


def pin(value):
    exact_keys(value, {"bytes", "sha256"})
    require(type(value["bytes"]) is int and 0 <= value["bytes"] <= 512 * 1024 * 1024
            and type(value["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", value["sha256"]) is not None,
            "PIN_SCHEMA")
    return value


def descriptor(value):
    # Two explicit historical forms, not arbitrary JSON traversal.
    if type(value) is dict and set(value) == {"path", "pin"}:
        return absolute(value["path"]), pin(value["pin"])
    exact_keys(value, {"path", "bytes", "sha256"})
    return absolute(value["path"]), pin({key: value[key] for key in ("bytes", "sha256")})


def digest(path):
    h = hashlib.sha256()
    count = 0
    with path.open("rb") as source:
        while chunk := source.read(1024 * 1024):
            count += len(chunk)
            require(count <= 512 * 1024 * 1024, "FILE_BOUND")
            h.update(chunk)
    return {"bytes": count, "sha256": h.hexdigest()}


def read_bound(desc, reason="PIN_MISMATCH"):
    path, expected = descriptor(desc)
    require(expected["bytes"] <= 32 * 1024 * 1024, "READ_BOUND")
    try:
        require(digest(path) == expected, reason)
        raw = path.read_bytes()
        require({"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()} == expected, reason)
        return raw
    except OSError as error:
        raise Refusal("MISSING_FILE") from error


def verify_release(release_path, external_sha256):
    """External digest is supplied by the reviewed controller, never by release JSON."""
    require(type(external_sha256) is str and re.fullmatch("[0-9a-f]{64}", external_sha256) is not None,
            "EXTERNAL_RELEASE_SHA_REQUIRED")
    path = absolute(str(release_path))
    try:
        require(path.stat().st_size <= 32 * 1024 * 1024, "JSON_BOUND")
        raw = path.read_bytes()
    except OSError as error:
        raise Refusal("MISSING_RELEASE") from error
    require(hashlib.sha256(raw).hexdigest() == external_sha256, "RELEASE_SHA_MISMATCH")
    release = decode(raw)
    exact_keys(release, RELEASE_KEYS)
    for key, expected in {"schema": "e04-prerequisite-gate-release-v1", "purpose": "GATE_QUALIFICATION_ONLY",
            "policy": POLICY, "target": TARGET, "targetState": "NOT_PREPARED", "targetModule": None,
            "e04ExecutionReleased": False}.items():
        same(release[key], expected, "RELEASE_SCOPE")
    exact_keys(release["gateSources"], {str(HERE / name) for name in SOURCE_NAMES})
    for source, expected in release["gateSources"].items():
        read_bound({"path": source, **pin(expected)}, "GATE_SOURCE_PIN")
    sentinel_path, sentinel_pin = descriptor(release["sentinel"])
    require(sentinel_path == HERE / "gate_sentinel.py"
            and sentinel_pin == release["gateSources"][str(sentinel_path)], "SENTINEL_SCOPE")
    exact_keys(release["policyEvidence"], POLICY_FILES)
    for name, expected_path in POLICY_FILES.items():
        actual_path, _ = descriptor(release["policyEvidence"][name])
        require(actual_path == expected_path, "POLICY_EVIDENCE")
        read_bound(release["policyEvidence"][name], "POLICY_PIN")
    exact_keys(release["tools"], {"python"})
    python, _ = descriptor(release["tools"]["python"])
    require(python == PYTHON, "TOOL_SCOPE")
    read_bound(release["tools"]["python"], "TOOL_PIN")
    same(release["output"], {"format": "JSON_STDOUT_ONLY"}, "OUTPUT_SCOPE")
    exact_keys(release["controls"], {"cases", "sentinelTimeoutSeconds"})
    case_path, case_pin = descriptor(release["controls"]["cases"])
    require(case_path == HERE / "gate-cases.json"
            and case_pin == release["gateSources"][str(case_path)], "CONTROL_SCOPE")
    same(release["controls"]["sentinelTimeoutSeconds"], 2, "CONTROL_SCOPE")
    exact_keys(release["transportAcceptance"], {"record", "closure"})
    return release


class Evidence:
    """Data-only exact inventory. No commands, predicates, plugins or import targets."""
    def __init__(self, closure):
        exact_keys(closure, {"schema", "filePins", "archives"})
        same(closure["schema"], "invoice-carrier-prerequisite-closure-v1", "CLOSURE_SCHEMA")
        require(type(closure["filePins"]) is dict and 5500 <= len(closure["filePins"]) <= 30000,
                "CLOSURE_BOUND")
        self.files = closure["filePins"]
        for name, expected in self.files.items():
            absolute(name)
            pin(expected)
        self.archives = closure["archives"]
        require(type(self.archives) is list, "ARCHIVE_SCHEMA")

    def cover(self, desc):
        path, expected = descriptor(desc)
        require(str(path) in self.files, "CLOSURE_MISSING")
        require(self.files[str(path)] == expected, "CLOSURE_CONTRADICTION")
        return path

    def document(self, desc):
        self.cover(desc)
        return decode(read_bound(desc))

    def mapping(self, values, *, count=None):
        require(type(values) is dict and (count is None or len(values) == count), "MAP_SCOPE")
        for name, expected in values.items():
            path = Path(name) if Path(name).is_absolute() else ROOT / name
            self.cover({"path": str(path), **pin(expected)})

    def archives_complete(self):
        paths = [self.cover(item) for item in self.archives]
        require(len(paths) == len(set(paths)), "ARCHIVE_DUPLICATE")
        require({str(EVIDENCE / item) for item in ARCHIVES}.issubset({str(path) for path in paths}),
                "ARCHIVE_MISSING")
        for desc, path in zip(self.archives, paths):
            manifest = self.document(desc)
            if path == EVIDENCE / "consumer-qa/artifact-manifest.json":
                require(type(manifest.get("entries")) is list, "ARCHIVE_SCHEMA")
                entries = manifest["entries"]
                for entry in entries:
                    exact_keys(entry, {"path", "bytes", "sha256"})
            elif path == EVIDENCE / "relay-primary/artifact-manifest.json":
                entries = [{"path": name, **pin(value)} for name, value in manifest.items()]
            else:
                require(type(manifest.get("files")) is dict, "ARCHIVE_SCHEMA")
                entries = [{"path": name, **pin(value)} for name, value in manifest["files"].items()]
            require(len(entries) > 0, "ARCHIVE_EMPTY")
            names = set()
            for entry in entries:
                relative = entry["path"]
                require(type(relative) is str and relative not in names and not Path(relative).is_absolute()
                        and ".." not in Path(relative).parts and str(Path(relative)) == relative, "ARCHIVE_PATH")
                names.add(relative)
                self.cover({"path": str(path.parent / relative), "bytes": entry["bytes"], "sha256": entry["sha256"]})

    def hash_all(self):
        # Streaming bounded reads only. Do not execute any file in this inventory.
        for name, expected in self.files.items():
            try:
                require(digest(absolute(name)) == expected, "CURRENT_FILE_PIN")
            except OSError as error:
                raise Refusal("MISSING_FILE") from error


def _reviews(evidence, record, expected_decision):
    exact_keys(record["reviews"], {"qa", "security"})
    for role in ("qa", "security"):
        review = evidence.document(record["reviews"][role])
        require(type(review) is dict, "ACTUAL_REVIEW")
        same(review.get("decision"), expected_decision, "ACTUAL_REVIEW")


def _base_acceptances(evidence, network):
    decisions = {"e01": "ACCEPT_CURRENT_CARRIER_LEGACY140_RUNTIME_SCOPE_ONLY",
                 "fixture": "ACCEPT_CURRENT_CARRIER_FIXTURE_QUALIFICATION_ONLY",
                 "consumer": "ACCEPT_CURRENT_CARRIER_CONSUMER_CONTROLS_RUNTIME_SCOPE_ONLY",
                 "handler": "ACCEPT_CURRENT_CARRIER_HANDLER_NOTICE_RUNTIME_SCOPE_ONLY"}
    records = {}
    for name, decision in decisions.items():
        record = evidence.document(network["accepted_inputs"][name])
        same(record["decision"], decision, "BASE_ACCEPTANCE_SCOPE")
        same(record["candidate_sources"], network["candidate_sources"], "BASE_SOURCE_LINEAGE")
        evidence.mapping(record["candidate_sources"], count=21)
        exact_keys(record["runs"], {"primary", "qa"})
        for run in record["runs"].values():
            same(run["qualified"], True, "BASE_RUN")
            same(run["natural_outer_exit"], 0, "BASE_RUN")
            if name != "fixture":
                same(run["failures"], 0, "BASE_RUN")
            if name == "e01":
                same(run["checks"], 140, "BASE_RUN")
                evidence.cover(run["rust_binary"])
                for phase in run["phases"].values():
                    same(phase["exit"], 0, "E01_PHASE")
                    same(phase["timeout_or_signal"], False, "E01_PHASE")
            else:
                evidence.cover(run["capture"])
            if name == "fixture":
                same(run["proofs"], 132, "FIXTURE_SCOPE")
                same(run["positive_producer_observations"], 36, "FIXTURE_SCOPE")
                evidence.cover(run["metadata_reconstruction_audit"])
            if name == "consumer":
                same(run["executed"], 124, "CONSUMER_SCOPE")
                evidence.cover(run["whole_comparisons"])
                evidence.cover(run["rust_binary"])
            if name == "handler":
                same(run["executedRows"], 56, "HANDLER_SCOPE")
                same(run["actualConsumerRows"], 52, "HANDLER_SCOPE")
                same(run["faultInjectionRows"], 4, "HANDLER_SCOPE")
                evidence.cover(run["rust_binary"])
        if name == "e01":
            same(record["material_findings"], [], "E01_FINDING")
            require(record["qa_decision"] == "ACCEPT_CURRENT_CARRIER_REFERENCE140_RUNTIME_SCOPE_ONLY"
                    and record["security_decision"] == decision, "E01_REVIEW")
        else:
            _reviews(evidence, record, "ACCEPT_CURRENT_CARRIER_CONSUMER124_RUNTIME_SCOPE_ONLY"
                     if name == "consumer" else decision)
            for key in ("accepted_matrix", "accepted_proof_bundle"):
                evidence.cover(record[key])
                selected = "selected_matrix" if key == "accepted_matrix" else "selected_proof_bundle"
                same(descriptor(record[key]), descriptor(network[selected]), "FIXTURE_LINEAGE")
            if name in ("consumer", "handler"):
                evidence.cover(record["release"])
                same(record["dependency_files_sha256"], network["dependency_files_sha256"], "DEPENDENCY_LINEAGE")
        records[name] = record
    build = evidence.document(network["accepted_inputs"]["build"])
    same(build["decision"], "ACCEPT_OFFLINE_BUILD_AND_EXACT_IMAGE_LINEAGE_ONLY", "BUILD_SCOPE")
    for key, expected in (("qualified", True), ("cleanup_qualified", True), ("natural_outer_exit", 0),
                          ("new_image_id", IMAGES["rs-relay"]), ("parent_image_id", OLD_IMAGES["rs-relay"])):
        same(build[key], expected, "BUILD_LINEAGE")
    for key in ("release", "frozen_plan", "build_capture", "artifact_manifest", "compiled_binary", "verified_binary"):
        evidence.cover(build[key])
    for review in build["actual_reviews"].values():
        evidence.cover(review)
    p01 = evidence.document(network["accepted_inputs"]["p01"])
    for key, expected in (("qualified", True), ("evidence_complete", True), ("control_pass", True),
                          ("cleanup_qualified", True), ("natural_outer_exit", 0), ("new_image_id", IMAGES["rs-relay"])):
        same(p01[key], expected, "P01_SCOPE")
    for key in ("release", "plan", "capture", "artifact_manifest", "tool_receipt", "build_admission"):
        evidence.cover(p01[key])
    for review in p01["actual_reviews"].values():
        evidence.cover(review)
    return records


def _network_run(evidence, network, label):
    run = network["runs"][label]
    exact_keys(run, {"session", "natural_outer_exit", "executedRows", "failures", "noticeCalls",
                     "cleanup_qualified", "release", "capture", "tool_receipt", "artifact_manifest", "backend_counts"})
    for key, expected in (("natural_outer_exit", 0), ("executedRows", 40), ("failures", 0),
                          ("noticeCalls", 6), ("cleanup_qualified", True)):
        same(run[key], expected, "NETWORK_RUN")
    same(run["backend_counts"], {"JS": 16, "RUST": 24}, "NETWORK_BACKENDS")
    release = evidence.document(run["release"])
    capture = evidence.document(run["capture"])
    receipt = evidence.document(run["tool_receipt"])
    evidence.cover(run["artifact_manifest"])
    for key, expected in (("natural_outer_exit", 0), ("session", run["session"])):
        same(receipt[key], expected, "NETWORK_RECEIPT")
    # Two retained actual schemas; never infer a missing qualification value or
    # fall back from one label's schema to the other.
    if label == "primary":
        receipt_result = receipt
    else:
        same(label, "qa", "NETWORK_RECEIPT")
        receipt_result = receipt["summary"]
        exact_keys(receipt_result, {"qualified", "executedRows", "failures", "noticeCalls", "error", "integrity_error"})
        same(receipt["scope"], "CURRENT_CARRIER_BOTH_RELAY_CONTROLS_ONLY", "NETWORK_RECEIPT")
    for key, expected in (("qualified", True), ("executedRows", 40), ("failures", 0), ("noticeCalls", 6)):
        same(receipt_result[key], expected, "NETWORK_RECEIPT")
    require(receipt_result.get("error") is None and receipt_result.get("integrity_error") is None,
            "NETWORK_RECEIPT_ERROR")
    for key, expected in (("qualified", True), ("executedRows", 40), ("failures", 0),
                          ("noticeCalls", 6), ("notExecutedRows", 0), ("label", label),
                          ("scope", "CURRENT_CARRIER_BOTH_RELAY_CONTROLS_ONLY")):
        same(capture[key], expected, "NETWORK_CAPTURE")
    require(capture.get("error") is None and capture.get("integrity_error") is None, "NETWORK_CAPTURE_ERROR")
    same(capture["release_pin"], descriptor(run["release"])[1], "NETWORK_RELEASE_BINDING")
    same(capture["cleanup"]["actual"]["qualified"], True, "NETWORK_CLEANUP")
    same(capture["cleanup"]["actual"]["problems"], [], "NETWORK_CLEANUP")
    same(capture["cleanup"]["actual"]["uncertain_creates"], [], "NETWORK_CLEANUP")
    exact_keys(capture["wire_phases"], {"strfry", "rs-relay"})
    for phase in capture["wire_phases"].values():
        same(phase["exit"], 0, "NETWORK_WIRE")
        same(phase["timeout_or_signal"], False, "NETWORK_WIRE")
    for backend, count in (("JS", 16), ("RUST", 24)):
        same(capture["channelCounters"][backend], {"adapterInvocations": count, "supervisedCommandLaunches": count}, "NETWORK_BACKENDS")
    capture_path, _ = descriptor(run["capture"])
    comparisons = evidence.document({"path": str(capture_path.parent / "whole-comparisons.json"),
                                     **pin(capture["comparisons_pin"])})
    require(type(comparisons) is list and len(comparisons) == 40, "NETWORK_COMPARISONS")
    counts = {"strfry": 0, "rs-relay": 0, "JS": 0, "RUST": 0}
    notices = 0
    for row in comparisons:
        same(row["matched"], True, "NETWORK_COMPARISONS")
        require(row["relay"] in ("strfry", "rs-relay") and row["backend"] in ("JS", "RUST"), "NETWORK_COMPARISONS")
        counts[row["relay"]] += 1
        counts[row["backend"]] += 1
        actual = row["actual"]
        same(actual["failure"], None, "NETWORK_COMPARISONS")
        same(actual["actualWholeConsumerResult"], row["expectedWholeConsumerResult"], "NETWORK_WHOLE_RESULT")
        same(actual["observation"], row["expectedNoticeObservation"], "NETWORK_NOTICE")
        notices += actual["observation"]["sinkInvocations"]
        consumer = actual["consumerEvidence"]
        for key, expected in (("mode", "ACTUAL_PINNED_CONSUMER"), ("launch_succeeded", True),
                              ("qualified_channel", True), ("exit", 0), ("timeout_or_signal", False)):
            same(consumer[key], expected, "NETWORK_ACTUAL_CONSUMER")
        same(consumer["request"], row["actualRequest"], "NETWORK_REQUEST")
        same(row["actualNetwork"]["qualified"], True, "NETWORK_WIRE")
        same(row["actualNetwork"]["close"]["code"], 1000, "NETWORK_CLOSE")
        same(row["actualNetwork"]["wireHex"], row["actualRequest"]["wireHex"], "NETWORK_RETRIEVAL")
    same(counts, {"strfry": 20, "rs-relay": 20, "JS": 16, "RUST": 24}, "NETWORK_COUNTS")
    same(notices, 6, "NETWORK_NOTICE")
    same(release["execution_released"], True, "NETWORK_RELEASE")
    same(release["released_label"], label, "NETWORK_RELEASE")
    same(release["image_ids"], network["image_ids"], "IMAGE_LINEAGE")
    same(release["historical_image_ids"], network["historical_image_ids"], "IMAGE_LINEAGE")
    same(release["candidate_files"], network["candidate_sources"], "SOURCE_LINEAGE")
    for key, count in (("candidate_files", 21), ("input_files", 44), ("dependency_files", 5220),
                       ("harness_files", 6), ("wire_runtime_pins", 819)):
        evidence.mapping(release[key], count=count)
    canonical = json.dumps(release["dependency_files"], sort_keys=True, separators=(",", ":"),
                           ensure_ascii=True, allow_nan=False).encode("ascii")
    same(hashlib.sha256(canonical).hexdigest(), network["dependency_files_sha256"], "DEPENDENCY_LINEAGE")
    for binary in release["target_rust_binaries"].values():
        evidence.cover(binary)
    for config in release["lab_configs"].values():
        for item in config["files"].values():
            evidence.cover(item)
    for key in ("build_admission", "p01_admission", "e01_runtime_release", "accepted_plan", "accepted_source_reviews",
                "selected_frozen_matrix", "selected_proof_bundle"):
        evidence.cover(release[key])
    same(descriptor(release["selected_frozen_matrix"]), descriptor(network["selected_matrix"]), "FIXTURE_LINEAGE")
    same(descriptor(release["selected_proof_bundle"]), descriptor(network["selected_proof_bundle"]), "FIXTURE_LINEAGE")
    for name in ("e01", "fixture", "consumer", "handler"):
        name_path = Path(release[name + "_acceptance_file"])
        desc = {"path": str(name_path if name_path.is_absolute() else ROOT / name_path),
                "pin": release[name + "_acceptance_pin"]}
        same(descriptor(desc), descriptor(network["accepted_inputs"][name]), "ACCEPTANCE_LINEAGE")
        evidence.cover(desc)


def _check_network_record(evidence, network):
    """Private DATA validation, also exercised by labelled semantic guard controls.

    No release token, admission capability, process invocation or sentinel exists
    on this path. Actual qualification always loads the fixed accepted record.
    """
    exact_keys(network, NETWORK_KEYS)
    for key, expected in (("schema", "invoice-carrier-two-relay-acceptance-v1"),
            ("decision", "ACCEPT_DERIVATIVE_TWO_RELAY_CARRIER_NOTICE_SCOPE_ONLY"),
            ("qualified", True), ("scope", "CURRENT_CARRIER_BOTH_RELAY_CONTROLS_ONLY"),
            ("mandatory_transport_paths_complete", True), ("unresolved_relevant_findings", []),
            ("historical_failure_preserved", True), ("image_ids", IMAGES), ("historical_image_ids", OLD_IMAGES)):
        same(network[key], expected, "TRANSPORT_ACCEPTANCE")
    require(type(network["limitations"]) is list and len(network["limitations"]) > 0, "SCOPE_LIMITATIONS")
    exact_keys(network["accepted_inputs"], {"e01", "fixture", "consumer", "handler", "build", "p01"})
    exact_keys(network["runs"], {"primary", "qa"})
    require(type(network["runs"]["primary"]["session"]) is int
            and type(network["runs"]["qa"]["session"]) is int
            and network["runs"]["primary"]["session"] != network["runs"]["qa"]["session"], "INDEPENDENT_QA")
    exact_keys(network["coverage_lineage"], {"security_report", "scopes"})
    same(network["coverage_lineage"]["scopes"], LINEAGE_SCOPES, "COVERAGE_LINEAGE")
    evidence.cover(network["coverage_lineage"]["security_report"])
    exact_keys(network["reviews"], {"qa", "security"})
    sessions = []
    for role in ("qa", "security"):
        review = network["reviews"][role]
        exact_keys(review, {"report_id", "session", "decision", "report"})
        require(type(review["report_id"]) is str and type(review["session"]) is str
                and review["session"].startswith("/root/"), "ACTUAL_REVIEW")
        same(review["decision"], "ACCEPT_DERIVATIVE_BOTH_RELAY40_RUNTIME_SCOPE_ONLY", "ACTUAL_REVIEW")
        actual = evidence.document(review["report"])
        same(actual["decision"], review["decision"], "ACTUAL_REVIEW")
        require(review["report_id"] in (actual.get("report_id"), actual.get("reportId")), "ACTUAL_REVIEW")
        sessions.append(review["session"])
    require(sessions[0] != sessions[1], "INDEPENDENT_REVIEW")
    same(descriptor(network["reviews"]["security"]["report"]),
         descriptor(network["coverage_lineage"]["security_report"]), "COVERAGE_LINEAGE")
    for key in ("selected_matrix", "selected_proof_bundle", "plan", "source_reviews"):
        evidence.cover(network[key])
    _base_acceptances(evidence, network)
    _network_run(evidence, network, "primary")
    _network_run(evidence, network, "qa")
    for path, expected in ((EVIDENCE / "relay-primary/capture.json", {"qualified": False, "executedRows": 0}),
                           (EVIDENCE / "close-diagnostic-primary/capture.json",
                            {"qualified": False, "evidence_complete": True, "control_pass": False})):
        require(str(path) in evidence.files, "HISTORICAL_FAILURE_MISSING")
        historical = evidence.document({"path": str(path), **evidence.files[str(path)]})
        for key, value in expected.items():
            same(historical[key], value, "HISTORICAL_FAILURE_CHANGED")
    evidence.archives_complete()


def verify_transport_prerequisites(release_path, external_sha256):
    """No caller JSON or pre-verified token is accepted; verify external release again."""
    release = verify_release(release_path, external_sha256)
    record_path, _ = descriptor(release["transportAcceptance"]["record"])
    require(record_path == ACCEPTANCE, "ACCEPTANCE_PATH")
    network = decode(read_bound(release["transportAcceptance"]["record"]))
    closure = decode(read_bound(release["transportAcceptance"]["closure"]))
    evidence = Evidence(closure)
    evidence.cover(release["transportAcceptance"]["record"])
    for policy_desc in release["policyEvidence"].values():
        evidence.cover(policy_desc)
    _check_network_record(evidence, network)
    evidence.hash_all()
    return {"verifiedFiles": len(evidence.files), "verifiedArchives": len(evidence.archives)}


def admit_e04(*_args, **_kwargs):
    """There is deliberately no E04 import, invocation or target implementation."""
    raise Refusal("TARGET_NOT_PREPARED")


def run_qualification(release_path, external_sha256):
    counts = verify_transport_prerequisites(release_path, external_sha256)
    # Recheck the same evidence and execution closure immediately before the only
    # fixed inert child. This is no immutable filesystem/race-free custody claim.
    verify_transport_prerequisites(release_path, external_sha256)
    command = [str(PYTHON), "-I", "-B", str(HERE / "gate_sentinel.py")]
    child = None
    try:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, cwd=str(ROOT), env={})
        stdout, stderr = child.communicate(timeout=2)
        require(child.returncode == 0 and stderr == b"", "SENTINEL_FAILURE")
        actual = decode(stdout)
        expected = {"schema": "e04-gate-sentinel-v1", "sentinelInvocations": 1,
                    "e04Executed": False, "e04Imports": 0, "targetImports": 0, "dependentChecks": 0}
        same(actual, expected, "SENTINEL_RESULT")
    except BaseException as error:
        cleanup_error = None
        if child is not None:
            try:
                if child.poll() is None:
                    child.kill()
                child.communicate(timeout=2)
                child.wait(timeout=2)
            except BaseException as failure:
                cleanup_error = failure
        reason = "SENTINEL_CLEANUP" if cleanup_error is not None else error.reason if isinstance(error, Refusal) else "SENTINEL_FAILURE"
        raise Refusal(reason, int(child is not None)) from error
    return dict(expected, schema="e04-gate-result-v1", status="GATE_CONTROL_PASS", reason=None,
                targetPrepared=False, verifiedEvidence=counts)


def main():
    result = {"schema": "e04-gate-result-v1", "status": "NOT_EXECUTED", "reason": None,
              "targetPrepared": False, "e04Executed": False, "e04Imports": 0,
              "targetImports": 0, "dependentChecks": 0, "sentinelInvocations": 0}
    try:
        require(len(sys.argv) == 4 and sys.argv[1] in ("qualify", "e04"), "CLI_SCOPE")
        if sys.argv[1] == "e04":
            admit_e04()
        result = run_qualification(sys.argv[2], sys.argv[3])
        code = 0
    except Refusal as error:
        result["reason"] = error.reason
        result["sentinelInvocations"] = error.sentinel_invocations
        code = 1
    except (OSError, KeyError, TypeError, ValueError, RecursionError, subprocess.SubprocessError):
        result["reason"] = "INCOMPLETE_OR_INVALID_EVIDENCE"
        code = 1
    print(json.dumps(result, sort_keys=True), flush=True)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
