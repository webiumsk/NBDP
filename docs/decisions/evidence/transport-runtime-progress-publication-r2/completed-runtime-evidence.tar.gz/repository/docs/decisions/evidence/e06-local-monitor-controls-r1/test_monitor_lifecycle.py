"""Owned-child lifecycle controls; fixture admission is NOT LOCAL admission.

The byte-pinned inert monitor module is loaded with standard importlib. Its
preflight, output namespace, cwd, budgets and stream limits are substituted for
these controls. No qualification/admission/runner module is loaded or evaluated.
The unchanged monitor run(), selector, WNOWAIT, signals, capture and reap execute.
"""
from pathlib import Path
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
MONITOR = HERE.parent / 'e06-local-fonly-primary-execution-r1/monitor.py'
EXPECTED = 'c3b938f5a2f8e04124e03c420b1b1c552db227ad27ebe9e99cd24416d72b03a0'
ACTUAL = HERE / 'actual-r1'


def pinned():
    raw = MONITOR.read_bytes()
    assert len(raw) == 30311 and hashlib.sha256(raw).hexdigest() == EXPECTED
    return {'path': str(MONITOR), 'bytes': len(raw), 'sha256': EXPECTED}


def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


class MonitorControls(unittest.TestCase):
    def exercise(self, name, behavior, fault_write=False):
        source_before = pinned()
        spec = importlib.util.spec_from_file_location('owned_monitor_fixture_' + name, MONITOR)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)  # inert stdlib module; no project imports
        case = ACTUAL / name
        case.mkdir(mode=0o700)
        output = case / 'outer'
        release = case / 'fixture-release.json'
        save(release, {'fixtureOnly': True, 'notLocalAuthority': True})
        release_pin = m.descriptor(release)
        result = dict(schema='n02316-local-run-capture-v1', runId='f42a68921299',
                      runRole='primary', executionSession='/root', config=m.PINS['config'],
                      release=release_pin, status='MATCHED', counts={'fixtureOnly': 1})
        if behavior == 'valid':
            code = 'import os; os.write(1, ' + repr((json.dumps(result) + '\n').encode()) + ')'
        elif behavior == 'nonzero':
            code = "import os; os.write(2,b'fixture-natural-nonzero\\n'); raise SystemExit(7)"
        elif behavior == 'timeout':
            code = "import os,time; os.write(2,b'fixture-ready\\n'); time.sleep(8)"
        elif behavior == 'overflow':
            code = "import os,time; os.write(1,b'X'*16384); time.sleep(8)"
        elif behavior == 'writefailure':
            code = "import os,time; os.write(1,b'fixture-capture-write\\n'); time.sleep(8)"
        else:
            self.fail('Unknown fixture behavior')
        argv = [sys.executable, '-I', '-B', '-c', code]
        save(case / 'fixture-input.json', dict(substitutions=['preflight', 'ROOT', 'OUTPUT',
             'NATIVE_OUTPUT', 'TOTAL_SECONDS', 'CLEANUP_RESERVE_SECONDS', 'CAPS'], argv=argv,
             totalSeconds=3, activeSeconds=2, stdoutCap=4096, stderrCap=4096,
             meaning='Owned Python child only; not actual transport/LOCAL/native admission.'))
        events = []
        state = {'reaped': False, 'pid': None}
        original_popen = subprocess.Popen
        original_waitid, original_killpg, original_fdopen = os.waitid, os.killpg, os.fdopen

        class ObservedPopen(original_popen):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                state['pid'] = self.pid
                events.append({'op': 'acquire', 'pid': self.pid})
            def wait(self, *args, **kwargs):
                events.append({'op': 'wait-begin', 'pid': self.pid})
                value = super().wait(*args, **kwargs)
                state['reaped'] = True
                events.append({'op': 'wait-reaped', 'pid': self.pid, 'exit': value})
                return value

        def waitid(which, pid, flags):
            self.assertEqual(pid, state['pid'])
            self.assertFalse(state['reaped'], 'No waitid after final reap')
            self.assertTrue(flags & os.WNOWAIT)
            value = original_waitid(which, pid, flags)
            events.append({'op': 'waitid-WNOWAIT', 'pid': pid, 'exited': value is not None})
            return value

        def killpg(pid, signum):
            self.assertEqual(pid, state['pid'])
            self.assertFalse(state['reaped'], 'No group signal after reap')
            events.append({'op': 'killpg', 'pid': pid, 'signal': int(signum)})
            return original_killpg(pid, signum)

        class FailingWrite:
            def __init__(self, handle): self.handle = handle
            def write(self, raw): raise OSError('FIXTURE_CAPTURE_WRITE_FAILURE')
            def flush(self): return self.handle.flush()
            def fileno(self): return self.handle.fileno()
            def close(self): return self.handle.close()

        def fdopen(fd, *args, **kwargs):
            handle = original_fdopen(fd, *args, **kwargs)
            if fault_write and args and args[0] == 'wb' and os.readlink('/proc/self/fd/' + str(fd)) == str(output / 'stdout.bin'):
                return FailingWrite(handle)
            return handle

        def fixture_preflight(args, originals):
            originals.remember(source_before)
            return source_before, release_pin, argv

        printed = io.StringIO()
        started = time.monotonic()
        with patch.object(m, 'preflight', fixture_preflight), patch.object(m, 'ROOT', case), \
             patch.object(m, 'OUTPUT', output), patch.object(m, 'NATIVE_OUTPUT', case / 'native-never-created'), \
             patch.object(m, 'TOTAL_SECONDS', 3), patch.object(m, 'CLEANUP_RESERVE_SECONDS', 1), \
             patch.object(m, 'CAPS', {'stdout': 4096, 'stderr': 4096}), \
             patch.object(m.subprocess, 'Popen', ObservedPopen), patch.object(m.os, 'waitid', waitid), \
             patch.object(m.os, 'killpg', killpg), patch.object(m.os, 'fdopen', fdopen), \
             contextlib.redirect_stdout(printed):
            exit_code = m.run(object())
        elapsed = time.monotonic() - started
        with (case / 'monitor-printed.jsonl').open('x') as handle:
            handle.write(printed.getvalue())
        raw = json.loads((output / 'execution.json').read_bytes())
        self.assertEqual(pinned(), source_before)
        self.assertTrue(raw['reaped'])
        self.assertTrue(raw['stdoutEOF'] and raw['stderrEOF'])
        self.assertIsNotNone(state['pid'])
        self.assertFalse(raw['nativeOutputExists'])
        self.assertLess(elapsed, 5)
        self.assertTrue(events and events[0]['op'] == 'acquire')
        reap_positions = [i for i, e in enumerate(events) if e['op'] == 'wait-reaped']
        self.assertEqual(len(reap_positions), 1)
        self.assertFalse(any(e['op'] == 'killpg' for e in events[reap_positions[0]+1:]))
        try:
            os.kill(state['pid'], 0)
        except ProcessLookupError:
            exact_pid_absent = True
        else:
            exact_pid_absent = False
        self.assertTrue(exact_pid_absent)
        save(case / 'control-observation.json', dict(case=name, source=source_before, sourceAfter=pinned(),
             actualMonitorReturn=exit_code, elapsedSeconds=elapsed, events=events,
             exactOwnedChildPidAbsentAfterReap=exact_pid_absent,
             scope='Fixture-preflight owned-child lifecycle only; no native/LOCAL call or authority.'))
        return raw, exit_code

    def test_01_natural_zero_contextual_reply(self):
        r, code = self.exercise('natural-zero', 'valid')
        self.assertEqual(code, 0)
        self.assertEqual(r['exit'], 0)
        self.assertIsNone(r['firstError'])
        self.assertEqual(r['secondaryErrors'], [])
        self.assertFalse(r['forced'])
        self.assertTrue(r['captureComplete'])
        self.assertEqual(r['candidateResult']['status'], 'MATCHED')
        self.assertEqual(r['signals'], [])

    def test_02_natural_nonzero_retains_stderr(self):
        r, code = self.exercise('natural-nonzero', 'nonzero')
        self.assertEqual(code, 2)
        self.assertEqual(r['exit'], 7)
        self.assertFalse(r['forced'])
        self.assertEqual(r['firstError']['message'], 'QUALIFICATION_CHILD_NONZERO_EXIT')
        self.assertEqual((ACTUAL / 'natural-nonzero/outer/stderr.bin').read_bytes(), b'fixture-natural-nonzero\n')
        self.assertEqual(r['observedBytes']['stdout'], 0)

    def test_03_active_timeout_cleans_owned_child(self):
        r, code = self.exercise('active-timeout', 'timeout')
        self.assertEqual(code, 2)
        self.assertTrue(r['timedOut'])
        self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'], 'MONITOR_ACTIVE_DEADLINE')
        self.assertTrue(r['signals'])

    def test_04_stdout_overflow_caps_and_cleans(self):
        r, code = self.exercise('stdout-overflow', 'overflow')
        self.assertEqual(code, 2)
        self.assertEqual(r['firstError']['message'], 'OUTER_STDOUT_BOUND')
        self.assertGreater(r['observedBytes']['stdout'], 4096)
        self.assertEqual(r['retainedBytes']['stdout'], 4096)
        self.assertFalse(r['captureComplete'])
        self.assertTrue(r['forced'])
        self.assertEqual((ACTUAL / 'stdout-overflow/outer/stdout.bin').stat().st_size, 4096)

    def test_05_capture_write_failure_retains_error_and_cleans(self):
        r, code = self.exercise('capture-write-failure', 'writefailure', fault_write=True)
        self.assertEqual(code, 2)
        self.assertEqual(r['firstError']['message'], 'FIXTURE_CAPTURE_WRITE_FAILURE')
        self.assertEqual(r['retainedBytes']['stdout'], 0)
        self.assertGreater(r['observedBytes']['stdout'], 0)
        self.assertFalse(r['captureComplete'])
        self.assertTrue(r['forced'])
        self.assertEqual((ACTUAL / 'capture-write-failure/outer/stdout.bin').stat().st_size, 0)


if __name__ == '__main__':
    ACTUAL.mkdir(mode=0o700, exist_ok=False)
    unittest.main(verbosity=2)
