"""Prepared seven owned-child controls. SOURCE ONLY; not executed in preparation.

No Node, strace or project admission runs. Each future case retains its actual
fixture inputs, raw capture files, result and lifecycle events under
controls-actual-r1/<case>; no TemporaryDirectory removes negative evidence.
"""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import unittest
from unittest.mock import patch

SOURCE=Path(__file__).resolve().with_name('supervisor.py')
CONTROLS=SOURCE.parent/'controls-actual-r1'

def save(path,value):
    raw=(json.dumps(value,indent=2)+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())

class StartupCaptureControls(unittest.TestCase):
    def fixture(self,kind,write_fault=None):
        spec=importlib.util.spec_from_file_location('diagnostic_fixture_only',SOURCE)
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        out=CONTROLS/kind;out.mkdir(mode=0o700)
        r,w=os.pipe2(os.O_CLOEXEC)
        if kind=='natural':
            code=f"import os,sys; data=sys.stdin.buffer.read(); os.write({w},b'stdin='+str(len(data)).encode()+b'\\n'); os.write(2,b'Error: EOF_REQUEST_COUNT\\n'); raise SystemExit(1)"
        elif kind=='timeout':code=f"import os,time; os.write({w},b'prefix\\n'); time.sleep(2)"
        elif kind=='trace-cap':code=f"import os,time; os.write({w},b'T'*8192); time.sleep(2)"
        elif kind=='stderr-cap':code=f"import os,time; os.write({w},b'prefix\\n'); os.write(2,b'E'*2048); time.sleep(2)"
        elif kind=='write-failure':code=f"import os,time; os.write({w},b'prefix\\n'); time.sleep(2)"
        elif kind in ('short-positive-write','prefix-then-exception'):
            code=f"import os,time; os.write({w},b'P'*32768); time.sleep(2)"
        else:raise AssertionError('Unknown fixture')
        argv=[sys.executable,'-I','-B','-c',code]
        save(out/'fixture-input.json',{'kind':kind,'argv':argv,'writeFault':write_fault,
          'fixtureCaps':{'trace':1024,'stdout':256,'stderr':512},'fixturePhaseSeconds':'.15',
          'fixtureCleanupSeconds':'.5','scope':'Owned Python child and synthetic trace only; not Node/strace/LOCAL.'})
        events=[];state={'reaped':False};calls=[]
        real_wait=subprocess.Popen.wait;real_killpg=os.killpg;real_fdopen=os.fdopen
        def wait(child,*args,**kwargs):
            value=real_wait(child,*args,**kwargs);state['reaped']=True;events.append({'op':'reaped','exit':value});return value
        def killpg(pid,signum):
            self.assertFalse(state['reaped'],'Never signal after reap');events.append({'op':'signal','signal':int(signum)});return real_killpg(pid,signum)
        class FaultWrite:
            def __init__(self,h):self.h=h
            def write(self,b):
                calls.append({'requestedBytes':len(b),'fault':write_fault})
                if write_fault=='before':raise OSError('FIXTURE_TRACE_WRITE_FAILURE')
                prefix=b[:128];actual=self.h.write(prefix);self.h.flush()
                calls[-1]['actualPrefixBytes']=actual
                if write_fault=='short-positive':return actual
                if write_fault=='prefix-exception':raise OSError('FIXTURE_PREFIX_THEN_EXCEPTION')
                raise AssertionError('Unknown write fault')
            def flush(self):return self.h.flush()
            def fileno(self):return self.h.fileno()
            def close(self):return self.h.close()
        def fdopen(fd,*args,**kwargs):
            h=real_fdopen(fd,*args,**kwargs)
            if write_fault and args and args[0]=='wb' and os.readlink('/proc/self/fd/'+str(fd))==str(out/'trace.bin'):return FaultWrite(h)
            return h
        try:
            with patch.object(m,'PHASE_SECONDS',.15),patch.object(m,'CLEANUP_SECONDS',.5),\
                 patch.object(m,'CAPS',{'trace':1024,'stdout':256,'stderr':512}),\
                 patch.dict(m.ENTRY_PATHS,{'historicalBinding':str(out/'fixture-binding.json')}),\
                 patch.object(m.subprocess.Popen,'wait',wait),patch.object(m.os,'killpg',killpg),\
                 patch.object(m.os,'fdopen',fdopen):
                record=m.capture(argv,r,w,out)
            save(out/'capture-result.json',record)
        except BaseException as error:
            save(out/'capture-exception.json',{'type':type(error).__name__,'message':str(error)});raise
        finally:
            save(out/'lifecycle-events.json',{'events':events,'captureWriteCalls':calls,'reaped':state['reaped']})
        raw={name:(out/(name+'.bin')).read_bytes() for name in ['trace','stdout','stderr']}
        self.assertTrue(record['reaped']);self.assertTrue(all(record['eof'].values()))
        self.assertEqual(events[-1]['op'],'reaped')
        pos=next(i for i,e in enumerate(events) if e['op']=='reaped')
        self.assertFalse(any(e['op']=='signal' for e in events[pos+1:]))
        with self.assertRaises(ProcessLookupError):os.kill(record['pid'],0)
        for name,content in raw.items():
            self.assertEqual(record['retainedBytes'][name],len(content))
            self.assertEqual(record['raw'][name]['bytes'],len(content))
            self.assertLessEqual(len(content),{'trace':1024,'stdout':256,'stderr':512}[name])
        return record,raw,calls

    def test_natural_eof_has_zero_stdin_and_no_force(self):
        r,raw,_=self.fixture('natural');self.assertEqual(r['exit'],1);self.assertFalse(r['forced'])
        self.assertTrue(r['captureComplete']);self.assertIsNone(r['firstError'])
        self.assertEqual(raw['trace'],b'stdin=0\n');self.assertEqual(raw['stdout'],b'')
        self.assertEqual(raw['stderr'],b'Error: EOF_REQUEST_COUNT\n')

    def test_timeout_retains_prefix_and_cleans(self):
        r,raw,_=self.fixture('timeout');self.assertTrue(r['forced']);self.assertTrue(r['timedOut'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_15S_STARTUP_DEADLINE')
        self.assertEqual(raw['trace'],b'prefix\n')

    def test_trace_overflow_retains_exact_cap(self):
        r,raw,_=self.fixture('trace-cap');self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_TRACE_CAP')
        self.assertGreater(r['observedBytes']['trace'],1024);self.assertEqual(len(raw['trace']),1024)
        self.assertFalse(r['captureComplete'])

    def test_stderr_overflow_retains_exact_cap(self):
        r,raw,_=self.fixture('stderr-cap');self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_STDERR_CAP')
        self.assertGreater(r['observedBytes']['stderr'],512);self.assertEqual(len(raw['stderr']),512)
        self.assertFalse(r['captureComplete'])

    def test_trace_write_failure_keeps_first_error_and_cleanup(self):
        r,raw,calls=self.fixture('write-failure',write_fault='before');self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'FIXTURE_TRACE_WRITE_FAILURE')
        self.assertEqual(raw['trace'],b'');self.assertGreater(r['observedBytes']['trace'],0)
        self.assertFalse(r['captureComplete']);self.assertEqual(len(calls),1)
        self.assertEqual(r['writeState']['trace'],'POISONED_FAILED_OR_UNCERTAIN')

    def test_short_positive_write_counts_prefix_before_assert_and_poisons(self):
        r,raw,calls=self.fixture('short-positive-write',write_fault='short-positive')
        self.assertEqual(r['firstError']['message'],'COMPLETE_CAPTURE_WRITE')
        self.assertEqual(r['acknowledgedWriteBytes']['trace'],128)
        self.assertEqual(r['retainedBytes']['trace'],128);self.assertEqual(raw['trace'],b'P'*128)
        self.assertEqual(len(calls),1,'No cleanup write after partial acknowledgement')
        self.assertEqual(r['writeState']['trace'],'POISONED_FAILED_OR_UNCERTAIN')
        self.assertTrue(r['forced']);self.assertFalse(r['captureComplete'])

    def test_prefix_then_exception_reconciles_actual_file_and_poisons(self):
        r,raw,calls=self.fixture('prefix-then-exception',write_fault='prefix-exception')
        self.assertEqual(r['firstError']['message'],'FIXTURE_PREFIX_THEN_EXCEPTION')
        self.assertEqual(r['acknowledgedWriteBytes']['trace'],0)
        self.assertEqual(r['retainedBytes']['trace'],128);self.assertEqual(raw['trace'],b'P'*128)
        self.assertEqual(len(calls),1,'No cleanup write after uncertain persisted prefix')
        self.assertEqual(r['writeState']['trace'],'POISONED_FAILED_OR_UNCERTAIN')
        self.assertTrue(r['forced']);self.assertFalse(r['captureComplete'])

if __name__=='__main__':
    CONTROLS.mkdir(mode=0o700,exist_ok=False)
    unittest.main(verbosity=2)
