# Fresh primary LOCAL configuration core, R2

DATA preparation only. Authors: `/root`, `/root/e06_local_configuration` and
`/root/local_monitor_controls`. Actual independent QA/security reviewers must
remain nonauthors. This preparation creates no final configuration, approval,
release or monitor and runs no tests or experiments.

The new run is `9df61b3f71ac`, role primary, execution session `/root`, with fresh
output root `/tmp/e6n-fonly-primary-9df61b3f71ac`. Only worker runId, outputRoot and
the Q-JS/Q-RUST output paths change. Whole configuration core changes only runId
and the new worker descriptor. All remaining source449, current controls, tools,
request, native oracles, IDs, backends, inventory, derivation and authority values
remain identical. The old failed runtime and original configuration remain intact.

`comparison.json` records every changed scalar; unchanged descriptor lengths are
intentional. `static-checks.json` records current direct descriptor hashes and
exact semantic equality outside the allowed paths. New files are exclusive
regular0600 files; no existing permission was changed. Output absence is a
preparation-time observation and must be rechecked immediately before activation.

Next steps are actual independent review of this WHOLE core and worker, followed
by coordinator-created genuine approval/final configuration and a separately
reviewed fresh exact monitor. No future descriptor hash is invented here. The
authority-mode correction requires its own security disposition and root action;
this preparation does not perform or approve it.

No new protocol source or control rerun follows from these run/output-only DATA
changes. Current source, controls, pair acceptance, authority modes and fresh
paths must still be checked by actual admission. A fresh exact root release and
whole-result QA/security review remain required before any success claim.
The old OWNED_AUTHORITY_0600 failure must not be overwritten or retroactively
qualified. No canonical E06 PASS or architectural blocker closure is implied.
