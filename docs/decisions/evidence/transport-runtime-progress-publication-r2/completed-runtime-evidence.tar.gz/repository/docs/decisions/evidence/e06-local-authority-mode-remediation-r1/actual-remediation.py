from pathlib import Path
import os,json,stat,hashlib,time
R=Path('/home/peterhorvath/apps/bitcoin/NBDP');E=R/'docs/decisions/evidence';P=E/'e06-local-authority-mode-remediation-r1';assert not P.exists();P.mkdir(mode=0o700)
def d(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def info(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and p.resolve(strict=True)==p and s.st_uid==os.getuid()==1000 and s.st_nlink==1
 return dict(descriptor=d(p),mode=oct(stat.S_IMODE(s.st_mode)),uid=s.st_uid,gid=s.st_gid,device=s.st_dev,inode=s.st_ino,nlink=s.st_nlink,ctimeNs=s.st_ctime_ns,mtimeNs=s.st_mtime_ns)
def save(n,x):
 fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
source=E/'e06-qualification-current-source-r3/source-approval.json';control=E/'e06-current-controls-r2/control-approval.json';S=json.loads(source.read_bytes());C=json.loads(control.read_bytes());W=json.loads((E/'e06-local-fonly-primary-preparation-r1/worker-config.json').read_bytes())
paths=[E/'e06-local-fonly-primary-preparation-r1/worker-config.json',E/'e06-local-fonly-primary-execution-r1/exact-root-local-release.json',source,control,Path(C['actualControlEvidence']['path'])]+[Path(v['subject']['path']) for v in S['reviews']+C['reviews']]
unique=list(dict.fromkeys(paths));before=[info(p) for p in unique]
for p,h,n in [(source,'e3e41bb6bae55d80702f9002cc99c72ad3a6345405a5043d3123dcafcbea685e',107717),(control,'c2c6d2b97ba4f25dbbb9074c079cd3ad29cbf9fa23aac709b31a97a273c0f5ee',1488)]:
 x=info(p);assert x['descriptor']['sha256']==h and x['descriptor']['bytes']==n and x['mode']=='0o664'
assert all(x['mode']=='0o600' for x in before if x['descriptor']['path'] not in [str(source),str(control)])
save('before.json',dict(schema='e06-authority-mode-before-v1',actor='/root',utcNs=time.time_ns(),ownedJsonOccurrences=len(paths),uniqueOperands=before,actualFailureSubject=d(E/'e06-local-fonly-primary-runtime-r1/subject.json'),actualIndependentReviews={'qa':dict(session='/root/transport_evidence_qa',decision='ACCEPT_LOCAL_FAILURE_EVIDENCE_ONLY',modeRemediation='Permissible exact-two-file preparation after preserved stats/hash; no new PO decision.'),'security':dict(session='/root/attachment_profile_security',decision='ACCEPT_ACTUAL_LOCAL_FAILURE_EVIDENCE_ONLY',modeRemediation='ACCEPT_EXACT_TWO_FILE_MODE_REMEDIATION_PREPARATION_ONLY')},limits='Localization source-order plus stable stat/hash readback, not direct runtime operand trace. Only two file mode changes authorized; preserve original run.'))
for p in [source,control]:
 old=next(x for x in before if x['descriptor']['path']==str(p));now=info(p);assert now==old
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  s=os.fstat(fd);assert s.st_ino==old['inode'] and s.st_dev==old['device'] and s.st_uid==1000 and s.st_nlink==1;os.fchmod(fd,0o600)
 finally:os.close(fd)
after=[info(p) for p in unique]
for old,new in zip(before,after):
 assert old['descriptor']==new['descriptor'] and old['inode']==new['inode'] and old['device']==new['device'] and old['uid']==new['uid'] and old['mtimeNs']==new['mtimeNs'] and new['mode']=='0o600'
closure=json.loads((E/'e06-qualification-current-source-r3/source-closure.json').read_bytes());assert len(closure)==449
for pin in closure:
 p=Path(pin['path']);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 assert n==pin['bytes'] and h.hexdigest()==pin['sha256']
save('result.json',dict(schema='e06-authority-mode-remediation-result-v1',actor='/root',utcNs=time.time_ns(),before=d(P/'before.json'),changedOnly=[str(source),str(control)],newMode='0600',uniqueOperandsAfter=after,current449SourcePinsMatch=True,sourceBytesPathsOwnersInodesMtimesUnchanged=True,limitations=['Git does not preserve0600 separately from0644; runtime authority materialization must explicitly enforce this boundary.','Original first-run files/negative outcome remain; tightening is preparation only, no retry or native qualification.','No schema/source449/validator/expectedanswer/gate/architectural blocker change.']))
print(json.dumps({'before':d(P/'before.json'),'result':d(P/'result.json'),'occurrences':len(paths),'unique':len(unique),'source449':True}))
