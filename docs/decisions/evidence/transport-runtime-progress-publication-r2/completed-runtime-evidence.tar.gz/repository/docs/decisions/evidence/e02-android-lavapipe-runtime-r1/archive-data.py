"""Fixed DATA-only mirror of completed root run; imports no project module."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
RUN = Path('/tmp/nbdp-e02-android-lavapipe-trace-v1/runs/5d7d122920e340dcafb457281a4efbb4')
OUT = ROOT / 'docs/decisions/evidence/e02-android-lavapipe-runtime-r1'
PREP = ROOT / 'docs/decisions/evidence/e02-android-lavapipe-preparation-r1'
DIRS = ('commands', 'cleanup', 'diagnostics', 'evidence', 'ownership', 'session')
TOP = ('supervisor-result.json', 'early-boot-partial.json', 'early-boot-result.json',
       'diagnostic-partial.json', 'diagnostic-result.json')
PROFILES = ('android-state/avd/ordinary.avd/config.ini',
            'android-state/avd/ordinary.avd/hardware-qemu.ini')
PREPARATION = ('subject.json', 'proposed-run-config.json',
               'renderer-evidence-plan.json', 'exact-root-lavapipe-release.json')


def descriptor(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def mirror(source, destination):
    assert source.is_file() and not source.is_symlink(), str(source)
    before = descriptor(source)
    raw = source.read_bytes()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(raw)
    after = descriptor(source); copied = descriptor(destination)
    assert before == after
    assert (before['bytes'], before['sha256']) == (copied['bytes'], copied['sha256'])
    return dict(before, mirror=str(destination))


def main():
    assert not (OUT / 'mirror-manifest.json').exists()
    for name, size, digest in (
        ('supervisor-result.json', 3123, 'b2a02b92afde49dad9ea6a8fbff863817071af6d628b93e0b423748975fb2a95'),
        ('diagnostic-result.json', 21985, '4c56476863f7a027973312363780001da34e5eee09634f521550fa0adf67687b'),
    ):
        actual = descriptor(RUN / name)
        assert (actual['bytes'], actual['sha256']) == (size, digest)
    files = []
    for dirname in DIRS:
        for source in sorted((RUN / dirname).rglob('*')):
            if source.is_file():
                files.append(mirror(source, OUT / 'actual-run' / source.relative_to(RUN)))
    for name in TOP + PROFILES:
        files.append(mirror(RUN / name, OUT / 'actual-run' / name))
    for name in PREPARATION:
        files.append(mirror(PREP / name, OUT / 'preparation-inputs' / name))
    selected = {Path(entry['path']) for entry in files if Path(entry['path']).is_relative_to(RUN)}
    all_members = {p for p in RUN.rglob('*') if p.is_file()}
    excluded = []
    for dirname, reason in (
        ('android-state', 'Entire mutable guest state except the two explicitly selected small profile text files; no userdata/images/encryption keys/ADB keys/tokens/cache contents read or copied.'),
        ('input', 'Mounted source/fixtures/placeholders excluded; current source pins and mounted-source equality are checked separately as DATA.'),
        ('relay-data', 'Disposable relay database excluded; no publication/business-effect evidence is inferred.'),
        ('docker-config', 'Docker client configuration not needed for selected observations.'),
    ):
        paths = [p for p in sorted((RUN / dirname).rglob('*')) if p.is_file() and p not in selected]
        excluded.append({'path': str(RUN / dirname), 'reason': reason,
                         'fileCount': len(paths), 'bytesFromMetadataOnly': sum(p.stat().st_size for p in paths)})
    excluded_paths = all_members - selected
    assert all(p.relative_to(RUN).parts[0] in ('android-state', 'input', 'relay-data', 'docker-config') for p in excluded_paths)
    assert sum(x['fileCount'] for x in excluded) == len(excluded_paths)
    records = []
    for p in sorted((RUN / 'commands').glob('*.json')):
        row = json.loads(p.read_text()); records.append(row)
        assert row['exit'] == 0 and row['reaped'] and not row['forced'] and not row['timedOut']
        assert row['error'] is None and row['stdoutEOF'] and row['stderrEOF'], str(p)
    assert len(records) == 162
    result = json.loads((RUN / 'supervisor-result.json').read_text())
    diagnostic = json.loads((RUN / 'diagnostic-result.json').read_text())
    early = json.loads((RUN / 'early-boot-result.json').read_text())
    lease = json.loads((RUN / 'session/lease.json').read_text())
    revoked = (RUN / 'session/control/REVOKED').read_text()
    assert 'Observed Android ANR: System UI' in revoked and 'command deadline' not in revoked
    assert result['executionState'] == 'FAILED_UNQUALIFIED' and not result['secondaryErrors']
    assert diagnostic['completed'] and diagnostic['firstError'] is None and not diagnostic['secondaryErrors']
    assert diagnostic['environmentStatus'] == 'ENVIRONMENT_FAILURE'
    assert result['cleanup']['ok'] and len(result['cleanup']['rows']) == 4
    for row in result['cleanup']['rows']:
        assert row['identityVerified'] and row['absenceConfirmed'] and not row['errors']
    for phase in (early, diagnostic):
        assert phase['endedMonotonicNs'] < phase['phaseDeadlineMonotonicNs'] < lease['deadlineMonoNs']
        assert all(phase[k] == 0 for k in ('apkInstalls', 'activityIntents', 'identityInputs',
                                         'loginActions', 'fixtureOperations', 'clipboardOperations'))
    for axis in ('Utc', 'Mono', 'Boot'):
        assert lease['deadline' + axis + 'Ns'] - lease['issued' + axis + 'Ns'] == 1800_000_000_000
    source_pins = json.loads((PREP / 'subject.json').read_text())['sources']
    for entry in source_pins:
        assert descriptor(Path(entry['path'])) == entry
    mounted = []
    for name in ('supervisor.py', 'lease_guard.py', 'android_driver.py'):
        expected = next(entry for entry in source_pins if Path(entry['path']).name == name)
        actual = descriptor(RUN / 'input' / name)
        assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
        mounted.append({'actualMountedSource': actual, 'sourcePin': expected})
    spool = []
    ui = []
    for checkpoint in ('before-install', 'late'):
        for stream in ('stdout', 'stderr'):
            prefix = RUN / 'diagnostics' / (checkpoint + '-emulator-' + stream + '.bin')
            final = RUN / 'session/fixtures' / ('emulator.' + stream)
            a = prefix.read_bytes(); b = final.read_bytes()
            assert b.startswith(a)
            spool.append({'checkpoint': checkpoint, 'stream': stream, 'frozenPrefix': descriptor(prefix),
                          'finalAfterOwnedCleanup': descriptor(final), 'prefixMatchesFinalBeginning': True,
                          'finalGrewBeyondFrozenPrefix': len(b) > len(a), 'additionalBytes': len(b) - len(a),
                          'limit': 'Captured earlier prefix and final retained file are separate artifacts; final bytes do not retroactively extend the checkpoint.'})
        xml = RUN / 'diagnostics' / (checkpoint + '-ui-xml.bin')
        png = RUN / 'diagnostics' / (checkpoint + '-ui-png.bin')
        tree = ET.fromstring(xml.read_bytes()); assert png.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        titles = [n.get('text') for n in tree.iter('node') if n.get('resource-id') == 'android:id/alertTitle']
        ui.append({'checkpoint': checkpoint, 'xml': descriptor(xml), 'png': descriptor(png),
                   'rawTitleTexts': titles, 'comparisonMethod': 'Fresh hashes and actual XML parsing, no constant expected-baseline comparison.'})
    phase_rows = [{'phase': p['phase'], 'completed': p['completed'], 'observations': len(p['observations']),
                   'budgetSeconds': p['phaseBudgetSeconds'], 'startedMonotonicNs': p['startedMonotonicNs'],
                   'endedMonotonicNs': p['endedMonotonicNs'],
                   'usedSeconds': (p['endedMonotonicNs'] - p['startedMonotonicNs']) / 1e9} for p in (early, diagnostic)]
    save('observation.json', {
        'schema': 'lavapipe-runtime-data-observation-v1', 'state': 'FAILED_UNQUALIFIED_ENVIRONMENT_FAILURE',
        'actor': '/root/android_health_implementer; DATA archiver, not run operator or independent reviewer',
        'firstFailure': diagnostic['firstEnvironmentError'], 'rawStickyReason': revoked,
        'failureMeaning': 'Completed observation detected Android System UI ANR; supervisor refused after capture. No command-deadline failure in162 command receipts.',
        'commands': {'count': len(records), 'allNaturalExitZero': True, 'allReapedAndBothEOF': True,
                     'forced': False, 'timedOut': False, 'errors': [], 'perCommandElapsedSamples': 'NOT_RETAINED'},
        'phaseEvidence': phase_rows, 'originalLeaseSeconds': 1800,
        'diagnosticCompleted': True, 'diagnosticEnvironmentStatus': diagnostic['environmentStatus'],
        'traceCorrelation': 'UNKNOWN_PENDING_INDEPENDENT_REVIEW', 'effectiveBackend': 'UNKNOWN', 'effectiveVendor': 'UNKNOWN',
        'backendMeaning': 'Actual raw emulator/main/SurfaceFlinger captures retained; independent interpretation pending. CLI/config or labels are not backend qualification.',
        'emulatorSpoolChronology': spool, 'ui': ui, 'cleanup': result['cleanup'],
        'sourcePinsReverifiedWithoutImport': source_pins, 'actualMountedSourceBindings': mounted,
        'canonicalE02Changed': False, 'ordinaryControlQualified': False,
        'experimentRerun': False, 'sourceChanged': False,
        'limits': ['No healthy baseline, ANR cause/fix or causal renderer comparison claim.',
                   'Latest trace/DropBox identity/reason/stack require independent matching.',
                   'Whole-container metrics and phase endpoints do not establish peaks, per-process resource cause or hard realtime.',
                   'No install/intent/identity/login/input/publication/business/native/crypto experiment was performed by this archiver.']})
    save('root-tool-association.json', {
        'schema': 'root-tool-association-transcription-v1',
        'provenance': 'Explicit parent /root mailbox transcription, not operated or independently witnessed by this DATA archiver.',
        'foregroundSession': 47670, 'launchToolChunk': 'eec7d6', 'completionToolChunk': '3bbf6e',
        'exit': 2, 'state': 'FINISHED', 'run': str(RUN),
        'supervisor': descriptor(RUN / 'supervisor-result.json'),
        'diagnostic': descriptor(RUN / 'diagnostic-result.json')})
    save('mirror-manifest.json', {
        'schema': 'lavapipe-selected-raw-mirror-v1', 'run': str(RUN), 'archiver': descriptor(Path(__file__).resolve()),
        'files': files, 'selectedRunFiles': len(selected), 'preparationFiles': len(PREPARATION),
        'mirroredFiles': len(files), 'mirroredBytes': sum(x['bytes'] for x in files),
        'originalAndMirrorPinsVerified': True, 'exclusions': excluded,
        'externalExclusions': ['SDK, Android images, APKs and node_modules/cache trees not read or copied.',
                               'No guest disk/userdata/encryption/ADB keys/tokens copied; only two named small config text files selected from android-state.'],
        'sourceExecution': False, 'experimentRerun': False})
    print(json.dumps({'mirroredFiles': len(files), 'mirroredBytes': sum(x['bytes'] for x in files),
        'commandReceipts': len(records), 'phaseEvidence': phase_rows, 'state': 'ARCHIVED_PENDING_INDEPENDENT_REVIEW'}))


if __name__ == '__main__':
    main()
