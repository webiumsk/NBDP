"""DATA-only exact mirror of the completed root LOCAL attempt; no project imports."""
from pathlib import Path
import hashlib,json,os,stat
HERE=Path(__file__).resolve().parent
NATIVE=Path('/tmp/e6n-fonly-primary-9df61b3f71ac')
OUTER=HERE.parent/'e06-local-fonly-primary-execution-r2/outer-actual'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def identity(s):return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def inventory(root):
 assert root.is_absolute() and root.resolve(strict=True)==root and stat.S_ISDIR(root.lstat().st_mode)
 rows=[]
 for p in sorted(root.rglob('*')):
  s=p.lstat()
  assert not stat.S_ISLNK(s.st_mode),str(p)
  if stat.S_ISDIR(s.st_mode):continue
  assert stat.S_ISREG(s.st_mode),str(p)
  rows.append((p,s))
 return rows
assert pin(OUTER/'execution.json') == dict(path=str(OUTER/'execution.json'),bytes=146297,sha256='0b471d85f9c65161614e5649c366eb07d8e9c7ff442d0ab261f4f5a479e3fc68')
out=HERE/'actual-run';assert not out.exists();out.mkdir(mode=0o700)
rows=[]
for label,root in [('native',NATIVE),('outer',OUTER)]:
 initial=inventory(root)
 for p,s in initial:
  before=identity(s);raw=p.read_bytes();after=p.lstat();assert before==identity(after)
  dst=out/label/p.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True)
  fd=os.open(dst,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  original=pin(p);mirror=pin(dst)
  assert original['bytes']==mirror['bytes'] and original['sha256']==mirror['sha256']
  assert before==identity(p.lstat())
  rows.append(dict(group=label,original=original,mirror=mirror,originalMode=oct(stat.S_IMODE(s.st_mode)),originalUid=s.st_uid,originalGid=s.st_gid,originalIdentity=dict(device=s.st_dev,inode=s.st_ino,size=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns)))
 final=inventory(root);assert [(str(p),identity(s)) for p,s in initial]==[(str(p),identity(s)) for p,s in final]
manifest=dict(schema='e06-completed-local-runtime-mirror-v1',mirrorOperator='/root/local_monitor_controls',actualExecutionOperator='/root',runId='9df61b3f71ac',roots={'native':str(NATIVE),'outer':str(OUTER)},files=rows,fileCount=len(rows),logicalBytes=sum(x['original']['bytes'] for x in rows),scope='All regular files of the completed native and outer output trees; only exact DATA copying, no recursive external descriptors, no source/runtime changes.',originalsPreserved=True,symlinksOrSpecialFiles=0)
p=HERE/'mirror-manifest.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(manifest=pin(p),files=len(rows),native=sum(x['group']=='native' for x in rows),outer=sum(x['group']=='outer' for x in rows),logicalBytes=manifest['logicalBytes'])))
