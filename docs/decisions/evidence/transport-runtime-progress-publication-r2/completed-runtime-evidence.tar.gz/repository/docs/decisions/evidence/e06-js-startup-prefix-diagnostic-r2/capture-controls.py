"""Finite capture of the owned-child controls; never invokes LOCAL admission."""
from pathlib import Path
import hashlib,json,os,selectors,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
TEST=HERE/'test_capture.py'
MONITOR=HERE/'supervisor.py'
FROZEN=['subject.json','supervisor.py','configuration.json','test_capture.py','original-inventory.json']
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for n in ('suite-stdout.bin','suite-stderr.bin','suite-execution.json'):
 assert not (HERE/n).exists()
assert not (HERE/'controls-actual-r1').exists()
frozen_before={n:pin(HERE/n) for n in FROZEN}
monitor_before=pin(MONITOR)
assert monitor_before['bytes']==20498 and monitor_before['sha256']=='f16375a685f2c635951f78e425d1f43641b27d1fd6e4f691ce5c273581b6ad62'
argv=[sys.executable,'-I','-B',str(TEST)]
started=time.monotonic_ns(); deadline=time.monotonic()+25
p=subprocess.Popen(argv,cwd=HERE,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'})
sel=selectors.DefaultSelector(); caps={'stdout':1048576,'stderr':1048576};counts=dict(stdout=0,stderr=0);eof=dict(stdout=False,stderr=False);forced=False;first=None
files={n:(HERE/('suite-'+n+'.bin')).open('xb') for n in caps}
for n,s in [('stdout',p.stdout),('stderr',p.stderr)]:
 os.set_blocking(s.fileno(),False);sel.register(s,selectors.EVENT_READ,n)
while not all(eof.values()):
 if time.monotonic()>deadline:
  first='SUITE_EXTERNAL_DEADLINE';forced=True;os.killpg(p.pid,signal.SIGKILL);break
 for key,_ in sel.select(.1):
  n=key.data;b=os.read(key.fd,65536)
  if not b:
   eof[n]=True;sel.unregister(key.fileobj);continue
  keep=b[:max(0,caps[n]-counts[n])];files[n].write(keep);counts[n]+=len(keep)
  if len(keep)!=len(b):
   first='SUITE_'+n.upper()+'_BOUND';forced=True;os.killpg(p.pid,signal.SIGKILL);break
 if forced:break
exit_code=p.wait(timeout=2)
for f in files.values():f.flush();os.fsync(f.fileno());f.close()
sel.close();p.stdout.close();p.stderr.close()
record=dict(schema='e06-startup-prefix-owned-child-suite-capture-v1',operator='/root/local_monitor_controls',argv=argv,cwd=str(HERE),stdin='DEVNULL',source=pin(TEST),captureSource=pin(Path(__file__).resolve()),interpreter=pin(Path(sys.executable).resolve()),monitorBefore=monitor_before,monitorAfter=pin(MONITOR),frozenBefore=frozen_before,frozenAfter={n:pin(HERE/n) for n in FROZEN},exit=exit_code,reaped=True,forced=forced,firstError=first,stdoutEOF=eof['stdout'],stderrEOF=eof['stderr'],retainedBytes=counts,streamCaps=caps,externalCeilingSeconds=25,elapsedNs=time.monotonic_ns()-started,stdout=pin(HERE/'suite-stdout.bin'),stderr=pin(HERE/'suite-stderr.bin'),limits=['Owned Python-child startup capture controls with synthetic trace pipe and reduced limits; no Node/strace workload, LOCAL admission, native interoperability or canonical assertions.','No Docker/Android/network/crypto/qualification/admission/runner module evaluation.','If outer capture were forced, no claim of separate-session descendant absence would follow.'])
(HERE/'suite-execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(0 if exit_code==0 and not forced and first is None and all(eof.values()) and record['monitorBefore']==record['monitorAfter'] and record['frozenBefore']==record['frozenAfter'] else 2)
