"""Prepared owned-Python-child controls. SOURCE ONLY; not executed in preparation.

No strace/Node/project modules run. The diagnostic supervisor is inertly imported;
fixture argv writes synthetic trace text through the inherited trace pipe. Actual
capture/lifecycle is exercised with reduced fixture-only caps/deadlines.
"""
from pathlib import Path
import importlib.util
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

SOURCE=Path(__file__).resolve().with_name('supervisor.py')

class StartupCaptureControls(unittest.TestCase):
    def fixture(self,kind,write_failure=False):
        spec=importlib.util.spec_from_file_location('diagnostic_fixture_only',SOURCE)
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        with tempfile.TemporaryDirectory(prefix='nbdp-startup-capture-control-') as tmp:
            out=Path(tmp);r,w=os.pipe2(os.O_CLOEXEC)
            if kind=='natural':
                code=f"import os,sys; data=sys.stdin.buffer.read(); os.write({w},b'stdin='+str(len(data)).encode()+b'\\n'); os.write(2,b'Error: EOF_REQUEST_COUNT\\n'); raise SystemExit(1)"
            elif kind=='timeout':code=f"import os,time; os.write({w},b'prefix\\n'); time.sleep(2)"
            elif kind=='trace-cap':code=f"import os,time; os.write({w},b'T'*8192); time.sleep(2)"
            elif kind=='stderr-cap':code=f"import os,time; os.write({w},b'prefix\\n'); os.write(2,b'E'*2048); time.sleep(2)"
            elif kind=='write-failure':code=f"import os,time; os.write({w},b'prefix\\n'); time.sleep(2)"
            else:raise AssertionError('Unknown fixture')
            events=[];state={'reaped':False};real_wait=subprocess.Popen.wait;real_killpg=os.killpg;real_fdopen=os.fdopen
            def wait(child,*args,**kwargs):
                value=real_wait(child,*args,**kwargs);state['reaped']=True;events.append('reaped');return value
            def killpg(pid,signum):
                self.assertFalse(state['reaped'],'Never signal after reap');events.append('signal');return real_killpg(pid,signum)
            class FailWrite:
                def __init__(self,h):self.h=h
                def write(self,b):raise OSError('FIXTURE_TRACE_WRITE_FAILURE')
                def flush(self):return self.h.flush()
                def fileno(self):return self.h.fileno()
                def close(self):return self.h.close()
            def fdopen(fd,*args,**kwargs):
                h=real_fdopen(fd,*args,**kwargs)
                if write_failure and args and args[0]=='wb' and os.readlink('/proc/self/fd/'+str(fd))==str(out/'trace.bin'):return FailWrite(h)
                return h
            with patch.object(m,'PHASE_SECONDS',.15),patch.object(m,'CLEANUP_SECONDS',.5),\
                 patch.object(m,'CAPS',{'trace':1024,'stdout':256,'stderr':512}),\
                 patch.dict(m.ENTRY_PATHS,{'historicalBinding':str(out/'fixture-binding.json')}),\
                 patch.object(m.subprocess.Popen,'wait',wait),patch.object(m.os,'killpg',killpg),\
                 patch.object(m.os,'fdopen',fdopen):
                record=m.capture([sys.executable,'-I','-B','-c',code],r,w,out)
            raw={name:(out/(name+'.bin')).read_bytes() for name in ['trace','stdout','stderr']}
            self.assertTrue(record['reaped']);self.assertTrue(all(record['eof'].values()))
            self.assertEqual(events[-1],'reaped');self.assertNotIn('signal',events[events.index('reaped')+1:])
            with self.assertRaises(ProcessLookupError):os.kill(record['pid'],0)
            return record,raw

    def test_natural_eof_has_zero_stdin_and_no_force(self):
        r,raw=self.fixture('natural');self.assertEqual(r['exit'],1);self.assertFalse(r['forced'])
        self.assertTrue(r['captureComplete']);self.assertIsNone(r['firstError'])
        self.assertEqual(raw['trace'],b'stdin=0\n');self.assertEqual(raw['stdout'],b'')
        self.assertEqual(raw['stderr'],b'Error: EOF_REQUEST_COUNT\n')

    def test_timeout_retains_prefix_and_cleans(self):
        r,raw=self.fixture('timeout');self.assertTrue(r['forced']);self.assertTrue(r['timedOut'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_15S_STARTUP_DEADLINE')
        self.assertEqual(raw['trace'],b'prefix\n')

    def test_trace_overflow_retains_exact_cap(self):
        r,raw=self.fixture('trace-cap');self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_TRACE_CAP')
        self.assertGreater(r['observedBytes']['trace'],1024);self.assertEqual(len(raw['trace']),1024)
        self.assertFalse(r['captureComplete'])

    def test_stderr_overflow_retains_exact_cap(self):
        r,raw=self.fixture('stderr-cap');self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'DIAGNOSTIC_STDERR_CAP')
        self.assertGreater(r['observedBytes']['stderr'],512);self.assertEqual(len(raw['stderr']),512)
        self.assertFalse(r['captureComplete'])

    def test_trace_write_failure_keeps_first_error_and_cleanup(self):
        r,raw=self.fixture('write-failure',write_failure=True);self.assertTrue(r['forced'])
        self.assertEqual(r['firstError']['message'],'FIXTURE_TRACE_WRITE_FAILURE')
        self.assertEqual(raw['trace'],b'');self.assertGreater(r['observedBytes']['trace'],0)
        self.assertFalse(r['captureComplete'])

if __name__=='__main__':unittest.main(verbosity=2)
