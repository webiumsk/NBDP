from pathlib import Path
import os,stat,json,hashlib,subprocess,shutil,time
R=Path('/home/peterhorvath/apps/bitcoin/NBDP');E=R/'docs/decisions/evidence';P=E/'e02-owned-avd-overlay-reclamation-r2';assert not P.exists();P.mkdir(mode=0o700)
def d(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def save(n,v):
 fd=os.open(P/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
inputs=[('nbdp-e02-android-boot-trace-v1','a378eba11798416a8c992f371b61f93b',2495572),('nbdp-e02-android-lavapipe-trace-v1','5d7d122920e340dcafb457281a4efbb4',2496158),('nbdp-e02-ordinary-client-v1','af9a4d7a477b4b9e9e122d312c60a34b',2493423),('nbdp-e02-ordinary-client-v1','267acc88b6604d1d9218e5ffe89f6ff1',2494182)];rows=[];cids=[]
for lab,run,inode in inputs:
 root=Path('/tmp')/lab/'runs'/run;p=root/'android-state/avd/ordinary.avd/userdata-qemu.img.qcow2';s=p.lstat();assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid()==1000 and s.st_gid==1000 and s.st_nlink==1 and s.st_dev==64513 and s.st_ino==inode
 assert all(not a.is_symlink() for a in p.parents)
 result=root/'supervisor-result.json';x=json.loads(result.read_bytes());assert x['executionState']=='FAILED_UNQUALIFIED' and x['cleanup']['ok'] and len(x['cleanup']['rows'])==4 and all(a['identityVerified'] and a['absenceConfirmed'] and a['removeExit']==0 for a in x['cleanup']['rows']);cids.extend(a['cid'] for a in x['cleanup']['rows'])
 profiles=[d(p.parent/n) for n in ['config.ini','hardware-qemu.ini']]
 rows.append(dict(overlay=d(p),device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,nlink=s.st_nlink,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,allocatedBytes=s.st_blocks*512,preservedProfiles=profiles,sourceResult=d(result)))
closure=(E/'e06-qualification-current-source-r3/source-closure.json').read_text();assert all(a['overlay']['path'] not in closure for a in rows)
a=subprocess.run(['docker','inspect',*cids],capture_output=True,timeout=20);assert a.returncode==1 and a.stdout.strip()==b'[]' and a.stderr==b''.join(('error: no such object: '+cid+'\n').encode() for cid in cids)
b=subprocess.run(['fuser',*[a['overlay']['path'] for a in rows]],capture_output=True,timeout=20);assert b.returncode==1 and not b.stdout.strip() and not b.stderr.strip()
save('before.json',dict(schema='nbdp-owned-disposable-overlay-reclamation-before-v1',actor='/root',utcNs=time.time_ns(),files=rows,freeBytes=shutil.disk_usage('/tmp').free,absence=dict(exactCids=cids,dockerExit=a.returncode,stdout=a.stdout.decode(),stderr=a.stderr.decode(),fuserExit=b.returncode,stdoutFuser=b.stdout.decode(),stderrFuser=b.stderr.decode()),independentInventory=dict(session='/root/android_anr_diagnosis',proof='1716 relevantJSON/source449/boot475+Lavapipe597 manifests have no userdataimage pins; all four exactownedregular files/cids absent/current no-open users observed.'),scope='Only4owneddiscardedguestuserdataimages; allotherstate/configuration/keys/rawsource/evidence/SDK/userwork preserved; no broader directory cleanup.'))
for row in rows:
 p=Path(row['overlay']['path']);s=p.lstat();assert s.st_dev==row['device'] and s.st_ino==row['inode'] and s.st_uid==1000 and s.st_nlink==1 and s.st_size==row['overlay']['bytes'] and s.st_mtime_ns==row['mtimeNs'] and s.st_ctime_ns==row['ctimeNs'] and stat.S_ISREG(s.st_mode);p.unlink();assert not p.exists()
 for q in row['preservedProfiles']:assert d(Path(q['path']))==q
save('result.json',dict(schema='nbdp-owned-disposable-overlay-reclamation-result-v1',actor='/root',utcNs=time.time_ns(),before=d(P/'before.json'),removed=[a['overlay'] for a in rows],allEightProfilesPreserved=True,freeAfter=shutil.disk_usage('/tmp').free,limits='No other files removed; guest resumption intentionally unavailable. Recorded raw/profiles/keys/source/canonical results unchanged. Fresh6GiB admission still mandatory; disk estimates are not runtime guarantees.'))
print((P/'result.json').read_text())
