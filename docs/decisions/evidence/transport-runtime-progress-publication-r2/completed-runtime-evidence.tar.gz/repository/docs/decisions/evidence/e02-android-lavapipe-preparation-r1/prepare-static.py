"""One-use source DATA freeze; stdlib AST/hash/diff, never project imports/tests."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
S = ROOT / 'experiments/prototypes/e02_android_lavapipe_trace_v1'
E = ROOT / 'docs/decisions/evidence/e02-android-lavapipe-preparation-r1'
B = ROOT / 'experiments/prototypes/e02_android_boot_trace_v1'
P = ROOT / 'docs/decisions/evidence/e02-android-boot-trace-preparation-r1'


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, value):
    with (E / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def functions(path):
    tree = ast.parse(path.read_bytes())
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result[node.name] = ast.dump(node, include_attributes=False)
        elif isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    result[node.name + '.' + method.name] = ast.dump(method, include_attributes=False)
    return result


def constants(path, names):
    result = {}
    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in names:
            result[node.targets[0].id] = ast.literal_eval(node.value)
    assert set(result) == set(names)
    return result


def main():
    assert not (E / 'subject.json').exists()
    protected = []
    for name, subject in (
        ('ordinary', E.parent / 'e02-ordinary-client-resume-r1/complete-source-config-subject-r11.json'),
        ('healthA', E.parent / 'e02-android-health-preparation-r2/subject.json'),
        ('cpu8B', E.parent / 'e02-android-health-cpu8-preparation-r1/subject.json'),
        ('bootTrace', P / 'subject.json'),
    ):
        value = json.loads(subject.read_text())
        for entry in value['sources']:
            assert pin(Path(entry['path'])) == entry, (name, entry['path'])
        protected.append({'name': name, 'subject': pin(subject), 'sourceCount': len(value['sources']), 'allCurrentPinsMatch': True})
    sources = [pin(path) for path in sorted(S.iterdir()) if path.is_file()]
    assert len(sources) == 12
    for path in S.glob('*.py'): ast.parse(path.read_bytes())
    a = constants(B / 'supervisor.py', ['CONFIG', 'EMULATOR', 'LIMITS', 'ROLES', 'LOG_OPTIONS', 'RUNTIME', 'RELAY', 'PY'])
    b = constants(S / 'supervisor.py', list(a))
    assert b['CONFIG'] == a['CONFIG'].replace('swiftshader_indirect', 'lavapipe')
    desired = list(a['EMULATOR']); desired[desired.index('-gpu') + 1] = 'lavapipe'
    assert b['EMULATOR'] == desired
    for key in set(a) - {'CONFIG', 'EMULATOR'}: assert a[key] == b[key], key
    changed = {}; unchanged = {}
    for name in ['supervisor.py', 'lease_guard.py', 'android_driver.py']:
        old = functions(B / name); new = functions(S / name)
        changed[name] = [key for key in sorted(set(old) | set(new)) if old.get(key) != new.get(key)]
        unchanged[name] = [key for key in sorted(old) if old[key] == new.get(key)]
    assert changed['lease_guard.py'] == sorted([
        'Lease.run_checked', '_EmulatorCapture.__init__', '_EmulatorCapture.close', '_EmulatorCapture.write', 'allowed_adb'])
    for key in ['sample', 'issue', 'strict', 'health_cgroup', 'Lease.__init__', 'Lease.revoke',
                'Lease.check', 'Lease.sleep', 'Lease.dispatch', 'main', 'adb_timeout']:
        assert key in unchanged['lease_guard.py'], key
    for key in ['Runtime.cleanup', 'Runtime.validate_owned', 'Runtime.validate_identity', 'Runtime.inspect',
                'Runtime.check', 'Runtime.command', 'Runtime.adb', 'Runtime.guest', 'Runtime.fixture',
                'Runtime.snapshot', 'finalize', 'qualify_namespace', 'require_android_affinity']:
        assert key in unchanged['supervisor.py'], key
    assert 'TracePhase.renderer' in changed['android_driver.py']
    for key in ['TracePhase.remaining', 'TracePhase.adb', 'TracePhase.metrics', 'TracePhase.ui',
                'TracePhase.finish', 'TracePhase.failure', 'TracePhase.release_cap', 'early', 'trace_observation', 'optional_status', 'anr_titles']:
        assert key in unchanged['android_driver.py'], key
    assert (S / 'test_lease_guard.py').read_bytes() == (B / 'test_lease_guard.py').read_bytes()
    for name in ['fixture.mjs', 'fixture-plan.json', 'ui-plan.json']:
        assert (S / name).read_bytes() == (B / name).read_bytes()
    counts = {}
    for path in sorted(S.glob('test_*.py')):
        counts[path.name] = sum(isinstance(n, ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(path.read_bytes())))
    assert counts == {'test_cleanup.py': 24, 'test_diagnostic.py': 28, 'test_lavapipe.py': 11, 'test_lease_guard.py': 29}, counts
    patch = []
    for path in sorted(S.iterdir()):
        if not path.is_file(): continue
        original = B / path.name
        patch.extend(difflib.unified_diff(original.read_text().splitlines(True) if original.exists() else [],
            path.read_text().splitlines(True), fromfile=str(original) if original.exists() else '/dev/null', tofile=str(path)))
    with (E / 'source.diff').open('x') as out: out.writelines(patch)
    config = json.loads((P / 'proposed-run-config.json').read_text())
    config.update(schema='e02-android-lavapipe-trace-runtime-plan-v1',
        scope='ANDROID_LAVAPIPE_TRACE_ONLY_NO_INSTALL_OR_INTENT', runId=uuid.uuid4().hex,
        state='SOURCE_ONLY_REQUIRES_NEW_INDEPENDENT_REVIEW_AND_RELEASE')
    config['sourceAndDependencyPins'] = [pin(S / Path(entry['path']).name) for entry in config['sourceAndDependencyPins']]
    save('proposed-run-config.json', config)
    output = Path('/tmp/nbdp-e02-android-lavapipe-trace-v1/runs') / config['runId']
    assert not output.exists()
    save('renderer-evidence-plan.json', {
        'schema': 'lavapipe-raw-backend-evidence-plan-v1',
        'scope': config['scope'], 'requestedRenderer': 'lavapipe', 'actualEffectiveBackend': 'UNKNOWN',
        'actualVendor': 'UNKNOWN', 'historicalEffectiveBackend': 'UNKNOWN',
        'sourceInput': 'Parent reports pinned cached37.2.12 supports Lavapipe and old swiftshader_indirect normalizes swiftshader. This implementer did not execute a binary or attest full source-to-binary identity.',
        'rawRequirements': ['Live emulator stdout/stderr prefixes before service termination',
            'Exact mandatory main-buffer epoch logcat', 'Exact mandatory dumpsys -t5 SurfaceFlinger',
            'Independent review of effective initialized backend and coherent runtime renderer/vendor; CLI/config alone insufficient'],
        'captureOrder': ['Original early30s three-read prefix', 'Original boot wait and namespace/build checks',
            'Original postboot trace/metrics prefix', 'Fixed private emulator stream prefixes',
            'Exact main/SurfaceFlinger reads', 'Unchanged mandatory uiautomator/XML/PNG',
            'Original bounded late checkpoint inside same180s phase'],
        'acceptance': ['All mandatory captures complete within original budgets, no forced/error/overflow and exact-owned cleanup',
            'Actual initialized renderer/vendor independently established from raw runtime output; contradictory/fallback/missing identity is UNKNOWN or FAIL',
            'Raw OS ANR/correlation/status retained; no health inference from absent ANR in short window'],
        'limits': ['Alternative environment readiness only, not causal comparison or a fix',
            'Unsupported/permission/empty output never becomes health/backend success',
            'Nonzero/timeout/overflow remains mandatory sticky failure; no UI deadline extension or skip',
            'Same image/software/storage is not an independent implementation; E02 remains PARTIAL22']})
    save('static-checks.json', {
        'schema': 'lavapipe-source-static-checks-v1', 'actor': '/root/android_health_implementer',
        'method': 'stdlib DATA hashing, JSON, AST and byte diff only; no project imports/tests/runtime',
        'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_REVIEW', 'protectedSourceGroups': protected,
        'changedFunctions': changed, 'unchangedFunctions': unchanged, 'sources': sources,
        'sourcePatch': pin(E / 'source.diff'), 'proposedConfiguration': pin(E / 'proposed-run-config.json'),
        'testDefinitionsOnly': counts, 'actualExecution': {'controls': 0, 'android': 0, 'services': 0},
        'verified': ['Renderer argv/config only semantic environment delta; all resource/image/guest pins unchanged',
            'Original clock/lease core, private-cgroup reader, ownership/inspect/cleanup AST unchanged',
            'Guard default-off path retained; only exact immutable emulator service can enable fixed capture',
            'Android start adds one exact own-run session/fixtures RW bind, strict expected-mount validation unchanged',
            '11 additional control definitions are prepared, not executed',
            'No new install, intent, identity/login, publication, UI recovery or ADB path authority'],
        'unknowns': ['Actual new tests results', 'Actual cached emulator support/load behavior',
            'Effective renderer/vendor', 'OS readiness/ANR cause', 'Full source-to-binary build attestation']})
    save('subject.json', {
        'schema': 'e02-lavapipe-source-config-subject-v1', 'author': '/root/android_health_implementer',
        'sourceAuthors': ['/root', '/root/e02_supervisor_implementer', '/root/e02_ui_implementer', '/root/android_health_implementer'],
        'coordinator': '/root', 'state': 'WRITES_STOPPED_PENDING_INDEPENDENT_REVIEW', 'scope': config['scope'],
        'sources': sources, 'configuration': pin(E / 'proposed-run-config.json'),
        'staticChecks': pin(E / 'static-checks.json'), 'baselineProvenance': pin(E / 'baseline-provenance.json'),
        'baselineSourceSubject': pin(P / 'subject.json'),
        'rendererEvidencePlan': pin(E / 'renderer-evidence-plan.json'), 'preparationScript': pin(Path(__file__).resolve()),
        'plannedOutput': str(output), 'executionReleased': False,
        'actualExecution': {'controls': 0, 'android': 0, 'relayPublications': 0},
        'requiredReviews': ['Independent exact source/config QA', 'Independent exact source/config security',
            'Actual reviewed controls and independent result acceptance', 'Fresh exact root diagnostic-only release'],
        'limits': ['Prepared source is not executed evidence; author cannot approve own findings',
            'No canonical result, blocker classification or architecture change', 'No backend/health/fix/causal claim']})
    interpreter = Path('/home/peterhorvath/.miniforge3/bin/python3.13')
    save('execution-plan.json', {
        'schema': 'lavapipe-proposed-execution-plan-v1', 'state': 'SOURCE_ONLY_NOT_EXECUTED_NOT_RELEASED',
        'subject': pin(E / 'subject.json'), 'configuration': pin(E / 'proposed-run-config.json'),
        'interpreter': pin(interpreter),
        'proposedPureControlCommands': [[str(interpreter), '-I', '-B', str(S / name)] for name in counts],
        'controlCounts': counts, 'controlCaptureRequirement': 'One finite foreground invocation per suite; raw streams/natural exit/reap/forced/error/timing plus before/after source/interpreter pins; no fix/retry without reviewed revision',
        'ownedChildMeaning': 'Guard and Lavapipe suites may create finite owned Python children only; Popen emulator argv mapping is test-only. No Docker/Android/network/crypto experiment.',
        'futureRuntimeFixedArgv': [str(interpreter), '-I', '-B', str(S / 'supervisor.py'),
            '--config', str(E / 'proposed-run-config.json'), '--config-sha', pin(E / 'proposed-run-config.json')['sha256'], '--out', str(output)],
        'futureRuntimeMissingBindings': {'--release': 'Fresh exact coordinator-owned reviewed release path',
                                         '--release-sha': 'Actual SHA256 only after that release exists'},
        'releaseSchema': 'e02-android-lavapipe-trace-release-v1',
        'rootReleaseCreated': False, 'leaseIssued': False, 'testsExecuted': False,
        'prerequisites': ['Independent source/config reviews', 'Actual current29/24/28/11 controls and independent acceptance',
            'Fresh current host/cache/source/admission checks and new exact root release; original1800s lease encompasses all phases'],
        'minimumOwnerInput': None})
    print(json.dumps({'sourceFiles': len(sources), 'preparedControlCounts': counts,
        'subject': pin(E / 'subject.json'), 'configuration': pin(E / 'proposed-run-config.json'),
        'state': 'WRITES_STOPPED_SOURCE_ONLY'}))


if __name__ == '__main__':
    main()
