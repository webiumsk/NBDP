# JS startup prefix diagnostic R3 — SOURCE/fixture revision only

Scope remains DIAGNOSTIC_STARTUP_PREFIX_ONLY. Authors are `/root` and
`/root/local_monitor_controls`; independent reviewers must remain nonauthors.
No R3 controls, Node, strace workload, attach, diagnostic or LOCAL execution has
run. No root grant, approval or future descriptor hash is created here.

## Preserved negative evidence and exact correction

R1 QA held its partial-write accounting source. R2 corrected capture accounting
and received SOURCE review, but its actual once-run fixture suite failed:5/7
passed,2 failed. Short-positive did not reach any write before its reduced.15s
window; timeout reached cleanup but emitted no expected prefix. That failure
remains accepted failure evidence, not activation readiness. Existing R1/R2
sources,48 actual control artifacts, review records and modes remain unchanged.
`prior-preservation.json` records every existing file and the three R2 suite
files' original0664 modes; this revision performs no chmod.

R3 changes only the fixture window to2.0s and child sleep to8s. The window still
starts before Popen and is never reset. Every one of the seven assertion-method
ASTs is identical to R2: natural EOF/zero input, timeout with actual prefix, trace
overflow, stderr overflow, before-write failure, partial positive write and
prefix-then-exception. A timeout is not an accepted substitute for exercising
partial-write behavior. The latter two must actually persist128 bytes and prove
one write attempt, original first fault, exact raw/count agreement, caps,
poisoning and independent EOF/reap cleanup. All seven must execute without skips.

The common fixture retains each future case's input, raw trace/stdout/stderr,
result and lifecycle events in controls-actual-r1/<case> under this fresh R3
namespace. No TemporaryDirectory removes evidence. Existing raw synthetic cases
are never overwritten or treated as interchangeable with a fresh run.

## Production diagnostic scope is unchanged

Every supervisor function/class and all global AST except HERE are identical to
accepted R2. The inventory retains all470 other rows byte/stat exact:449 current
source members,17 original R2 native files,3 original outer files and cached
strace; Node is already in the449. Only the own supervisor row is renewed to
this R3 path/pin/stat, giving471 unique rows. Configuration changes only its own
supervisor/inventory descriptors and fresh output path. Trace flags/entries,
environment, zero DEVNULL stdin, historical-binding semantics and all caps are
unchanged. Read-family buffers remain raw/undecoded; no payload/key/env dump.

Production diagnostic budgets remain20s admission,15s startup including tracer,
5s cleanup and20s postflight inside60s. Existing LOCAL15/240/1500/1800 budgets
are untouched. The fixture2s window is not a claim that the actual15s diagnostic
completed or that its startup/authority path passed. There is no full LOCAL
retry, protocol optimization, business request, sidecar, SDK or canonical PASS.

## New private bounded control-capture helper

`capture-controls.py` is now part of the complete frozen source subject. It pins
the whole actual subject file list plus itself and fixed Python3.13 before/after.
It starts only test_capture.py, with zero stdin and fixed environment. Its25s
outer budget reserves23s active and2s cleanup; it retains WNOWAIT ownership
through possible group TERM/KILL and never signals after final reap. It uses
1MiB stdout/stderr caps, accounts positive prefixes, poisons uncertain streams,
and reconciles raw sizes. This wrapper is trusted owned-child capture, not
hostile containment or proof of escaped-descendant absence. Python checks cannot
hard-preempt blocked kernel/filesystem calls.

Both raw suite files and suite-execution.json are exclusive regular0600 files
created with O_CREAT|O_EXCL|O_NOFOLLOW, unbuffered writes and explicit flush/fsync.
Current R2 mode history is preserved rather than silently repaired. A capture
write/storage or lifecycle failure remains visible and unqualified. Suite exit0
is not independent acceptance or an NBDP experiment PASS.

## Review, activation and interpretation

Same independent QA/security SOURCE review of the whole supervisor/helper/test/
configuration/inventory/plan subject precedes running any R3 controls. Preserve
the first actual result; no autonomous fix/retry follows failure. Only accepted
actual seven-control evidence can support later diagnostic readiness, and root
must separately create the exact fresh diagnostic-only grant under the unchanged
strict contract in supervisor.py and configuration.json. Saved R2 binding/release
are historical input, never fresh authority. Grant hashes/reports remain absent.

Expected startup EOF_REQUEST_COUNT is diagnostic-only. Timeout gives a prefix,
not completed startup. Source filenames and trace timings are phase inference,
not JS markers, measured untraced performance or proven cause. No CPU/RSS claim
is made; time is not selected. Historical strace version/help copies retain their
original R1 descriptors and actual tool dd7992; no metadata probe was rerun.
Ptrace permission and actual trace support remain UNKNOWN. No architectural
blocker, canonical gate, production service or user decision changes.
