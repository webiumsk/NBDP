"""DATA preparation only. No project imports, evaluation or runtime dispatch.

Writes only this assigned preparation directory. Never creates configuration
approval, final configuration, release, runtime output or synthetic payloads.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import stat
import uuid

ROOT = Path('/home/peterhorvath/apps/bitcoin/NBDP')
HERE = ROOT / 'docs/decisions/evidence/e06-local-fonly-primary-preparation-r1'
EVIDENCE = ROOT / 'docs/decisions/evidence'
SOURCE = ROOT / 'experiments/prototypes/e06_relay_https_negative_v1'
AUTHOR = '/root/e06_local_configuration'


def need(value, message):
    if not value:
        raise ValueError(message)


def pin(path):
    path = Path(path)
    need(path.is_absolute() and not path.is_symlink()
         and path.resolve(strict=True) == path
         and stat.S_ISREG(path.stat().st_mode), 'Canonical regular original required')
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as handle:
        before = os.fstat(handle.fileno())
        need(before.st_size <= 536870912, 'Bounded original file required')
        while block := handle.read(1048576):
            size += len(block)
            digest.update(block)
        after = os.fstat(handle.fileno())
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size,
                              value.st_mtime_ns, value.st_ctime_ns)
    need(identity(before) == identity(after) and size == before.st_size,
         'Original changed during DATA hash')
    return dict(path=str(path), bytes=size, sha256=digest.hexdigest())


def read(path):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'Duplicate preparation JSON key')
            result[key] = value
        return result
    path = Path(path)
    need(path.stat().st_size <= 33554432, 'Bounded DATA JSON required')
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def same(left, right):
    # Preparation comparison only. Not an imported/copied protocol validator.
    return json.dumps(left, sort_keys=True, separators=(',', ':')) == json.dumps(
        right, sort_keys=True, separators=(',', ':'))


def write(name, value):
    target = HERE / name
    need(target.parent == HERE and not target.exists(), 'Fresh owned preparation output required')
    raw = (json.dumps(value, indent=2) + '\n').encode()
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return pin(target)


def main():
    need(Path(__file__).resolve(strict=True) == HERE / 'prepare.py', 'Fixed preparation script')
    need(set(p.name for p in HERE.iterdir()) == {'prepare.py'}, 'Unused owned directory required')
    anchors = {
        'sourceClosure': (EVIDENCE / 'e06-qualification-current-source-r3/source-closure.json',
                          '76cfc1d55602c4c18f7adabde2b67679f3d828517a4cf4abefdf13d57029b100'),
        'sourceApproval': (EVIDENCE / 'e06-qualification-current-source-r3/source-approval.json',
                           'e3e41bb6bae55d80702f9002cc99c72ad3a6345405a5043d3123dcafcbea685e'),
        'controlApproval': (EVIDENCE / 'e06-current-controls-r2/control-approval.json',
                            'c2c6d2b97ba4f25dbbb9074c079cd3ad29cbf9fa23aac709b31a97a273c0f5ee'),
        'primaryMatrixAcceptance': (EVIDENCE / 'e06-inventory-enforcement-matrix-r1/acceptance.json',
                                    '834526802dce0ab821d6d6447511f707b7086a810f2c21a1fe3ae29534d7ccc1'),
        'admittedArgumentWitness': (EVIDENCE / 'e06-inventory-enforcement-matrix-r1/actual-run/gate-arguments.json',
                                    '7409de200a12d8dfdd048a822aa03a938e090503538b7ef074a2e513fb58a222'),
        'qualificationSchema': (SOURCE / 'qualification-schemas.json',
                                'dcbbbd2c9b84d5cd477718896f287f8abc6f6574e148a04421bc3a9043157a2b')
    }
    anchor_pins = {}
    for name, (path, sha) in anchors.items():
        descriptor = pin(path)
        need(descriptor['sha256'] == sha, 'Assigned immutable anchor drift: ' + name)
        anchor_pins[name] = descriptor
    closure = read(anchors['sourceClosure'][0])
    need(len(closure) == 449 and len({d['path'] for d in closure}) == 449,
         'Assigned current449 source graph required')
    source_mapping = {d['path']: d for d in closure}
    for descriptor in closure:
        need(pin(descriptor['path']) == descriptor, 'Current source hash drift')
    source_approval = read(anchors['sourceApproval'][0])
    controls = read(anchors['controlApproval'][0])
    need(source_approval['decision'] == 'ACCEPT_SOURCE_ONLY'
         and same(source_approval['sourceClosure'], closure), 'Actual SOURCE authority join')
    need(controls['decision'] == 'ACCEPT_CONTROLS_ONLY'
         and controls['sourceApproval'] == anchor_pins['sourceApproval'], 'Actual runtime control-approval join')
    schemas = read(anchors['qualificationSchema'][0])
    definitions = dict(schemas['workerDefinitions'], **schemas['checkerDefinitions'])
    arguments = read(anchors['admittedArgumentWitness'][0])
    worker = arguments['worker']
    core = arguments['config']
    run_id = uuid.uuid4().hex[:12]
    output = '/tmp/e6n-fonly-primary-' + run_id
    need(re.fullmatch('[a-z0-9]{6,12}', run_id) and not os.path.lexists(output), 'Fresh LOCAL namespace required')
    worker.update(schema='n02316-local-qualification-worker-config-v1', runId=run_id,
                  runRole='primary', executionSession='/root', sourceClosure=closure,
                  sourceApproval=anchor_pins['sourceApproval'], controlAcceptance=anchor_pins['controlApproval'],
                  outputRoot=output,
                  jobs=[dict(jobId='Q-' + backend, backend=backend, output=output + '/Q-' + backend)
                        for backend in ('JS', 'RUST')])
    need(set(worker) == set(definitions['qualificationWorkerConfig']['record']), 'Exact worker record keys')
    need(worker['scope'] == definitions['scope']['literal']
         and worker['environment'] == definitions['environment']['literal'], 'Exact fixed scope/environment')
    need(worker['inputInventory'] == schemas['qualificationInputInventory'], 'Current57-role inventory pointer')
    role_map = read(worker['inputInventory']['path'])
    need(len(role_map) == 57, 'Exactly57 immutable input roles')
    for descriptor in role_map.values():
        need(source_mapping.get(descriptor['path']) == descriptor
             and pin(descriptor['path']) == descriptor, 'Actual inventory source membership/hash')
    derivation = read(schemas['qualificationMaterialization']['path'])
    need(derivation['acceptedPlan'] == worker['acceptedPlan'] and derivation['executionReleased'] is False,
         'Actual separate derivation/plan join')
    need(worker['request'] == derivation['outputs']['request.jsonl'], 'Original request descriptor join')
    request_raw = Path(worker['request']['path']).read_bytes()
    need(request_raw.endswith(b'\n') and request_raw.count(b'\n') == 1, 'One original JSONL request')
    request = read(worker['request']['path'])
    candidate = read(core['candidate']['path'])
    need(same(request, candidate['N02']['requestCandidate']) and request['dWireHex'] is None,
         'Unchanged whole F-only candidate request')
    need(bytes.fromhex(request['fWireHex']) == Path(worker['fFixture']['path']).read_bytes(),
         'Original F wire is identical to request data')
    for backend in ('JS', 'RUST'):
        expected = read(core['expectedReplies'][backend]['path'])
        need(len(expected) == 13 and same(expected, candidate['N02']['expectedByBackend'][backend])
             and expected['validationCallCounts'] == {'D': 0, 'F': 1}, 'Original whole13-key oracle')
        need(core['expectedReplies'][backend] == derivation['outputs'][backend + '.expected.json'],
             'Original checker-only expected descriptor')
    for descriptor in [*worker['sourcePrerequisites'].values(), *worker['tools'].values(),
                       worker['acceptedPlan'], worker['acceptedInertFreeze'], worker['workerSchema'],
                       worker['qualificationSchema'], worker['inputInventory'], worker['request'],
                       worker['fFixture'], schemas['qualificationMaterialization'],
                       *core['expectedReplies'].values(), core['candidate']]:
        need(source_mapping.get(descriptor['path']) == descriptor
             and pin(descriptor['path']) == descriptor, 'Original descriptor membership/hash')
    worker_pin = write('worker-config.json', worker)
    core.update(schema='n02316-local-qualification-config-v1', runId=run_id, runRole='primary',
                executionSession='/root', workerConfig=worker_pin,
                sourceApproval=anchor_pins['sourceApproval'], controlAcceptance=anchor_pins['controlApproval'],
                primaryAcceptance=None)
    need(set(core) == set(definitions['qualificationConfigurationCore']['record']), 'Exact core record keys')
    need('configurationAcceptance' not in core and 'expectedReplies' not in worker,
         'No future approval or worker oracle exposure')
    core_pin = write('configuration-core.json', core)
    plan = dict(
        schema='e06-local-fonly-proposed-execution-plan-v1', state='DATA_ONLY_NOT_RELEASED',
        author=AUTHOR, executionReady=False, runId=run_id, executionSession='/root', runRole='primary',
        configurationCore=core_pin, workerConfig=worker_pin,
        workflowPrerequisites=dict(
            currentSourceAcceptance=pin(EVIDENCE / 'e06-qualification-current-source-r3/acceptance.json'),
            currentControlAcceptance=pin(EVIDENCE / 'e06-current-controls-r2/control-acceptance.json'),
            currentGrammarAcceptance=pin(EVIDENCE / 'e06-opaque-inventory-controls-r1/acceptance.json'),
            primaryMatrixAcceptance=anchor_pins['primaryMatrixAcceptance'],
            independentQaMatrixAcceptance=None, pairedMatrixAcceptance=None,
            gate='Coordinator must record actual paired matrix qualification before LOCAL release; no schema field is invented.'),
        finalization=dict(
            requiredReviewDecision='ACCEPT_CONFIGURATION_ONLY', reviewSubject=core_pin,
            configurationApprovalSchema='n02316-local-configuration-approval-v1',
            finalConfigurationPath=str(HERE / 'qualification-config.json'),
            releaseSchema='n02316-local-qualification-release-v1',
            releaseDecision='RELEASE_EXACT_LOCAL_F_ONLY_RUN_ONLY',
            createdApproval=False, createdFinalConfiguration=False, createdRelease=False),
        conditionalInvocation=dict(
            interpreter=worker['tools']['python'], argvPrefix=[worker['tools']['python']['path'], '-I', '-B',
                str(SOURCE / 'qualification.py')],
            requiredFreshOperands=['final configuration path', 'final configuration SHA256',
                                   'fresh root release path', 'fresh root release SHA256', '/root', 'primary'],
            environment=worker['environment'], cwd=str(ROOT), stdin='EMPTY_BYTES',
            proposedExternalCeilingSeconds=1800,
            warning='The actual CLI immediately runs JS then RUST after full admission; there is no admission-only flag.'),
        preservedBudgetsSeconds=dict(localPhase=1500, perJob=240, startup=15,
            combinedWriteReply=15, terminal=5, postTerminalDrain=2, failureCleanupAggregate=15),
        expectedRun=dict(orderedJobs=['Q-JS', 'Q-RUST'], metadataRequests=2, metadataReplies=2,
                         dValidations=0, fValidations=2, requiredStatus='MATCHED'),
        requiredEvidence=['Real launch/response/terminal receipts and raw streams for each fresh owned native child.',
            'Natural0/reap/full EOF, empty stderr, current original source/input pins, no first/secondary errors.',
            'Whole typed13-key JS/RUST reply equality and original-versus-owned request byte custody.',
            'Actual accepted_transport verification before native work; it has not been invoked here.',
            'Independent actual-result review; later QA native repetition must use a distinct actual session.'],
        outputRoot=output, outputCreated=False, actualExecution=dict(projectImports=0, projectEvaluations=0,
            tests=0, nativeJobs=0, transportVerifiers=0, crypto=0, network=0),
        limits=['Only orphan F-only metadata evidence could result; no acquisition, recovered originals or N02 completion.',
            'N03/N16 private target guards and original/owned-request custody regression remain TARGET gates.',
            'No canonical E06 PASS, architectural blocker closure, SDK, production or profile adoption.'])
    plan_pin = write('execution-plan.json', plan)
    for descriptor in closure:
        need(pin(descriptor['path']) == descriptor, 'Current source changed during DATA preparation')
    static = dict(schema='e06-local-fonly-data-static-checks-v1', author=AUTHOR,
        evidenceType='STDLIB_DATA_HASH_AND_SHAPE_INSPECTION_ONLY', sourceClosure=anchor_pins['sourceClosure'],
        all449OriginalSourceHashesMatchBeforeAndAfter=True, sourceMemberCount=len(closure),
        fixedAnchors=anchor_pins, originalInventoryRoleCount=57,
        realInputArgumentsUsedAsDescriptorProvenance=anchor_pins['admittedArgumentWitness'],
        originalRequestBytes=worker['request']['bytes'], originalPayloadsRegenerated=False,
        exactWorkerTopLevelKeys=True, exactCoreTopLevelKeys=True, expectedRepliesWorkerVisible=False,
        expectedRepliesWholeKeys=13, sourceRelevantPrerequisites=len(worker['sourcePrerequisites']),
        configuredTools=len(worker['tools']), configuredEnvironmentVariables=len(worker['environment']),
        freshOutputAbsent=not os.path.lexists(output), sourceApprovalDecision=source_approval['decision'],
        controlApprovalDecision=controls['decision'], workerConfig=worker_pin, configurationCore=core_pin,
        executionPlan=plan_pin, actualExecution=plan['actualExecution'],
        limits=['No actual project schema validator, full LOCAL admission, accepted_transport or native entry was evaluated.',
                'Top-level record checks and original DATA equality are preparation checks, not runtime conformance.'])
    static_pin = write('static-checks.json', static)
    subject = dict(schema='e06-local-fonly-configuration-review-subject-v1', state='WRITES_STOPPED_PENDING_REVIEW',
        authors=['/root', AUTHOR], intendedOperator='/root', refs=['E06', 'Q06', 'Q08', 'Q09', 'Q24', 'Q27'],
        configurationCore=core_pin, workerConfig=worker_pin, executionPlan=plan_pin, staticChecks=static_pin,
        sources=dict(sourceClosure=anchor_pins['sourceClosure'], sourceApproval=anchor_pins['sourceApproval'],
                     controlApproval=anchor_pins['controlApproval']),
        preparationScript=pin(Path(__file__)),
        requiredActualConfigurationReview=dict(decision='ACCEPT_CONFIGURATION_ONLY', subject=core_pin,
            meaning='Both independent nonauthor reviewers must accept the exact core including the pinned worker.'),
        pendingBeforeActivation=['Actual independent QA matrix and paired matrix qualification.',
            'Two actual independent exact-core configuration reviews; genuine configuration approval and final config.',
            'Fresh strict root LOCAL release, trusted outer source/tool pin checks and finite external monitoring.'],
        protectedSourceFilesChanged=False, executionReleased=False,
        limits=['The core and worker are real current-schema DATA operands, not actual LOCAL acceptance.',
                'No future hash, review, approval, release, native observation or authority is fabricated.'])
    subject_pin = write('subject.json', subject)
    print(json.dumps(dict(workerConfig=worker_pin, configurationCore=core_pin,
                          executionPlan=plan_pin, staticChecks=static_pin, subject=subject_pin,
                          outputRoot=output, executionReady=False)))


if __name__ == '__main__':
    main()
