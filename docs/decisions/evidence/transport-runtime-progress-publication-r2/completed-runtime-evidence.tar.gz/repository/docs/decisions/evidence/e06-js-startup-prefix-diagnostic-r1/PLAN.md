# JS startup prefix diagnostic — SOURCE ONLY

Scope is exactly **DIAGNOSTIC_STARTUP_PREFIX_ONLY**, run `b78216ad503f`.
Authors are `/root` and `/root/local_monitor_controls`. No Node, strace workload,
ptrace attach, wrapper test or LOCAL invocation has executed during preparation.
Only cached strace version/help metadata probes ran, each under5s. They confirm
option availability, not current ptrace permission or successful tracing.

## Question and existing negative evidence

R2 delivered its6,276-byte request to the parent's pipe in approximately0.326ms
but received no child reply or stderr before NATIVE_COMBINED_WRITE_REPLY_DEADLINE.
That proves neither the child read the request nor exact JS startup progress.
Source inspection conditionally estimates more than3GB of repeated hashing before
stdin and more than4GB before the handler if preceding checks succeed. Those are
source-derived conditional totals, not measured bytes, duration or a proved cause.
This diagnostic observes only a startup prefix with zero input. It cannot reach
the request handler or demonstrate the latter estimate.

## Exact command and streams

`configuration.json` pins cached strace, Node, case.mjs, metadata_loader.mjs, the
metadata entry and the saved R2 binding. Actual Node argv is exactly:

```text
PINNED_NODE PINNED_METADATA_LOADER SAVED_R2_BINDING EXACT_SAVED_BINDING_SHA
```

Those names represent the actual complete descriptors in configuration.json,
not floating tools or caller-selected inputs. cwd is the original R2 Q-JS job
directory. stdin is DEVNULL, zero bytes: source gates _handleLine and sidecar
creation behind complete newline-delimited input. The old binding and embedded
LOCAL release are historical data inspected by startup, never fresh authority.
Only the new separately reviewed diagnostic root grant permits this invocation.

The actual tracer argv uses fixed `--kill-on-exit --interruptible=1 -f -qq -ttt
-s 256 -e trace=execve,openat,read,pread64,readv,close -e raw=read,pread64,readv`,
then `-o /proc/self/fd/ACTUAL_OWNED_TRACE_PIPE_FD --` and the exact Node argv.
The FD is allocated by the supervisor and inherited only by its owned tracer;
there is no caller-selected trace target, shell or attach PID. Raw read-family
arguments print pointers/counts, suppressing buffer contents. No read/write dump
options, verbose environment dump or payload/key logging is enabled. The six
environment variables are fixed and contain no credentials. Open paths/argv and
local host metadata are retained intentionally in private outputs.

Trace capture is a pipe, not an unbounded strace disk file:16MiB retained trace,
64KiB stdout and256KiB stderr, bounded reads, exact observed/retained counts.
Stdout is unexpected for zero input and causes immediate unqualified cleanup.
Stderr combines Node and strace diagnostic errors and must not be mislabelled as
Node-only without raw attribution. Capture errors retain the first error and
bounded secondary errors. A forced or incomplete capture remains unqualified.

## Budgets, ownership and immutable originals

The original15s startup ceiling includes Popen/tracer startup, Node exec, imports
and verification; it is not renewed after any stage. Cooperative Python checks
are not hard kernel preemption. New diagnostic-only outer admission/hash budget
is20s, capture15s, cleanup at most5s, postflight at most20s, all within60s total.
These separate diagnostic budgets do not alter any original15/240/1500/1800
conformance budget. No runtime timeout increase, current LOCAL retry, source
optimization or parameter sweep is included.

The tracer is a fresh Popen session. Real WNOWAIT retains ownership until all
possible group TERM/KILL signals finish; no signal path follows final wait/reap.
`--kill-on-exit` requests tracee termination if tracer dies. Actual signal/exit/EOF
facts must be reviewed; neither that option nor group signalling proves absence
of hostile or escaped descendants. No ptrace/Yama/security policy is changed.
Permission denial is a preserved diagnostic outcome.

`original-inventory.json` snapshots bytes AND stat identity for all449 current
source members, every one of the17 original R2 native files and3 outer files,
plus the cached strace tool and this supervisor:471 unique files. Raw R2 tree
membership is also fixed. Admission compares exact original snapshots and
postflight repeats them. The source node path is already among the449 members.
Original R2 output is read only by this trusted zero-input source path; it is not
OS-mounted read-only containment. Any new old-tree file, changed bytes, mode or
stat identity makes the diagnostic unqualified. Atime is intentionally excluded
because reading can update it. No chmod or original mutation is performed.

## Fresh grant and actual independent review

No grant, approval, final LOCAL configuration or future descriptor hash exists
here. Root must first obtain actual nonauthor QA/security acceptance of the
complete subject/configuration/source/tests/plan. The grant is a strict closed
record at `exact-root-diagnostic-release.json` with schema
`e06-js-startup-prefix-root-release-v1`, decision
`RELEASE_DIAGNOSTIC_STARTUP_PREFIX_ONLY`, exact scope/run/root/session, actual
supervisor/configuration/whole-subject descriptors and actual QA/security review
descriptors. Review records contain exactly role/session/decision/subject and
decision ACCEPT_DIAGNOSTIC_SOURCE_CONFIG_ONLY on the same actual whole subject;
sessions must be distinct nonauthors. Fresh issuedAt/notAfter are signed64-style
metadata integer values, lifetime at most120s, with at least60s remaining at
admission. They are not NBDP wire integers or a reused LOCAL grant.

Root externally checks the actual accepted supervisor/config/grant hashes before
evaluating the supervisor. Its own checks add corruption detection and do not
authenticate source or prove reviews happened. No invented future hash appears
in the proposed invocation. New output actual-startup-r1 must remain absent.

## Controls and interpretation

Prepared `test_capture.py` controls are NOT RUN. After source review, five
meaningful owned-Python-child controls exercise natural EOF/zero stdin, timeout,
trace overflow, stderr overflow and trace-file write failure using the unchanged
capture function and explicit fixture budgets/argv. They do not invoke strace,
Node or project admission. Retain raw suite outputs and actual independent
acceptance before relying on first activation; preserve any first failure.

Expected natural startup completion emits Error: EOF_REQUEST_COUNT and exits1
with empty stdout. This is a diagnostic observation, not PASS, request validation,
handler execution or LOCAL/native conformance. A15s timeout provides only the
retained trace prefix. File names, syscall ordering and timestamps allow source-
supported phase inference; they are not direct JS markers or measured causal
attribution. Trace overhead changes runtime and invalidates untraced performance
claims. `/usr/bin/time` is not selected, and no CPU/RSS/resource-cause claim is
made. Actual raw trace interpretation and unchanged-original review remain
independent QA/security tasks. No full R3/LOCAL retry, E06 PASS, blocker closure,
SDK, production change, architecture change or extra user approval is implied.
