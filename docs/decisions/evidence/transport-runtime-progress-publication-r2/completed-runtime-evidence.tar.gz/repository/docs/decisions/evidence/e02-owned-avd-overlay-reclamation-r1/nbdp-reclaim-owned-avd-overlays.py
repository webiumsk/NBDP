from pathlib import Path
import os,stat,json,hashlib,subprocess,shutil,time
R=Path('/home/peterhorvath/apps/bitcoin/NBDP');E=R/'docs/decisions/evidence';O=E/'e02-owned-avd-overlay-reclamation-r1';assert not O.exists();O.mkdir(mode=0o700)
def desc(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def save(n,x):
 p=O/n;fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
 with os.fdopen(fd,'w') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
rows=[];cids=[]
for lab,run,ev,inode in [('nbdp-e02-android-health-v1','8e4865aa7ad547968e7d3b4a53d7fcf6','e02-android-health-runtime-r1',2144344),('nbdp-e02-android-health-cpu8-v1','47f51f07d66d42f2b520fcbd2c64c866','e02-android-health-cpu8-runtime-r1',2494752)]:
 p=Path('/tmp')/lab/'runs'/run/'android-state/avd/ordinary.avd/userdata-qemu.img.qcow2';s=p.lstat();assert p.resolve(strict=True)==p and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid()==1000 and s.st_nlink==1 and s.st_ino==inode and s.st_dev==64513
 for a in p.parents:assert not a.is_symlink()
 profile=p.parent/'config.ini';pd=desc(profile);assert pd['bytes']==576 and pd['sha256']=='45f1bbfdf46d2786734bdfc418f120a2947533e598680b2dbc7ce22649b334f6'
 result=E/ev/'actual-run/supervisor-result.json';x=json.loads(result.read_bytes());assert x['cleanup']['ok'] and all(z['absenceConfirmed'] and z['identityVerified'] and z['removeExit']==0 for z in x['cleanup']['rows']);cids += [z['cid'] for z in x['cleanup']['rows']]
 rows.append(dict(overlay=desc(p),device=s.st_dev,inode=s.st_ino,allocatedBytes=s.st_blocks*512,uid=s.st_uid,nlink=s.st_nlink,profilePreserved=pd,result=desc(result)))
closure=(E/'e06-qualification-current-source-r3/source-closure.json').read_text();assert all(z['overlay']['path'] not in closure for z in rows)
a=subprocess.run(['docker','inspect',*cids],capture_output=True,timeout=20);assert a.returncode==1 and a.stdout.strip()==b'[]' and all(cid.encode() in a.stderr for cid in cids) and a.stderr.count(b'No such object')==8
b=subprocess.run(['fuser',*[z['overlay']['path'] for z in rows]],capture_output=True,timeout=20);assert b.returncode==1 and not b.stdout.strip() and not b.stderr.strip()
v=dict(schema='nbdp-owned-disposable-avd-reclamation-v1',actor='/root',timeUtcNs=time.time_ns(),scope='Only two exact unreferenced disposable userdata overlays; prevents guest resumption, retains all recorded evidence and all other files.',files=rows,sourceClosureCheck='No candidate overlay path in current449 closure; independent research additionally checked archived596/565 manifests and455 preparation/runtime JSON files with no image descriptors.',absence={'argv':['docker','inspect',*cids],'exit':a.returncode,'stdout':a.stdout.decode(),'stderr':a.stderr.decode(),'fuserExit':b.returncode,'fuserStdout':b.stdout.decode(),'fuserStderr':b.stderr.decode(),'limit':'No open user observed in current process view; not hostile-host proof.'},freeBefore=shutil.disk_usage('/tmp').free)
save('before-removal.json',v)
for z in rows:
 p=Path(z['overlay']['path']);s=p.lstat();assert s.st_ino==z['inode'] and s.st_dev==z['device'] and s.st_size==z['overlay']['bytes'] and s.st_nlink==1 and stat.S_ISREG(s.st_mode);p.unlink();assert not p.exists();assert desc(Path(z['profilePreserved']['path']))==z['profilePreserved']
save('result.json',dict(schema='nbdp-owned-disposable-avd-reclamation-result-v1',actor='/root',filesRemoved=[z['overlay'] for z in rows],profilesPreserved=True,freeAfter=shutil.disk_usage('/tmp').free,beforeEvidence=desc(O/'before-removal.json'),limits='No other files removed. Recorded disk images were not published/accepted evidence dependencies. No change to source/configuration/controls or canonical results.'))
print((O/'result.json').read_text())
