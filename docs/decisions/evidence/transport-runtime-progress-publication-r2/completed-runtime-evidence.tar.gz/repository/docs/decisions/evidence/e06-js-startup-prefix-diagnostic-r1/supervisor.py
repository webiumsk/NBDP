"""DIAGNOSTIC_STARTUP_PREFIX_ONLY. Inert on import; no LOCAL qualification.

Only a fresh independently reviewed diagnostic root grant permits main(). The
saved R2 binding and embedded LOCAL release are historical startup inputs, never
fresh execution authority. Zero stdin prevents metadata._handleLine invocation.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import selectors
import signal
import stat
import subprocess
import sys
import time

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
HERE=ROOT/'docs/decisions/evidence/e06-js-startup-prefix-diagnostic-r1'
CONFIG=HERE/'configuration.json'
OUTPUT=HERE/'actual-startup-r1'
RUN_ID='b78216ad503f'
SCOPE='DIAGNOSTIC_STARTUP_PREFIX_ONLY'
ENV={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
     'WS_NO_BUFFER_UTIL':'1','WS_NO_UTF_8_VALIDATE':'1'}
CAPS={'trace':16777216,'stdout':65536,'stderr':262144}
PHASE_SECONDS=15
CLEANUP_SECONDS=5
TOTAL_SECONDS=60
AUTHORS=['/root','/root/local_monitor_controls']
ENTRY_PATHS={'node':'/home/peterhorvath/.nvm/versions/node/v22.18.0/bin/node',
 'strace':'/usr/bin/strace',
 'metadataLoader':str(ROOT/'experiments/prototypes/e06_relay_https_negative_v1/metadata_loader.mjs'),
 'case':str(ROOT/'experiments/prototypes/e06_relay_https_negative_v1/case.mjs'),
 'metadataEntry':str(ROOT/'experiments/prototypes/e06_invoice_file_v1/js/metadata.mjs'),
 'historicalBinding':'/tmp/e6n-fonly-primary-9df61b3f71ac/Q-JS/binding.json'}
TRACE_OPTIONS=['--kill-on-exit','--interruptible=1','-f','-qq','-ttt','-s','256',
 '-e','trace=execve,openat,read,pread64,readv,close',
 '-e','raw=read,pread64,readv']

class Refusal(ValueError):pass

def need(ok,message):
    if not ok:raise Refusal(message)

def strict(raw):
    need(type(raw) is bytes and len(raw)<=4194304,'DATA_JSON_BOUND')
    def pairs(rows):
        result={}
        for k,v in rows:need(k not in result,'DUPLICATE_JSON_KEY');result[k]=v
        return result
    return json.loads(raw.decode('utf-8','strict'),object_pairs_hook=pairs,
      parse_float=lambda _:need(False,'INTEGER_METADATA_ONLY'),
      parse_constant=lambda _:need(False,'FINITE_METADATA_ONLY'))

def closed(value,keys):need(type(value) is dict and set(value)==set(keys),'CLOSED_KEYS')

def descriptor(path,live=lambda:None):
    p=Path(path);live()
    need(p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink(),'CANONICAL_REGULAR_PATH')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW);h=hashlib.sha256();size=0
    with os.fdopen(fd,'rb') as f:
        before=os.fstat(f.fileno());need(stat.S_ISREG(before.st_mode) and before.st_size<=536870912,'REGULAR_BOUNDED_ORIGINAL')
        while block:=f.read(1048576):live();size+=len(block);h.update(block)
        after=os.fstat(f.fileno())
    ident=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_uid,s.st_gid)
    need(ident(before)==ident(after) and size==before.st_size,'ORIGINAL_CHANGED_DURING_HASH');live()
    return {'path':str(p),'bytes':size,'sha256':h.hexdigest()}

def file_state(path,live=lambda:None):
    d=descriptor(path,live);s=Path(path).lstat()
    return {'descriptor':d,'stat':{'device':s.st_dev,'inode':s.st_ino,'size':s.st_size,
       'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid}}

def checked(pin,live=lambda:None):
    closed(pin,('path','bytes','sha256'));need(descriptor(pin['path'],live)==pin,'EXACT_DESCRIPTOR:'+pin['path']);return pin

def doc(pin,live=lambda:None):
    checked(pin,live);need(pin['bytes']<=4194304,'DATA_DOCUMENT_BOUND');raw=Path(pin['path']).read_bytes()
    need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'DOCUMENT_REREAD_CHANGED')
    live();return strict(raw)

def owned(path):
    p=Path(path);s=p.lstat();need(stat.S_ISREG(s.st_mode) and not p.is_symlink()
      and s.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)==0o600,'OWNED_REGULAR_0600')

def write(path,raw):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return descriptor(path)

def tree_paths(root):
    p=Path(root);need(p.resolve(strict=True)==p and p.is_dir(),'FIXED_ORIGINAL_TREE')
    files=[]
    for f in sorted(p.rglob('*')):
        s=f.lstat();need(not stat.S_ISLNK(s.st_mode),'NO_ORIGINAL_TREE_LINKS')
        if stat.S_ISDIR(s.st_mode):continue
        need(stat.S_ISREG(s.st_mode),'NO_ORIGINAL_TREE_SPECIALS');files.append(str(f))
    return files

def snapshot(inventory,live):
    rows=[]
    for row in inventory['files']:
        value=file_state(row['descriptor']['path'],live);need(value==row,'ORIGINAL_BYTES_OR_STAT_DRIFT:'+row['descriptor']['path']);rows.append(value)
    for root,expected in inventory['rawTreeFiles'].items():need(tree_paths(root)==expected,'ORIGINAL_R2_TREE_MEMBERSHIP_DRIFT')
    return {'fileCount':len(rows),'allBytesAndStatCurrent':True,'rows':rows}

def admission(args,started):
    def live():need(time.monotonic()<started+20,'DIAGNOSTIC_ADMISSION_20S_BOUND')
    for value in (args.supervisor_sha,args.configuration_sha,args.grant_sha):need(re.fullmatch('[0-9a-f]{64}',value),'EXTERNAL_TRUSTED_SHA_REQUIRED')
    own=descriptor(Path(__file__),live);need(Path(__file__).resolve()==HERE/'supervisor.py' and own['sha256']==args.supervisor_sha,'EXTERNAL_SUPERVISOR_PIN')
    cfg_pin=descriptor(CONFIG,live);need(cfg_pin['sha256']==args.configuration_sha,'EXTERNAL_CONFIGURATION_PIN');cfg=doc(cfg_pin,live)
    closed(cfg,('schema','scope','runId','supervisor','entries','inventory','traceOptions','caps','timers','environment','stdin','output','authors','timeToolUsed'))
    need(cfg['schema']=='e06-js-startup-prefix-configuration-v1' and cfg['scope']==SCOPE and cfg['runId']==RUN_ID,'DIAGNOSTIC_CONFIG_SCOPE')
    need(cfg['supervisor']==own and cfg['traceOptions']==TRACE_OPTIONS and cfg['caps']==CAPS and cfg['environment']==ENV,'EXACT_REVIEWED_SUPERVISOR_POLICY')
    need(cfg['timers']=={'total':60,'admission':20,'startupIncludingTracer':15,'cleanup':5,'postflight':20}
      and cfg['stdin']=='DEVNULL_ZERO_BYTES' and cfg['output']==str(OUTPUT) and cfg['authors']==AUTHORS
      and cfg['timeToolUsed'] is False,'EXACT_DIAGNOSTIC_BOUNDARIES')
    closed(cfg['entries'],ENTRY_PATHS)
    for key,path in ENTRY_PATHS.items():need(cfg['entries'][key]['path']==path,'FIXED_ENTRY_PATH');checked(cfg['entries'][key],live)
    inventory=doc(cfg['inventory'],live)
    closed(inventory,('schema','files','sourceMemberCount','originalR2FileCount','rawTreeFiles'))
    need(inventory['schema']=='e06-js-startup-prefix-inventory-v1' and inventory['sourceMemberCount']==449
      and inventory['originalR2FileCount']==20 and len(inventory['files'])==471,'EXACT_DIAGNOSTIC_ORIGINAL_INVENTORY')
    prior=snapshot(inventory,live)
    grant_path=Path(args.grant);need(grant_path==HERE/'exact-root-diagnostic-release.json','FIXED_FRESH_GRANT_PATH');owned(grant_path)
    gp=descriptor(grant_path,live);need(gp['sha256']==args.grant_sha,'EXTERNAL_DIAGNOSTIC_GRANT_PIN');grant=doc(gp,live)
    closed(grant,('schema','decision','scope','rootSession','executionSession','runId','supervisor','configuration','reviewedSubject','qaReview','securityReview','issuedAtUtcNs','notAfterUtcNs'))
    need(grant['schema']=='e06-js-startup-prefix-root-release-v1' and grant['decision']=='RELEASE_DIAGNOSTIC_STARTUP_PREFIX_ONLY'
      and grant['scope']==SCOPE and grant['rootSession']==grant['executionSession']=='/root' and grant['runId']==RUN_ID
      and grant['supervisor']==own and grant['configuration']==cfg_pin,'FRESH_DIAGNOSTIC_AUTHORITY_ONLY')
    need(grant['reviewedSubject']['path']==str(HERE/'subject.json'),'FIXED_WHOLE_SUBJECT_PATH');subject=doc(grant['reviewedSubject'],live)
    need(subject['supervisor']==own and subject['configuration']==cfg_pin and subject['authors']==AUTHORS,'WHOLE_REVIEWED_SUBJECT_JOIN')
    for p in subject['files']:checked(p,live)
    sessions=[]
    for role,key in [('qa','qaReview'),('security','securityReview')]:
        review=doc(grant[key],live);closed(review,('role','session','decision','subject'))
        need(review['role']==role and review['decision']=='ACCEPT_DIAGNOSTIC_SOURCE_CONFIG_ONLY'
          and review['subject']==grant['reviewedSubject'] and type(review['session']) is str
          and review['session'] not in AUTHORS,'ACTUAL_INDEPENDENT_DIAGNOSTIC_REVIEW_JOIN');sessions.append(review['session'])
    need(len(set(sessions))==2,'TWO_DISTINCT_DIAGNOSTIC_REVIEWERS')
    now=time.time_ns();issued=grant['issuedAtUtcNs'];expiry=grant['notAfterUtcNs']
    need(type(issued) is int and type(expiry) is int and 0<=issued<=now and now+60_000_000_000<=expiry
      and 0<expiry-issued<=120_000_000_000,'FRESH_FINITE_DIAGNOSTIC_GRANT')
    need(not os.path.lexists(OUTPUT),'FRESH_PRIVATE_OUTPUT_REQUIRED');live()
    return cfg_pin,cfg,inventory,prior,gp


def capture(argv,trace_r,trace_w,out):
    started=time.monotonic();deadline=started+PHASE_SECONDS
    record={'argv':argv,'stdin':'DEVNULL_ZERO_BYTES','phaseCeilingSeconds':PHASE_SECONDS,
      'phaseIncludesTracerStartup':True,'cleanupCeilingSeconds':CLEANUP_SECONDS,'launchAttempted':False,
      'pid':None,'pidMeaning':'Owned tracer PID in tool execution namespace','exit':None,'reaped':False,
      'forced':False,'timedOut':False,'signals':[],'firstError':None,'secondaryErrors':[],
      'observedBytes':dict.fromkeys(CAPS,0),'retainedBytes':dict.fromkeys(CAPS,0),'eof':dict.fromkeys(CAPS,False)}
    process=None;selector=None;streams={};interrupted=[];handlers={};reaped=False
    def fault(error):
        item={'type':type(error).__name__,'message':str(error)[:4096]}
        if record['firstError'] is None:record['firstError']=item
        elif len(record['secondaryErrors'])<16:record['secondaryErrors'].append(item)
    def observe():
        need(process is not None and not reaped and process.returncode is None,'OWNED_UNREAPED_TRACER_REQUIRED')
        return os.waitid(os.P_PID,process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
    def pump(delay):
        try:events=selector.select(delay)
        except BaseException as error:fault(error);return
        for key,_ in events:
            name=key.data
            try:block=os.read(key.fd,65536)
            except BlockingIOError:continue
            except BaseException as error:fault(error);continue
            if not block:
                record['eof'][name]=True;selector.unregister(key.fileobj);continue
            record['observedBytes'][name]+=len(block)
            keep=block[:max(0,CAPS[name]-record['retainedBytes'][name])]
            if keep:
                try:
                    n=streams[name].write(keep);need(type(n) is int and n==len(keep),'COMPLETE_CAPTURE_WRITE');record['retainedBytes'][name]+=n
                except BaseException as error:fault(error)
            if len(keep)!=len(block):fault(Refusal('DIAGNOSTIC_'+name.upper()+'_CAP'))
            if name=='stdout':fault(Refusal('UNEXPECTED_STDOUT_WITH_ZERO_REQUEST_BYTES'))
    try:
        for name in CAPS:
            fd=os.open(out/(name+'.bin'),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);streams[name]=os.fdopen(fd,'wb')
        for signum in (signal.SIGINT,signal.SIGTERM):
            handlers[signum]=signal.getsignal(signum);signal.signal(signum,lambda n,f:interrupted.append(n) if not interrupted else None)
        record['launchAttempted']=True
        process=subprocess.Popen(argv,cwd=ENTRY_PATHS['historicalBinding'].rsplit('/',1)[0],env=ENV,
          stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,
          pass_fds=(trace_w,),bufsize=0)
        record['pid']=process.pid;os.close(trace_w);trace_w=None
        selector=selectors.DefaultSelector()
        for name,pipe in [('trace',trace_r),('stdout',process.stdout),('stderr',process.stderr)]:
            fd=pipe if type(pipe) is int else pipe.fileno();os.set_blocking(fd,False);selector.register(pipe,selectors.EVENT_READ,name)
        while True:
            need(not interrupted,'DIAGNOSTIC_INTERRUPTED')
            if time.monotonic()>=deadline:record['timedOut']=True;raise TimeoutError('DIAGNOSTIC_15S_STARTUP_DEADLINE')
            if observe() is not None and all(record['eof'].values()):break
            pump(min(.05,max(0,deadline-time.monotonic())))
            if record['firstError'] is not None:break
    except BaseException as error:fault(error)
    finally:
        if trace_w is not None:os.close(trace_w)
        if process is not None:
            try:
                exited=observe();complete=exited is not None and all(record['eof'].values())
                cleanup_deadline=min(time.monotonic()+CLEANUP_SECONDS,deadline+CLEANUP_SECONDS)
                for signum,seconds in [(signal.SIGTERM,2),(signal.SIGKILL,3)]:
                    if complete:break
                    observe()
                    try:os.killpg(process.pid,signum);record['signals'].append(int(signum));record['forced']=True
                    except ProcessLookupError:pass
                    until=min(cleanup_deadline,time.monotonic()+seconds)
                    while time.monotonic()<until:
                        if selector is not None:pump(min(.05,max(0,until-time.monotonic())))
                        exited=observe();complete=exited is not None and all(record['eof'].values())
                        if complete:break
                if exited is not None:record['exit']=process.wait(timeout=0);reaped=True;record['reaped']=True
                else:fault(Refusal('OWNED_TRACER_NOT_REAPED_IN_BOUND'))
            except BaseException as error:fault(error)
        if selector is not None:selector.close()
        for pipe in (() if process is None else (process.stdout,process.stderr)):
            try:pipe.close()
            except BaseException as error:fault(error)
        try:os.close(trace_r)
        except OSError as error:fault(error)
        for handle in streams.values():
            try:handle.flush();os.fsync(handle.fileno())
            except BaseException as error:fault(error)
            finally:handle.close()
        for signum,handler in handlers.items():signal.signal(signum,handler)
    record['elapsedMilliseconds']=int((time.monotonic()-started)*1000)
    record['captureComplete']=all(record['eof'].values()) and record['observedBytes']==record['retainedBytes']
    record['receivedSignals']=interrupted
    record['raw']={name:descriptor(out/(name+'.bin')) for name in CAPS if (out/(name+'.bin')).is_file()}
    return record


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--supervisor-sha',required=True);parser.add_argument('--configuration-sha',required=True)
    parser.add_argument('--grant',required=True);parser.add_argument('--grant-sha',required=True);args=parser.parse_args()
    started=time.monotonic();cfg_pin,cfg,inventory,before,gp=admission(args,started)
    OUTPUT.mkdir(mode=0o700)
    trace_r,trace_w=os.pipe2(os.O_CLOEXEC)
    trace_target='/proc/self/fd/'+str(trace_w)
    entries=cfg['entries'];argv=[entries['strace']['path'],*TRACE_OPTIONS,'-o',trace_target,'--',
      entries['node']['path'],entries['metadataLoader']['path'],entries['historicalBinding']['path'],entries['historicalBinding']['sha256']]
    result={'schema':'e06-js-startup-prefix-diagnostic-result-v1','scope':SCOPE,'runId':RUN_ID,
      'executionSession':'/root','configuration':cfg_pin,'freshDiagnosticRelease':gp,
      'historicalBinding':entries['historicalBinding'],'beforeSnapshot':before,
      'firstError':None,'secondaryErrors':[],'sourceOnlyPhaseInference':True,
      'timeToolUsed':False,'cpuOrRssMeasured':False,'runtimePhaseProgress':'UNKNOWN',
      'limits':['Diagnostic trace prefix only; no full LOCAL, R3, canonical PASS or business request.',
        'Saved R2 binding/release are historical data; only the fresh diagnostic grant authorizes startup.',
        'Read-family syscall arguments are raw pointers; no buffer contents/env dump. Filename/time inference is not direct JS markers.',
        'Tracing overhead changes startup cost; no untraced performance or resource-cause inference.',
        'Private regular0600 outputs and trusted exact source are not hostile-host or OS read-only containment.',
        'Forced/uncertain cleanup cannot attest every escaped descendant; no ptrace policy changes.',
        'Python deadline checks are not hard preemption of blocked kernel/filesystem calls.']}
    result['capture']=capture(argv,trace_r,trace_w,OUTPUT)
    result['firstError']=result['capture']['firstError']
    result['secondaryErrors']=list(result['capture']['secondaryErrors'])
    post_deadline=min(time.monotonic()+20,started+TOTAL_SECONDS)
    try:
        def live():need(time.monotonic()<post_deadline,'DIAGNOSTIC_POSTFLIGHT_OR_TOTAL_BOUND')
        result['afterSnapshot']=snapshot(inventory,live)
        checked(cfg_pin,live);checked(gp,live);result['originalsUnchanged']=True
    except BaseException as error:
        result['originalsUnchanged']=False
        later={'type':type(error).__name__,'message':str(error)[:4096]}
        if result['firstError'] is None:result['firstError']=later
        elif len(result['secondaryErrors'])<16:result['secondaryErrors'].append(later)
    cap=result['capture'];stderr=(OUTPUT/'stderr.bin').read_bytes() if (OUTPUT/'stderr.bin').is_file() else b''
    expected=(cap['reaped'] and not cap['forced'] and cap['exit']==1 and cap['captureComplete']
      and cap['firstError'] is None and stderr==b'Error: EOF_REQUEST_COUNT\n' and cap['observedBytes']['stdout']==0)
    result['expectedEofErrorObserved']=expected
    result['disposition']='EXPECTED_EOF_ERROR_OBSERVED_DIAGNOSTIC_ONLY' if expected else 'PREFIX_ONLY_UNQUALIFIED_OR_STARTUP_REFUSAL'
    result['elapsedMilliseconds']=int((time.monotonic()-started)*1000)
    result['diagnosticExit']=0 if expected and result['originalsUnchanged'] and result['firstError'] is None else 2
    p=write(OUTPUT/'result.json',(json.dumps(result,indent=2)+'\n').encode())
    print(json.dumps({'result':p,'diagnosticExit':result['diagnosticExit'],'disposition':result['disposition'],'independentReviewRequired':True}))
    return result['diagnosticExit']

if __name__=='__main__':
    try:raise SystemExit(main())
    except BaseException as error:
        if isinstance(error,SystemExit):raise
        os.write(2,('DIAGNOSTIC_PREFLIGHT_OR_CAPTURE_FAILURE: '+type(error).__name__+': '+str(error))[:16384].encode('utf-8','backslashreplace')+b'\n')
        raise SystemExit(2)
