"""Fixed-path DATA-only archival; does not import or invoke experiment code."""
from pathlib import Path
import hashlib
import json

REPO = Path('/home/peterhorvath/apps/bitcoin/NBDP')
RUN = Path('/tmp/nbdp-e02-android-boot-trace-v1/runs/a378eba11798416a8c992f371b61f93b')
OUT = REPO / 'docs/decisions/evidence/e02-android-boot-trace-runtime-r1'
PREP = REPO / 'docs/decisions/evidence/e02-android-boot-trace-preparation-r1'
DIRS = ('commands', 'cleanup', 'diagnostics', 'evidence', 'ownership', 'session')
TOP = ('supervisor-result.json', 'early-boot-partial.json',
       'early-boot-result.json', 'diagnostic-partial.json')
INPUTS = ('subject.json', 'proposed-run-config.json', 'phase-plan.json',
          'exact-root-trace-release.json')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_json(path, data):
    with path.open('x') as f:
        f.write(json.dumps(data, indent=2) + '\n')


def copy_one(src, dst):
    assert src.is_file() and not src.is_symlink(), str(src)
    raw = src.read_bytes()
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('xb') as f:
        f.write(raw)
    assert dst.read_bytes() == raw == src.read_bytes(), str(src)
    return {'path': str(src), 'mirror': str(dst), 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    assert RUN.is_dir() and OUT.is_dir()
    assert not (OUT / 'mirror-manifest.json').exists()
    for name, size, digest in (
        ('supervisor-result.json', 3091, '03648444ca0e6c9072d103f2f9369a81e70328abc9db05ae4631d45f5242eafc'),
        ('diagnostic-partial.json', 8256, 'a77b4681aaf6f22662c2f5d189eb33d6537e2d9d59211cc4e6c7b80d10c13a92'),
    ):
        raw = (RUN / name).read_bytes()
        assert len(raw) == size and sha(raw) == digest
    files = []
    for dirname in DIRS:
        for src in sorted((RUN / dirname).rglob('*')):
            if src.is_file():
                files.append(copy_one(src, OUT / 'actual-run' / src.relative_to(RUN)))
    for name in TOP:
        files.append(copy_one(RUN / name, OUT / 'actual-run' / name))
    for name in INPUTS:
        files.append(copy_one(PREP / name, OUT / 'preparation-inputs' / name))
    excluded = []
    for dirname, reason in (
        ('android-state', 'Entire guest mutable state excluded, including all images, encryption keys, ADB keys, tokens and user state; no contents read.'),
        ('input', 'Mounted input copies/fixtures and placeholder binaries excluded; exact source/config pins remain in subject/config, not an execution claim.'),
        ('relay-data', 'Disposable relay database excluded; no fixture publication or business effects are claimed.'),
        ('docker-config', 'Docker client configuration excluded; not needed for selected runtime observations.'),
    ):
        paths = [p for p in sorted((RUN / dirname).rglob('*')) if p.is_file()]
        excluded.append({'path': str(RUN / dirname), 'reason': reason,
                         'fileCount': len(paths), 'bytesFromMetadataOnly': sum(p.stat().st_size for p in paths)})
    selected = {Path(x['path']) for x in files if Path(x['path']).is_relative_to(RUN)}
    all_run_files = {p for p in RUN.rglob('*') if p.is_file()}
    excluded_paths = {p for name in ('android-state', 'input', 'relay-data', 'docker-config')
                      for p in (RUN / name).rglob('*') if p.is_file()}
    assert selected.isdisjoint(excluded_paths)
    assert all_run_files == selected | excluded_paths, 'Unclassified run member'
    assert not (RUN / 'diagnostic-result.json').exists()
    assert not any(p.suffix in ('.png', '.xml') for p in selected)
    records = [json.loads((RUN / 'commands' / f'{n:04d}.json').read_text()) for n in range(1, 133)]
    assert len(list((RUN / 'commands').glob('*.json'))) == 132
    abnormal = [(n, r) for n, r in enumerate(records, 1)
                if r['error'] is not None or r['forced'] or r['timedOut'] or r['exit'] != 0
                or not r['reaped'] or not r['stdoutEOF'] or not r['stderrEOF']]
    assert len(abnormal) == 1 and abnormal[0][0] == 132
    early = json.loads((RUN / 'early-boot-result.json').read_text())
    post = json.loads((RUN / 'diagnostic-partial.json').read_text())
    lease = json.loads((RUN / 'session/lease.json').read_text())
    result = json.loads((RUN / 'supervisor-result.json').read_text())
    revoked = (RUN / 'session/control/REVOKED').read_text()
    assert revoked == 'owned command failed: LeaseDenied: command deadline\n'
    assert result['executionState'] == 'FAILED_UNQUALIFIED' and result['cleanup']['ok']
    assert len(result['cleanup']['rows']) == 4
    for axis in ('Utc', 'Mono', 'Boot'):
        assert lease['deadline' + axis + 'Ns'] - lease['issued' + axis + 'Ns'] == 1800_000_000_000
    for phase in (early, post):
        assert phase['endedMonotonicNs'] < phase['phaseDeadlineMonotonicNs'] < lease['deadlineMonoNs']
    source_checks = []
    for entry in json.loads((PREP / 'subject.json').read_text())['sources']:
        raw = Path(entry['path']).read_bytes()
        assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
        source_checks.append(entry)
    observation = {
        'schema': 'e02-boot-trace-acquired-prefix-v1',
        'state': 'FAILED_UNQUALIFIED_ACQUIRED_PREFIX_ONLY',
        'authorRole': 'implementer, data archiver; not run operator or independent reviewer',
        'canonicalE02Changed': False, 'ordinaryControlQualified': False,
        'sourceAndEnvironmentModified': False, 'experimentRerun': False,
        'commandReceipts': 132, 'normalCompletedReceipts': 131,
        'sourcePinsReverifiedWithoutImport': source_checks,
        'firstAbnormalCommand': {'number': 132, 'receipt': 'actual-run/commands/0132.json',
                                'operation': 'adb shell uiautomator dump /sdcard/nbdp-window.xml',
                                'exit': abnormal[0][1]['exit'], 'forced': abnormal[0][1]['forced'],
                                'reaped': abnormal[0][1]['reaped'], 'timedOut': abnormal[0][1]['timedOut'],
                                'error': abnormal[0][1]['error'],
                                'stdoutEOF': abnormal[0][1]['stdoutEOF'], 'stderrEOF': abnormal[0][1]['stderrEOF']},
        'firstStickyTrigger': {'rawControl': revoked, 'path': 'actual-run/session/control/REVOKED',
                              'meaning': 'Preserved first reason is owned-command deadline; final outer receipt observes sticky revocation.',
                              'limit': 'No retained nested child receipt/per-command elapsed sample proves exact inner completion timing or ANR causality. Exit 0 does not override forced/error.'},
        'phaseEvidence': {
            'originalLeaseSeconds': 1800,
            'early': {'budgetSeconds': early['phaseBudgetSeconds'], 'completed': early['completed'],
                      'observations': len(early['observations']),
                      'startedMonotonicNs': early['startedMonotonicNs'],
                      'endedMonotonicNs': early['endedMonotonicNs'],
                      'usedSeconds': (early['endedMonotonicNs'] - early['startedMonotonicNs']) / 1e9},
            'postbootPrefix': {'budgetSeconds': post['phaseBudgetSeconds'], 'completed': post['completed'],
                               'observations': len(post['observations']),
                               'startedMonotonicNs': post['startedMonotonicNs'],
                               'endedMonotonicNs': post['endedMonotonicNs'],
                               'usedPrefixSeconds': (post['endedMonotonicNs'] - post['startedMonotonicNs']) / 1e9},
            'lastObservationToPartialEndSeconds': (post['endedMonotonicNs'] - post['observations'][-1]['endedMonotonicNs']) / 1e9,
            'leaseIssuedToPartialEndMonotonicSeconds': (post['endedMonotonicNs'] - lease['issuedMonoNs']) / 1e9,
            'limit': 'Raw endpoints retained; not all-command duration, wall-clock cleanup timing, peak usage or hard real-time proof. Phase deadline/original lease were not renewed.'},
        'traceEvidence': {'lastanr': 'UNKNOWN_EXPLICIT_NO_ENTRY', 'lastanrTraces': 'CANDIDATE_UNMATCHED',
                          'dropboxSystemAppAnr': 'CANDIDATE_UNMATCHED',
                          'matchingPidReasonStackCause': 'PENDING_INDEPENDENT_RAW_CORRELATION',
                          'privateCgroupSamples': 1, 'pressureMetrics': 'UNKNOWN_UNAVAILABLE'},
        'missing': ['UI XML', 'UI PNG', 'later checkpoint', 'final diagnostic-result.json',
                    'per-command elapsed clock samples', 'retained nested uiautomator child receipt'],
        'cleanup': result['cleanup'],
        'limits': ['No whole healthy/qualified ordinary-client row or E02 completion.',
                   'No APK install, activity intent, identity/login/input/publication claimed; diagnostic driver action counters remain zero.',
                   'Existing trace/DropBox payloads require independent matching; latest trace alone does not establish cause.',
                   'All raw command streams retained, including empty streams and cleanup error-channel output.']}
    write_json(OUT / 'acquired-prefix.json', observation)
    write_json(OUT / 'root-tool-association.json', {
        'schema': 'root-tool-association-transcription-v1',
        'provenance': 'Explicitly transcribed from parent /root task message, not witnessed or executed by this archiver.',
        'foregroundSession': 30292, 'launchToolChunk': 'b8a98d', 'completionToolChunk': '1c3a5f',
        'exit': 2, 'state': 'FINISHED', 'run': str(RUN),
        'expectedSupervisorBytes': 3091,
        'expectedSupervisorSha256': '03648444ca0e6c9072d103f2f9369a81e70328abc9db05ae4631d45f5242eafc',
        'expectedPartialBytes': 8256,
        'expectedPartialSha256': 'a77b4681aaf6f22662c2f5d189eb33d6537e2d9d59211cc4e6c7b80d10c13a92'})
    write_json(OUT / 'mirror-manifest.json', {
        'schema': 'fixed-selected-raw-mirror-v1', 'run': str(RUN),
        'archiver': {'path': str(Path(__file__).resolve()), 'bytes': Path(__file__).stat().st_size,
                     'sha256': sha(Path(__file__).read_bytes())},
        'selectedRunFiles': len(selected), 'preparationInputFiles': len(INPUTS),
        'mirroredFiles': len(files), 'mirroredBytes': sum(x['bytes'] for x in files),
        'sourceFilesRecheckedAfterCopy': True, 'files': files, 'exclusions': excluded,
        'externalExclusions': ['SDK, Android image, APK, node_modules and all external caches are not traversed or copied.',
                               'No guest userdata/encryption/ADB keys or tokens copied; entire android-state excluded.'],
        'noSourceExecution': True, 'noExperimentRerun': True})
    print(json.dumps({'mirroredFiles': len(files), 'mirroredBytes': sum(x['bytes'] for x in files),
                      'state': 'DATA_ARCHIVE_COMPLETE_PENDING_INDEPENDENT_REVIEW'}))


if __name__ == '__main__':
    main()
