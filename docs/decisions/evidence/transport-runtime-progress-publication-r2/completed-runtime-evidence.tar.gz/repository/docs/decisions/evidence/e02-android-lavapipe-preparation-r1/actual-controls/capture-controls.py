"""Trusted finite capture for the separately accepted pure-control scope only.

No target source is imported by this monitor. Fixed tests import their accepted
subjects themselves. This is not a release/approval, protocol validator, Android
or interoperability harness. Importing starts no child.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import selectors
import signal
import subprocess
import sys
import time

ROOT=Path('/home/peterhorvath/apps/bitcoin/NBDP')
E=ROOT/'docs/decisions/evidence/e02-android-lavapipe-preparation-r1'
OUT=E/'actual-controls'
PYTHON=Path('/home/peterhorvath/.miniforge3/bin/python3.13')
PYTHON_PIN={'path':str(PYTHON),'bytes':32959480,'sha256':'5e2f62ca6ab9c6992460493de8a8867e84f8e6078f0e5c197b5232b79e4b35f1'}
SUBJECT={'path':str(E/'subject.json'),'bytes':5559,'sha256':'e25c48d7e613462cd13ec6ffc613cbda2c5c1f6b309c19a94635944fd7fc4771'}
CONFIG={'path':str(E/'proposed-run-config.json'),'bytes':3172,'sha256':'c53adce6f18e20fdf64214dd051acea5efa3283f1ecb164c62d0d2f3323bc18b'}
ENV={'PATH':'/home/peterhorvath/.miniforge3/bin:/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'}
SUITES=(('guard','test_lease_guard.py',29),('cleanup','test_cleanup.py',24),('diagnostic','test_diagnostic.py',28),('lavapipe','test_lavapipe.py',11))
MAX_STREAM=2097152

def pin(path):
    p=Path(path);assert p.is_absolute() and p.resolve(strict=True)==p and not p.is_symlink() and p.is_file()
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        while block:=f.read(1048576):h.update(block);n+=len(block)
    return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}

def save(path,value):
    raw=(json.dumps(value,indent=2)+'\n').encode();write(path,raw);return pin(path)

def write(path,raw):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())

def frozen(expected):
    actual=[pin(p['path']) for p in expected]
    if actual!=expected:raise RuntimeError('SOURCE_OR_INTERPRETER_DRIFT')
    return actual

def child(label,filename,expected_count):
    argv=[str(PYTHON),'-I','-B',str(ROOT/'experiments/prototypes/e02_android_lavapipe_trace_v1'/filename)]
    started=time.monotonic();deadline=started+60
    p=None;held=False;first=None;secondary=[];forced=False;reaped=False
    data={'stdout':bytearray(),'stderr':bytearray()};seen={'stdout':0,'stderr':0};eof={'stdout':False,'stderr':False}
    selector=selectors.DefaultSelector()
    def observe():return os.waitid(os.P_PID,p.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
    def pump(seconds):
        for key,_ in selector.select(seconds):
            raw=os.read(key.fd,65536)
            if not raw:eof[key.data]=True;selector.unregister(key.fileobj);continue
            name=key.data;seen[name]+=len(raw)
            data[name].extend(raw[:max(0,MAX_STREAM-len(data[name]))])
            if seen[name]>MAX_STREAM:raise RuntimeError('CONTROL_CAPTURE_OVERFLOW:'+name)
    try:
        p=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,bufsize=0)
        held=True
        for name in data:
            stream=getattr(p,name);os.set_blocking(stream.fileno(),False);selector.register(stream,selectors.EVENT_READ,name)
        while True:
            if time.monotonic()>=deadline:raise RuntimeError('CONTROL60S_DEADLINE')
            if observe() is not None and not selector.get_map():break
            pump(.05)
    except BaseException as exc:first=type(exc).__name__+': '+str(exc)
    finally:
        if p is not None and held:
            try:
                if first is not None:
                    observe()
                    try:os.killpg(p.pid,signal.SIGTERM);forced=True
                    except ProcessLookupError:pass
                    end=time.monotonic()+2
                    while time.monotonic()<end:
                        if observe() is not None and not selector.get_map():break
                        try:pump(.05)
                        except BaseException:break
                    observe()
                    try:os.killpg(p.pid,signal.SIGKILL);forced=True
                    except ProcessLookupError:pass
                    end=time.monotonic()+1
                    while selector.get_map() and time.monotonic()<end:
                        try:pump(.05)
                        except BaseException:break
                exit_code=p.wait(timeout=3);reaped=True;held=False
            except BaseException as exc:
                secondary.append('Owned capture cleanup: '+repr(exc));exit_code=p.returncode
                if first is None:first=secondary.pop()
        else:exit_code=None
        selector.close()
        if p is not None:
            for name in data:
                try:getattr(p,name).close()
                except OSError:pass
    duration=int((time.monotonic()-started)*1000)
    streams={}
    for name,raw in data.items():
        path=OUT/(label+'.'+name);write(path,bytes(raw));streams[name]=pin(path)
    text=bytes(data['stderr']).decode('utf-8','replace');runs=re.findall(r'^Ran ([0-9]+) tests? in ',text,re.M)
    observed_count=int(runs[0]) if len(runs)==1 else None
    success=(exit_code==0 and first is None and not secondary and reaped and not forced
             and all(eof.values()) and observed_count==expected_count and text.rstrip().endswith('\nOK'))
    if not success and first is None:first='UNQUALIFIED_CONTROL_RESULT:exit='+str(exit_code)+':count='+str(observed_count)
    result={'label':label,'argv':argv,'environment':ENV,'cwd':str(ROOT),'source':pin(argv[-1]),
        'pid':None if p is None else p.pid,'pidMeaning':'PID in this tool execution namespace, not asserted host PID',
        'exit':exit_code,'naturalExit':exit_code if not forced and reaped else None,'reaped':reaped,
        'stdoutEOF':eof['stdout'],'stderrEOF':eof['stderr'],'forced':forced,
        'error':first,'secondaryErrors':secondary,'durationMs':duration,'deadlineSeconds':60,
        'observedBytes':seen,'streams':streams,'expectedControls':expected_count,'observedControls':observed_count,
        'qualifiedPureControls':success,'scope':'PURE_CONTROL_ONLY; mocked diagnostic data and owned Python/tempfile controls, no Android or transport.'}
    save(OUT/(label+'-execution.json'),result);return result

def main():
    if sys.argv[1:]!=['--execute-after-parent-acceptance']:raise RuntimeError('Exact externally authorized pure-control invocation required')
    assert pin(E/'subject.json')==SUBJECT and pin(E/'proposed-run-config.json')==CONFIG
    assert pin(PYTHON)==PYTHON_PIN
    subject=json.loads((E/'subject.json').read_bytes());expected=subject['sources']+[SUBJECT,CONFIG,PYTHON_PIN,pin(Path(__file__).resolve())]
    before=frozen(expected);save(OUT/'sources-before.json',before)
    rows=[];first=None;secondary=[]
    for label,filename,count in SUITES:
        try:
            frozen(expected);row=child(label,filename,count);rows.append(row)
            if not row['qualifiedPureControls']:first=row['error'];break
            frozen(expected)
        except BaseException as exc:first=repr(exc);break
    try:after=frozen(expected);source_integrity=True
    except BaseException as exc:
        after=[];source_integrity=False
        if first is None:first=repr(exc)
        else:secondary.append(repr(exc))
    save(OUT/'sources-after.json',after)
    result={'schema':'e02-lavapipe-actual-pure-controls-v1','actor':'/root/android_health_implementer',
        'executionAuthorityBasis':'Actual parent /root message after independent QA and security ACCEPT_LAVAPIPE_SOURCE_CONFIG_FOR_PURE_CONTROLS_ONLY for the exact subject/config; this record grants no authority.',
        'subject':SUBJECT,'configuration':CONFIG,'captureSource':pin(Path(__file__).resolve()),'interpreter':pin(PYTHON),'interpreterVersion':sys.version,
        'sourceIntegrity':source_integrity,'sourceBefore':pin(OUT/'sources-before.json'),'sourceAfter':pin(OUT/'sources-after.json'),
        'rows':rows,'error':first,'secondaryErrors':secondary,'qualifiedPureControls':first is None and source_integrity and len(rows)==4,
        'remainingSuites':'NONE' if len(rows)==4 else 'NOT_EXECUTED_AFTER_FIRST_FAILURE',
        'limits':['Counts are separate pure-control scopes, not E02 assertions or Android evidence.','No Android/Docker/relay/network/crypto/protocol runtime experiment, release or approval. Tests exercise resource/isolation validators as declared pure controls.','Namespace lifecycle/capture is not hostile-host or hard realtime attestation.']}
    save(OUT/'execution.json',result);print(json.dumps({'qualifiedPureControls':result['qualifiedPureControls'],'error':first,'rows':[{k:r[k] for k in ['label','exit','observedControls','qualifiedPureControls','durationMs']} for r in rows],'execution':pin(OUT/'execution.json')}))
    return 0 if result['qualifiedPureControls'] else 2

if __name__=='__main__':raise SystemExit(main())
