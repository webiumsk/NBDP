"""Finite fixed DATA acquisition only. Never invokes SDK tools or project code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import shutil
import ssl
import stat
import struct
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

REPO = Path('/home/peterhorvath/apps/bitcoin/NBDP')
E = REPO / 'docs/decisions/evidence/e02-api35-fixture-preparation-r1'
DEST = Path('/tmp/nbdp-e02-api35-fixture')
SDK = DEST / 'sdk'
ORIGINAL = Path('/tmp/nbdp-e02-ingress-runtime/sdk')
METADATA = Path('/tmp/nbdp-e02-api35-metadata')
ZIP = DEST / 'downloads/x86_64-35_r02.zip'
URL = 'https://dl.google.com/android/repository/sys-img/android/x86_64-35_r02.zip'
ZIP_SIZE = 782404023
ZIP_SHA1 = '2d857d170c0d1b827149565da34b3383e5306f7f'
UNPACKED = 1777735194
RESERVE = 6 * 1024**3
CHUNK = 1048576
START = time.monotonic()
GLOBAL_END = START + 1200
SPACE = {'minimumSampledFree': None, 'checks': 0, 'reserveBytes': RESERVE}
STAGES = []


def check_space(additional=0):
    if time.monotonic() >= GLOBAL_END: raise RuntimeError('GLOBAL1200S_DEADLINE')
    free = shutil.disk_usage('/tmp').free
    SPACE['checks'] += 1
    SPACE['minimumSampledFree'] = free if SPACE['minimumSampledFree'] is None else min(SPACE['minimumSampledFree'], free)
    if free - additional < RESERVE: raise RuntimeError('SIX_GIB_RESERVE_REFUSED:' + str(free))
    return free


def exclusive(path, mode=0o600):
    check_space()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    return os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode), 'wb')


def write_chunk(stream, block):
    check_space(len(block)); stream.write(block); check_space()


def save(name, value):
    raw = (json.dumps(value, indent=2) + '\n').encode()
    with exclusive(E / name) as out:
        write_chunk(out, raw); out.flush(); os.fsync(out.fileno())


def descriptor(path, sha1=False):
    h = hashlib.sha256(); one = hashlib.sha1() if sha1 else None; count = 0
    with path.open('rb') as source:
        while block := source.read(CHUNK):
            check_space(); count += len(block); h.update(block)
            if one is not None: one.update(block)
    result = {'path': str(path), 'bytes': count, 'sha256': h.hexdigest()}
    if one is not None: result['sha1'] = one.hexdigest()
    return result


def stage(name, **extra):
    row = {'stage': name, 'utcNs': time.time_ns(), 'elapsedSeconds': time.monotonic() - START,
           'diskFree': check_space(), **extra}
    STAGES.append(row)
    save('stage-%02d.json' % len(STAGES), row)
    print(json.dumps(row), flush=True)


def snapshot_sources():
    rows = []
    for dirname in ('emulator', 'platform-tools'):
        root = ORIGINAL / dirname
        if root.resolve(strict=True) != root or not root.is_dir(): raise RuntimeError('SOURCE_ROOT_REFUSED')
        for path in [root, *sorted(root.rglob('*'))]:
            info = path.lstat(); relative = str(path.relative_to(ORIGINAL))
            base = {'path': relative, 'mode': oct(stat.S_IMODE(info.st_mode)),
                    'mtimeNs': info.st_mtime_ns, 'inode': info.st_ino, 'device': info.st_dev}
            if stat.S_ISDIR(info.st_mode): base['type'] = 'directory'
            elif stat.S_ISREG(info.st_mode):
                base.update(type='regular', bytes=info.st_size, sha256=descriptor(path)['sha256'])
            elif stat.S_ISLNK(info.st_mode):
                target = path.resolve(strict=True)
                if not target.is_relative_to(ORIGINAL): raise RuntimeError('OUTSIDE_SDK_SYMLINK')
                base.update(type='symlink', target=str(path.readlink()))
            else: raise RuntimeError('SOURCE_SPECIAL_FILE')
            rows.append(base)
    if sum(row.get('bytes', 0) for row in rows if row['path'].startswith('emulator/')) != 903291301:
        raise RuntimeError('SOURCE_EMULATOR_SIZE_DRIFT')
    if sum(row.get('bytes', 0) for row in rows if row['path'].startswith('platform-tools/')) != 22198160:
        raise RuntimeError('SOURCE_PLATFORM_TOOLS_SIZE_DRIFT')
    return rows


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise RuntimeError('EXACT_GOOGLE_URL_REDIRECT_REFUSED')


def download():
    begin = time.monotonic(); deadline = begin + 300
    record = {'url': URL, 'attempts': 1, 'maximumSeconds': 300, 'connectAndReadTimeoutSeconds': 15,
              'tlsVerified': True, 'redirectsAllowed': False, 'authentication': 'NONE', 'bytes': 0,
              'expectedBytes': ZIP_SIZE, 'expectedOfficialSha1': ZIP_SHA1, 'sha256': 'UNKNOWN', 'error': None}
    try:
        opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl.create_default_context()), NoRedirect())
        request = urllib.request.Request(URL, headers={'User-Agent': 'NBDP-isolated-fixture-acquisition/1', 'Accept-Encoding': 'identity'})
        with opener.open(request, timeout=15) as response, exclusive(ZIP) as out:
            if response.status != 200 or response.geturl() != URL: raise RuntimeError('EXACT_HTTP200_URL_REQUIRED')
            record['httpStatus'] = response.status
            record['headers'] = dict(response.headers.items())
            length = response.headers.get('Content-Length')
            if length is not None and int(length) != ZIP_SIZE: raise RuntimeError('CONTENT_LENGTH_REFUSED')
            one = hashlib.sha1(); two = hashlib.sha256()
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0: raise RuntimeError('DOWNLOAD300S_DEADLINE')
                if response.fp is None: break
                # Fixed TLS socket timeout also encloses the remaining aggregate budget.
                response.fp.raw._sock.settimeout(min(15, remaining))
                block = response.read(min(CHUNK, ZIP_SIZE + 1 - record['bytes']))
                if not block: break
                if record['bytes'] + len(block) > ZIP_SIZE: raise RuntimeError('EXACT_DOWNLOAD_BYTE_CAP')
                write_chunk(out, block); one.update(block); two.update(block); record['bytes'] += len(block)
            out.flush(); os.fsync(out.fileno())
            if record['bytes'] != ZIP_SIZE: raise RuntimeError('OFFICIAL_SIZE_MISMATCH')
            record['sha1'] = one.hexdigest()
            if record['sha1'] != ZIP_SHA1: raise RuntimeError('OFFICIAL_SHA1_MISMATCH')
            record['sha256'] = two.hexdigest(); record['officialSizeAndSha1Verified'] = True
    except BaseException as exc:
        record['error'] = repr(exc); raise
    finally:
        record['elapsedSeconds'] = time.monotonic() - begin
        record['partialOrCompleteFilePreserved'] = ZIP.exists()
        save('download.json', record)
    return descriptor(ZIP, sha1=True)


def validate_zip():
    cached = json.loads((METADATA / 'x86_64-35_r02.central-directory.json').read_text())
    entries = []; ranges = []
    with zipfile.ZipFile(ZIP) as archive, ZIP.open('rb') as raw:
        if len(archive.infolist()) != 24: raise RuntimeError('EXACT24_ZIP_ENTRIES_REQUIRED')
        names = set()
        for info in archive.infolist():
            check_space(); name = info.filename; path = PurePosixPath(name)
            mode = info.external_attr >> 16
            if (name != info.orig_filename or '\x00' in name or '\\' in name or path.is_absolute()
                    or '..' in path.parts or '.' in path.parts or str(path) != name or not name.startswith('x86_64/')
                    or info.is_dir() or name in names or not stat.S_ISREG(mode)
                    or info.flag_bits not in (0, 8) or info.compress_type not in (0, 8)
                    or not 0 <= info.file_size <= UNPACKED):
                raise RuntimeError('ZIP_SAFE_REGULAR_ENTRY_REFUSED:' + name)
            names.add(name)
            raw.seek(info.header_offset); header = raw.read(30)
            fields = struct.unpack('<4s5H3I2H', header)
            signature, _, flags, method, _, _, crc, compressed, unpacked, nlen, extra = fields
            local_name = raw.read(nlen)
            if signature != b'PK\x03\x04' or flags != info.flag_bits or method != info.compress_type or local_name.decode('cp437') != name:
                raise RuntimeError('ZIP_LOCAL_HEADER_NAME_FLAGS_METHOD_MISMATCH')
            payload = info.header_offset + 30 + nlen + extra
            end = payload + info.compress_size
            if flags & 8:
                if (crc, compressed, unpacked) not in ((0, 0, 0), (info.CRC, info.compress_size, info.file_size)):
                    raise RuntimeError('ZIP_LOCAL_DESCRIPTOR_PLACEHOLDERS_REFUSED')
                raw.seek(end); data = raw.read(16)
                if data[:4] == b'PK\x07\x08': actual = struct.unpack('<3I', data[4:16]); end += 16
                else: actual = struct.unpack('<3I', data[:12]); end += 12
                if actual != (info.CRC, info.compress_size, info.file_size): raise RuntimeError('ZIP_DATA_DESCRIPTOR_CRC_SIZE_MISMATCH')
            elif (crc, compressed, unpacked) != (info.CRC, info.compress_size, info.file_size):
                raise RuntimeError('ZIP_LOCAL_CRC_SIZE_MISMATCH')
            if end > archive.start_dir: raise RuntimeError('ZIP_PAYLOAD_OVERLAPS_CENTRAL_DIRECTORY')
            ranges.append((info.header_offset, end))
            rows = {'name': name, 'compressedBytes': info.compress_size, 'uncompressedBytes': info.file_size,
                    'method': info.compress_type, 'flags': info.flag_bits, 'unixMode': oct(mode),
                    'crc32': '%08x' % info.CRC, 'localHeaderOffset': info.header_offset}
            if rows != cached['files'][len(entries)]: raise RuntimeError('FULL_ZIP_CENTRAL_DIFFERS_RANGE_HINT')
            # Full decompression and ZIP CRC check occurs BEFORE any extraction.
            length = 0; hashed = hashlib.sha256()
            with archive.open(info) as source:
                while block := source.read(CHUNK):
                    check_space(); length += len(block)
                    if length > info.file_size: raise RuntimeError('ZIP_UNCOMPRESSED_ENTRY_BOUND')
                    hashed.update(block)
            if length != info.file_size: raise RuntimeError('ZIP_UNCOMPRESSED_SIZE_MISMATCH')
            entries.append(dict(rows, uncompressedSha256=hashed.hexdigest(), fullCrcVerified=True))
    if sum(entry['uncompressedBytes'] for entry in entries) != UNPACKED: raise RuntimeError('ZIP_TOTAL_UNCOMPRESSED_BOUND')
    ordered = sorted(ranges)
    if any(a[1] > b[0] for a, b in zip(ordered, ordered[1:])): raise RuntimeError('ZIP_LOCAL_PAYLOAD_OVERLAP')
    save('zip-validation.json', {'entries': entries, 'count': len(entries), 'uncompressedBytes': UNPACKED,
                                'fullLocalHeadersDescriptorsAndPayloadCrcVerifiedBeforeExtraction': True})
    return entries


def copy_tools(before):
    copied = []
    for row in before:
        check_space(); source = ORIGINAL / row['path']; dest = SDK / row['path']
        if row['type'] == 'directory': dest.mkdir(parents=True, mode=int(row['mode'], 8)); continue
        if row['type'] == 'symlink':
            # This pinned source currently contains none; preserve safe mapped target only.
            target = (source.parent / row['target']).resolve(strict=True)
            if not target.is_relative_to(ORIGINAL): raise RuntimeError('OUTSIDE_SOURCE_SYMLINK')
            mapped = SDK / target.relative_to(ORIGINAL)
            dest.symlink_to(os.path.relpath(mapped, dest.parent)); continue
        fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as stream, exclusive(dest, int(row['mode'], 8)) as out:
            count = 0; hashed = hashlib.sha256()
            while block := stream.read(CHUNK):
                count += len(block)
                if count > row['bytes']: raise RuntimeError('SOURCE_COPY_SIZE_DRIFT')
                write_chunk(out, block); hashed.update(block)
            out.flush(); os.fsync(out.fileno()); os.fchmod(out.fileno(), int(row['mode'], 8))
        if count != row['bytes'] or hashed.hexdigest() != row['sha256']: raise RuntimeError('SOURCE_COPY_HASH_DRIFT')
        if dest.stat().st_ino == source.stat().st_ino and dest.stat().st_dev == source.stat().st_dev:
            raise RuntimeError('HARDLINK_COPY_REFUSED')
        copied.append(descriptor(dest))
    save('copied-tools.json', {'files': copied, 'regularCount': len(copied), 'hardlinksUsed': False,
                             'executableModesPreserved': True, 'originalModified': False})


def extract(entries):
    base = SDK / 'system-images/android-35/default'
    with zipfile.ZipFile(ZIP) as archive:
        for entry in entries:
            check_space(entry['uncompressedBytes'])
            dest = base / entry['name']
            with archive.open(entry['name']) as source, exclusive(dest, int(entry['unixMode'], 8) & 0o777) as out:
                size = 0; hashed = hashlib.sha256()
                while block := source.read(CHUNK):
                    size += len(block)
                    if size > entry['uncompressedBytes']: raise RuntimeError('EXTRACT_ENTRY_BOUND')
                    write_chunk(out, block); hashed.update(block)
                out.flush(); os.fsync(out.fileno()); os.fchmod(out.fileno(), int(entry['unixMode'], 8) & 0o777)
            if size != entry['uncompressedBytes'] or hashed.hexdigest() != entry['uncompressedSha256']:
                raise RuntimeError('EXTRACT_UNCOMPRESSED_HASH_MISMATCH')


def inventory():
    rows = []
    for path in sorted(SDK.rglob('*')):
        check_space()
        if path.is_symlink():
            if not path.resolve(strict=True).is_relative_to(SDK): raise RuntimeError('NEW_SDK_OUTSIDE_SYMLINK')
            rows.append({'path': str(path.relative_to(SDK)), 'symlink': str(path.readlink())})
        elif path.is_file():
            rows.append({'path': str(path.relative_to(SDK)), 'size': path.stat().st_size,
                         'mode': oct(path.stat().st_mode & 0o777), 'sha256': descriptor(path)['sha256']})
        elif not path.is_dir(): raise RuntimeError('NEW_SDK_SPECIAL_FILE')
    aggregate = hashlib.sha256(json.dumps(rows, separators=(',', ':'), sort_keys=True).encode()).hexdigest()
    save('sdk-tree.json', {'root': str(SDK), 'sha256': aggregate, 'files': rows,
                          'aggregateHashMethod': 'SHA256 UTF8 json.dumps(files,sort_keys=True,separators=(comma,colon))',
                          'schemaCompatibility': 'Accepted file-row format: path,size,mode,sha256 or path,symlink. Extra index metadata is DATA only.'})
    return rows


def main():
    failure = None; before = None; zip_pin = None; rows = None
    check_space(65536)
    result_fd = os.open(E / 'result.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    os.posix_fallocate(result_fd, 0, 65536)
    script_raw = Path(__file__).read_bytes()
    script_pin = {'path': str(Path(__file__).resolve()), 'bytes': len(script_raw),
                  'sha256': hashlib.sha256(script_raw).hexdigest()}
    result = {'schema': 'api35-fixture-data-preparation-v1', 'actor': '/root/android_health_implementer',
              'runtimeCompatibility': 'UNKNOWN_NOT_EXECUTED', 'SDKManagerInvoked': False,
              'licenseAcceptedOrModified': False, 'servicesOrEmulatorInvoked': False,
              'sourceOrSharedDocsGitChanged': False, 'firstError': None}
    try:
        if DEST.exists(): raise RuntimeError('FRESH_FIXTURE_ROOT_REQUIRED')
        check_space(903291301 + 22198160 + ZIP_SIZE + UNPACKED)
        DEST.mkdir(mode=0o700); SDK.mkdir(mode=0o700)
        metadata = descriptor(METADATA / 'sys-img2-4.xml')
        fragment = descriptor(METADATA / 'api35-remote-package.raw.xml')
        if (metadata['bytes'], metadata['sha256']) != (190717, '3dcfa09ffd6f970ab344815e2d88020b31679fbfbcddb19bafa1821a5e16df08'):
            raise RuntimeError('OFFICIAL_METADATA_PIN_DRIFT')
        if (fragment['bytes'], fragment['sha256']) != (1114, 'fd6ffe54a4d03cb91ed81a7b369c3c4ae34e81890aa069d3add2618e21b2aed4'):
            raise RuntimeError('OFFICIAL_FRAGMENT_PIN_DRIFT')
        save('metadata-provenance.json', {'officialMetadata': metadata, 'rawPackageFragment': fragment,
            'reclamation': descriptor(REPO / 'docs/decisions/evidence/e02-owned-avd-overlay-reclamation-r2/result.json'),
            'archiveUrl': URL, 'api': 35, 'extension': 13, 'revision': 2, 'abi': 'x86_64', 'tag': 'default'})
        before = snapshot_sources(); save('source-before.json', before); stage('source-snapshot-before')
        xml = ET.parse(METADATA / 'sys-img2-4.xml').getroot()
        text = next(node.text for node in xml if node.tag.split('}')[-1] == 'license' and node.attrib.get('id') == 'android-sdk-license')
        with exclusive(E / 'current-official-license-text.txt') as out: write_chunk(out, text.encode('utf-8'))
        accepted = Path('/tmp/nbdp-e02-android-artifact/sdk/licenses/android-sdk-license')
        accepted_pin = descriptor(accepted)
        if (accepted_pin['bytes'], accepted_pin['sha256']) != (41, 'c43fa37686457c3f18caa3607945f4ec52a9d1beaaad8117e50dc4e863270c85'):
            raise RuntimeError('EXISTING_ACCEPTED_LICENSE_DESCRIPTOR_DRIFT')
        save('license-provenance.json', {'referencedLicenseId': 'android-sdk-license',
            'currentOfficialText': descriptor(E / 'current-official-license-text.txt'), 'existingAcceptedFile': accepted_pin,
            'currentRawTextUtf8Sha1': hashlib.sha1(text.encode('utf-8')).hexdigest(),
            'exactRawTextHashAppearsInExistingFile': hashlib.sha1(text.encode('utf-8')).hexdigest() in accepted.read_text().splitlines(),
            'normalizedSdkLicenseIdentity': 'UNKNOWN_NOT_ASSERTED',
            'limit': 'No undocumented normalization or automatic license acceptance; descriptor retained without modifying/copying a global acceptance file.'})
        zip_pin = download(); stage('official-archive-downloaded-and-hashed', archive=zip_pin)
        entries = validate_zip(); stage('full-zip-local-and-crc-validation-before-extraction')
        copy_tools(before); stage('tools-copied')
        extract(entries); stage('api35-extracted')
        rows = inventory(); stage('complete-sdk-tree-hashed', entries=len(rows))
        after = snapshot_sources(); save('source-after.json', after)
        if after != before: raise RuntimeError('ORIGINAL_SOURCE_METADATA_OR_HASH_CHANGED')
        source_props = SDK / 'system-images/android-35/default/x86_64/source.properties'
        build_props = SDK / 'system-images/android-35/default/x86_64/build.prop'
        emulator_props = SDK / 'emulator/source.properties'
        tools_props = SDK / 'platform-tools/source.properties'
        prop = lambda p: dict(line.split('=', 1) for line in p.read_text().splitlines() if '=' in line and not line.startswith('#'))
        save('properties.json', {'imageSourceProperties': {'file': descriptor(source_props), 'values': prop(source_props)},
            'buildProperties': {'file': descriptor(build_props), 'values': prop(build_props)},
            'emulatorProperties': {'file': descriptor(emulator_props), 'values': prop(emulator_props)},
            'platformToolsProperties': {'file': descriptor(tools_props), 'values': prop(tools_props)},
            'imageFingerprintSourceOnly': prop(build_props).get('ro.system.build.fingerprint', prop(build_props).get('ro.build.fingerprint', 'UNKNOWN')),
            'meaning': 'Source metadata only, not booted fingerprint or runtime compatibility.'})
        result.update(state='DATA_PREPARATION_COMPLETE_PENDING_INDEPENDENT_REVIEW', archive=zip_pin,
                      sdkRoot=str(SDK), sdkInventory=descriptor(E / 'sdk-tree.json'),
                      sourceBeforeAfterEqual=True, sdkFileEntries=len(rows), archiveRetained=True)
    except BaseException as exc:
        failure = exc; result.update(state='FAILED_PREPARATION_PRESERVED_NO_RETRY', firstError=repr(exc),
                                     archiveRetained=ZIP.exists(), partialFixtureRetained=DEST.exists())
        if before is not None and not (E / 'source-after.json').exists():
            try:
                after = snapshot_sources(); save('source-after.json', after)
                result['sourceBeforeAfterEqual'] = before == after
            except BaseException as secondary: result['secondarySourceObservationError'] = repr(secondary)
    finally:
        result.update(durationSeconds=time.monotonic() - START, stages=STAGES, spaceChecks=SPACE,
                      diskFreeNow=shutil.disk_usage('/tmp').free, script=script_pin)
        # This bounded extent was reserved before acquisition. Failure evidence
        # can replace it without allocating new blocks below the reserve.
        raw = (json.dumps(result, indent=2) + '\n').encode()
        if len(raw) > 65536: raise RuntimeError('RESERVED_RESULT_EVIDENCE_BOUND')
        offset = 0
        while offset < len(raw):
            written = os.write(result_fd, raw[offset:])
            if written <= 0: raise OSError('Result evidence short write')
            offset += written
        os.ftruncate(result_fd, len(raw)); os.fsync(result_fd); os.close(result_fd)
        print(json.dumps({'state': result['state'], 'firstError': result['firstError'], 'diskFreeNow': result['diskFreeNow']}), flush=True)
    return 0 if failure is None else 2


if __name__ == '__main__':
    raise SystemExit(main())
